;/*!node_modules/react-pdf/dist/cjs/DocumentContext.js*/
amis.define('0928cf0', function(require, exports, module, define) {

  "use strict";
  'use client';
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  exports.default = (0, react_1.createContext)(null);
  

});

;/*!node_modules/react-pdf/dist/cjs/Message.js*/
amis.define('545c5f6', function(require, exports, module, define) {

  "use strict";
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  function Message(_a) {
      var children = _a.children, type = _a.type;
      return (0, jsx_runtime_1.jsx)("div", { className: "react-pdf__message react-pdf__message--".concat(type), children: children });
  }
  exports.default = Message;
  

});

;/*!node_modules/react-pdf/dist/cjs/LinkService.js*/
amis.define('5f22bd2', function(require, exports, module, define) {

  "use strict";
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  /* Copyright 2015 Mozilla Foundation
   *
   * Licensed under the Apache License, Version 2.0 (the "License");
   * you may not use this file except in compliance with the License.
   * You may obtain a copy of the License at
   *
   *     http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing, software
   * distributed under the License is distributed on an "AS IS" BASIS,
   * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   * See the License for the specific language governing permissions and
   * limitations under the License.
   */
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var DEFAULT_LINK_REL = 'noopener noreferrer nofollow';
  var LinkService = /** @class */ (function () {
      function LinkService() {
          this.externalLinkEnabled = true;
          this.externalLinkRel = undefined;
          this.externalLinkTarget = undefined;
          this.isInPresentationMode = false;
          this.pdfDocument = undefined;
          this.pdfViewer = undefined;
      }
      LinkService.prototype.setDocument = function (pdfDocument) {
          this.pdfDocument = pdfDocument;
      };
      LinkService.prototype.setViewer = function (pdfViewer) {
          this.pdfViewer = pdfViewer;
      };
      LinkService.prototype.setExternalLinkRel = function (externalLinkRel) {
          this.externalLinkRel = externalLinkRel;
      };
      LinkService.prototype.setExternalLinkTarget = function (externalLinkTarget) {
          this.externalLinkTarget = externalLinkTarget;
      };
      LinkService.prototype.setHistory = function () {
          // Intentionally empty
      };
      Object.defineProperty(LinkService.prototype, "pagesCount", {
          get: function () {
              return this.pdfDocument ? this.pdfDocument.numPages : 0;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LinkService.prototype, "page", {
          get: function () {
              (0, tiny_invariant_1.default)(this.pdfViewer, 'PDF viewer is not initialized.');
              return this.pdfViewer.currentPageNumber || 0;
          },
          set: function (value) {
              (0, tiny_invariant_1.default)(this.pdfViewer, 'PDF viewer is not initialized.');
              this.pdfViewer.currentPageNumber = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LinkService.prototype, "rotation", {
          // eslint-disable-next-line @typescript-eslint/class-literal-property-style
          get: function () {
              return 0;
          },
          set: function (value) {
              // Intentionally empty
          },
          enumerable: false,
          configurable: true
      });
      LinkService.prototype.goToDestination = function (dest) {
          var _this = this;
          return new Promise(function (resolve) {
              (0, tiny_invariant_1.default)(_this.pdfDocument, 'PDF document not loaded.');
              (0, tiny_invariant_1.default)(dest, 'Destination is not specified.');
              if (typeof dest === 'string') {
                  _this.pdfDocument.getDestination(dest).then(resolve);
              }
              else if (Array.isArray(dest)) {
                  resolve(dest);
              }
              else {
                  dest.then(resolve);
              }
          }).then(function (explicitDest) {
              (0, tiny_invariant_1.default)(Array.isArray(explicitDest), "\"".concat(explicitDest, "\" is not a valid destination array."));
              var destRef = explicitDest[0];
              new Promise(function (resolve) {
                  (0, tiny_invariant_1.default)(_this.pdfDocument, 'PDF document not loaded.');
                  if (destRef instanceof Object) {
                      _this.pdfDocument
                          .getPageIndex(destRef)
                          .then(function (pageIndex) {
                          resolve(pageIndex);
                      })
                          .catch(function () {
                          (0, tiny_invariant_1.default)(false, "\"".concat(destRef, "\" is not a valid page reference."));
                      });
                  }
                  else if (typeof destRef === 'number') {
                      resolve(destRef);
                  }
                  else {
                      (0, tiny_invariant_1.default)(false, "\"".concat(destRef, "\" is not a valid destination reference."));
                  }
              }).then(function (pageIndex) {
                  var pageNumber = pageIndex + 1;
                  (0, tiny_invariant_1.default)(_this.pdfViewer, 'PDF viewer is not initialized.');
                  (0, tiny_invariant_1.default)(pageNumber >= 1 && pageNumber <= _this.pagesCount, "\"".concat(pageNumber, "\" is not a valid page number."));
                  _this.pdfViewer.scrollPageIntoView({
                      dest: explicitDest,
                      pageIndex: pageIndex,
                      pageNumber: pageNumber,
                  });
              });
          });
      };
      LinkService.prototype.navigateTo = function (dest) {
          this.goToDestination(dest);
      };
      LinkService.prototype.goToPage = function (pageNumber) {
          var pageIndex = pageNumber - 1;
          (0, tiny_invariant_1.default)(this.pdfViewer, 'PDF viewer is not initialized.');
          (0, tiny_invariant_1.default)(pageNumber >= 1 && pageNumber <= this.pagesCount, "\"".concat(pageNumber, "\" is not a valid page number."));
          this.pdfViewer.scrollPageIntoView({
              pageIndex: pageIndex,
              pageNumber: pageNumber,
          });
      };
      LinkService.prototype.addLinkAttributes = function (link, url, newWindow) {
          link.href = url;
          link.rel = this.externalLinkRel || DEFAULT_LINK_REL;
          link.target = newWindow ? '_blank' : this.externalLinkTarget || '';
      };
      LinkService.prototype.getDestinationHash = function () {
          return '#';
      };
      LinkService.prototype.getAnchorUrl = function () {
          return '#';
      };
      LinkService.prototype.setHash = function () {
          // Intentionally empty
      };
      LinkService.prototype.executeNamedAction = function () {
          // Intentionally empty
      };
      LinkService.prototype.cachePageRef = function () {
          // Intentionally empty
      };
      LinkService.prototype.isPageVisible = function () {
          return true;
      };
      LinkService.prototype.isPageCached = function () {
          return true;
      };
      LinkService.prototype.executeSetOCGState = function () {
          // Intentionally empty
      };
      return LinkService;
  }());
  exports.default = LinkService;
  

});

;/*!node_modules/react-pdf/dist/cjs/PasswordResponses.js*/
amis.define('5e4d83f', function(require, exports, module, define) {

  "use strict";
  // As defined in https://github.com/mozilla/pdf.js/blob/d9fac3459609a807be6506fb3441b5da4b154d14/src/shared/util.js#L371-L374
  Object.defineProperty(exports, "__esModule", { value: true });
  var PasswordResponses = {
      NEED_PASSWORD: 1,
      INCORRECT_PASSWORD: 2,
  };
  exports.default = PasswordResponses;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/utils.js*/
amis.define('53cbee3', function(require, exports, module, define) {

  "use strict";
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.loadFromFile = exports.isCancelException = exports.makePageCallback = exports.cancelRunningTask = exports.displayWorkerWarning = exports.displayCORSWarning = exports.getDevicePixelRatio = exports.dataURItoByteString = exports.isDataURI = exports.isBlob = exports.isArrayBuffer = exports.isString = exports.isProvided = exports.isDefined = exports.isLocalFileSystem = exports.isBrowser = void 0;
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  /**
   * Checks if we're running in a browser environment.
   */
  exports.isBrowser = typeof document !== 'undefined';
  /**
   * Checks whether we're running from a local file system.
   */
  exports.isLocalFileSystem = exports.isBrowser && window.location.protocol === 'file:';
  /**
   * Checks whether a variable is defined.
   *
   * @param {*} variable Variable to check
   */
  function isDefined(variable) {
      return typeof variable !== 'undefined';
  }
  exports.isDefined = isDefined;
  /**
   * Checks whether a variable is defined and not null.
   *
   * @param {*} variable Variable to check
   */
  function isProvided(variable) {
      return isDefined(variable) && variable !== null;
  }
  exports.isProvided = isProvided;
  /**
   * Checks whether a variable provided is a string.
   *
   * @param {*} variable Variable to check
   */
  function isString(variable) {
      return typeof variable === 'string';
  }
  exports.isString = isString;
  /**
   * Checks whether a variable provided is an ArrayBuffer.
   *
   * @param {*} variable Variable to check
   */
  function isArrayBuffer(variable) {
      return variable instanceof ArrayBuffer;
  }
  exports.isArrayBuffer = isArrayBuffer;
  /**
   * Checks whether a variable provided is a Blob.
   *
   * @param {*} variable Variable to check
   */
  function isBlob(variable) {
      (0, tiny_invariant_1.default)(exports.isBrowser, 'isBlob can only be used in a browser environment');
      return variable instanceof Blob;
  }
  exports.isBlob = isBlob;
  /**
   * Checks whether a variable provided is a data URI.
   *
   * @param {*} variable String to check
   */
  function isDataURI(variable) {
      return isString(variable) && /^data:/.test(variable);
  }
  exports.isDataURI = isDataURI;
  function dataURItoByteString(dataURI) {
      (0, tiny_invariant_1.default)(isDataURI(dataURI), 'Invalid data URI.');
      var _a = dataURI.split(','), _b = _a[0], headersString = _b === void 0 ? '' : _b, _c = _a[1], dataString = _c === void 0 ? '' : _c;
      var headers = headersString.split(';');
      if (headers.indexOf('base64') !== -1) {
          return atob(dataString);
      }
      return unescape(dataString);
  }
  exports.dataURItoByteString = dataURItoByteString;
  function getDevicePixelRatio() {
      return (exports.isBrowser && window.devicePixelRatio) || 1;
  }
  exports.getDevicePixelRatio = getDevicePixelRatio;
  var allowFileAccessFromFilesTip = 'On Chromium based browsers, you can use --allow-file-access-from-files flag for debugging purposes.';
  function displayCORSWarning() {
      (0, warning_1.default)(!exports.isLocalFileSystem, "Loading PDF as base64 strings/URLs may not work on protocols other than HTTP/HTTPS. ".concat(allowFileAccessFromFilesTip));
  }
  exports.displayCORSWarning = displayCORSWarning;
  function displayWorkerWarning() {
      (0, warning_1.default)(!exports.isLocalFileSystem, "Loading PDF.js worker may not work on protocols other than HTTP/HTTPS. ".concat(allowFileAccessFromFilesTip));
  }
  exports.displayWorkerWarning = displayWorkerWarning;
  function cancelRunningTask(runningTask) {
      if (runningTask && runningTask.cancel)
          runningTask.cancel();
  }
  exports.cancelRunningTask = cancelRunningTask;
  function makePageCallback(page, scale) {
      Object.defineProperty(page, 'width', {
          get: function () {
              return this.view[2] * scale;
          },
          configurable: true,
      });
      Object.defineProperty(page, 'height', {
          get: function () {
              return this.view[3] * scale;
          },
          configurable: true,
      });
      Object.defineProperty(page, 'originalWidth', {
          get: function () {
              return this.view[2];
          },
          configurable: true,
      });
      Object.defineProperty(page, 'originalHeight', {
          get: function () {
              return this.view[3];
          },
          configurable: true,
      });
      return page;
  }
  exports.makePageCallback = makePageCallback;
  function isCancelException(error) {
      return error.name === 'RenderingCancelledException';
  }
  exports.isCancelException = isCancelException;
  function loadFromFile(file) {
      return new Promise(function (resolve, reject) {
          var reader = new FileReader();
          reader.onload = function () {
              if (!reader.result) {
                  return reject(new Error('Error while reading a file.'));
              }
              resolve(reader.result);
          };
          reader.onerror = function (event) {
              if (!event.target) {
                  return reject(new Error('Error while reading a file.'));
              }
              var error = event.target.error;
              if (!error) {
                  return reject(new Error('Error while reading a file.'));
              }
              switch (error.code) {
                  case error.NOT_FOUND_ERR:
                      return reject(new Error('Error while reading a file: File not found.'));
                  case error.SECURITY_ERR:
                      return reject(new Error('Error while reading a file: Security error.'));
                  case error.ABORT_ERR:
                      return reject(new Error('Error while reading a file: Aborted.'));
                  default:
                      return reject(new Error('Error while reading a file.'));
              }
          };
          reader.readAsArrayBuffer(file);
      });
  }
  exports.loadFromFile = loadFromFile;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/hooks/useResolver.js*/
amis.define('e049f4f', function(require, exports, module, define) {

  "use strict";
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  function reducer(state, action) {
      switch (action.type) {
          case 'RESOLVE':
              return { value: action.value, error: undefined };
          case 'REJECT':
              return { value: false, error: action.error };
          case 'RESET':
              return { value: undefined, error: undefined };
          default:
              return state;
      }
  }
  function useResolver() {
      return (0, react_1.useReducer)((reducer), { value: undefined, error: undefined });
  }
  exports.default = useResolver;
  

});

;/*!node_modules/react-pdf/dist/cjs/Document.js*/
amis.define('3cac0a2', function(require, exports, module, define) {

  "use strict";
  'use client';
  var tslib_1 = require("a5c5bc6");
  var __createBinding = (this && this.__createBinding) || (Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function () { return m[k]; } };
      }
      Object.defineProperty(o, k2, desc);
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  }));
  var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  });
  var __importStar = (this && this.__importStar) || function (mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k in mod)
              if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                  __createBinding(result, mod, k);
      __setModuleDefault(result, mod);
      return result;
  };
  var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
      function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
      return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) { try {
              step(generator.next(value));
          }
          catch (e) {
              reject(e);
          } }
          function rejected(value) { try {
              step(generator["throw"](value));
          }
          catch (e) {
              reject(e);
          } }
          function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
  };
  var __rest = (this && this.__rest) || function (s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var make_event_props_1 = __importDefault(require("1728961"));
  var make_cancellable_promise_1 = __importDefault(require("f2505c7"));
  var clsx_1 = __importDefault(require("5c50c18"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var dequal_1 = require("3c0affb");
  var pdfjs = __importStar(require("node_modules/pdfjs-dist/build/pdf.mjs"));
  var DocumentContext_js_1 = __importDefault(require("0928cf0"));
  var Message_js_1 = __importDefault(require("545c5f6"));
  var LinkService_js_1 = __importDefault(require("5f22bd2"));
  var PasswordResponses_js_1 = __importDefault(require("5e4d83f"));
  var utils_js_1 = require("53cbee3");
  var useResolver_js_1 = __importDefault(require("e049f4f"));
  var PDFDataRangeTransport = pdfjs.PDFDataRangeTransport;
  var defaultOnPassword = function (callback, reason) {
      switch (reason) {
          case PasswordResponses_js_1.default.NEED_PASSWORD: {
              // eslint-disable-next-line no-alert
              var password = prompt('Enter the password to open this PDF file.');
              callback(password);
              break;
          }
          case PasswordResponses_js_1.default.INCORRECT_PASSWORD: {
              // eslint-disable-next-line no-alert
              var password = prompt('Invalid password. Please try again.');
              callback(password);
              break;
          }
          default:
      }
  };
  function isParameterObject(file) {
      return (typeof file === 'object' &&
          file !== null &&
          ('data' in file || 'range' in file || 'url' in file));
  }
  /**
   * Loads a document passed using `file` prop.
   */
  var Document = (0, react_1.forwardRef)(function Document(_a, ref) {
      var _b;
      var _this = this;
      var children = _a.children, className = _a.className, _c = _a.error, error = _c === void 0 ? 'Failed to load PDF file.' : _c, externalLinkRel = _a.externalLinkRel, externalLinkTarget = _a.externalLinkTarget, file = _a.file, inputRef = _a.inputRef, imageResourcesPath = _a.imageResourcesPath, _d = _a.loading, loading = _d === void 0 ? 'Loading PDF…' : _d, _e = _a.noData, noData = _e === void 0 ? 'No PDF file specified.' : _e, onItemClick = _a.onItemClick, onLoadErrorProps = _a.onLoadError, onLoadProgress = _a.onLoadProgress, onLoadSuccessProps = _a.onLoadSuccess, _f = _a.onPassword, onPassword = _f === void 0 ? defaultOnPassword : _f, onSourceErrorProps = _a.onSourceError, onSourceSuccessProps = _a.onSourceSuccess, options = _a.options, renderMode = _a.renderMode, rotate = _a.rotate, otherProps = __rest(_a, ["children", "className", "error", "externalLinkRel", "externalLinkTarget", "file", "inputRef", "imageResourcesPath", "loading", "noData", "onItemClick", "onLoadError", "onLoadProgress", "onLoadSuccess", "onPassword", "onSourceError", "onSourceSuccess", "options", "renderMode", "rotate"]);
      var _g = (0, useResolver_js_1.default)(), sourceState = _g[0], sourceDispatch = _g[1];
      var source = sourceState.value, sourceError = sourceState.error;
      var _h = (0, useResolver_js_1.default)(), pdfState = _h[0], pdfDispatch = _h[1];
      var pdf = pdfState.value, pdfError = pdfState.error;
      var linkService = (0, react_1.useRef)(new LinkService_js_1.default());
      var pages = (0, react_1.useRef)([]);
      var prevFile = (0, react_1.useRef)(undefined);
      var prevOptions = (0, react_1.useRef)(undefined);
      if (file && file !== prevFile.current && isParameterObject(file)) {
          (0, warning_1.default)(!(0, dequal_1.dequal)(file, prevFile.current), "File prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to \"file\" prop.");
          prevFile.current = file;
      }
      // Detect non-memoized changes in options prop
      if (options && options !== prevOptions.current) {
          (0, warning_1.default)(!(0, dequal_1.dequal)(options, prevOptions.current), "Options prop passed to <Document /> changed, but it's equal to previous one. This might result in unnecessary reloads. Consider memoizing the value passed to \"options\" prop.");
          prevOptions.current = options;
      }
      var viewer = (0, react_1.useRef)({
          // Handling jumping to internal links target
          scrollPageIntoView: function (args) {
              var dest = args.dest, pageNumber = args.pageNumber, _b = args.pageIndex, pageIndex = _b === void 0 ? pageNumber - 1 : _b;
              // First, check if custom handling of onItemClick was provided
              if (onItemClick) {
                  onItemClick({ dest: dest, pageIndex: pageIndex, pageNumber: pageNumber });
                  return;
              }
              // If not, try to look for target page within the <Document>.
              var page = pages.current[pageIndex];
              if (page) {
                  // Scroll to the page automatically
                  page.scrollIntoView();
                  return;
              }
              (0, warning_1.default)(false, "An internal link leading to page ".concat(pageNumber, " was clicked, but neither <Document> was provided with onItemClick nor it was able to find the page within itself. Either provide onItemClick to <Document> and handle navigating by yourself or ensure that all pages are rendered within <Document>."));
          },
      });
      (0, react_1.useImperativeHandle)(ref, function () { return ({
          linkService: linkService,
          pages: pages,
          viewer: viewer,
      }); }, []);
      /**
       * Called when a document source is resolved correctly
       */
      function onSourceSuccess() {
          if (onSourceSuccessProps) {
              onSourceSuccessProps();
          }
      }
      /**
       * Called when a document source failed to be resolved correctly
       */
      function onSourceError() {
          if (!sourceError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, sourceError.toString());
          if (onSourceErrorProps) {
              onSourceErrorProps(sourceError);
          }
      }
      function resetSource() {
          sourceDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetSource, [file, sourceDispatch]);
      var findDocumentSource = (0, react_1.useCallback)(function () { return __awaiter(_this, void 0, void 0, function () {
          var fileByteString, data, url, otherParams, fileByteString;
          return tslib_1.__generator(this, function (_b) {
              switch (_b.label) {
                  case 0:
                      if (!file) {
                          return [2 /*return*/, null];
                      }
                      // File is a string
                      if (typeof file === 'string') {
                          if ((0, utils_js_1.isDataURI)(file)) {
                              fileByteString = (0, utils_js_1.dataURItoByteString)(file);
                              return [2 /*return*/, { data: fileByteString }];
                          }
                          (0, utils_js_1.displayCORSWarning)();
                          return [2 /*return*/, { url: file }];
                      }
                      // File is PDFDataRangeTransport
                      if (file instanceof PDFDataRangeTransport) {
                          return [2 /*return*/, { range: file }];
                      }
                      // File is an ArrayBuffer
                      if ((0, utils_js_1.isArrayBuffer)(file)) {
                          return [2 /*return*/, { data: file }];
                      }
                      if (!utils_js_1.isBrowser) return [3 /*break*/, 2];
                      if (!(0, utils_js_1.isBlob)(file)) return [3 /*break*/, 2];
                      return [4 /*yield*/, (0, utils_js_1.loadFromFile)(file)];
                  case 1:
                      data = _b.sent();
                      return [2 /*return*/, { data: data }];
                  case 2:
                      // At this point, file must be an object
                      (0, tiny_invariant_1.default)(typeof file === 'object', 'Invalid parameter in file, need either Uint8Array, string or a parameter object');
                      (0, tiny_invariant_1.default)(isParameterObject(file), 'Invalid parameter object: need either .data, .range or .url');
                      // File .url is a string
                      if ('url' in file && typeof file.url === 'string') {
                          if ((0, utils_js_1.isDataURI)(file.url)) {
                              url = file.url, otherParams = __rest(file, ["url"]);
                              fileByteString = (0, utils_js_1.dataURItoByteString)(url);
                              return [2 /*return*/, Object.assign({ data: fileByteString }, otherParams)];
                          }
                          (0, utils_js_1.displayCORSWarning)();
                      }
                      return [2 /*return*/, file];
              }
          });
      }); }, [file]);
      (0, react_1.useEffect)(function () {
          var cancellable = (0, make_cancellable_promise_1.default)(findDocumentSource());
          cancellable.promise
              .then(function (nextSource) {
              sourceDispatch({ type: 'RESOLVE', value: nextSource });
          })
              .catch(function (error) {
              sourceDispatch({ type: 'REJECT', error: error });
          });
          return function () {
              (0, utils_js_1.cancelRunningTask)(cancellable);
          };
      }, [findDocumentSource, sourceDispatch]);
      (0, react_1.useEffect)(function () {
          if (typeof source === 'undefined') {
              return;
          }
          if (source === false) {
              onSourceError();
              return;
          }
          onSourceSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [source]);
      /**
       * Called when a document is read successfully
       */
      function onLoadSuccess() {
          if (!pdf) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          if (onLoadSuccessProps) {
              onLoadSuccessProps(pdf);
          }
          pages.current = new Array(pdf.numPages);
          linkService.current.setDocument(pdf);
      }
      /**
       * Called when a document failed to read successfully
       */
      function onLoadError() {
          if (!pdfError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, pdfError.toString());
          if (onLoadErrorProps) {
              onLoadErrorProps(pdfError);
          }
      }
      function resetDocument() {
          pdfDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetDocument, [pdfDispatch, source]);
      function loadDocument() {
          if (!source) {
              return;
          }
          var documentInitParams = Object.assign(Object.assign({}, source), options);
          var destroyable = pdfjs.getDocument(documentInitParams);
          if (onLoadProgress) {
              destroyable.onProgress = onLoadProgress;
          }
          if (onPassword) {
              destroyable.onPassword = onPassword;
          }
          var loadingTask = destroyable;
          loadingTask.promise
              .then(function (nextPdf) {
              pdfDispatch({ type: 'RESOLVE', value: nextPdf });
          })
              .catch(function (error) {
              if (loadingTask.destroyed) {
                  return;
              }
              pdfDispatch({ type: 'REJECT', error: error });
          });
          return function () {
              loadingTask.destroy();
          };
      }
      (0, react_1.useEffect)(loadDocument, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [options, pdfDispatch, source]);
      (0, react_1.useEffect)(function () {
          if (typeof pdf === 'undefined') {
              return;
          }
          if (pdf === false) {
              onLoadError();
              return;
          }
          onLoadSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [pdf]);
      function setupLinkService() {
          linkService.current.setViewer(viewer.current);
          linkService.current.setExternalLinkRel(externalLinkRel);
          linkService.current.setExternalLinkTarget(externalLinkTarget);
      }
      (0, react_1.useEffect)(setupLinkService, [externalLinkRel, externalLinkTarget]);
      function registerPage(pageIndex, ref) {
          pages.current[pageIndex] = ref;
      }
      function unregisterPage(pageIndex) {
          delete pages.current[pageIndex];
      }
      var childContext = (0, react_1.useMemo)(function () { return ({
          imageResourcesPath: imageResourcesPath,
          linkService: linkService.current,
          onItemClick: onItemClick,
          pdf: pdf,
          registerPage: registerPage,
          renderMode: renderMode,
          rotate: rotate,
          unregisterPage: unregisterPage,
      }); }, [imageResourcesPath, onItemClick, pdf, renderMode, rotate]);
      var eventProps = (0, react_1.useMemo)(function () { return (0, make_event_props_1.default)(otherProps, function () { return pdf; }); }, [otherProps, pdf]);
      function renderChildren() {
          return (0, jsx_runtime_1.jsx)(DocumentContext_js_1.default.Provider, { value: childContext, children: children });
      }
      function renderContent() {
          if (!file) {
              return (0, jsx_runtime_1.jsx)(Message_js_1.default, { type: "no-data", children: typeof noData === 'function' ? noData() : noData });
          }
          if (pdf === undefined || pdf === null) {
              return ((0, jsx_runtime_1.jsx)(Message_js_1.default, { type: "loading", children: typeof loading === 'function' ? loading() : loading }));
          }
          if (pdf === false) {
              return (0, jsx_runtime_1.jsx)(Message_js_1.default, { type: "error", children: typeof error === 'function' ? error() : error });
          }
          return renderChildren();
      }
      return ((0, jsx_runtime_1.jsx)("div", Object.assign({ className: (0, clsx_1.default)('react-pdf__Document', className),
          // Assertion is needed for React 18 compatibility
          ref: inputRef, style: (_b = {},
              _b['--scale-factor'] = '1',
              _b) }, eventProps, { children: renderContent() })));
  });
  exports.default = Document;
  

});

;/*!node_modules/react-pdf/dist/cjs/OutlineContext.js*/
amis.define('cef9ea6', function(require, exports, module, define) {

  "use strict";
  'use client';
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  exports.default = (0, react_1.createContext)(null);
  

});

;/*!node_modules/react-pdf/dist/cjs/Ref.js*/
amis.define('6a90b07', function(require, exports, module, define) {

  "use strict";
  Object.defineProperty(exports, "__esModule", { value: true });
  var Ref = /** @class */ (function () {
      function Ref(_a) {
          var num = _a.num, gen = _a.gen;
          this.num = num;
          this.gen = gen;
      }
      Ref.prototype.toString = function () {
          var str = "".concat(this.num, "R");
          if (this.gen !== 0) {
              str += this.gen;
          }
          return str;
      };
      return Ref;
  }());
  exports.default = Ref;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/hooks/useCachedValue.js*/
amis.define('7ccc429', function(require, exports, module, define) {

  "use strict";
  'use client';
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  var utils_js_1 = require("53cbee3");
  function useCachedValue(getter) {
      var ref = (0, react_1.useRef)(undefined);
      var currentValue = ref.current;
      if ((0, utils_js_1.isDefined)(currentValue)) {
          return function () { return currentValue; };
      }
      return function () {
          var value = getter();
          ref.current = value;
          return value;
      };
  }
  exports.default = useCachedValue;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/hooks/useDocumentContext.js*/
amis.define('adc95b7', function(require, exports, module, define) {

  "use strict";
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  var DocumentContext_js_1 = __importDefault(require("0928cf0"));
  function useDocumentContext() {
      return (0, react_1.useContext)(DocumentContext_js_1.default);
  }
  exports.default = useDocumentContext;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/hooks/useOutlineContext.js*/
amis.define('22cedd7', function(require, exports, module, define) {

  "use strict";
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  var OutlineContext_js_1 = __importDefault(require("cef9ea6"));
  function useOutlineContext() {
      return (0, react_1.useContext)(OutlineContext_js_1.default);
  }
  exports.default = useOutlineContext;
  

});

;/*!node_modules/react-pdf/dist/cjs/OutlineItem.js*/
amis.define('642f26d', function(require, exports, module, define) {

  "use strict";
  var tslib_1 = require("a5c5bc6");
  var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
      function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
      return new (P || (P = Promise))(function (resolve, reject) {
          function fulfilled(value) { try {
              step(generator.next(value));
          }
          catch (e) {
              reject(e);
          } }
          function rejected(value) { try {
              step(generator["throw"](value));
          }
          catch (e) {
              reject(e);
          } }
          function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
          step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
  };
  var __rest = (this && this.__rest) || function (s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var Ref_js_1 = __importDefault(require("6a90b07"));
  var useCachedValue_js_1 = __importDefault(require("7ccc429"));
  var useDocumentContext_js_1 = __importDefault(require("adc95b7"));
  var useOutlineContext_js_1 = __importDefault(require("22cedd7"));
  function OutlineItem(props) {
      var _this = this;
      var documentContext = (0, useDocumentContext_js_1.default)();
      var outlineContext = (0, useOutlineContext_js_1.default)();
      (0, tiny_invariant_1.default)(outlineContext, 'Unable to find Outline context.');
      var mergedProps = Object.assign(Object.assign(Object.assign({}, documentContext), outlineContext), props);
      var item = mergedProps.item, linkService = mergedProps.linkService, onItemClick = mergedProps.onItemClick, pdf = mergedProps.pdf, otherProps = __rest(mergedProps, ["item", "linkService", "onItemClick", "pdf"]);
      (0, tiny_invariant_1.default)(pdf, 'Attempted to load an outline, but no document was specified. Wrap <Outline /> in a <Document /> or pass explicit `pdf` prop.');
      var getDestination = (0, useCachedValue_js_1.default)(function () {
          if (typeof item.dest === 'string') {
              return pdf.getDestination(item.dest);
          }
          return item.dest;
      });
      var getPageIndex = (0, useCachedValue_js_1.default)(function () { return __awaiter(_this, void 0, void 0, function () {
          var destination, ref;
          return tslib_1.__generator(this, function (_a) {
              switch (_a.label) {
                  case 0: return [4 /*yield*/, getDestination()];
                  case 1:
                      destination = _a.sent();
                      if (!destination) {
                          throw new Error('Destination not found.');
                      }
                      ref = destination[0];
                      return [2 /*return*/, pdf.getPageIndex(new Ref_js_1.default(ref))];
              }
          });
      }); });
      var getPageNumber = (0, useCachedValue_js_1.default)(function () { return __awaiter(_this, void 0, void 0, function () {
          var pageIndex;
          return tslib_1.__generator(this, function (_a) {
              switch (_a.label) {
                  case 0: return [4 /*yield*/, getPageIndex()];
                  case 1:
                      pageIndex = _a.sent();
                      return [2 /*return*/, pageIndex + 1];
              }
          });
      }); });
      function onClick(event) {
          event.preventDefault();
          (0, tiny_invariant_1.default)(onItemClick || linkService, 'Either onItemClick callback or linkService must be defined in order to navigate to an outline item.');
          if (onItemClick) {
              Promise.all([getDestination(), getPageIndex(), getPageNumber()]).then(function (_a) {
                  var dest = _a[0], pageIndex = _a[1], pageNumber = _a[2];
                  onItemClick({
                      dest: dest,
                      pageIndex: pageIndex,
                      pageNumber: pageNumber,
                  });
              });
          }
          else if (linkService) {
              linkService.goToDestination(item.dest);
          }
      }
      function renderSubitems() {
          if (!item.items || !item.items.length) {
              return null;
          }
          var subitems = item.items;
          return ((0, jsx_runtime_1.jsx)("ul", { children: subitems.map(function (subitem, subitemIndex) { return ((0, jsx_runtime_1.jsx)(OutlineItem, Object.assign({ item: subitem, pdf: pdf }, otherProps), typeof subitem.dest === 'string' ? subitem.dest : subitemIndex)); }) }));
      }
      return ((0, jsx_runtime_1.jsxs)("li", { children: [(0, jsx_runtime_1.jsx)("a", { href: "#", onClick: onClick, children: item.title }), renderSubitems()] }));
  }
  exports.default = OutlineItem;
  

});

;/*!node_modules/react-pdf/dist/cjs/Outline.js*/
amis.define('3c3b2bb', function(require, exports, module, define) {

  "use strict";
  'use client';
  var __rest = (this && this.__rest) || function (s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var make_cancellable_promise_1 = __importDefault(require("f2505c7"));
  var make_event_props_1 = __importDefault(require("1728961"));
  var clsx_1 = __importDefault(require("5c50c18"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var OutlineContext_js_1 = __importDefault(require("cef9ea6"));
  var OutlineItem_js_1 = __importDefault(require("642f26d"));
  var utils_js_1 = require("53cbee3");
  var useDocumentContext_js_1 = __importDefault(require("adc95b7"));
  var useResolver_js_1 = __importDefault(require("e049f4f"));
  /**
   * Displays an outline (table of contents).
   *
   * Should be placed inside `<Document />`. Alternatively, it can have `pdf` prop passed, which can be obtained from `<Document />`'s `onLoadSuccess` callback function.
   */
  function Outline(props) {
      var documentContext = (0, useDocumentContext_js_1.default)();
      var mergedProps = Object.assign(Object.assign({}, documentContext), props);
      var className = mergedProps.className, inputRef = mergedProps.inputRef, onItemClick = mergedProps.onItemClick, onLoadErrorProps = mergedProps.onLoadError, onLoadSuccessProps = mergedProps.onLoadSuccess, pdf = mergedProps.pdf, otherProps = __rest(mergedProps, ["className", "inputRef", "onItemClick", "onLoadError", "onLoadSuccess", "pdf"]);
      (0, tiny_invariant_1.default)(pdf, 'Attempted to load an outline, but no document was specified. Wrap <Outline /> in a <Document /> or pass explicit `pdf` prop.');
      var _a = (0, useResolver_js_1.default)(), outlineState = _a[0], outlineDispatch = _a[1];
      var outline = outlineState.value, outlineError = outlineState.error;
      /**
       * Called when an outline is read successfully
       */
      function onLoadSuccess() {
          if (typeof outline === 'undefined' || outline === false) {
              return;
          }
          if (onLoadSuccessProps) {
              onLoadSuccessProps(outline);
          }
      }
      /**
       * Called when an outline failed to read successfully
       */
      function onLoadError() {
          if (!outlineError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, outlineError.toString());
          if (onLoadErrorProps) {
              onLoadErrorProps(outlineError);
          }
      }
      function resetOutline() {
          outlineDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetOutline, [outlineDispatch, pdf]);
      function loadOutline() {
          if (!pdf) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          var cancellable = (0, make_cancellable_promise_1.default)(pdf.getOutline());
          var runningTask = cancellable;
          cancellable.promise
              .then(function (nextOutline) {
              outlineDispatch({ type: 'RESOLVE', value: nextOutline });
          })
              .catch(function (error) {
              outlineDispatch({ type: 'REJECT', error: error });
          });
          return function () { return (0, utils_js_1.cancelRunningTask)(runningTask); };
      }
      (0, react_1.useEffect)(loadOutline, [outlineDispatch, pdf]);
      (0, react_1.useEffect)(function () {
          if (outline === undefined) {
              return;
          }
          if (outline === false) {
              onLoadError();
              return;
          }
          onLoadSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [outline]);
      var childContext = (0, react_1.useMemo)(function () { return ({
          onItemClick: onItemClick,
      }); }, [onItemClick]);
      var eventProps = (0, react_1.useMemo)(function () { return (0, make_event_props_1.default)(otherProps, function () { return outline; }); }, [otherProps, outline]);
      if (!outline) {
          return null;
      }
      function renderOutline() {
          if (!outline) {
              return null;
          }
          return ((0, jsx_runtime_1.jsx)("ul", { children: outline.map(function (item, itemIndex) { return ((0, jsx_runtime_1.jsx)(OutlineItem_js_1.default, { item: item, pdf: pdf }, typeof item.dest === 'string' ? item.dest : itemIndex)); }) }));
      }
      return ((0, jsx_runtime_1.jsx)("div", Object.assign({ className: (0, clsx_1.default)('react-pdf__Outline', className), ref: inputRef }, eventProps, { children: (0, jsx_runtime_1.jsx)(OutlineContext_js_1.default.Provider, { value: childContext, children: renderOutline() }) })));
  }
  exports.default = Outline;
  

});

;/*!node_modules/react-pdf/dist/cjs/PageContext.js*/
amis.define('ec75848', function(require, exports, module, define) {

  "use strict";
  'use client';
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  exports.default = (0, react_1.createContext)(null);
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/constants.js*/
amis.define('efb8b77', function(require, exports, module, define) {

  "use strict";
  // From pdfjs-dist/lib/web/struct_tree_layer_builder.js
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.HEADING_PATTERN = exports.PDF_ROLE_TO_HTML_ROLE = void 0;
  exports.PDF_ROLE_TO_HTML_ROLE = {
      // Document level structure types
      Document: null, // There's a "document" role, but it doesn't make sense here.
      DocumentFragment: null,
      // Grouping level structure types
      Part: 'group',
      Sect: 'group', // XXX: There's a "section" role, but it's abstract.
      Div: 'group',
      Aside: 'note',
      NonStruct: 'none',
      // Block level structure types
      P: null,
      // H<n>,
      H: 'heading',
      Title: null,
      FENote: 'note',
      // Sub-block level structure type
      Sub: 'group',
      // General inline level structure types
      Lbl: null,
      Span: null,
      Em: null,
      Strong: null,
      Link: 'link',
      Annot: 'note',
      Form: 'form',
      // Ruby and Warichu structure types
      Ruby: null,
      RB: null,
      RT: null,
      RP: null,
      Warichu: null,
      WT: null,
      WP: null,
      // List standard structure types
      L: 'list',
      LI: 'listitem',
      LBody: null,
      // Table standard structure types
      Table: 'table',
      TR: 'row',
      TH: 'columnheader',
      TD: 'cell',
      THead: 'columnheader',
      TBody: null,
      TFoot: null,
      // Standard structure type Caption
      Caption: null,
      // Standard structure type Figure
      Figure: 'figure',
      // Standard structure type Formula
      Formula: null,
      // standard structure type Artifact
      Artifact: null,
  };
  exports.HEADING_PATTERN = /^H(\d+)$/;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/structTreeUtils.js*/
amis.define('0772fe8', function(require, exports, module, define) {

  "use strict";
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.getAttributes = exports.getBaseAttributes = exports.getRoleAttributes = exports.isStructTreeNodeWithOnlyContentChild = exports.isStructTreeNode = exports.isPdfRole = void 0;
  var constants_js_1 = require("efb8b77");
  function isPdfRole(role) {
      return role in constants_js_1.PDF_ROLE_TO_HTML_ROLE;
  }
  exports.isPdfRole = isPdfRole;
  function isStructTreeNode(node) {
      return 'children' in node;
  }
  exports.isStructTreeNode = isStructTreeNode;
  function isStructTreeNodeWithOnlyContentChild(node) {
      if (!isStructTreeNode(node)) {
          return false;
      }
      return node.children.length === 1 && 0 in node.children && 'id' in node.children[0];
  }
  exports.isStructTreeNodeWithOnlyContentChild = isStructTreeNodeWithOnlyContentChild;
  function getRoleAttributes(node) {
      var attributes = {};
      if (isStructTreeNode(node)) {
          var role = node.role;
          var matches = role.match(constants_js_1.HEADING_PATTERN);
          if (matches) {
              attributes.role = 'heading';
              attributes['aria-level'] = Number(matches[1]);
          }
          else if (isPdfRole(role)) {
              var htmlRole = constants_js_1.PDF_ROLE_TO_HTML_ROLE[role];
              if (htmlRole) {
                  attributes.role = htmlRole;
              }
          }
      }
      return attributes;
  }
  exports.getRoleAttributes = getRoleAttributes;
  function getBaseAttributes(node) {
      var attributes = {};
      if (isStructTreeNode(node)) {
          if (node.alt !== undefined) {
              attributes['aria-label'] = node.alt;
          }
          if (node.lang !== undefined) {
              attributes.lang = node.lang;
          }
          if (isStructTreeNodeWithOnlyContentChild(node)) {
              var child = node.children[0];
              if (child) {
                  var childAttributes = getBaseAttributes(child);
                  return Object.assign(Object.assign({}, attributes), childAttributes);
              }
          }
      }
      else {
          if ('id' in node) {
              attributes['aria-owns'] = node.id;
          }
      }
      return attributes;
  }
  exports.getBaseAttributes = getBaseAttributes;
  function getAttributes(node) {
      if (!node) {
          return null;
      }
      return Object.assign(Object.assign({}, getRoleAttributes(node)), getBaseAttributes(node));
  }
  exports.getAttributes = getAttributes;
  

});

;/*!node_modules/react-pdf/dist/cjs/StructTreeItem.js*/
amis.define('55d2f92', function(require, exports, module, define) {

  "use strict";
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var structTreeUtils_js_1 = require("0772fe8");
  function StructTreeItem(_a) {
      var className = _a.className, node = _a.node;
      var attributes = (0, react_1.useMemo)(function () { return (0, structTreeUtils_js_1.getAttributes)(node); }, [node]);
      var children = (0, react_1.useMemo)(function () {
          if (!(0, structTreeUtils_js_1.isStructTreeNode)(node)) {
              return null;
          }
          if ((0, structTreeUtils_js_1.isStructTreeNodeWithOnlyContentChild)(node)) {
              return null;
          }
          return node.children.map(function (child, index) {
              return (
              // eslint-disable-next-line react/no-array-index-key
              (0, jsx_runtime_1.jsx)(StructTreeItem, { node: child }, index));
          });
      }, [node]);
      return ((0, jsx_runtime_1.jsx)("span", Object.assign({ className: className }, attributes, { children: children })));
  }
  exports.default = StructTreeItem;
  

});

;/*!node_modules/react-pdf/dist/cjs/shared/hooks/usePageContext.js*/
amis.define('9fdce60', function(require, exports, module, define) {

  "use strict";
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var react_1 = require("547621d");
  var PageContext_js_1 = __importDefault(require("ec75848"));
  function usePageContext() {
      return (0, react_1.useContext)(PageContext_js_1.default);
  }
  exports.default = usePageContext;
  

});

;/*!node_modules/react-pdf/dist/cjs/StructTree.js*/
amis.define('ab25816', function(require, exports, module, define) {

  "use strict";
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var make_cancellable_promise_1 = __importDefault(require("f2505c7"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var StructTreeItem_js_1 = __importDefault(require("55d2f92"));
  var usePageContext_js_1 = __importDefault(require("9fdce60"));
  var useResolver_js_1 = __importDefault(require("e049f4f"));
  var utils_js_1 = require("53cbee3");
  function StructTree() {
      var pageContext = (0, usePageContext_js_1.default)();
      (0, tiny_invariant_1.default)(pageContext, 'Unable to find Page context.');
      var onGetStructTreeErrorProps = pageContext.onGetStructTreeError, onGetStructTreeSuccessProps = pageContext.onGetStructTreeSuccess;
      var _a = (0, useResolver_js_1.default)(), structTreeState = _a[0], structTreeDispatch = _a[1];
      var structTree = structTreeState.value, structTreeError = structTreeState.error;
      var customTextRenderer = pageContext.customTextRenderer, page = pageContext.page;
      function onLoadSuccess() {
          if (!structTree) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          if (onGetStructTreeSuccessProps) {
              onGetStructTreeSuccessProps(structTree);
          }
      }
      function onLoadError() {
          if (!structTreeError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, structTreeError.toString());
          if (onGetStructTreeErrorProps) {
              onGetStructTreeErrorProps(structTreeError);
          }
      }
      function resetAnnotations() {
          structTreeDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetAnnotations, [structTreeDispatch, page]);
      function loadStructTree() {
          if (customTextRenderer) {
              // TODO: Document why this is necessary
              return;
          }
          if (!page) {
              return;
          }
          var cancellable = (0, make_cancellable_promise_1.default)(page.getStructTree());
          var runningTask = cancellable;
          cancellable.promise
              .then(function (nextStructTree) {
              structTreeDispatch({ type: 'RESOLVE', value: nextStructTree });
          })
              .catch(function (error) {
              structTreeDispatch({ type: 'REJECT', error: error });
          });
          return function () { return (0, utils_js_1.cancelRunningTask)(runningTask); };
      }
      (0, react_1.useEffect)(loadStructTree, [customTextRenderer, page, structTreeDispatch]);
      (0, react_1.useEffect)(function () {
          if (structTree === undefined) {
              return;
          }
          if (structTree === false) {
              onLoadError();
              return;
          }
          onLoadSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [structTree]);
      if (!structTree) {
          return null;
      }
      return (0, jsx_runtime_1.jsx)(StructTreeItem_js_1.default, { className: "react-pdf__Page__structTree structTree", node: structTree });
  }
  exports.default = StructTree;
  

});

;/*!node_modules/react-pdf/dist/cjs/Page/Canvas.js*/
amis.define('d600fe5', function(require, exports, module, define) {

  "use strict";
  'use client';
  var __createBinding = (this && this.__createBinding) || (Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function () { return m[k]; } };
      }
      Object.defineProperty(o, k2, desc);
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  }));
  var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  });
  var __importStar = (this && this.__importStar) || function (mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k in mod)
              if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                  __createBinding(result, mod, k);
      __setModuleDefault(result, mod);
      return result;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var merge_refs_1 = __importDefault(require("563dbc1"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var pdfjs = __importStar(require("node_modules/pdfjs-dist/build/pdf.mjs"));
  var StructTree_js_1 = __importDefault(require("ab25816"));
  var usePageContext_js_1 = __importDefault(require("9fdce60"));
  var utils_js_1 = require("53cbee3");
  var ANNOTATION_MODE = pdfjs.AnnotationMode;
  function Canvas(props) {
      var pageContext = (0, usePageContext_js_1.default)();
      (0, tiny_invariant_1.default)(pageContext, 'Unable to find Page context.');
      var mergedProps = Object.assign(Object.assign({}, pageContext), props);
      var _className = mergedProps._className, canvasBackground = mergedProps.canvasBackground, _a = mergedProps.devicePixelRatio, devicePixelRatio = _a === void 0 ? (0, utils_js_1.getDevicePixelRatio)() : _a, onRenderErrorProps = mergedProps.onRenderError, onRenderSuccessProps = mergedProps.onRenderSuccess, page = mergedProps.page, renderForms = mergedProps.renderForms, renderTextLayer = mergedProps.renderTextLayer, rotate = mergedProps.rotate, scale = mergedProps.scale;
      var canvasRef = props.canvasRef;
      (0, tiny_invariant_1.default)(page, 'Attempted to render page canvas, but no page was specified.');
      var canvasElement = (0, react_1.useRef)(null);
      /**
       * Called when a page is rendered successfully.
       */
      function onRenderSuccess() {
          if (!page) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          if (onRenderSuccessProps) {
              onRenderSuccessProps((0, utils_js_1.makePageCallback)(page, scale));
          }
      }
      /**
       * Called when a page fails to render.
       */
      function onRenderError(error) {
          if ((0, utils_js_1.isCancelException)(error)) {
              return;
          }
          (0, warning_1.default)(false, error.toString());
          if (onRenderErrorProps) {
              onRenderErrorProps(error);
          }
      }
      var renderViewport = (0, react_1.useMemo)(function () { return page.getViewport({ scale: scale * devicePixelRatio, rotation: rotate }); }, [devicePixelRatio, page, rotate, scale]);
      var viewport = (0, react_1.useMemo)(function () { return page.getViewport({ scale: scale, rotation: rotate }); }, [page, rotate, scale]);
      function drawPageOnCanvas() {
          if (!page) {
              return;
          }
          // Ensures the canvas will be re-rendered from scratch. Otherwise all form data will stay.
          page.cleanup();
          var canvas = canvasElement.current;
          if (!canvas) {
              return;
          }
          canvas.width = renderViewport.width;
          canvas.height = renderViewport.height;
          canvas.style.width = "".concat(Math.floor(viewport.width), "px");
          canvas.style.height = "".concat(Math.floor(viewport.height), "px");
          canvas.style.visibility = 'hidden';
          var renderContext = {
              annotationMode: renderForms ? ANNOTATION_MODE.ENABLE_FORMS : ANNOTATION_MODE.ENABLE,
              canvasContext: canvas.getContext('2d', { alpha: false }),
              viewport: renderViewport,
          };
          if (canvasBackground) {
              renderContext.background = canvasBackground;
          }
          var cancellable = page.render(renderContext);
          var runningTask = cancellable;
          cancellable.promise
              .then(function () {
              canvas.style.visibility = '';
              onRenderSuccess();
          })
              .catch(onRenderError);
          return function () { return (0, utils_js_1.cancelRunningTask)(runningTask); };
      }
      (0, react_1.useEffect)(drawPageOnCanvas, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [
          canvasBackground,
          canvasElement,
          devicePixelRatio,
          page,
          renderForms,
          renderViewport,
          viewport,
      ]);
      var cleanup = (0, react_1.useCallback)(function () {
          var canvas = canvasElement.current;
          /**
           * Zeroing the width and height cause most browsers to release graphics
           * resources immediately, which can greatly reduce memory consumption.
           */
          if (canvas) {
              canvas.width = 0;
              canvas.height = 0;
          }
      }, [canvasElement]);
      (0, react_1.useEffect)(function () { return cleanup; }, [cleanup]);
      return ((0, jsx_runtime_1.jsx)("canvas", { className: "".concat(_className, "__canvas"), dir: "ltr", ref: (0, merge_refs_1.default)(canvasRef, canvasElement), style: {
              display: 'block',
              userSelect: 'none',
          }, children: renderTextLayer ? (0, jsx_runtime_1.jsx)(StructTree_js_1.default, {}) : null }));
  }
  exports.default = Canvas;
  

});

;/*!node_modules/react-pdf/dist/cjs/Page/TextLayer.js*/
amis.define('5b18673', function(require, exports, module, define) {

  "use strict";
  'use client';
  var __createBinding = (this && this.__createBinding) || (Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function () { return m[k]; } };
      }
      Object.defineProperty(o, k2, desc);
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  }));
  var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  });
  var __importStar = (this && this.__importStar) || function (mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k in mod)
              if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                  __createBinding(result, mod, k);
      __setModuleDefault(result, mod);
      return result;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var make_cancellable_promise_1 = __importDefault(require("f2505c7"));
  var clsx_1 = __importDefault(require("5c50c18"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var pdfjs = __importStar(require("node_modules/pdfjs-dist/build/pdf.mjs"));
  var usePageContext_js_1 = __importDefault(require("9fdce60"));
  var useResolver_js_1 = __importDefault(require("e049f4f"));
  var utils_js_1 = require("53cbee3");
  function isTextItem(item) {
      return 'str' in item;
  }
  function TextLayer() {
      var pageContext = (0, usePageContext_js_1.default)();
      (0, tiny_invariant_1.default)(pageContext, 'Unable to find Page context.');
      var customTextRenderer = pageContext.customTextRenderer, onGetTextError = pageContext.onGetTextError, onGetTextSuccess = pageContext.onGetTextSuccess, onRenderTextLayerError = pageContext.onRenderTextLayerError, onRenderTextLayerSuccess = pageContext.onRenderTextLayerSuccess, page = pageContext.page, pageIndex = pageContext.pageIndex, pageNumber = pageContext.pageNumber, rotate = pageContext.rotate, scale = pageContext.scale;
      (0, tiny_invariant_1.default)(page, 'Attempted to load page text content, but no page was specified.');
      var _a = (0, useResolver_js_1.default)(), textContentState = _a[0], textContentDispatch = _a[1];
      var textContent = textContentState.value, textContentError = textContentState.error;
      var layerElement = (0, react_1.useRef)(null);
      var endElement = (0, react_1.useRef)(undefined);
      (0, warning_1.default)(parseInt(window.getComputedStyle(document.body).getPropertyValue('--react-pdf-text-layer'), 10) === 1, 'TextLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-text-layer');
      /**
       * Called when a page text content is read successfully
       */
      function onLoadSuccess() {
          if (!textContent) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          if (onGetTextSuccess) {
              onGetTextSuccess(textContent);
          }
      }
      /**
       * Called when a page text content failed to read successfully
       */
      function onLoadError() {
          if (!textContentError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, textContentError.toString());
          if (onGetTextError) {
              onGetTextError(textContentError);
          }
      }
      function resetTextContent() {
          textContentDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetTextContent, [page, textContentDispatch]);
      function loadTextContent() {
          if (!page) {
              return;
          }
          var cancellable = (0, make_cancellable_promise_1.default)(page.getTextContent());
          var runningTask = cancellable;
          cancellable.promise
              .then(function (nextTextContent) {
              textContentDispatch({ type: 'RESOLVE', value: nextTextContent });
          })
              .catch(function (error) {
              textContentDispatch({ type: 'REJECT', error: error });
          });
          return function () { return (0, utils_js_1.cancelRunningTask)(runningTask); };
      }
      (0, react_1.useEffect)(loadTextContent, [page, textContentDispatch]);
      (0, react_1.useEffect)(function () {
          if (textContent === undefined) {
              return;
          }
          if (textContent === false) {
              onLoadError();
              return;
          }
          onLoadSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [textContent]);
      /**
       * Called when a text layer is rendered successfully
       */
      var onRenderSuccess = (0, react_1.useCallback)(function () {
          if (onRenderTextLayerSuccess) {
              onRenderTextLayerSuccess();
          }
      }, [onRenderTextLayerSuccess]);
      /**
       * Called when a text layer failed to render successfully
       */
      var onRenderError = (0, react_1.useCallback)(function (error) {
          (0, warning_1.default)(false, error.toString());
          if (onRenderTextLayerError) {
              onRenderTextLayerError(error);
          }
      }, [onRenderTextLayerError]);
      function onMouseDown() {
          var end = endElement.current;
          if (!end) {
              return;
          }
          end.classList.add('active');
      }
      function onMouseUp() {
          var end = endElement.current;
          if (!end) {
              return;
          }
          end.classList.remove('active');
      }
      var viewport = (0, react_1.useMemo)(function () { return page.getViewport({ scale: scale, rotation: rotate }); }, [page, rotate, scale]);
      function renderTextLayer() {
          if (!page || !textContent) {
              return;
          }
          var layer = layerElement.current;
          if (!layer) {
              return;
          }
          layer.innerHTML = '';
          var textContentSource = page.streamTextContent({ includeMarkedContent: true });
          var parameters = {
              container: layer,
              textContentSource: textContentSource,
              viewport: viewport,
          };
          var cancellable = new pdfjs.TextLayer(parameters);
          var runningTask = cancellable;
          cancellable
              .render()
              .then(function () {
              var end = document.createElement('div');
              end.className = 'endOfContent';
              layer.append(end);
              endElement.current = end;
              var layerChildren = layer.querySelectorAll('[role="presentation"]');
              if (customTextRenderer) {
                  var index_1 = 0;
                  textContent.items.forEach(function (item, itemIndex) {
                      if (!isTextItem(item)) {
                          return;
                      }
                      var child = layerChildren[index_1];
                      if (!child) {
                          return;
                      }
                      var content = customTextRenderer(Object.assign({ pageIndex: pageIndex, pageNumber: pageNumber, itemIndex: itemIndex }, item));
                      child.innerHTML = content;
                      index_1 += item.str && item.hasEOL ? 2 : 1;
                  });
              }
              // Intentional immediate callback
              onRenderSuccess();
          })
              .catch(onRenderError);
          return function () { return (0, utils_js_1.cancelRunningTask)(runningTask); };
      }
      (0, react_1.useLayoutEffect)(renderTextLayer, [
          customTextRenderer,
          onRenderError,
          onRenderSuccess,
          page,
          pageIndex,
          pageNumber,
          textContent,
          viewport,
      ]);
      return (
      // eslint-disable-next-line jsx-a11y/no-static-element-interactions
      (0, jsx_runtime_1.jsx)("div", { className: (0, clsx_1.default)('react-pdf__Page__textContent', 'textLayer'), onMouseUp: onMouseUp, onMouseDown: onMouseDown, ref: layerElement }));
  }
  exports.default = TextLayer;
  

});

;/*!node_modules/react-pdf/dist/cjs/Page/AnnotationLayer.js*/
amis.define('b79200d', function(require, exports, module, define) {

  "use strict";
  'use client';
  var __createBinding = (this && this.__createBinding) || (Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function () { return m[k]; } };
      }
      Object.defineProperty(o, k2, desc);
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  }));
  var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  });
  var __importStar = (this && this.__importStar) || function (mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k in mod)
              if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                  __createBinding(result, mod, k);
      __setModuleDefault(result, mod);
      return result;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var make_cancellable_promise_1 = __importDefault(require("f2505c7"));
  var clsx_1 = __importDefault(require("5c50c18"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var pdfjs = __importStar(require("node_modules/pdfjs-dist/build/pdf.mjs"));
  var useDocumentContext_js_1 = __importDefault(require("adc95b7"));
  var usePageContext_js_1 = __importDefault(require("9fdce60"));
  var useResolver_js_1 = __importDefault(require("e049f4f"));
  var utils_js_1 = require("53cbee3");
  function AnnotationLayer() {
      var documentContext = (0, useDocumentContext_js_1.default)();
      var pageContext = (0, usePageContext_js_1.default)();
      (0, tiny_invariant_1.default)(pageContext, 'Unable to find Page context.');
      var mergedProps = Object.assign(Object.assign({}, documentContext), pageContext);
      var imageResourcesPath = mergedProps.imageResourcesPath, linkService = mergedProps.linkService, onGetAnnotationsErrorProps = mergedProps.onGetAnnotationsError, onGetAnnotationsSuccessProps = mergedProps.onGetAnnotationsSuccess, onRenderAnnotationLayerErrorProps = mergedProps.onRenderAnnotationLayerError, onRenderAnnotationLayerSuccessProps = mergedProps.onRenderAnnotationLayerSuccess, page = mergedProps.page, pdf = mergedProps.pdf, renderForms = mergedProps.renderForms, rotate = mergedProps.rotate, _a = mergedProps.scale, scale = _a === void 0 ? 1 : _a;
      (0, tiny_invariant_1.default)(pdf, 'Attempted to load page annotations, but no document was specified. Wrap <Page /> in a <Document /> or pass explicit `pdf` prop.');
      (0, tiny_invariant_1.default)(page, 'Attempted to load page annotations, but no page was specified.');
      (0, tiny_invariant_1.default)(linkService, 'Attempted to load page annotations, but no linkService was specified.');
      var _b = (0, useResolver_js_1.default)(), annotationsState = _b[0], annotationsDispatch = _b[1];
      var annotations = annotationsState.value, annotationsError = annotationsState.error;
      var layerElement = (0, react_1.useRef)(null);
      (0, warning_1.default)(parseInt(window.getComputedStyle(document.body).getPropertyValue('--react-pdf-annotation-layer'), 10) === 1, 'AnnotationLayer styles not found. Read more: https://github.com/wojtekmaj/react-pdf#support-for-annotations');
      function onLoadSuccess() {
          if (!annotations) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          if (onGetAnnotationsSuccessProps) {
              onGetAnnotationsSuccessProps(annotations);
          }
      }
      function onLoadError() {
          if (!annotationsError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, annotationsError.toString());
          if (onGetAnnotationsErrorProps) {
              onGetAnnotationsErrorProps(annotationsError);
          }
      }
      function resetAnnotations() {
          annotationsDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetAnnotations, [annotationsDispatch, page]);
      function loadAnnotations() {
          if (!page) {
              return;
          }
          var cancellable = (0, make_cancellable_promise_1.default)(page.getAnnotations());
          var runningTask = cancellable;
          cancellable.promise
              .then(function (nextAnnotations) {
              annotationsDispatch({ type: 'RESOLVE', value: nextAnnotations });
          })
              .catch(function (error) {
              annotationsDispatch({ type: 'REJECT', error: error });
          });
          return function () {
              (0, utils_js_1.cancelRunningTask)(runningTask);
          };
      }
      (0, react_1.useEffect)(loadAnnotations, [annotationsDispatch, page, renderForms]);
      (0, react_1.useEffect)(function () {
          if (annotations === undefined) {
              return;
          }
          if (annotations === false) {
              onLoadError();
              return;
          }
          onLoadSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [annotations]);
      function onRenderSuccess() {
          if (onRenderAnnotationLayerSuccessProps) {
              onRenderAnnotationLayerSuccessProps();
          }
      }
      function onRenderError(error) {
          (0, warning_1.default)(false, "".concat(error));
          if (onRenderAnnotationLayerErrorProps) {
              onRenderAnnotationLayerErrorProps(error);
          }
      }
      var viewport = (0, react_1.useMemo)(function () { return page.getViewport({ scale: scale, rotation: rotate }); }, [page, rotate, scale]);
      function renderAnnotationLayer() {
          if (!pdf || !page || !linkService || !annotations) {
              return;
          }
          var layer = layerElement.current;
          if (!layer) {
              return;
          }
          var clonedViewport = viewport.clone({ dontFlip: true });
          var annotationLayerParameters = {
              accessibilityManager: null, // TODO: Implement this
              annotationCanvasMap: null, // TODO: Implement this
              annotationEditorUIManager: null, // TODO: Implement this
              div: layer,
              l10n: null, // TODO: Implement this
              page: page,
              viewport: clonedViewport,
          };
          var renderParameters = {
              annotations: annotations,
              annotationStorage: pdf.annotationStorage,
              div: layer,
              imageResourcesPath: imageResourcesPath,
              linkService: linkService,
              page: page,
              renderForms: renderForms,
              viewport: clonedViewport,
          };
          layer.innerHTML = '';
          try {
              new pdfjs.AnnotationLayer(annotationLayerParameters).render(renderParameters);
              // Intentional immediate callback
              onRenderSuccess();
          }
          catch (error) {
              onRenderError(error);
          }
          return function () {
              // TODO: Cancel running task?
          };
      }
      (0, react_1.useEffect)(renderAnnotationLayer, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [annotations, imageResourcesPath, linkService, page, renderForms, viewport]);
      return ((0, jsx_runtime_1.jsx)("div", { className: (0, clsx_1.default)('react-pdf__Page__annotations', 'annotationLayer'), ref: layerElement }));
  }
  exports.default = AnnotationLayer;
  

});

;/*!node_modules/react-pdf/dist/cjs/Page.js*/
amis.define('33e7b9d', function(require, exports, module, define) {

  "use strict";
  'use client';
  var __rest = (this && this.__rest) || function (s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var react_1 = require("547621d");
  var make_cancellable_promise_1 = __importDefault(require("f2505c7"));
  var make_event_props_1 = __importDefault(require("1728961"));
  var clsx_1 = __importDefault(require("5c50c18"));
  var merge_refs_1 = __importDefault(require("563dbc1"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var warning_1 = __importDefault(require("a7f2cb4"));
  var PageContext_js_1 = __importDefault(require("ec75848"));
  var Message_js_1 = __importDefault(require("545c5f6"));
  var Canvas_js_1 = __importDefault(require("d600fe5"));
  var TextLayer_js_1 = __importDefault(require("5b18673"));
  var AnnotationLayer_js_1 = __importDefault(require("b79200d"));
  var utils_js_1 = require("53cbee3");
  var useDocumentContext_js_1 = __importDefault(require("adc95b7"));
  var useResolver_js_1 = __importDefault(require("e049f4f"));
  var defaultScale = 1;
  /**
   * Displays a page.
   *
   * Should be placed inside `<Document />`. Alternatively, it can have `pdf` prop passed, which can be obtained from `<Document />`'s `onLoadSuccess` callback function, however some advanced functions like linking between pages inside a document may not be working correctly.
   */
  function Page(props) {
      var _a;
      var documentContext = (0, useDocumentContext_js_1.default)();
      var mergedProps = Object.assign(Object.assign({}, documentContext), props);
      var _b = mergedProps._className, _className = _b === void 0 ? 'react-pdf__Page' : _b, _c = mergedProps._enableRegisterUnregisterPage, _enableRegisterUnregisterPage = _c === void 0 ? true : _c, canvasBackground = mergedProps.canvasBackground, canvasRef = mergedProps.canvasRef, children = mergedProps.children, className = mergedProps.className, CustomRenderer = mergedProps.customRenderer, customTextRenderer = mergedProps.customTextRenderer, devicePixelRatio = mergedProps.devicePixelRatio, _d = mergedProps.error, error = _d === void 0 ? 'Failed to load the page.' : _d, height = mergedProps.height, inputRef = mergedProps.inputRef, _e = mergedProps.loading, loading = _e === void 0 ? 'Loading page…' : _e, _f = mergedProps.noData, noData = _f === void 0 ? 'No page specified.' : _f, onGetAnnotationsErrorProps = mergedProps.onGetAnnotationsError, onGetAnnotationsSuccessProps = mergedProps.onGetAnnotationsSuccess, onGetStructTreeErrorProps = mergedProps.onGetStructTreeError, onGetStructTreeSuccessProps = mergedProps.onGetStructTreeSuccess, onGetTextErrorProps = mergedProps.onGetTextError, onGetTextSuccessProps = mergedProps.onGetTextSuccess, onLoadErrorProps = mergedProps.onLoadError, onLoadSuccessProps = mergedProps.onLoadSuccess, onRenderAnnotationLayerErrorProps = mergedProps.onRenderAnnotationLayerError, onRenderAnnotationLayerSuccessProps = mergedProps.onRenderAnnotationLayerSuccess, onRenderErrorProps = mergedProps.onRenderError, onRenderSuccessProps = mergedProps.onRenderSuccess, onRenderTextLayerErrorProps = mergedProps.onRenderTextLayerError, onRenderTextLayerSuccessProps = mergedProps.onRenderTextLayerSuccess, pageIndexProps = mergedProps.pageIndex, pageNumberProps = mergedProps.pageNumber, pdf = mergedProps.pdf, registerPage = mergedProps.registerPage, _g = mergedProps.renderAnnotationLayer, renderAnnotationLayerProps = _g === void 0 ? true : _g, _h = mergedProps.renderForms, renderForms = _h === void 0 ? false : _h, _j = mergedProps.renderMode, renderMode = _j === void 0 ? 'canvas' : _j, _k = mergedProps.renderTextLayer, renderTextLayerProps = _k === void 0 ? true : _k, rotateProps = mergedProps.rotate, _l = mergedProps.scale, scaleProps = _l === void 0 ? defaultScale : _l, unregisterPage = mergedProps.unregisterPage, width = mergedProps.width, otherProps = __rest(mergedProps, ["_className", "_enableRegisterUnregisterPage", "canvasBackground", "canvasRef", "children", "className", "customRenderer", "customTextRenderer", "devicePixelRatio", "error", "height", "inputRef", "loading", "noData", "onGetAnnotationsError", "onGetAnnotationsSuccess", "onGetStructTreeError", "onGetStructTreeSuccess", "onGetTextError", "onGetTextSuccess", "onLoadError", "onLoadSuccess", "onRenderAnnotationLayerError", "onRenderAnnotationLayerSuccess", "onRenderError", "onRenderSuccess", "onRenderTextLayerError", "onRenderTextLayerSuccess", "pageIndex", "pageNumber", "pdf", "registerPage", "renderAnnotationLayer", "renderForms", "renderMode", "renderTextLayer", "rotate", "scale", "unregisterPage", "width"]);
      var _m = (0, useResolver_js_1.default)(), pageState = _m[0], pageDispatch = _m[1];
      var page = pageState.value, pageError = pageState.error;
      var pageElement = (0, react_1.useRef)(null);
      (0, tiny_invariant_1.default)(pdf, 'Attempted to load a page, but no document was specified. Wrap <Page /> in a <Document /> or pass explicit `pdf` prop.');
      var pageIndex = (0, utils_js_1.isProvided)(pageNumberProps) ? pageNumberProps - 1 : pageIndexProps !== null && pageIndexProps !== void 0 ? pageIndexProps : null;
      var pageNumber = pageNumberProps !== null && pageNumberProps !== void 0 ? pageNumberProps : ((0, utils_js_1.isProvided)(pageIndexProps) ? pageIndexProps + 1 : null);
      var rotate = rotateProps !== null && rotateProps !== void 0 ? rotateProps : (page ? page.rotate : null);
      var scale = (0, react_1.useMemo)(function () {
          if (!page) {
              return null;
          }
          // Be default, we'll render page at 100% * scale width.
          var pageScale = 1;
          // Passing scale explicitly null would cause the page not to render
          var scaleWithDefault = scaleProps !== null && scaleProps !== void 0 ? scaleProps : defaultScale;
          // If width/height is defined, calculate the scale of the page so it could be of desired width.
          if (width || height) {
              var viewport = page.getViewport({ scale: 1, rotation: rotate });
              if (width) {
                  pageScale = width / viewport.width;
              }
              else if (height) {
                  pageScale = height / viewport.height;
              }
          }
          return scaleWithDefault * pageScale;
      }, [height, page, rotate, scaleProps, width]);
      function hook() {
          return function () {
              if (!(0, utils_js_1.isProvided)(pageIndex)) {
                  // Impossible, but TypeScript doesn't know that
                  return;
              }
              if (_enableRegisterUnregisterPage && unregisterPage) {
                  unregisterPage(pageIndex);
              }
          };
      }
      (0, react_1.useEffect)(hook, [_enableRegisterUnregisterPage, pdf, pageIndex, unregisterPage]);
      /**
       * Called when a page is loaded successfully
       */
      function onLoadSuccess() {
          if (onLoadSuccessProps) {
              if (!page || !scale) {
                  // Impossible, but TypeScript doesn't know that
                  return;
              }
              onLoadSuccessProps((0, utils_js_1.makePageCallback)(page, scale));
          }
          if (_enableRegisterUnregisterPage && registerPage) {
              if (!(0, utils_js_1.isProvided)(pageIndex) || !pageElement.current) {
                  // Impossible, but TypeScript doesn't know that
                  return;
              }
              registerPage(pageIndex, pageElement.current);
          }
      }
      /**
       * Called when a page failed to load
       */
      function onLoadError() {
          if (!pageError) {
              // Impossible, but TypeScript doesn't know that
              return;
          }
          (0, warning_1.default)(false, pageError.toString());
          if (onLoadErrorProps) {
              onLoadErrorProps(pageError);
          }
      }
      function resetPage() {
          pageDispatch({ type: 'RESET' });
      }
      (0, react_1.useEffect)(resetPage, [pageDispatch, pdf, pageIndex]);
      function loadPage() {
          if (!pdf || !pageNumber) {
              return;
          }
          var cancellable = (0, make_cancellable_promise_1.default)(pdf.getPage(pageNumber));
          var runningTask = cancellable;
          cancellable.promise
              .then(function (nextPage) {
              pageDispatch({ type: 'RESOLVE', value: nextPage });
          })
              .catch(function (error) {
              pageDispatch({ type: 'REJECT', error: error });
          });
          return function () { return (0, utils_js_1.cancelRunningTask)(runningTask); };
      }
      (0, react_1.useEffect)(loadPage, [pageDispatch, pdf, pageIndex, pageNumber, registerPage]);
      (0, react_1.useEffect)(function () {
          if (page === undefined) {
              return;
          }
          if (page === false) {
              onLoadError();
              return;
          }
          onLoadSuccess();
      }, 
      // Ommitted callbacks so they are not called every time they change
      // eslint-disable-next-line react-hooks/exhaustive-deps
      [page, scale]);
      var childContext = (0, react_1.useMemo)(function () {
          // Technically there cannot be page without pageIndex, pageNumber, rotate and scale, but TypeScript doesn't know that
          return page && (0, utils_js_1.isProvided)(pageIndex) && pageNumber && (0, utils_js_1.isProvided)(rotate) && (0, utils_js_1.isProvided)(scale)
              ? {
                  _className: _className,
                  canvasBackground: canvasBackground,
                  customTextRenderer: customTextRenderer,
                  devicePixelRatio: devicePixelRatio,
                  onGetAnnotationsError: onGetAnnotationsErrorProps,
                  onGetAnnotationsSuccess: onGetAnnotationsSuccessProps,
                  onGetStructTreeError: onGetStructTreeErrorProps,
                  onGetStructTreeSuccess: onGetStructTreeSuccessProps,
                  onGetTextError: onGetTextErrorProps,
                  onGetTextSuccess: onGetTextSuccessProps,
                  onRenderAnnotationLayerError: onRenderAnnotationLayerErrorProps,
                  onRenderAnnotationLayerSuccess: onRenderAnnotationLayerSuccessProps,
                  onRenderError: onRenderErrorProps,
                  onRenderSuccess: onRenderSuccessProps,
                  onRenderTextLayerError: onRenderTextLayerErrorProps,
                  onRenderTextLayerSuccess: onRenderTextLayerSuccessProps,
                  page: page,
                  pageIndex: pageIndex,
                  pageNumber: pageNumber,
                  renderForms: renderForms,
                  renderTextLayer: renderTextLayerProps,
                  rotate: rotate,
                  scale: scale,
              }
              : null;
      }, [
          _className,
          canvasBackground,
          customTextRenderer,
          devicePixelRatio,
          onGetAnnotationsErrorProps,
          onGetAnnotationsSuccessProps,
          onGetStructTreeErrorProps,
          onGetStructTreeSuccessProps,
          onGetTextErrorProps,
          onGetTextSuccessProps,
          onRenderAnnotationLayerErrorProps,
          onRenderAnnotationLayerSuccessProps,
          onRenderErrorProps,
          onRenderSuccessProps,
          onRenderTextLayerErrorProps,
          onRenderTextLayerSuccessProps,
          page,
          pageIndex,
          pageNumber,
          renderForms,
          renderTextLayerProps,
          rotate,
          scale,
      ]);
      var eventProps = (0, react_1.useMemo)(function () { return (0, make_event_props_1.default)(otherProps, function () { return page ? (scale ? (0, utils_js_1.makePageCallback)(page, scale) : undefined) : page; }); }, [otherProps, page, scale]);
      var pageKey = "".concat(pageIndex, "@").concat(scale, "/").concat(rotate);
      function renderMainLayer() {
          switch (renderMode) {
              case 'custom': {
                  (0, tiny_invariant_1.default)(CustomRenderer, "renderMode was set to \"custom\", but no customRenderer was passed.");
                  return (0, jsx_runtime_1.jsx)(CustomRenderer, {}, "".concat(pageKey, "_custom"));
              }
              case 'none':
                  return null;
              case 'canvas':
              default:
                  return (0, jsx_runtime_1.jsx)(Canvas_js_1.default, { canvasRef: canvasRef }, "".concat(pageKey, "_canvas"));
          }
      }
      function renderTextLayer() {
          if (!renderTextLayerProps) {
              return null;
          }
          return (0, jsx_runtime_1.jsx)(TextLayer_js_1.default, {}, "".concat(pageKey, "_text"));
      }
      function renderAnnotationLayer() {
          if (!renderAnnotationLayerProps) {
              return null;
          }
          /**
           * As of now, PDF.js 2.0.943 returns warnings on unimplemented annotations in SVG mode.
           * Therefore, as a fallback, we render "traditional" AnnotationLayer component.
           */
          return (0, jsx_runtime_1.jsx)(AnnotationLayer_js_1.default, {}, "".concat(pageKey, "_annotations"));
      }
      function renderChildren() {
          return ((0, jsx_runtime_1.jsxs)(PageContext_js_1.default.Provider, { value: childContext, children: [renderMainLayer(), renderTextLayer(), renderAnnotationLayer(), children] }));
      }
      function renderContent() {
          if (!pageNumber) {
              return (0, jsx_runtime_1.jsx)(Message_js_1.default, { type: "no-data", children: typeof noData === 'function' ? noData() : noData });
          }
          if (pdf === null || page === undefined || page === null) {
              return ((0, jsx_runtime_1.jsx)(Message_js_1.default, { type: "loading", children: typeof loading === 'function' ? loading() : loading }));
          }
          if (pdf === false || page === false) {
              return (0, jsx_runtime_1.jsx)(Message_js_1.default, { type: "error", children: typeof error === 'function' ? error() : error });
          }
          return renderChildren();
      }
      return ((0, jsx_runtime_1.jsx)("div", Object.assign({ className: (0, clsx_1.default)(_className, className), "data-page-number": pageNumber,
          // Assertion is needed for React 18 compatibility
          ref: (0, merge_refs_1.default)(inputRef, pageElement), style: (_a = {},
              _a['--scale-factor'] = "".concat(scale),
              _a.backgroundColor = canvasBackground || 'white',
              _a.position = 'relative',
              _a.minWidth = 'min-content',
              _a.minHeight = 'min-content',
              _a) }, eventProps, { children: renderContent() })));
  }
  exports.default = Page;
  

});

;/*!node_modules/react-pdf/dist/cjs/Thumbnail.js*/
amis.define('096eb0d', function(require, exports, module, define) {

  "use strict";
  'use client';
  var __rest = (this && this.__rest) || function (s, e) {
      var t = {};
      for (var p in s)
          if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
              t[p] = s[p];
      if (s != null && typeof Object.getOwnPropertySymbols === "function")
          for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
              if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                  t[p[i]] = s[p[i]];
          }
      return t;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  var jsx_runtime_1 = require("c6b9325");
  var clsx_1 = __importDefault(require("5c50c18"));
  var tiny_invariant_1 = __importDefault(require("0a3bd3b"));
  var Page_js_1 = __importDefault(require("33e7b9d"));
  var utils_js_1 = require("53cbee3");
  var useDocumentContext_js_1 = __importDefault(require("adc95b7"));
  /**
   * Displays a thumbnail of a page. Does not render the annotation layer or the text layer. Does not register itself as a link target, so the user will not be scrolled to a Thumbnail component when clicked on an internal link (e.g. in Table of Contents). When clicked, attempts to navigate to the page clicked (similarly to a link in Outline).
   *
   * Should be placed inside `<Document />`. Alternatively, it can have `pdf` prop passed, which can be obtained from `<Document />`'s `onLoadSuccess` callback function.
   */
  function Thumbnail(props) {
      var documentContext = (0, useDocumentContext_js_1.default)();
      var mergedProps = Object.assign(Object.assign({}, documentContext), props);
      var className = mergedProps.className, linkService = mergedProps.linkService, onItemClick = mergedProps.onItemClick, pageIndexProps = mergedProps.pageIndex, pageNumberProps = mergedProps.pageNumber, pdf = mergedProps.pdf;
      (0, tiny_invariant_1.default)(pdf, 'Attempted to load a thumbnail, but no document was specified. Wrap <Thumbnail /> in a <Document /> or pass explicit `pdf` prop.');
      var pageIndex = (0, utils_js_1.isProvided)(pageNumberProps) ? pageNumberProps - 1 : pageIndexProps !== null && pageIndexProps !== void 0 ? pageIndexProps : null;
      var pageNumber = pageNumberProps !== null && pageNumberProps !== void 0 ? pageNumberProps : ((0, utils_js_1.isProvided)(pageIndexProps) ? pageIndexProps + 1 : null);
      function onClick(event) {
          event.preventDefault();
          if (!(0, utils_js_1.isProvided)(pageIndex) || !pageNumber) {
              return;
          }
          (0, tiny_invariant_1.default)(onItemClick || linkService, 'Either onItemClick callback or linkService must be defined in order to navigate to an outline item.');
          if (onItemClick) {
              onItemClick({
                  pageIndex: pageIndex,
                  pageNumber: pageNumber,
              });
          }
          else if (linkService) {
              linkService.goToPage(pageNumber);
          }
      }
      // eslint-disable-next-line react/prop-types
      var classNameProps = props.className, onItemClickProps = props.onItemClick, pageProps = __rest(props, ["className", "onItemClick"]);
      return (
      /* eslint-disable-next-line jsx-a11y/anchor-is-valid */
      (0, jsx_runtime_1.jsx)("a", { className: (0, clsx_1.default)('react-pdf__Thumbnail', className), href: pageNumber ? '#' : undefined, onClick: onClick, children: (0, jsx_runtime_1.jsx)(Page_js_1.default, Object.assign({}, pageProps, { _className: "react-pdf__Thumbnail__page", _enableRegisterUnregisterPage: false, renderAnnotationLayer: false, renderTextLayer: false })) }));
  }
  exports.default = Thumbnail;
  

});

;/*!node_modules/react-pdf/dist/cjs/index.js*/
amis.define('8ae3776', function(require, exports, module, define) {

  "use strict";
  var __createBinding = (this && this.__createBinding) || (Object.create ? (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
          desc = { enumerable: true, get: function () { return m[k]; } };
      }
      Object.defineProperty(o, k2, desc);
  }) : (function (o, m, k, k2) {
      if (k2 === undefined)
          k2 = k;
      o[k2] = m[k];
  }));
  var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function (o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
  }) : function (o, v) {
      o["default"] = v;
  });
  var __importStar = (this && this.__importStar) || function (mod) {
      if (mod && mod.__esModule)
          return mod;
      var result = {};
      if (mod != null)
          for (var k in mod)
              if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                  __createBinding(result, mod, k);
      __setModuleDefault(result, mod);
      return result;
  };
  var __importDefault = (this && this.__importDefault) || function (mod) {
      return (mod && mod.__esModule) ? mod : { "default": mod };
  };
  Object.defineProperty(exports, "__esModule", { value: true });
  exports.PasswordResponses = exports.usePageContext = exports.useOutlineContext = exports.useDocumentContext = exports.Thumbnail = exports.Page = exports.Outline = exports.Document = exports.pdfjs = void 0;
  var pdfjs = __importStar(require("node_modules/pdfjs-dist/build/pdf.mjs"));
  exports.pdfjs = pdfjs;
  var Document_js_1 = __importDefault(require("3cac0a2"));
  exports.Document = Document_js_1.default;
  var Outline_js_1 = __importDefault(require("3c3b2bb"));
  exports.Outline = Outline_js_1.default;
  var Page_js_1 = __importDefault(require("33e7b9d"));
  exports.Page = Page_js_1.default;
  var Thumbnail_js_1 = __importDefault(require("096eb0d"));
  exports.Thumbnail = Thumbnail_js_1.default;
  var useDocumentContext_js_1 = __importDefault(require("adc95b7"));
  exports.useDocumentContext = useDocumentContext_js_1.default;
  var useOutlineContext_js_1 = __importDefault(require("22cedd7"));
  exports.useOutlineContext = useOutlineContext_js_1.default;
  var usePageContext_js_1 = __importDefault(require("9fdce60"));
  exports.usePageContext = usePageContext_js_1.default;
  var PasswordResponses_js_1 = __importDefault(require("5e4d83f"));
  exports.PasswordResponses = PasswordResponses_js_1.default;
  var utils_js_1 = require("53cbee3");
  (0, utils_js_1.displayWorkerWarning)();
  pdfjs.GlobalWorkerOptions.workerSrc = 'pdf.worker.mjs';
  

});

;/*!node_modules/amis/node_modules/amis-ui/lib/components/PdfViewer.js*/
amis.define('69ebd92', function(require, exports, module, define) {

  /**
   * amis-ui v6.13.0
   * Copyright 2018-2025 fex
   */
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', { value: true });
  
  var tslib = require('a5c5bc6');
  var React = require('547621d');
  var amisCore = require('abff7ef');
  var reactPdf = require('8ae3776');
  var icons = require('b684f5a');
  var Input = require('6db073b');
  var Spinner = require('b7f88a0');
  
  function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }
  
  var React__default = /*#__PURE__*/_interopDefaultLegacy(React);
  
  var __react_jsx__ = require('547621d');
  var _J$X_ = (__react_jsx__["default"] || __react_jsx__).createElement;
  (__react_jsx__["default"] || __react_jsx__).Fragment;
  reactPdf.pdfjs.GlobalWorkerOptions.workerSrc = amisCore.getGlobalOptions().pdfjsWorkerSrc;
  var PdfViewer = function (props) {
      var cx = props.classnames, className = props.className, loading = props.loading, _a = props.width, width = _a === void 0 ? 300 : _a;
      var _b = tslib.__read(React__default["default"].useState(props.file), 2), file = _b[0], setFile = _b[1];
      var _c = tslib.__read(React__default["default"].useState(false), 2), loaded = _c[0], setLoaded = _c[1];
      var _d = tslib.__read(React__default["default"].useState(1), 2), page = _d[0], setPage = _d[1];
      var _e = tslib.__read(React__default["default"].useState(1), 2), scale = _e[0], setScale = _e[1];
      var _f = tslib.__read(React__default["default"].useState(1), 2), total = _f[0], setTotal = _f[1];
      var inputRef = React__default["default"].useRef();
      React__default["default"].useEffect(function () {
          if (props.file instanceof ArrayBuffer && props.file.byteLength > 0) {
              setFile(props.file);
          }
          else {
              setFile(undefined);
          }
      }, [props.file]);
      function handleLoadSuccess(_a) {
          var numPages = _a.numPages;
          setLoaded(true);
          setTotal(numPages);
      }
      function handleChangePage(idx) {
          var newPage = page + idx;
          if (newPage <= 0 || newPage > total) {
              return;
          }
          setPage(newPage);
      }
      function handlePageBlur(event) {
          var newPage = +event.target.value;
          if (isNaN(newPage) || newPage <= 0 || newPage > total) {
              if (inputRef.current) {
                  inputRef.current.value = page + '';
              }
              return;
          }
          setPage(newPage);
      }
      function handleChangeScale(t) {
          setScale(scale * t);
      }
      function renderLoading() {
          return (_J$X_("div", { className: cx('PdfViewer-Loading') },
              _J$X_(Spinner["default"], null)));
      }
      function renderTool() {
          return (_J$X_("div", { className: cx('PdfViewer-Tool') },
              _J$X_(icons.Icon, { className: "icon", icon: "prev", onClick: function () { return handleChangePage(-1); } }),
              _J$X_(Input["default"], { className: "page-input", value: page, onBlur: handlePageBlur, ref: inputRef }),
              _J$X_("span", { className: "gap" }, "/"),
              _J$X_("span", null, total),
              _J$X_(icons.Icon, { className: "icon", icon: "next", onClick: function () { return handleChangePage(1); } }),
              _J$X_(icons.Icon, { className: "icon", icon: "zoom-in", onClick: function () { return handleChangeScale(1.2); } }),
              _J$X_(icons.Icon, { className: "icon", icon: "zoom-out", onClick: function () { return handleChangeScale(0.8); } })));
      }
      return (_J$X_("div", { className: cx(className, 'PdfViewer') }, !file || loading ? (renderLoading()) : (_J$X_(React__default["default"].Fragment, null,
          _J$X_("div", { className: cx('PdfViewer-Content', { 'is-loaded': loaded }) },
              _J$X_(reactPdf.Document, { file: file, onLoadSuccess: handleLoadSuccess, onLoadError: function (err) { return console.log(err); }, loading: renderLoading() },
                  _J$X_(reactPdf.Page, { className: cx('PdfViewer-Content-Page'), pageNumber: page, width: width, height: props.height, loading: renderLoading(), noData: _J$X_("div", null, "No PDF data"), scale: scale, renderTextLayer: false, renderAnnotationLayer: false }))),
          loaded ? renderTool() : null))));
  };
  var PdfViewer$1 = amisCore.themeable(PdfViewer);
  
  exports["default"] = PdfViewer$1;
  

});
