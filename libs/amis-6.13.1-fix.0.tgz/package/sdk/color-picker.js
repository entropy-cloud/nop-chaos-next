;/*!node_modules/reactcss/lib/flattenNames.js*/
amis.define('90f91b0', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.flattenNames = undefined;
  
  var _isString2 = require('c44b773');
  
  var _isString3 = _interopRequireDefault(_isString2);
  
  var _forOwn2 = require('8e86cc4');
  
  var _forOwn3 = _interopRequireDefault(_forOwn2);
  
  var _isPlainObject2 = require('154c2de');
  
  var _isPlainObject3 = _interopRequireDefault(_isPlainObject2);
  
  var _map2 = require('10ab2ce');
  
  var _map3 = _interopRequireDefault(_map2);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var flattenNames = exports.flattenNames = function flattenNames() {
    var things = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  
    var names = [];
  
    (0, _map3.default)(things, function (thing) {
      if (Array.isArray(thing)) {
        flattenNames(thing).map(function (name) {
          return names.push(name);
        });
      } else if ((0, _isPlainObject3.default)(thing)) {
        (0, _forOwn3.default)(thing, function (value, key) {
          value === true && names.push(key);
          names.push(key + '-' + value);
        });
      } else if ((0, _isString3.default)(thing)) {
        names.push(thing);
      }
    });
  
    return names;
  };
  
  exports.default = flattenNames;

});

;/*!node_modules/reactcss/lib/mergeClasses.js*/
amis.define('5dd3016', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.mergeClasses = undefined;
  
  var _forOwn2 = require('8e86cc4');
  
  var _forOwn3 = _interopRequireDefault(_forOwn2);
  
  var _cloneDeep2 = require('3941723');
  
  var _cloneDeep3 = _interopRequireDefault(_cloneDeep2);
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var mergeClasses = exports.mergeClasses = function mergeClasses(classes) {
    var activeNames = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  
    var styles = classes.default && (0, _cloneDeep3.default)(classes.default) || {};
    activeNames.map(function (name) {
      var toMerge = classes[name];
      if (toMerge) {
        (0, _forOwn3.default)(toMerge, function (value, key) {
          if (!styles[key]) {
            styles[key] = {};
          }
  
          styles[key] = _extends({}, styles[key], toMerge[key]);
        });
      }
  
      return name;
    });
    return styles;
  };
  
  exports.default = mergeClasses;

});

;/*!node_modules/reactcss/lib/autoprefix.js*/
amis.define('28de761', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.autoprefix = undefined;
  
  var _forOwn2 = require('8e86cc4');
  
  var _forOwn3 = _interopRequireDefault(_forOwn2);
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var transforms = {
    borderRadius: function borderRadius(value) {
      return {
        msBorderRadius: value,
        MozBorderRadius: value,
        OBorderRadius: value,
        WebkitBorderRadius: value,
        borderRadius: value
      };
    },
    boxShadow: function boxShadow(value) {
      return {
        msBoxShadow: value,
        MozBoxShadow: value,
        OBoxShadow: value,
        WebkitBoxShadow: value,
        boxShadow: value
      };
    },
    userSelect: function userSelect(value) {
      return {
        WebkitTouchCallout: value,
        KhtmlUserSelect: value,
        MozUserSelect: value,
        msUserSelect: value,
        WebkitUserSelect: value,
        userSelect: value
      };
    },
  
    flex: function flex(value) {
      return {
        WebkitBoxFlex: value,
        MozBoxFlex: value,
        WebkitFlex: value,
        msFlex: value,
        flex: value
      };
    },
    flexBasis: function flexBasis(value) {
      return {
        WebkitFlexBasis: value,
        flexBasis: value
      };
    },
    justifyContent: function justifyContent(value) {
      return {
        WebkitJustifyContent: value,
        justifyContent: value
      };
    },
  
    transition: function transition(value) {
      return {
        msTransition: value,
        MozTransition: value,
        OTransition: value,
        WebkitTransition: value,
        transition: value
      };
    },
  
    transform: function transform(value) {
      return {
        msTransform: value,
        MozTransform: value,
        OTransform: value,
        WebkitTransform: value,
        transform: value
      };
    },
    absolute: function absolute(value) {
      var direction = value && value.split(' ');
      return {
        position: 'absolute',
        top: direction && direction[0],
        right: direction && direction[1],
        bottom: direction && direction[2],
        left: direction && direction[3]
      };
    },
    extend: function extend(name, otherElementStyles) {
      var otherStyle = otherElementStyles[name];
      if (otherStyle) {
        return otherStyle;
      }
      return {
        'extend': name
      };
    }
  };
  
  var autoprefix = exports.autoprefix = function autoprefix(elements) {
    var prefixed = {};
    (0, _forOwn3.default)(elements, function (styles, element) {
      var expanded = {};
      (0, _forOwn3.default)(styles, function (value, key) {
        var transform = transforms[key];
        if (transform) {
          expanded = _extends({}, expanded, transform(value));
        } else {
          expanded[key] = value;
        }
      });
      prefixed[element] = expanded;
    });
    return prefixed;
  };
  
  exports.default = autoprefix;

});

;/*!node_modules/reactcss/lib/components/hover.js*/
amis.define('afd5a2f', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.hover = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var hover = exports.hover = function hover(Component) {
    var Span = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'span';
  
    return function (_React$Component) {
      _inherits(Hover, _React$Component);
  
      function Hover() {
        var _ref;
  
        var _temp, _this, _ret;
  
        _classCallCheck(this, Hover);
  
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
  
        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Hover.__proto__ || Object.getPrototypeOf(Hover)).call.apply(_ref, [this].concat(args))), _this), _this.state = { hover: false }, _this.handleMouseOver = function () {
          return _this.setState({ hover: true });
        }, _this.handleMouseOut = function () {
          return _this.setState({ hover: false });
        }, _this.render = function () {
          return _react2.default.createElement(
            Span,
            { onMouseOver: _this.handleMouseOver, onMouseOut: _this.handleMouseOut },
            _react2.default.createElement(Component, _extends({}, _this.props, _this.state))
          );
        }, _temp), _possibleConstructorReturn(_this, _ret);
      }
  
      return Hover;
    }(_react2.default.Component);
  };
  
  exports.default = hover;

});

;/*!node_modules/reactcss/lib/components/active.js*/
amis.define('01f54ef', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.active = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var active = exports.active = function active(Component) {
    var Span = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'span';
  
    return function (_React$Component) {
      _inherits(Active, _React$Component);
  
      function Active() {
        var _ref;
  
        var _temp, _this, _ret;
  
        _classCallCheck(this, Active);
  
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
  
        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Active.__proto__ || Object.getPrototypeOf(Active)).call.apply(_ref, [this].concat(args))), _this), _this.state = { active: false }, _this.handleMouseDown = function () {
          return _this.setState({ active: true });
        }, _this.handleMouseUp = function () {
          return _this.setState({ active: false });
        }, _this.render = function () {
          return _react2.default.createElement(
            Span,
            { onMouseDown: _this.handleMouseDown, onMouseUp: _this.handleMouseUp },
            _react2.default.createElement(Component, _extends({}, _this.props, _this.state))
          );
        }, _temp), _possibleConstructorReturn(_this, _ret);
      }
  
      return Active;
    }(_react2.default.Component);
  };
  
  exports.default = active;

});

;/*!node_modules/reactcss/lib/loop.js*/
amis.define('2f63931', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var loopable = function loopable(i, length) {
    var props = {};
    var setProp = function setProp(name) {
      var value = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  
      props[name] = value;
    };
  
    i === 0 && setProp('first-child');
    i === length - 1 && setProp('last-child');
    (i === 0 || i % 2 === 0) && setProp('even');
    Math.abs(i % 2) === 1 && setProp('odd');
    setProp('nth-child', i);
  
    return props;
  };
  
  exports.default = loopable;

});

;/*!node_modules/reactcss/lib/index.js*/
amis.define('de9fee7', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ReactCSS = exports.loop = exports.handleActive = exports.handleHover = exports.hover = undefined;
  
  var _flattenNames = require('90f91b0');
  
  var _flattenNames2 = _interopRequireDefault(_flattenNames);
  
  var _mergeClasses = require('5dd3016');
  
  var _mergeClasses2 = _interopRequireDefault(_mergeClasses);
  
  var _autoprefix = require('28de761');
  
  var _autoprefix2 = _interopRequireDefault(_autoprefix);
  
  var _hover2 = require('afd5a2f');
  
  var _hover3 = _interopRequireDefault(_hover2);
  
  var _active = require('01f54ef');
  
  var _active2 = _interopRequireDefault(_active);
  
  var _loop2 = require('2f63931');
  
  var _loop3 = _interopRequireDefault(_loop2);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  exports.hover = _hover3.default;
  exports.handleHover = _hover3.default;
  exports.handleActive = _active2.default;
  exports.loop = _loop3.default;
  var ReactCSS = exports.ReactCSS = function ReactCSS(classes) {
    for (var _len = arguments.length, activations = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      activations[_key - 1] = arguments[_key];
    }
  
    var activeNames = (0, _flattenNames2.default)(activations);
    var merged = (0, _mergeClasses2.default)(classes, activeNames);
    return (0, _autoprefix2.default)(merged);
  };
  
  exports.default = ReactCSS;

});

;/*!node_modules/react-color/lib/helpers/alpha.js*/
amis.define('091c980', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var calculateChange = exports.calculateChange = function calculateChange(e, hsl, direction, initialA, container) {
    var containerWidth = container.clientWidth;
    var containerHeight = container.clientHeight;
    var x = typeof e.pageX === 'number' ? e.pageX : e.touches[0].pageX;
    var y = typeof e.pageY === 'number' ? e.pageY : e.touches[0].pageY;
    var left = x - (container.getBoundingClientRect().left + window.pageXOffset);
    var top = y - (container.getBoundingClientRect().top + window.pageYOffset);
  
    if (direction === 'vertical') {
      var a = void 0;
      if (top < 0) {
        a = 0;
      } else if (top > containerHeight) {
        a = 1;
      } else {
        a = Math.round(top * 100 / containerHeight) / 100;
      }
  
      if (hsl.a !== a) {
        return {
          h: hsl.h,
          s: hsl.s,
          l: hsl.l,
          a: a,
          source: 'rgb'
        };
      }
    } else {
      var _a = void 0;
      if (left < 0) {
        _a = 0;
      } else if (left > containerWidth) {
        _a = 1;
      } else {
        _a = Math.round(left * 100 / containerWidth) / 100;
      }
  
      if (initialA !== _a) {
        return {
          h: hsl.h,
          s: hsl.s,
          l: hsl.l,
          a: _a,
          source: 'rgb'
        };
      }
    }
    return null;
  };

});

;/*!node_modules/react-color/lib/helpers/checkboard.js*/
amis.define('b60478a', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var checkboardCache = {};
  
  var render = exports.render = function render(c1, c2, size, serverCanvas) {
    if (typeof document === 'undefined' && !serverCanvas) {
      return null;
    }
    var canvas = serverCanvas ? new serverCanvas() : document.createElement('canvas');
    canvas.width = size * 2;
    canvas.height = size * 2;
    var ctx = canvas.getContext('2d');
    if (!ctx) {
      return null;
    } // If no context can be found, return early.
    ctx.fillStyle = c1;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = c2;
    ctx.fillRect(0, 0, size, size);
    ctx.translate(size, size);
    ctx.fillRect(0, 0, size, size);
    return canvas.toDataURL();
  };
  
  var get = exports.get = function get(c1, c2, size, serverCanvas) {
    var key = c1 + '-' + c2 + '-' + size + (serverCanvas ? '-server' : '');
  
    if (checkboardCache[key]) {
      return checkboardCache[key];
    }
  
    var checkboard = render(c1, c2, size, serverCanvas);
    checkboardCache[key] = checkboard;
    return checkboard;
  };

});

;/*!node_modules/react-color/lib/components/common/Checkboard.js*/
amis.define('4e8ecbd', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Checkboard = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _checkboard = require('b60478a');
  
  var checkboard = _interopRequireWildcard(_checkboard);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Checkboard = exports.Checkboard = function Checkboard(_ref) {
    var white = _ref.white,
        grey = _ref.grey,
        size = _ref.size,
        renderers = _ref.renderers,
        borderRadius = _ref.borderRadius,
        boxShadow = _ref.boxShadow,
        children = _ref.children;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        grid: {
          borderRadius: borderRadius,
          boxShadow: boxShadow,
          absolute: '0px 0px 0px 0px',
          background: 'url(' + checkboard.get(white, grey, size, renderers.canvas) + ') center left'
        }
      }
    });
    return (0, _react.isValidElement)(children) ? _react2.default.cloneElement(children, _extends({}, children.props, { style: _extends({}, children.props.style, styles.grid) })) : _react2.default.createElement('div', { style: styles.grid });
  };
  
  Checkboard.defaultProps = {
    size: 8,
    white: 'transparent',
    grey: 'rgba(0,0,0,.08)',
    renderers: {}
  };
  
  exports.default = Checkboard;

});

;/*!node_modules/react-color/lib/components/common/Alpha.js*/
amis.define('ca6dd8c', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Alpha = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _alpha = require('091c980');
  
  var alpha = _interopRequireWildcard(_alpha);
  
  var _Checkboard = require('4e8ecbd');
  
  var _Checkboard2 = _interopRequireDefault(_Checkboard);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var Alpha = exports.Alpha = function (_ref) {
    _inherits(Alpha, _ref);
  
    function Alpha() {
      var _ref2;
  
      var _temp, _this, _ret;
  
      _classCallCheck(this, Alpha);
  
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
  
      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref2 = Alpha.__proto__ || Object.getPrototypeOf(Alpha)).call.apply(_ref2, [this].concat(args))), _this), _this.handleChange = function (e) {
        var change = alpha.calculateChange(e, _this.props.hsl, _this.props.direction, _this.props.a, _this.container);
        change && typeof _this.props.onChange === 'function' && _this.props.onChange(change, e);
      }, _this.handleMouseDown = function (e) {
        _this.handleChange(e);
        window.addEventListener('mousemove', _this.handleChange);
        window.addEventListener('mouseup', _this.handleMouseUp);
      }, _this.handleMouseUp = function () {
        _this.unbindEventListeners();
      }, _this.unbindEventListeners = function () {
        window.removeEventListener('mousemove', _this.handleChange);
        window.removeEventListener('mouseup', _this.handleMouseUp);
      }, _temp), _possibleConstructorReturn(_this, _ret);
    }
  
    _createClass(Alpha, [{
      key: 'componentWillUnmount',
      value: function componentWillUnmount() {
        this.unbindEventListeners();
      }
    }, {
      key: 'render',
      value: function render() {
        var _this2 = this;
  
        var rgb = this.props.rgb;
        var styles = (0, _reactcss2.default)({
          'default': {
            alpha: {
              absolute: '0px 0px 0px 0px',
              borderRadius: this.props.radius
            },
            checkboard: {
              absolute: '0px 0px 0px 0px',
              overflow: 'hidden',
              borderRadius: this.props.radius
            },
            gradient: {
              absolute: '0px 0px 0px 0px',
              background: 'linear-gradient(to right, rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ', 0) 0%,\n           rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ', 1) 100%)',
              boxShadow: this.props.shadow,
              borderRadius: this.props.radius
            },
            container: {
              position: 'relative',
              height: '100%',
              margin: '0 3px'
            },
            pointer: {
              position: 'absolute',
              left: rgb.a * 100 + '%'
            },
            slider: {
              width: '4px',
              borderRadius: '1px',
              height: '8px',
              boxShadow: '0 0 2px rgba(0, 0, 0, .6)',
              background: '#fff',
              marginTop: '1px',
              transform: 'translateX(-2px)'
            }
          },
          'vertical': {
            gradient: {
              background: 'linear-gradient(to bottom, rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ', 0) 0%,\n           rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ', 1) 100%)'
            },
            pointer: {
              left: 0,
              top: rgb.a * 100 + '%'
            }
          },
          'overwrite': _extends({}, this.props.style)
        }, {
          vertical: this.props.direction === 'vertical',
          overwrite: true
        });
  
        return _react2.default.createElement(
          'div',
          { style: styles.alpha },
          _react2.default.createElement(
            'div',
            { style: styles.checkboard },
            _react2.default.createElement(_Checkboard2.default, { renderers: this.props.renderers })
          ),
          _react2.default.createElement('div', { style: styles.gradient }),
          _react2.default.createElement(
            'div',
            {
              style: styles.container,
              ref: function ref(container) {
                return _this2.container = container;
              },
              onMouseDown: this.handleMouseDown,
              onTouchMove: this.handleChange,
              onTouchStart: this.handleChange
            },
            _react2.default.createElement(
              'div',
              { style: styles.pointer },
              this.props.pointer ? _react2.default.createElement(this.props.pointer, this.props) : _react2.default.createElement('div', { style: styles.slider })
            )
          )
        );
      }
    }]);
  
    return Alpha;
  }(_react.PureComponent || _react.Component);
  
  exports.default = Alpha;

});

;/*!node_modules/react-color/lib/components/common/EditableInput.js*/
amis.define('75321d6', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.EditableInput = undefined;
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var DEFAULT_ARROW_OFFSET = 1;
  
  var UP_KEY_CODE = 38;
  var DOWN_KEY_CODE = 40;
  var VALID_KEY_CODES = [UP_KEY_CODE, DOWN_KEY_CODE];
  var isValidKeyCode = function isValidKeyCode(keyCode) {
    return VALID_KEY_CODES.indexOf(keyCode) > -1;
  };
  var getNumberValue = function getNumberValue(value) {
    return Number(String(value).replace(/%/g, ''));
  };
  
  var idCounter = 1;
  
  var EditableInput = exports.EditableInput = function (_ref) {
    _inherits(EditableInput, _ref);
  
    function EditableInput(props) {
      _classCallCheck(this, EditableInput);
  
      var _this = _possibleConstructorReturn(this, (EditableInput.__proto__ || Object.getPrototypeOf(EditableInput)).call(this));
  
      _this.handleBlur = function () {
        if (_this.state.blurValue) {
          _this.setState({ value: _this.state.blurValue, blurValue: null });
        }
      };
  
      _this.handleChange = function (e) {
        _this.setUpdatedValue(e.target.value, e);
      };
  
      _this.handleKeyDown = function (e) {
        // In case `e.target.value` is a percentage remove the `%` character
        // and update accordingly with a percentage
        // https://github.com/casesandberg/react-color/issues/383
        var value = getNumberValue(e.target.value);
        if (!isNaN(value) && isValidKeyCode(e.keyCode)) {
          var offset = _this.getArrowOffset();
          var updatedValue = e.keyCode === UP_KEY_CODE ? value + offset : value - offset;
  
          _this.setUpdatedValue(updatedValue, e);
        }
      };
  
      _this.handleDrag = function (e) {
        if (_this.props.dragLabel) {
          var newValue = Math.round(_this.props.value + e.movementX);
          if (newValue >= 0 && newValue <= _this.props.dragMax) {
            _this.props.onChange && _this.props.onChange(_this.getValueObjectWithLabel(newValue), e);
          }
        }
      };
  
      _this.handleMouseDown = function (e) {
        if (_this.props.dragLabel) {
          e.preventDefault();
          _this.handleDrag(e);
          window.addEventListener('mousemove', _this.handleDrag);
          window.addEventListener('mouseup', _this.handleMouseUp);
        }
      };
  
      _this.handleMouseUp = function () {
        _this.unbindEventListeners();
      };
  
      _this.unbindEventListeners = function () {
        window.removeEventListener('mousemove', _this.handleDrag);
        window.removeEventListener('mouseup', _this.handleMouseUp);
      };
  
      _this.state = {
        value: String(props.value).toUpperCase(),
        blurValue: String(props.value).toUpperCase()
      };
  
      _this.inputId = 'rc-editable-input-' + idCounter++;
      return _this;
    }
  
    _createClass(EditableInput, [{
      key: 'componentDidUpdate',
      value: function componentDidUpdate(prevProps, prevState) {
        if (this.props.value !== this.state.value && (prevProps.value !== this.props.value || prevState.value !== this.state.value)) {
          if (this.input === document.activeElement) {
            this.setState({ blurValue: String(this.props.value).toUpperCase() });
          } else {
            this.setState({ value: String(this.props.value).toUpperCase(), blurValue: !this.state.blurValue && String(this.props.value).toUpperCase() });
          }
        }
      }
    }, {
      key: 'componentWillUnmount',
      value: function componentWillUnmount() {
        this.unbindEventListeners();
      }
    }, {
      key: 'getValueObjectWithLabel',
      value: function getValueObjectWithLabel(value) {
        return _defineProperty({}, this.props.label, value);
      }
    }, {
      key: 'getArrowOffset',
      value: function getArrowOffset() {
        return this.props.arrowOffset || DEFAULT_ARROW_OFFSET;
      }
    }, {
      key: 'setUpdatedValue',
      value: function setUpdatedValue(value, e) {
        var onChangeValue = this.props.label ? this.getValueObjectWithLabel(value) : value;
        this.props.onChange && this.props.onChange(onChangeValue, e);
  
        this.setState({ value: value });
      }
    }, {
      key: 'render',
      value: function render() {
        var _this2 = this;
  
        var styles = (0, _reactcss2.default)({
          'default': {
            wrap: {
              position: 'relative'
            }
          },
          'user-override': {
            wrap: this.props.style && this.props.style.wrap ? this.props.style.wrap : {},
            input: this.props.style && this.props.style.input ? this.props.style.input : {},
            label: this.props.style && this.props.style.label ? this.props.style.label : {}
          },
          'dragLabel-true': {
            label: {
              cursor: 'ew-resize'
            }
          }
        }, {
          'user-override': true
        }, this.props);
  
        return _react2.default.createElement(
          'div',
          { style: styles.wrap },
          _react2.default.createElement('input', {
            id: this.inputId,
            style: styles.input,
            ref: function ref(input) {
              return _this2.input = input;
            },
            value: this.state.value,
            onKeyDown: this.handleKeyDown,
            onChange: this.handleChange,
            onBlur: this.handleBlur,
            placeholder: this.props.placeholder,
            spellCheck: 'false'
          }),
          this.props.label && !this.props.hideLabel ? _react2.default.createElement(
            'label',
            {
              htmlFor: this.inputId,
              style: styles.label,
              onMouseDown: this.handleMouseDown
            },
            this.props.label
          ) : null
        );
      }
    }]);
  
    return EditableInput;
  }(_react.PureComponent || _react.Component);
  
  exports.default = EditableInput;

});

;/*!node_modules/react-color/lib/helpers/hue.js*/
amis.define('1665623', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var calculateChange = exports.calculateChange = function calculateChange(e, direction, hsl, container) {
    var containerWidth = container.clientWidth;
    var containerHeight = container.clientHeight;
    var x = typeof e.pageX === 'number' ? e.pageX : e.touches[0].pageX;
    var y = typeof e.pageY === 'number' ? e.pageY : e.touches[0].pageY;
    var left = x - (container.getBoundingClientRect().left + window.pageXOffset);
    var top = y - (container.getBoundingClientRect().top + window.pageYOffset);
  
    if (direction === 'vertical') {
      var h = void 0;
      if (top < 0) {
        h = 359;
      } else if (top > containerHeight) {
        h = 0;
      } else {
        var percent = -(top * 100 / containerHeight) + 100;
        h = 360 * percent / 100;
      }
  
      if (hsl.h !== h) {
        return {
          h: h,
          s: hsl.s,
          l: hsl.l,
          a: hsl.a,
          source: 'hsl'
        };
      }
    } else {
      var _h = void 0;
      if (left < 0) {
        _h = 0;
      } else if (left > containerWidth) {
        _h = 359;
      } else {
        var _percent = left * 100 / containerWidth;
        _h = 360 * _percent / 100;
      }
  
      if (hsl.h !== _h) {
        return {
          h: _h,
          s: hsl.s,
          l: hsl.l,
          a: hsl.a,
          source: 'hsl'
        };
      }
    }
    return null;
  };

});

;/*!node_modules/react-color/lib/components/common/Hue.js*/
amis.define('4e680b6', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Hue = undefined;
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _hue = require('1665623');
  
  var hue = _interopRequireWildcard(_hue);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var Hue = exports.Hue = function (_ref) {
    _inherits(Hue, _ref);
  
    function Hue() {
      var _ref2;
  
      var _temp, _this, _ret;
  
      _classCallCheck(this, Hue);
  
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
  
      return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref2 = Hue.__proto__ || Object.getPrototypeOf(Hue)).call.apply(_ref2, [this].concat(args))), _this), _this.handleChange = function (e) {
        var change = hue.calculateChange(e, _this.props.direction, _this.props.hsl, _this.container);
        change && typeof _this.props.onChange === 'function' && _this.props.onChange(change, e);
      }, _this.handleMouseDown = function (e) {
        _this.handleChange(e);
        window.addEventListener('mousemove', _this.handleChange);
        window.addEventListener('mouseup', _this.handleMouseUp);
      }, _this.handleMouseUp = function () {
        _this.unbindEventListeners();
      }, _temp), _possibleConstructorReturn(_this, _ret);
    }
  
    _createClass(Hue, [{
      key: 'componentWillUnmount',
      value: function componentWillUnmount() {
        this.unbindEventListeners();
      }
    }, {
      key: 'unbindEventListeners',
      value: function unbindEventListeners() {
        window.removeEventListener('mousemove', this.handleChange);
        window.removeEventListener('mouseup', this.handleMouseUp);
      }
    }, {
      key: 'render',
      value: function render() {
        var _this2 = this;
  
        var _props$direction = this.props.direction,
            direction = _props$direction === undefined ? 'horizontal' : _props$direction;
  
  
        var styles = (0, _reactcss2.default)({
          'default': {
            hue: {
              absolute: '0px 0px 0px 0px',
              borderRadius: this.props.radius,
              boxShadow: this.props.shadow
            },
            container: {
              padding: '0 2px',
              position: 'relative',
              height: '100%',
              borderRadius: this.props.radius
            },
            pointer: {
              position: 'absolute',
              left: this.props.hsl.h * 100 / 360 + '%'
            },
            slider: {
              marginTop: '1px',
              width: '4px',
              borderRadius: '1px',
              height: '8px',
              boxShadow: '0 0 2px rgba(0, 0, 0, .6)',
              background: '#fff',
              transform: 'translateX(-2px)'
            }
          },
          'vertical': {
            pointer: {
              left: '0px',
              top: -(this.props.hsl.h * 100 / 360) + 100 + '%'
            }
          }
        }, { vertical: direction === 'vertical' });
  
        return _react2.default.createElement(
          'div',
          { style: styles.hue },
          _react2.default.createElement(
            'div',
            {
              className: 'hue-' + direction,
              style: styles.container,
              ref: function ref(container) {
                return _this2.container = container;
              },
              onMouseDown: this.handleMouseDown,
              onTouchMove: this.handleChange,
              onTouchStart: this.handleChange
            },
            _react2.default.createElement(
              'style',
              null,
              '\n            .hue-horizontal {\n              background: linear-gradient(to right, #f00 0%, #ff0 17%, #0f0\n                33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n              background: -webkit-linear-gradient(to right, #f00 0%, #ff0\n                17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n            }\n\n            .hue-vertical {\n              background: linear-gradient(to top, #f00 0%, #ff0 17%, #0f0 33%,\n                #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n              background: -webkit-linear-gradient(to top, #f00 0%, #ff0 17%,\n                #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, #f00 100%);\n            }\n          '
            ),
            _react2.default.createElement(
              'div',
              { style: styles.pointer },
              this.props.pointer ? _react2.default.createElement(this.props.pointer, this.props) : _react2.default.createElement('div', { style: styles.slider })
            )
          )
        );
      }
    }]);
  
    return Hue;
  }(_react.PureComponent || _react.Component);
  
  exports.default = Hue;

});

;/*!node_modules/react-color/lib/components/common/Raised.js*/
amis.define('085c23f', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Raised = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Raised = exports.Raised = function Raised(_ref) {
    var zDepth = _ref.zDepth,
        radius = _ref.radius,
        background = _ref.background,
        children = _ref.children,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        wrap: {
          position: 'relative',
          display: 'inline-block'
        },
        content: {
          position: 'relative'
        },
        bg: {
          absolute: '0px 0px 0px 0px',
          boxShadow: '0 ' + zDepth + 'px ' + zDepth * 4 + 'px rgba(0,0,0,.24)',
          borderRadius: radius,
          background: background
        }
      },
      'zDepth-0': {
        bg: {
          boxShadow: 'none'
        }
      },
  
      'zDepth-1': {
        bg: {
          boxShadow: '0 2px 10px rgba(0,0,0,.12), 0 2px 5px rgba(0,0,0,.16)'
        }
      },
      'zDepth-2': {
        bg: {
          boxShadow: '0 6px 20px rgba(0,0,0,.19), 0 8px 17px rgba(0,0,0,.2)'
        }
      },
      'zDepth-3': {
        bg: {
          boxShadow: '0 17px 50px rgba(0,0,0,.19), 0 12px 15px rgba(0,0,0,.24)'
        }
      },
      'zDepth-4': {
        bg: {
          boxShadow: '0 25px 55px rgba(0,0,0,.21), 0 16px 28px rgba(0,0,0,.22)'
        }
      },
      'zDepth-5': {
        bg: {
          boxShadow: '0 40px 77px rgba(0,0,0,.22), 0 27px 24px rgba(0,0,0,.2)'
        }
      },
      'square': {
        bg: {
          borderRadius: '0'
        }
      },
      'circle': {
        bg: {
          borderRadius: '50%'
        }
      }
    }, passedStyles), { 'zDepth-1': zDepth === 1 });
  
    return _react2.default.createElement(
      'div',
      { style: styles.wrap },
      _react2.default.createElement('div', { style: styles.bg }),
      _react2.default.createElement(
        'div',
        { style: styles.content },
        children
      )
    );
  };
  
  Raised.propTypes = {
    background: _propTypes2.default.string,
    zDepth: _propTypes2.default.oneOf([0, 1, 2, 3, 4, 5]),
    radius: _propTypes2.default.number,
    styles: _propTypes2.default.object
  };
  
  Raised.defaultProps = {
    background: '#fff',
    zDepth: 1,
    radius: 2,
    styles: {}
  };
  
  exports.default = Raised;

});

;/*!node_modules/react-color/lib/helpers/saturation.js*/
amis.define('b59cf5f', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  var calculateChange = exports.calculateChange = function calculateChange(e, hsl, container) {
    var _container$getBoundin = container.getBoundingClientRect(),
        containerWidth = _container$getBoundin.width,
        containerHeight = _container$getBoundin.height;
  
    var x = typeof e.pageX === 'number' ? e.pageX : e.touches[0].pageX;
    var y = typeof e.pageY === 'number' ? e.pageY : e.touches[0].pageY;
    var left = x - (container.getBoundingClientRect().left + window.pageXOffset);
    var top = y - (container.getBoundingClientRect().top + window.pageYOffset);
  
    if (left < 0) {
      left = 0;
    } else if (left > containerWidth) {
      left = containerWidth;
    }
  
    if (top < 0) {
      top = 0;
    } else if (top > containerHeight) {
      top = containerHeight;
    }
  
    var saturation = left / containerWidth;
    var bright = 1 - top / containerHeight;
  
    return {
      h: hsl.h,
      s: saturation,
      v: bright,
      a: hsl.a,
      source: 'hsv'
    };
  };

});

;/*!node_modules/react-color/lib/components/common/Saturation.js*/
amis.define('94f50b6', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Saturation = undefined;
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _throttle = require('0bcbeb9');
  
  var _throttle2 = _interopRequireDefault(_throttle);
  
  var _saturation = require('b59cf5f');
  
  var saturation = _interopRequireWildcard(_saturation);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var Saturation = exports.Saturation = function (_ref) {
    _inherits(Saturation, _ref);
  
    function Saturation(props) {
      _classCallCheck(this, Saturation);
  
      var _this = _possibleConstructorReturn(this, (Saturation.__proto__ || Object.getPrototypeOf(Saturation)).call(this, props));
  
      _this.handleChange = function (e) {
        typeof _this.props.onChange === 'function' && _this.throttle(_this.props.onChange, saturation.calculateChange(e, _this.props.hsl, _this.container), e);
      };
  
      _this.handleMouseDown = function (e) {
        _this.handleChange(e);
        var renderWindow = _this.getContainerRenderWindow();
        renderWindow.addEventListener('mousemove', _this.handleChange);
        renderWindow.addEventListener('mouseup', _this.handleMouseUp);
      };
  
      _this.handleMouseUp = function () {
        _this.unbindEventListeners();
      };
  
      _this.throttle = (0, _throttle2.default)(function (fn, data, e) {
        fn(data, e);
      }, 50);
      return _this;
    }
  
    _createClass(Saturation, [{
      key: 'componentWillUnmount',
      value: function componentWillUnmount() {
        this.throttle.cancel();
        this.unbindEventListeners();
      }
    }, {
      key: 'getContainerRenderWindow',
      value: function getContainerRenderWindow() {
        var container = this.container;
  
        var renderWindow = window;
        while (!renderWindow.document.contains(container) && renderWindow.parent !== renderWindow) {
          renderWindow = renderWindow.parent;
        }
        return renderWindow;
      }
    }, {
      key: 'unbindEventListeners',
      value: function unbindEventListeners() {
        var renderWindow = this.getContainerRenderWindow();
        renderWindow.removeEventListener('mousemove', this.handleChange);
        renderWindow.removeEventListener('mouseup', this.handleMouseUp);
      }
    }, {
      key: 'render',
      value: function render() {
        var _this2 = this;
  
        var _ref2 = this.props.style || {},
            color = _ref2.color,
            white = _ref2.white,
            black = _ref2.black,
            pointer = _ref2.pointer,
            circle = _ref2.circle;
  
        var styles = (0, _reactcss2.default)({
          'default': {
            color: {
              absolute: '0px 0px 0px 0px',
              background: 'hsl(' + this.props.hsl.h + ',100%, 50%)',
              borderRadius: this.props.radius
            },
            white: {
              absolute: '0px 0px 0px 0px',
              borderRadius: this.props.radius
            },
            black: {
              absolute: '0px 0px 0px 0px',
              boxShadow: this.props.shadow,
              borderRadius: this.props.radius
            },
            pointer: {
              position: 'absolute',
              top: -(this.props.hsv.v * 100) + 100 + '%',
              left: this.props.hsv.s * 100 + '%',
              cursor: 'default'
            },
            circle: {
              width: '4px',
              height: '4px',
              boxShadow: '0 0 0 1.5px #fff, inset 0 0 1px 1px rgba(0,0,0,.3),\n            0 0 1px 2px rgba(0,0,0,.4)',
              borderRadius: '50%',
              cursor: 'hand',
              transform: 'translate(-2px, -2px)'
            }
          },
          'custom': {
            color: color,
            white: white,
            black: black,
            pointer: pointer,
            circle: circle
          }
        }, { 'custom': !!this.props.style });
  
        return _react2.default.createElement(
          'div',
          {
            style: styles.color,
            ref: function ref(container) {
              return _this2.container = container;
            },
            onMouseDown: this.handleMouseDown,
            onTouchMove: this.handleChange,
            onTouchStart: this.handleChange
          },
          _react2.default.createElement(
            'style',
            null,
            '\n          .saturation-white {\n            background: -webkit-linear-gradient(to right, #fff, rgba(255,255,255,0));\n            background: linear-gradient(to right, #fff, rgba(255,255,255,0));\n          }\n          .saturation-black {\n            background: -webkit-linear-gradient(to top, #000, rgba(0,0,0,0));\n            background: linear-gradient(to top, #000, rgba(0,0,0,0));\n          }\n        '
          ),
          _react2.default.createElement(
            'div',
            { style: styles.white, className: 'saturation-white' },
            _react2.default.createElement('div', { style: styles.black, className: 'saturation-black' }),
            _react2.default.createElement(
              'div',
              { style: styles.pointer },
              this.props.pointer ? _react2.default.createElement(this.props.pointer, this.props) : _react2.default.createElement('div', { style: styles.circle })
            )
          )
        );
      }
    }]);
  
    return Saturation;
  }(_react.PureComponent || _react.Component);
  
  exports.default = Saturation;

});

;/*!node_modules/tinycolor2/cjs/tinycolor.js*/
amis.define('dcff141', function(require, exports, module, define) {

  // This file is autogenerated. It's used to publish CJS to npm.
  (function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
    typeof define === 'function' && define.amd ? define(factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.tinycolor = factory());
  })(this, (function () { 'use strict';
  
    function _typeof(obj) {
      "@babel/helpers - typeof";
  
      return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
        return typeof obj;
      } : function (obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      }, _typeof(obj);
    }
  
    // https://github.com/bgrins/TinyColor
    // Brian Grinstead, MIT License
  
    var trimLeft = /^\s+/;
    var trimRight = /\s+$/;
    function tinycolor(color, opts) {
      color = color ? color : "";
      opts = opts || {};
  
      // If input is already a tinycolor, return itself
      if (color instanceof tinycolor) {
        return color;
      }
      // If we are called as a function, call using new instead
      if (!(this instanceof tinycolor)) {
        return new tinycolor(color, opts);
      }
      var rgb = inputToRGB(color);
      this._originalInput = color, this._r = rgb.r, this._g = rgb.g, this._b = rgb.b, this._a = rgb.a, this._roundA = Math.round(100 * this._a) / 100, this._format = opts.format || rgb.format;
      this._gradientType = opts.gradientType;
  
      // Don't let the range of [0,255] come back in [0,1].
      // Potentially lose a little bit of precision here, but will fix issues where
      // .5 gets interpreted as half of the total, instead of half of 1
      // If it was supposed to be 128, this was already taken care of by `inputToRgb`
      if (this._r < 1) this._r = Math.round(this._r);
      if (this._g < 1) this._g = Math.round(this._g);
      if (this._b < 1) this._b = Math.round(this._b);
      this._ok = rgb.ok;
    }
    tinycolor.prototype = {
      isDark: function isDark() {
        return this.getBrightness() < 128;
      },
      isLight: function isLight() {
        return !this.isDark();
      },
      isValid: function isValid() {
        return this._ok;
      },
      getOriginalInput: function getOriginalInput() {
        return this._originalInput;
      },
      getFormat: function getFormat() {
        return this._format;
      },
      getAlpha: function getAlpha() {
        return this._a;
      },
      getBrightness: function getBrightness() {
        //http://www.w3.org/TR/AERT#color-contrast
        var rgb = this.toRgb();
        return (rgb.r * 299 + rgb.g * 587 + rgb.b * 114) / 1000;
      },
      getLuminance: function getLuminance() {
        //http://www.w3.org/TR/2008/REC-WCAG20-20081211/#relativeluminancedef
        var rgb = this.toRgb();
        var RsRGB, GsRGB, BsRGB, R, G, B;
        RsRGB = rgb.r / 255;
        GsRGB = rgb.g / 255;
        BsRGB = rgb.b / 255;
        if (RsRGB <= 0.03928) R = RsRGB / 12.92;else R = Math.pow((RsRGB + 0.055) / 1.055, 2.4);
        if (GsRGB <= 0.03928) G = GsRGB / 12.92;else G = Math.pow((GsRGB + 0.055) / 1.055, 2.4);
        if (BsRGB <= 0.03928) B = BsRGB / 12.92;else B = Math.pow((BsRGB + 0.055) / 1.055, 2.4);
        return 0.2126 * R + 0.7152 * G + 0.0722 * B;
      },
      setAlpha: function setAlpha(value) {
        this._a = boundAlpha(value);
        this._roundA = Math.round(100 * this._a) / 100;
        return this;
      },
      toHsv: function toHsv() {
        var hsv = rgbToHsv(this._r, this._g, this._b);
        return {
          h: hsv.h * 360,
          s: hsv.s,
          v: hsv.v,
          a: this._a
        };
      },
      toHsvString: function toHsvString() {
        var hsv = rgbToHsv(this._r, this._g, this._b);
        var h = Math.round(hsv.h * 360),
          s = Math.round(hsv.s * 100),
          v = Math.round(hsv.v * 100);
        return this._a == 1 ? "hsv(" + h + ", " + s + "%, " + v + "%)" : "hsva(" + h + ", " + s + "%, " + v + "%, " + this._roundA + ")";
      },
      toHsl: function toHsl() {
        var hsl = rgbToHsl(this._r, this._g, this._b);
        return {
          h: hsl.h * 360,
          s: hsl.s,
          l: hsl.l,
          a: this._a
        };
      },
      toHslString: function toHslString() {
        var hsl = rgbToHsl(this._r, this._g, this._b);
        var h = Math.round(hsl.h * 360),
          s = Math.round(hsl.s * 100),
          l = Math.round(hsl.l * 100);
        return this._a == 1 ? "hsl(" + h + ", " + s + "%, " + l + "%)" : "hsla(" + h + ", " + s + "%, " + l + "%, " + this._roundA + ")";
      },
      toHex: function toHex(allow3Char) {
        return rgbToHex(this._r, this._g, this._b, allow3Char);
      },
      toHexString: function toHexString(allow3Char) {
        return "#" + this.toHex(allow3Char);
      },
      toHex8: function toHex8(allow4Char) {
        return rgbaToHex(this._r, this._g, this._b, this._a, allow4Char);
      },
      toHex8String: function toHex8String(allow4Char) {
        return "#" + this.toHex8(allow4Char);
      },
      toRgb: function toRgb() {
        return {
          r: Math.round(this._r),
          g: Math.round(this._g),
          b: Math.round(this._b),
          a: this._a
        };
      },
      toRgbString: function toRgbString() {
        return this._a == 1 ? "rgb(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ")" : "rgba(" + Math.round(this._r) + ", " + Math.round(this._g) + ", " + Math.round(this._b) + ", " + this._roundA + ")";
      },
      toPercentageRgb: function toPercentageRgb() {
        return {
          r: Math.round(bound01(this._r, 255) * 100) + "%",
          g: Math.round(bound01(this._g, 255) * 100) + "%",
          b: Math.round(bound01(this._b, 255) * 100) + "%",
          a: this._a
        };
      },
      toPercentageRgbString: function toPercentageRgbString() {
        return this._a == 1 ? "rgb(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%)" : "rgba(" + Math.round(bound01(this._r, 255) * 100) + "%, " + Math.round(bound01(this._g, 255) * 100) + "%, " + Math.round(bound01(this._b, 255) * 100) + "%, " + this._roundA + ")";
      },
      toName: function toName() {
        if (this._a === 0) {
          return "transparent";
        }
        if (this._a < 1) {
          return false;
        }
        return hexNames[rgbToHex(this._r, this._g, this._b, true)] || false;
      },
      toFilter: function toFilter(secondColor) {
        var hex8String = "#" + rgbaToArgbHex(this._r, this._g, this._b, this._a);
        var secondHex8String = hex8String;
        var gradientType = this._gradientType ? "GradientType = 1, " : "";
        if (secondColor) {
          var s = tinycolor(secondColor);
          secondHex8String = "#" + rgbaToArgbHex(s._r, s._g, s._b, s._a);
        }
        return "progid:DXImageTransform.Microsoft.gradient(" + gradientType + "startColorstr=" + hex8String + ",endColorstr=" + secondHex8String + ")";
      },
      toString: function toString(format) {
        var formatSet = !!format;
        format = format || this._format;
        var formattedString = false;
        var hasAlpha = this._a < 1 && this._a >= 0;
        var needsAlphaFormat = !formatSet && hasAlpha && (format === "hex" || format === "hex6" || format === "hex3" || format === "hex4" || format === "hex8" || format === "name");
        if (needsAlphaFormat) {
          // Special case for "transparent", all other non-alpha formats
          // will return rgba when there is transparency.
          if (format === "name" && this._a === 0) {
            return this.toName();
          }
          return this.toRgbString();
        }
        if (format === "rgb") {
          formattedString = this.toRgbString();
        }
        if (format === "prgb") {
          formattedString = this.toPercentageRgbString();
        }
        if (format === "hex" || format === "hex6") {
          formattedString = this.toHexString();
        }
        if (format === "hex3") {
          formattedString = this.toHexString(true);
        }
        if (format === "hex4") {
          formattedString = this.toHex8String(true);
        }
        if (format === "hex8") {
          formattedString = this.toHex8String();
        }
        if (format === "name") {
          formattedString = this.toName();
        }
        if (format === "hsl") {
          formattedString = this.toHslString();
        }
        if (format === "hsv") {
          formattedString = this.toHsvString();
        }
        return formattedString || this.toHexString();
      },
      clone: function clone() {
        return tinycolor(this.toString());
      },
      _applyModification: function _applyModification(fn, args) {
        var color = fn.apply(null, [this].concat([].slice.call(args)));
        this._r = color._r;
        this._g = color._g;
        this._b = color._b;
        this.setAlpha(color._a);
        return this;
      },
      lighten: function lighten() {
        return this._applyModification(_lighten, arguments);
      },
      brighten: function brighten() {
        return this._applyModification(_brighten, arguments);
      },
      darken: function darken() {
        return this._applyModification(_darken, arguments);
      },
      desaturate: function desaturate() {
        return this._applyModification(_desaturate, arguments);
      },
      saturate: function saturate() {
        return this._applyModification(_saturate, arguments);
      },
      greyscale: function greyscale() {
        return this._applyModification(_greyscale, arguments);
      },
      spin: function spin() {
        return this._applyModification(_spin, arguments);
      },
      _applyCombination: function _applyCombination(fn, args) {
        return fn.apply(null, [this].concat([].slice.call(args)));
      },
      analogous: function analogous() {
        return this._applyCombination(_analogous, arguments);
      },
      complement: function complement() {
        return this._applyCombination(_complement, arguments);
      },
      monochromatic: function monochromatic() {
        return this._applyCombination(_monochromatic, arguments);
      },
      splitcomplement: function splitcomplement() {
        return this._applyCombination(_splitcomplement, arguments);
      },
      // Disabled until https://github.com/bgrins/TinyColor/issues/254
      // polyad: function (number) {
      //   return this._applyCombination(polyad, [number]);
      // },
      triad: function triad() {
        return this._applyCombination(polyad, [3]);
      },
      tetrad: function tetrad() {
        return this._applyCombination(polyad, [4]);
      }
    };
  
    // If input is an object, force 1 into "1.0" to handle ratios properly
    // String input requires "1.0" as input, so 1 will be treated as 1
    tinycolor.fromRatio = function (color, opts) {
      if (_typeof(color) == "object") {
        var newColor = {};
        for (var i in color) {
          if (color.hasOwnProperty(i)) {
            if (i === "a") {
              newColor[i] = color[i];
            } else {
              newColor[i] = convertToPercentage(color[i]);
            }
          }
        }
        color = newColor;
      }
      return tinycolor(color, opts);
    };
  
    // Given a string or object, convert that input to RGB
    // Possible string inputs:
    //
    //     "red"
    //     "#f00" or "f00"
    //     "#ff0000" or "ff0000"
    //     "#ff000000" or "ff000000"
    //     "rgb 255 0 0" or "rgb (255, 0, 0)"
    //     "rgb 1.0 0 0" or "rgb (1, 0, 0)"
    //     "rgba (255, 0, 0, 1)" or "rgba 255, 0, 0, 1"
    //     "rgba (1.0, 0, 0, 1)" or "rgba 1.0, 0, 0, 1"
    //     "hsl(0, 100%, 50%)" or "hsl 0 100% 50%"
    //     "hsla(0, 100%, 50%, 1)" or "hsla 0 100% 50%, 1"
    //     "hsv(0, 100%, 100%)" or "hsv 0 100% 100%"
    //
    function inputToRGB(color) {
      var rgb = {
        r: 0,
        g: 0,
        b: 0
      };
      var a = 1;
      var s = null;
      var v = null;
      var l = null;
      var ok = false;
      var format = false;
      if (typeof color == "string") {
        color = stringInputToObject(color);
      }
      if (_typeof(color) == "object") {
        if (isValidCSSUnit(color.r) && isValidCSSUnit(color.g) && isValidCSSUnit(color.b)) {
          rgb = rgbToRgb(color.r, color.g, color.b);
          ok = true;
          format = String(color.r).substr(-1) === "%" ? "prgb" : "rgb";
        } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.v)) {
          s = convertToPercentage(color.s);
          v = convertToPercentage(color.v);
          rgb = hsvToRgb(color.h, s, v);
          ok = true;
          format = "hsv";
        } else if (isValidCSSUnit(color.h) && isValidCSSUnit(color.s) && isValidCSSUnit(color.l)) {
          s = convertToPercentage(color.s);
          l = convertToPercentage(color.l);
          rgb = hslToRgb(color.h, s, l);
          ok = true;
          format = "hsl";
        }
        if (color.hasOwnProperty("a")) {
          a = color.a;
        }
      }
      a = boundAlpha(a);
      return {
        ok: ok,
        format: color.format || format,
        r: Math.min(255, Math.max(rgb.r, 0)),
        g: Math.min(255, Math.max(rgb.g, 0)),
        b: Math.min(255, Math.max(rgb.b, 0)),
        a: a
      };
    }
  
    // Conversion Functions
    // --------------------
  
    // `rgbToHsl`, `rgbToHsv`, `hslToRgb`, `hsvToRgb` modified from:
    // <http://mjijackson.com/2008/02/rgb-to-hsl-and-rgb-to-hsv-color-model-conversion-algorithms-in-javascript>
  
    // `rgbToRgb`
    // Handle bounds / percentage checking to conform to CSS color spec
    // <http://www.w3.org/TR/css3-color/>
    // *Assumes:* r, g, b in [0, 255] or [0, 1]
    // *Returns:* { r, g, b } in [0, 255]
    function rgbToRgb(r, g, b) {
      return {
        r: bound01(r, 255) * 255,
        g: bound01(g, 255) * 255,
        b: bound01(b, 255) * 255
      };
    }
  
    // `rgbToHsl`
    // Converts an RGB color value to HSL.
    // *Assumes:* r, g, and b are contained in [0, 255] or [0, 1]
    // *Returns:* { h, s, l } in [0,1]
    function rgbToHsl(r, g, b) {
      r = bound01(r, 255);
      g = bound01(g, 255);
      b = bound01(b, 255);
      var max = Math.max(r, g, b),
        min = Math.min(r, g, b);
      var h,
        s,
        l = (max + min) / 2;
      if (max == min) {
        h = s = 0; // achromatic
      } else {
        var d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r:
            h = (g - b) / d + (g < b ? 6 : 0);
            break;
          case g:
            h = (b - r) / d + 2;
            break;
          case b:
            h = (r - g) / d + 4;
            break;
        }
        h /= 6;
      }
      return {
        h: h,
        s: s,
        l: l
      };
    }
  
    // `hslToRgb`
    // Converts an HSL color value to RGB.
    // *Assumes:* h is contained in [0, 1] or [0, 360] and s and l are contained [0, 1] or [0, 100]
    // *Returns:* { r, g, b } in the set [0, 255]
    function hslToRgb(h, s, l) {
      var r, g, b;
      h = bound01(h, 360);
      s = bound01(s, 100);
      l = bound01(l, 100);
      function hue2rgb(p, q, t) {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1 / 6) return p + (q - p) * 6 * t;
        if (t < 1 / 2) return q;
        if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
        return p;
      }
      if (s === 0) {
        r = g = b = l; // achromatic
      } else {
        var q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        var p = 2 * l - q;
        r = hue2rgb(p, q, h + 1 / 3);
        g = hue2rgb(p, q, h);
        b = hue2rgb(p, q, h - 1 / 3);
      }
      return {
        r: r * 255,
        g: g * 255,
        b: b * 255
      };
    }
  
    // `rgbToHsv`
    // Converts an RGB color value to HSV
    // *Assumes:* r, g, and b are contained in the set [0, 255] or [0, 1]
    // *Returns:* { h, s, v } in [0,1]
    function rgbToHsv(r, g, b) {
      r = bound01(r, 255);
      g = bound01(g, 255);
      b = bound01(b, 255);
      var max = Math.max(r, g, b),
        min = Math.min(r, g, b);
      var h,
        s,
        v = max;
      var d = max - min;
      s = max === 0 ? 0 : d / max;
      if (max == min) {
        h = 0; // achromatic
      } else {
        switch (max) {
          case r:
            h = (g - b) / d + (g < b ? 6 : 0);
            break;
          case g:
            h = (b - r) / d + 2;
            break;
          case b:
            h = (r - g) / d + 4;
            break;
        }
        h /= 6;
      }
      return {
        h: h,
        s: s,
        v: v
      };
    }
  
    // `hsvToRgb`
    // Converts an HSV color value to RGB.
    // *Assumes:* h is contained in [0, 1] or [0, 360] and s and v are contained in [0, 1] or [0, 100]
    // *Returns:* { r, g, b } in the set [0, 255]
    function hsvToRgb(h, s, v) {
      h = bound01(h, 360) * 6;
      s = bound01(s, 100);
      v = bound01(v, 100);
      var i = Math.floor(h),
        f = h - i,
        p = v * (1 - s),
        q = v * (1 - f * s),
        t = v * (1 - (1 - f) * s),
        mod = i % 6,
        r = [v, q, p, p, t, v][mod],
        g = [t, v, v, q, p, p][mod],
        b = [p, p, t, v, v, q][mod];
      return {
        r: r * 255,
        g: g * 255,
        b: b * 255
      };
    }
  
    // `rgbToHex`
    // Converts an RGB color to hex
    // Assumes r, g, and b are contained in the set [0, 255]
    // Returns a 3 or 6 character hex
    function rgbToHex(r, g, b, allow3Char) {
      var hex = [pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16))];
  
      // Return a 3 character hex if possible
      if (allow3Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0);
      }
      return hex.join("");
    }
  
    // `rgbaToHex`
    // Converts an RGBA color plus alpha transparency to hex
    // Assumes r, g, b are contained in the set [0, 255] and
    // a in [0, 1]. Returns a 4 or 8 character rgba hex
    function rgbaToHex(r, g, b, a, allow4Char) {
      var hex = [pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16)), pad2(convertDecimalToHex(a))];
  
      // Return a 4 character hex if possible
      if (allow4Char && hex[0].charAt(0) == hex[0].charAt(1) && hex[1].charAt(0) == hex[1].charAt(1) && hex[2].charAt(0) == hex[2].charAt(1) && hex[3].charAt(0) == hex[3].charAt(1)) {
        return hex[0].charAt(0) + hex[1].charAt(0) + hex[2].charAt(0) + hex[3].charAt(0);
      }
      return hex.join("");
    }
  
    // `rgbaToArgbHex`
    // Converts an RGBA color to an ARGB Hex8 string
    // Rarely used, but required for "toFilter()"
    function rgbaToArgbHex(r, g, b, a) {
      var hex = [pad2(convertDecimalToHex(a)), pad2(Math.round(r).toString(16)), pad2(Math.round(g).toString(16)), pad2(Math.round(b).toString(16))];
      return hex.join("");
    }
  
    // `equals`
    // Can be called with any tinycolor input
    tinycolor.equals = function (color1, color2) {
      if (!color1 || !color2) return false;
      return tinycolor(color1).toRgbString() == tinycolor(color2).toRgbString();
    };
    tinycolor.random = function () {
      return tinycolor.fromRatio({
        r: Math.random(),
        g: Math.random(),
        b: Math.random()
      });
    };
  
    // Modification Functions
    // ----------------------
    // Thanks to less.js for some of the basics here
    // <https://github.com/cloudhead/less.js/blob/master/lib/less/functions.js>
  
    function _desaturate(color, amount) {
      amount = amount === 0 ? 0 : amount || 10;
      var hsl = tinycolor(color).toHsl();
      hsl.s -= amount / 100;
      hsl.s = clamp01(hsl.s);
      return tinycolor(hsl);
    }
    function _saturate(color, amount) {
      amount = amount === 0 ? 0 : amount || 10;
      var hsl = tinycolor(color).toHsl();
      hsl.s += amount / 100;
      hsl.s = clamp01(hsl.s);
      return tinycolor(hsl);
    }
    function _greyscale(color) {
      return tinycolor(color).desaturate(100);
    }
    function _lighten(color, amount) {
      amount = amount === 0 ? 0 : amount || 10;
      var hsl = tinycolor(color).toHsl();
      hsl.l += amount / 100;
      hsl.l = clamp01(hsl.l);
      return tinycolor(hsl);
    }
    function _brighten(color, amount) {
      amount = amount === 0 ? 0 : amount || 10;
      var rgb = tinycolor(color).toRgb();
      rgb.r = Math.max(0, Math.min(255, rgb.r - Math.round(255 * -(amount / 100))));
      rgb.g = Math.max(0, Math.min(255, rgb.g - Math.round(255 * -(amount / 100))));
      rgb.b = Math.max(0, Math.min(255, rgb.b - Math.round(255 * -(amount / 100))));
      return tinycolor(rgb);
    }
    function _darken(color, amount) {
      amount = amount === 0 ? 0 : amount || 10;
      var hsl = tinycolor(color).toHsl();
      hsl.l -= amount / 100;
      hsl.l = clamp01(hsl.l);
      return tinycolor(hsl);
    }
  
    // Spin takes a positive or negative amount within [-360, 360] indicating the change of hue.
    // Values outside of this range will be wrapped into this range.
    function _spin(color, amount) {
      var hsl = tinycolor(color).toHsl();
      var hue = (hsl.h + amount) % 360;
      hsl.h = hue < 0 ? 360 + hue : hue;
      return tinycolor(hsl);
    }
  
    // Combination Functions
    // ---------------------
    // Thanks to jQuery xColor for some of the ideas behind these
    // <https://github.com/infusion/jQuery-xcolor/blob/master/jquery.xcolor.js>
  
    function _complement(color) {
      var hsl = tinycolor(color).toHsl();
      hsl.h = (hsl.h + 180) % 360;
      return tinycolor(hsl);
    }
    function polyad(color, number) {
      if (isNaN(number) || number <= 0) {
        throw new Error("Argument to polyad must be a positive number");
      }
      var hsl = tinycolor(color).toHsl();
      var result = [tinycolor(color)];
      var step = 360 / number;
      for (var i = 1; i < number; i++) {
        result.push(tinycolor({
          h: (hsl.h + i * step) % 360,
          s: hsl.s,
          l: hsl.l
        }));
      }
      return result;
    }
    function _splitcomplement(color) {
      var hsl = tinycolor(color).toHsl();
      var h = hsl.h;
      return [tinycolor(color), tinycolor({
        h: (h + 72) % 360,
        s: hsl.s,
        l: hsl.l
      }), tinycolor({
        h: (h + 216) % 360,
        s: hsl.s,
        l: hsl.l
      })];
    }
    function _analogous(color, results, slices) {
      results = results || 6;
      slices = slices || 30;
      var hsl = tinycolor(color).toHsl();
      var part = 360 / slices;
      var ret = [tinycolor(color)];
      for (hsl.h = (hsl.h - (part * results >> 1) + 720) % 360; --results;) {
        hsl.h = (hsl.h + part) % 360;
        ret.push(tinycolor(hsl));
      }
      return ret;
    }
    function _monochromatic(color, results) {
      results = results || 6;
      var hsv = tinycolor(color).toHsv();
      var h = hsv.h,
        s = hsv.s,
        v = hsv.v;
      var ret = [];
      var modification = 1 / results;
      while (results--) {
        ret.push(tinycolor({
          h: h,
          s: s,
          v: v
        }));
        v = (v + modification) % 1;
      }
      return ret;
    }
  
    // Utility Functions
    // ---------------------
  
    tinycolor.mix = function (color1, color2, amount) {
      amount = amount === 0 ? 0 : amount || 50;
      var rgb1 = tinycolor(color1).toRgb();
      var rgb2 = tinycolor(color2).toRgb();
      var p = amount / 100;
      var rgba = {
        r: (rgb2.r - rgb1.r) * p + rgb1.r,
        g: (rgb2.g - rgb1.g) * p + rgb1.g,
        b: (rgb2.b - rgb1.b) * p + rgb1.b,
        a: (rgb2.a - rgb1.a) * p + rgb1.a
      };
      return tinycolor(rgba);
    };
  
    // Readability Functions
    // ---------------------
    // <http://www.w3.org/TR/2008/REC-WCAG20-20081211/#contrast-ratiodef (WCAG Version 2)
  
    // `contrast`
    // Analyze the 2 colors and returns the color contrast defined by (WCAG Version 2)
    tinycolor.readability = function (color1, color2) {
      var c1 = tinycolor(color1);
      var c2 = tinycolor(color2);
      return (Math.max(c1.getLuminance(), c2.getLuminance()) + 0.05) / (Math.min(c1.getLuminance(), c2.getLuminance()) + 0.05);
    };
  
    // `isReadable`
    // Ensure that foreground and background color combinations meet WCAG2 guidelines.
    // The third argument is an optional Object.
    //      the 'level' property states 'AA' or 'AAA' - if missing or invalid, it defaults to 'AA';
    //      the 'size' property states 'large' or 'small' - if missing or invalid, it defaults to 'small'.
    // If the entire object is absent, isReadable defaults to {level:"AA",size:"small"}.
  
    // *Example*
    //    tinycolor.isReadable("#000", "#111") => false
    //    tinycolor.isReadable("#000", "#111",{level:"AA",size:"large"}) => false
    tinycolor.isReadable = function (color1, color2, wcag2) {
      var readability = tinycolor.readability(color1, color2);
      var wcag2Parms, out;
      out = false;
      wcag2Parms = validateWCAG2Parms(wcag2);
      switch (wcag2Parms.level + wcag2Parms.size) {
        case "AAsmall":
        case "AAAlarge":
          out = readability >= 4.5;
          break;
        case "AAlarge":
          out = readability >= 3;
          break;
        case "AAAsmall":
          out = readability >= 7;
          break;
      }
      return out;
    };
  
    // `mostReadable`
    // Given a base color and a list of possible foreground or background
    // colors for that base, returns the most readable color.
    // Optionally returns Black or White if the most readable color is unreadable.
    // *Example*
    //    tinycolor.mostReadable(tinycolor.mostReadable("#123", ["#124", "#125"],{includeFallbackColors:false}).toHexString(); // "#112255"
    //    tinycolor.mostReadable(tinycolor.mostReadable("#123", ["#124", "#125"],{includeFallbackColors:true}).toHexString();  // "#ffffff"
    //    tinycolor.mostReadable("#a8015a", ["#faf3f3"],{includeFallbackColors:true,level:"AAA",size:"large"}).toHexString(); // "#faf3f3"
    //    tinycolor.mostReadable("#a8015a", ["#faf3f3"],{includeFallbackColors:true,level:"AAA",size:"small"}).toHexString(); // "#ffffff"
    tinycolor.mostReadable = function (baseColor, colorList, args) {
      var bestColor = null;
      var bestScore = 0;
      var readability;
      var includeFallbackColors, level, size;
      args = args || {};
      includeFallbackColors = args.includeFallbackColors;
      level = args.level;
      size = args.size;
      for (var i = 0; i < colorList.length; i++) {
        readability = tinycolor.readability(baseColor, colorList[i]);
        if (readability > bestScore) {
          bestScore = readability;
          bestColor = tinycolor(colorList[i]);
        }
      }
      if (tinycolor.isReadable(baseColor, bestColor, {
        level: level,
        size: size
      }) || !includeFallbackColors) {
        return bestColor;
      } else {
        args.includeFallbackColors = false;
        return tinycolor.mostReadable(baseColor, ["#fff", "#000"], args);
      }
    };
  
    // Big List of Colors
    // ------------------
    // <https://www.w3.org/TR/css-color-4/#named-colors>
    var names = tinycolor.names = {
      aliceblue: "f0f8ff",
      antiquewhite: "faebd7",
      aqua: "0ff",
      aquamarine: "7fffd4",
      azure: "f0ffff",
      beige: "f5f5dc",
      bisque: "ffe4c4",
      black: "000",
      blanchedalmond: "ffebcd",
      blue: "00f",
      blueviolet: "8a2be2",
      brown: "a52a2a",
      burlywood: "deb887",
      burntsienna: "ea7e5d",
      cadetblue: "5f9ea0",
      chartreuse: "7fff00",
      chocolate: "d2691e",
      coral: "ff7f50",
      cornflowerblue: "6495ed",
      cornsilk: "fff8dc",
      crimson: "dc143c",
      cyan: "0ff",
      darkblue: "00008b",
      darkcyan: "008b8b",
      darkgoldenrod: "b8860b",
      darkgray: "a9a9a9",
      darkgreen: "006400",
      darkgrey: "a9a9a9",
      darkkhaki: "bdb76b",
      darkmagenta: "8b008b",
      darkolivegreen: "556b2f",
      darkorange: "ff8c00",
      darkorchid: "9932cc",
      darkred: "8b0000",
      darksalmon: "e9967a",
      darkseagreen: "8fbc8f",
      darkslateblue: "483d8b",
      darkslategray: "2f4f4f",
      darkslategrey: "2f4f4f",
      darkturquoise: "00ced1",
      darkviolet: "9400d3",
      deeppink: "ff1493",
      deepskyblue: "00bfff",
      dimgray: "696969",
      dimgrey: "696969",
      dodgerblue: "1e90ff",
      firebrick: "b22222",
      floralwhite: "fffaf0",
      forestgreen: "228b22",
      fuchsia: "f0f",
      gainsboro: "dcdcdc",
      ghostwhite: "f8f8ff",
      gold: "ffd700",
      goldenrod: "daa520",
      gray: "808080",
      green: "008000",
      greenyellow: "adff2f",
      grey: "808080",
      honeydew: "f0fff0",
      hotpink: "ff69b4",
      indianred: "cd5c5c",
      indigo: "4b0082",
      ivory: "fffff0",
      khaki: "f0e68c",
      lavender: "e6e6fa",
      lavenderblush: "fff0f5",
      lawngreen: "7cfc00",
      lemonchiffon: "fffacd",
      lightblue: "add8e6",
      lightcoral: "f08080",
      lightcyan: "e0ffff",
      lightgoldenrodyellow: "fafad2",
      lightgray: "d3d3d3",
      lightgreen: "90ee90",
      lightgrey: "d3d3d3",
      lightpink: "ffb6c1",
      lightsalmon: "ffa07a",
      lightseagreen: "20b2aa",
      lightskyblue: "87cefa",
      lightslategray: "789",
      lightslategrey: "789",
      lightsteelblue: "b0c4de",
      lightyellow: "ffffe0",
      lime: "0f0",
      limegreen: "32cd32",
      linen: "faf0e6",
      magenta: "f0f",
      maroon: "800000",
      mediumaquamarine: "66cdaa",
      mediumblue: "0000cd",
      mediumorchid: "ba55d3",
      mediumpurple: "9370db",
      mediumseagreen: "3cb371",
      mediumslateblue: "7b68ee",
      mediumspringgreen: "00fa9a",
      mediumturquoise: "48d1cc",
      mediumvioletred: "c71585",
      midnightblue: "191970",
      mintcream: "f5fffa",
      mistyrose: "ffe4e1",
      moccasin: "ffe4b5",
      navajowhite: "ffdead",
      navy: "000080",
      oldlace: "fdf5e6",
      olive: "808000",
      olivedrab: "6b8e23",
      orange: "ffa500",
      orangered: "ff4500",
      orchid: "da70d6",
      palegoldenrod: "eee8aa",
      palegreen: "98fb98",
      paleturquoise: "afeeee",
      palevioletred: "db7093",
      papayawhip: "ffefd5",
      peachpuff: "ffdab9",
      peru: "cd853f",
      pink: "ffc0cb",
      plum: "dda0dd",
      powderblue: "b0e0e6",
      purple: "800080",
      rebeccapurple: "663399",
      red: "f00",
      rosybrown: "bc8f8f",
      royalblue: "4169e1",
      saddlebrown: "8b4513",
      salmon: "fa8072",
      sandybrown: "f4a460",
      seagreen: "2e8b57",
      seashell: "fff5ee",
      sienna: "a0522d",
      silver: "c0c0c0",
      skyblue: "87ceeb",
      slateblue: "6a5acd",
      slategray: "708090",
      slategrey: "708090",
      snow: "fffafa",
      springgreen: "00ff7f",
      steelblue: "4682b4",
      tan: "d2b48c",
      teal: "008080",
      thistle: "d8bfd8",
      tomato: "ff6347",
      turquoise: "40e0d0",
      violet: "ee82ee",
      wheat: "f5deb3",
      white: "fff",
      whitesmoke: "f5f5f5",
      yellow: "ff0",
      yellowgreen: "9acd32"
    };
  
    // Make it easy to access colors via `hexNames[hex]`
    var hexNames = tinycolor.hexNames = flip(names);
  
    // Utilities
    // ---------
  
    // `{ 'name1': 'val1' }` becomes `{ 'val1': 'name1' }`
    function flip(o) {
      var flipped = {};
      for (var i in o) {
        if (o.hasOwnProperty(i)) {
          flipped[o[i]] = i;
        }
      }
      return flipped;
    }
  
    // Return a valid alpha value [0,1] with all invalid values being set to 1
    function boundAlpha(a) {
      a = parseFloat(a);
      if (isNaN(a) || a < 0 || a > 1) {
        a = 1;
      }
      return a;
    }
  
    // Take input from [0, n] and return it as [0, 1]
    function bound01(n, max) {
      if (isOnePointZero(n)) n = "100%";
      var processPercent = isPercentage(n);
      n = Math.min(max, Math.max(0, parseFloat(n)));
  
      // Automatically convert percentage into number
      if (processPercent) {
        n = parseInt(n * max, 10) / 100;
      }
  
      // Handle floating point rounding errors
      if (Math.abs(n - max) < 0.000001) {
        return 1;
      }
  
      // Convert into [0, 1] range if it isn't already
      return n % max / parseFloat(max);
    }
  
    // Force a number between 0 and 1
    function clamp01(val) {
      return Math.min(1, Math.max(0, val));
    }
  
    // Parse a base-16 hex value into a base-10 integer
    function parseIntFromHex(val) {
      return parseInt(val, 16);
    }
  
    // Need to handle 1.0 as 100%, since once it is a number, there is no difference between it and 1
    // <http://stackoverflow.com/questions/7422072/javascript-how-to-detect-number-as-a-decimal-including-1-0>
    function isOnePointZero(n) {
      return typeof n == "string" && n.indexOf(".") != -1 && parseFloat(n) === 1;
    }
  
    // Check to see if string passed in is a percentage
    function isPercentage(n) {
      return typeof n === "string" && n.indexOf("%") != -1;
    }
  
    // Force a hex value to have 2 characters
    function pad2(c) {
      return c.length == 1 ? "0" + c : "" + c;
    }
  
    // Replace a decimal with it's percentage value
    function convertToPercentage(n) {
      if (n <= 1) {
        n = n * 100 + "%";
      }
      return n;
    }
  
    // Converts a decimal to a hex value
    function convertDecimalToHex(d) {
      return Math.round(parseFloat(d) * 255).toString(16);
    }
    // Converts a hex value to a decimal
    function convertHexToDecimal(h) {
      return parseIntFromHex(h) / 255;
    }
    var matchers = function () {
      // <http://www.w3.org/TR/css3-values/#integers>
      var CSS_INTEGER = "[-\\+]?\\d+%?";
  
      // <http://www.w3.org/TR/css3-values/#number-value>
      var CSS_NUMBER = "[-\\+]?\\d*\\.\\d+%?";
  
      // Allow positive/negative integer/number.  Don't capture the either/or, just the entire outcome.
      var CSS_UNIT = "(?:" + CSS_NUMBER + ")|(?:" + CSS_INTEGER + ")";
  
      // Actual matching.
      // Parentheses and commas are optional, but not required.
      // Whitespace can take the place of commas or opening paren
      var PERMISSIVE_MATCH3 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
      var PERMISSIVE_MATCH4 = "[\\s|\\(]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")[,|\\s]+(" + CSS_UNIT + ")\\s*\\)?";
      return {
        CSS_UNIT: new RegExp(CSS_UNIT),
        rgb: new RegExp("rgb" + PERMISSIVE_MATCH3),
        rgba: new RegExp("rgba" + PERMISSIVE_MATCH4),
        hsl: new RegExp("hsl" + PERMISSIVE_MATCH3),
        hsla: new RegExp("hsla" + PERMISSIVE_MATCH4),
        hsv: new RegExp("hsv" + PERMISSIVE_MATCH3),
        hsva: new RegExp("hsva" + PERMISSIVE_MATCH4),
        hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
        hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
        hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
        hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
      };
    }();
  
    // `isValidCSSUnit`
    // Take in a single string / number and check to see if it looks like a CSS unit
    // (see `matchers` above for definition).
    function isValidCSSUnit(color) {
      return !!matchers.CSS_UNIT.exec(color);
    }
  
    // `stringInputToObject`
    // Permissive string parsing.  Take in a number of formats, and output an object
    // based on detected format.  Returns `{ r, g, b }` or `{ h, s, l }` or `{ h, s, v}`
    function stringInputToObject(color) {
      color = color.replace(trimLeft, "").replace(trimRight, "").toLowerCase();
      var named = false;
      if (names[color]) {
        color = names[color];
        named = true;
      } else if (color == "transparent") {
        return {
          r: 0,
          g: 0,
          b: 0,
          a: 0,
          format: "name"
        };
      }
  
      // Try to match string input using regular expressions.
      // Keep most of the number bounding out of this function - don't worry about [0,1] or [0,100] or [0,360]
      // Just return an object and let the conversion functions handle that.
      // This way the result will be the same whether the tinycolor is initialized with string or object.
      var match;
      if (match = matchers.rgb.exec(color)) {
        return {
          r: match[1],
          g: match[2],
          b: match[3]
        };
      }
      if (match = matchers.rgba.exec(color)) {
        return {
          r: match[1],
          g: match[2],
          b: match[3],
          a: match[4]
        };
      }
      if (match = matchers.hsl.exec(color)) {
        return {
          h: match[1],
          s: match[2],
          l: match[3]
        };
      }
      if (match = matchers.hsla.exec(color)) {
        return {
          h: match[1],
          s: match[2],
          l: match[3],
          a: match[4]
        };
      }
      if (match = matchers.hsv.exec(color)) {
        return {
          h: match[1],
          s: match[2],
          v: match[3]
        };
      }
      if (match = matchers.hsva.exec(color)) {
        return {
          h: match[1],
          s: match[2],
          v: match[3],
          a: match[4]
        };
      }
      if (match = matchers.hex8.exec(color)) {
        return {
          r: parseIntFromHex(match[1]),
          g: parseIntFromHex(match[2]),
          b: parseIntFromHex(match[3]),
          a: convertHexToDecimal(match[4]),
          format: named ? "name" : "hex8"
        };
      }
      if (match = matchers.hex6.exec(color)) {
        return {
          r: parseIntFromHex(match[1]),
          g: parseIntFromHex(match[2]),
          b: parseIntFromHex(match[3]),
          format: named ? "name" : "hex"
        };
      }
      if (match = matchers.hex4.exec(color)) {
        return {
          r: parseIntFromHex(match[1] + "" + match[1]),
          g: parseIntFromHex(match[2] + "" + match[2]),
          b: parseIntFromHex(match[3] + "" + match[3]),
          a: convertHexToDecimal(match[4] + "" + match[4]),
          format: named ? "name" : "hex8"
        };
      }
      if (match = matchers.hex3.exec(color)) {
        return {
          r: parseIntFromHex(match[1] + "" + match[1]),
          g: parseIntFromHex(match[2] + "" + match[2]),
          b: parseIntFromHex(match[3] + "" + match[3]),
          format: named ? "name" : "hex"
        };
      }
      return false;
    }
    function validateWCAG2Parms(parms) {
      // return valid WCAG2 parms for isReadable.
      // If input parms are invalid, return {"level":"AA", "size":"small"}
      var level, size;
      parms = parms || {
        level: "AA",
        size: "small"
      };
      level = (parms.level || "AA").toUpperCase();
      size = (parms.size || "small").toLowerCase();
      if (level !== "AA" && level !== "AAA") {
        level = "AA";
      }
      if (size !== "small" && size !== "large") {
        size = "small";
      }
      return {
        level: level,
        size: size
      };
    }
  
    return tinycolor;
  
  }));
  

});

;/*!node_modules/react-color/lib/helpers/color.js*/
amis.define('dade38d', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.isvalidColorString = exports.red = exports.getContrastingColor = exports.isValidHex = exports.toState = exports.simpleCheckForValidColor = undefined;
  
  var _each = require('d328c8f');
  
  var _each2 = _interopRequireDefault(_each);
  
  var _tinycolor = require('dcff141');
  
  var _tinycolor2 = _interopRequireDefault(_tinycolor);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var simpleCheckForValidColor = exports.simpleCheckForValidColor = function simpleCheckForValidColor(data) {
    var keysToCheck = ['r', 'g', 'b', 'a', 'h', 's', 'l', 'v'];
    var checked = 0;
    var passed = 0;
    (0, _each2.default)(keysToCheck, function (letter) {
      if (data[letter]) {
        checked += 1;
        if (!isNaN(data[letter])) {
          passed += 1;
        }
        if (letter === 's' || letter === 'l') {
          var percentPatt = /^\d+%$/;
          if (percentPatt.test(data[letter])) {
            passed += 1;
          }
        }
      }
    });
    return checked === passed ? data : false;
  };
  
  var toState = exports.toState = function toState(data, oldHue) {
    var color = data.hex ? (0, _tinycolor2.default)(data.hex) : (0, _tinycolor2.default)(data);
    var hsl = color.toHsl();
    var hsv = color.toHsv();
    var rgb = color.toRgb();
    var hex = color.toHex();
    if (hsl.s === 0) {
      hsl.h = oldHue || 0;
      hsv.h = oldHue || 0;
    }
    var transparent = hex === '000000' && rgb.a === 0;
  
    return {
      hsl: hsl,
      hex: transparent ? 'transparent' : '#' + hex,
      rgb: rgb,
      hsv: hsv,
      oldHue: data.h || oldHue || hsl.h,
      source: data.source
    };
  };
  
  var isValidHex = exports.isValidHex = function isValidHex(hex) {
    if (hex === 'transparent') {
      return true;
    }
    // disable hex4 and hex8
    var lh = String(hex).charAt(0) === '#' ? 1 : 0;
    return hex.length !== 4 + lh && hex.length < 7 + lh && (0, _tinycolor2.default)(hex).isValid();
  };
  
  var getContrastingColor = exports.getContrastingColor = function getContrastingColor(data) {
    if (!data) {
      return '#fff';
    }
    var col = toState(data);
    if (col.hex === 'transparent') {
      return 'rgba(0,0,0,0.4)';
    }
    var yiq = (col.rgb.r * 299 + col.rgb.g * 587 + col.rgb.b * 114) / 1000;
    return yiq >= 128 ? '#000' : '#fff';
  };
  
  var red = exports.red = {
    hsl: { a: 1, h: 0, l: 0.5, s: 1 },
    hex: '#ff0000',
    rgb: { r: 255, g: 0, b: 0, a: 1 },
    hsv: { h: 0, s: 1, v: 1, a: 1 }
  };
  
  var isvalidColorString = exports.isvalidColorString = function isvalidColorString(string, type) {
    var stringWithoutDegree = string.replace('°', '');
    return (0, _tinycolor2.default)(type + ' (' + stringWithoutDegree + ')')._ok;
  };

});

;/*!node_modules/react-color/lib/components/common/ColorWrap.js*/
amis.define('f09be53', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ColorWrap = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _debounce = require('e35a00e');
  
  var _debounce2 = _interopRequireDefault(_debounce);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var ColorWrap = exports.ColorWrap = function ColorWrap(Picker) {
    var ColorPicker = function (_ref) {
      _inherits(ColorPicker, _ref);
  
      function ColorPicker(props) {
        _classCallCheck(this, ColorPicker);
  
        var _this = _possibleConstructorReturn(this, (ColorPicker.__proto__ || Object.getPrototypeOf(ColorPicker)).call(this));
  
        _this.handleChange = function (data, event) {
          var isValidColor = color.simpleCheckForValidColor(data);
          if (isValidColor) {
            var colors = color.toState(data, data.h || _this.state.oldHue);
            _this.setState(colors);
            _this.props.onChangeComplete && _this.debounce(_this.props.onChangeComplete, colors, event);
            _this.props.onChange && _this.props.onChange(colors, event);
          }
        };
  
        _this.handleSwatchHover = function (data, event) {
          var isValidColor = color.simpleCheckForValidColor(data);
          if (isValidColor) {
            var colors = color.toState(data, data.h || _this.state.oldHue);
            _this.props.onSwatchHover && _this.props.onSwatchHover(colors, event);
          }
        };
  
        _this.state = _extends({}, color.toState(props.color, 0));
  
        _this.debounce = (0, _debounce2.default)(function (fn, data, event) {
          fn(data, event);
        }, 100);
        return _this;
      }
  
      _createClass(ColorPicker, [{
        key: 'render',
        value: function render() {
          var optionalEvents = {};
          if (this.props.onSwatchHover) {
            optionalEvents.onSwatchHover = this.handleSwatchHover;
          }
  
          return _react2.default.createElement(Picker, _extends({}, this.props, this.state, {
            onChange: this.handleChange
          }, optionalEvents));
        }
      }], [{
        key: 'getDerivedStateFromProps',
        value: function getDerivedStateFromProps(nextProps, state) {
          return _extends({}, color.toState(nextProps.color, state.oldHue));
        }
      }]);
  
      return ColorPicker;
    }(_react.PureComponent || _react.Component);
  
    ColorPicker.propTypes = _extends({}, Picker.propTypes);
  
    ColorPicker.defaultProps = _extends({}, Picker.defaultProps, {
      color: {
        h: 250,
        s: 0.50,
        l: 0.20,
        a: 1
      }
    });
  
    return ColorPicker;
  };
  
  exports.default = ColorWrap;

});

;/*!node_modules/react-color/lib/helpers/interaction.js*/
amis.define('3663eae', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.handleFocus = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /* eslint-disable no-invalid-this */
  
  
  var handleFocus = exports.handleFocus = function handleFocus(Component) {
    var Span = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'span';
    return function (_React$Component) {
      _inherits(Focus, _React$Component);
  
      function Focus() {
        var _ref;
  
        var _temp, _this, _ret;
  
        _classCallCheck(this, Focus);
  
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
  
        return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = Focus.__proto__ || Object.getPrototypeOf(Focus)).call.apply(_ref, [this].concat(args))), _this), _this.state = { focus: false }, _this.handleFocus = function () {
          return _this.setState({ focus: true });
        }, _this.handleBlur = function () {
          return _this.setState({ focus: false });
        }, _temp), _possibleConstructorReturn(_this, _ret);
      }
  
      _createClass(Focus, [{
        key: 'render',
        value: function render() {
          return _react2.default.createElement(
            Span,
            { onFocus: this.handleFocus, onBlur: this.handleBlur },
            _react2.default.createElement(Component, _extends({}, this.props, this.state))
          );
        }
      }]);
  
      return Focus;
    }(_react2.default.Component);
  };

});

;/*!node_modules/react-color/lib/components/common/Swatch.js*/
amis.define('2c706fc', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Swatch = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _interaction = require('3663eae');
  
  var _Checkboard = require('4e8ecbd');
  
  var _Checkboard2 = _interopRequireDefault(_Checkboard);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var ENTER = 13;
  
  var Swatch = exports.Swatch = function Swatch(_ref) {
    var color = _ref.color,
        style = _ref.style,
        _ref$onClick = _ref.onClick,
        onClick = _ref$onClick === undefined ? function () {} : _ref$onClick,
        onHover = _ref.onHover,
        _ref$title = _ref.title,
        title = _ref$title === undefined ? color : _ref$title,
        children = _ref.children,
        focus = _ref.focus,
        _ref$focusStyle = _ref.focusStyle,
        focusStyle = _ref$focusStyle === undefined ? {} : _ref$focusStyle;
  
    var transparent = color === 'transparent';
    var styles = (0, _reactcss2.default)({
      default: {
        swatch: _extends({
          background: color,
          height: '100%',
          width: '100%',
          cursor: 'pointer',
          position: 'relative',
          outline: 'none'
        }, style, focus ? focusStyle : {})
      }
    });
  
    var handleClick = function handleClick(e) {
      return onClick(color, e);
    };
    var handleKeyDown = function handleKeyDown(e) {
      return e.keyCode === ENTER && onClick(color, e);
    };
    var handleHover = function handleHover(e) {
      return onHover(color, e);
    };
  
    var optionalEvents = {};
    if (onHover) {
      optionalEvents.onMouseOver = handleHover;
    }
  
    return _react2.default.createElement(
      'div',
      _extends({
        style: styles.swatch,
        onClick: handleClick,
        title: title,
        tabIndex: 0,
        onKeyDown: handleKeyDown
      }, optionalEvents),
      children,
      transparent && _react2.default.createElement(_Checkboard2.default, {
        borderRadius: styles.swatch.borderRadius,
        boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.1)'
      })
    );
  };
  
  exports.default = (0, _interaction.handleFocus)(Swatch);

});

;/*!node_modules/react-color/lib/components/common/index.js*/
amis.define('0eb8409', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  
  var _Alpha = require('ca6dd8c');
  
  Object.defineProperty(exports, 'Alpha', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Alpha).default;
    }
  });
  
  var _Checkboard = require('4e8ecbd');
  
  Object.defineProperty(exports, 'Checkboard', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Checkboard).default;
    }
  });
  
  var _EditableInput = require('75321d6');
  
  Object.defineProperty(exports, 'EditableInput', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_EditableInput).default;
    }
  });
  
  var _Hue = require('4e680b6');
  
  Object.defineProperty(exports, 'Hue', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Hue).default;
    }
  });
  
  var _Raised = require('085c23f');
  
  Object.defineProperty(exports, 'Raised', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Raised).default;
    }
  });
  
  var _Saturation = require('94f50b6');
  
  Object.defineProperty(exports, 'Saturation', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Saturation).default;
    }
  });
  
  var _ColorWrap = require('f09be53');
  
  Object.defineProperty(exports, 'ColorWrap', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_ColorWrap).default;
    }
  });
  
  var _Swatch = require('2c706fc');
  
  Object.defineProperty(exports, 'Swatch', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Swatch).default;
    }
  });
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

});

;/*!node_modules/react-color/lib/components/alpha/AlphaPointer.js*/
amis.define('9082555', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AlphaPointer = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var AlphaPointer = exports.AlphaPointer = function AlphaPointer(_ref) {
    var direction = _ref.direction;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '18px',
          height: '18px',
          borderRadius: '50%',
          transform: 'translate(-9px, -1px)',
          backgroundColor: 'rgb(248, 248, 248)',
          boxShadow: '0 1px 4px 0 rgba(0, 0, 0, 0.37)'
        }
      },
      'vertical': {
        picker: {
          transform: 'translate(-3px, -9px)'
        }
      }
    }, { vertical: direction === 'vertical' });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  exports.default = AlphaPointer;

});

;/*!node_modules/react-color/lib/components/alpha/Alpha.js*/
amis.define('fbf358d', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.AlphaPicker = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _common = require('0eb8409');
  
  var _AlphaPointer = require('9082555');
  
  var _AlphaPointer2 = _interopRequireDefault(_AlphaPointer);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var AlphaPicker = exports.AlphaPicker = function AlphaPicker(_ref) {
    var rgb = _ref.rgb,
        hsl = _ref.hsl,
        width = _ref.width,
        height = _ref.height,
        onChange = _ref.onChange,
        direction = _ref.direction,
        style = _ref.style,
        renderers = _ref.renderers,
        pointer = _ref.pointer,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          position: 'relative',
          width: width,
          height: height
        },
        alpha: {
          radius: '2px',
          style: style
        }
      }
    });
  
    return _react2.default.createElement(
      'div',
      { style: styles.picker, className: 'alpha-picker ' + className },
      _react2.default.createElement(_common.Alpha, _extends({}, styles.alpha, {
        rgb: rgb,
        hsl: hsl,
        pointer: pointer,
        renderers: renderers,
        onChange: onChange,
        direction: direction
      }))
    );
  };
  
  AlphaPicker.defaultProps = {
    width: '316px',
    height: '16px',
    direction: 'horizontal',
    pointer: _AlphaPointer2.default
  };
  
  exports.default = (0, _common.ColorWrap)(AlphaPicker);

});

;/*!node_modules/react-color/lib/components/block/BlockSwatches.js*/
amis.define('39bc9ba', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.BlockSwatches = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _common = require('0eb8409');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var BlockSwatches = exports.BlockSwatches = function BlockSwatches(_ref) {
    var colors = _ref.colors,
        onClick = _ref.onClick,
        onSwatchHover = _ref.onSwatchHover;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        swatches: {
          marginRight: '-10px'
        },
        swatch: {
          width: '22px',
          height: '22px',
          float: 'left',
          marginRight: '10px',
          marginBottom: '10px',
          borderRadius: '4px'
        },
        clear: {
          clear: 'both'
        }
      }
    });
  
    return _react2.default.createElement(
      'div',
      { style: styles.swatches },
      (0, _map2.default)(colors, function (c) {
        return _react2.default.createElement(_common.Swatch, {
          key: c,
          color: c,
          style: styles.swatch,
          onClick: onClick,
          onHover: onSwatchHover,
          focusStyle: {
            boxShadow: '0 0 4px ' + c
          }
        });
      }),
      _react2.default.createElement('div', { style: styles.clear })
    );
  };
  
  exports.default = BlockSwatches;

});

;/*!node_modules/react-color/lib/components/block/Block.js*/
amis.define('c056046', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Block = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  var _BlockSwatches = require('39bc9ba');
  
  var _BlockSwatches2 = _interopRequireDefault(_BlockSwatches);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Block = exports.Block = function Block(_ref) {
    var onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        hex = _ref.hex,
        colors = _ref.colors,
        width = _ref.width,
        triangle = _ref.triangle,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var transparent = hex === 'transparent';
    var handleChange = function handleChange(hexCode, e) {
      color.isValidHex(hexCode) && onChange({
        hex: hexCode,
        source: 'hex'
      }, e);
    };
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        card: {
          width: width,
          background: '#fff',
          boxShadow: '0 1px rgba(0,0,0,.1)',
          borderRadius: '6px',
          position: 'relative'
        },
        head: {
          height: '110px',
          background: hex,
          borderRadius: '6px 6px 0 0',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'relative'
        },
        body: {
          padding: '10px'
        },
        label: {
          fontSize: '18px',
          color: color.getContrastingColor(hex),
          position: 'relative'
        },
        triangle: {
          width: '0px',
          height: '0px',
          borderStyle: 'solid',
          borderWidth: '0 10px 10px 10px',
          borderColor: 'transparent transparent ' + hex + ' transparent',
          position: 'absolute',
          top: '-10px',
          left: '50%',
          marginLeft: '-10px'
        },
        input: {
          width: '100%',
          fontSize: '12px',
          color: '#666',
          border: '0px',
          outline: 'none',
          height: '22px',
          boxShadow: 'inset 0 0 0 1px #ddd',
          borderRadius: '4px',
          padding: '0 7px',
          boxSizing: 'border-box'
        }
      },
      'hide-triangle': {
        triangle: {
          display: 'none'
        }
      }
    }, passedStyles), { 'hide-triangle': triangle === 'hide' });
  
    return _react2.default.createElement(
      'div',
      { style: styles.card, className: 'block-picker ' + className },
      _react2.default.createElement('div', { style: styles.triangle }),
      _react2.default.createElement(
        'div',
        { style: styles.head },
        transparent && _react2.default.createElement(_common.Checkboard, { borderRadius: '6px 6px 0 0' }),
        _react2.default.createElement(
          'div',
          { style: styles.label },
          hex
        )
      ),
      _react2.default.createElement(
        'div',
        { style: styles.body },
        _react2.default.createElement(_BlockSwatches2.default, { colors: colors, onClick: handleChange, onSwatchHover: onSwatchHover }),
        _react2.default.createElement(_common.EditableInput, {
          style: { input: styles.input },
          value: hex,
          onChange: handleChange
        })
      )
    );
  };
  
  Block.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    colors: _propTypes2.default.arrayOf(_propTypes2.default.string),
    triangle: _propTypes2.default.oneOf(['top', 'hide']),
    styles: _propTypes2.default.object
  };
  
  Block.defaultProps = {
    width: 170,
    colors: ['#D9E3F0', '#F47373', '#697689', '#37D67A', '#2CCCE4', '#555555', '#dce775', '#ff8a65', '#ba68c8'],
    triangle: 'top',
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Block);

});

;/*!node_modules/material-colors/dist/colors.js*/
amis.define('4fd9d03', function(require, exports, module, define) {

  (function(root, factory) {
    if (typeof define === 'function' && define.amd) {
      define([], factory);
    } else if (typeof exports === 'object') {
      module.exports = factory();
    } else {
      root.materialColors = factory();
    }
  })(this, function() {
    return {"red":{"50":"#ffebee","100":"#ffcdd2","200":"#ef9a9a","300":"#e57373","400":"#ef5350","500":"#f44336","600":"#e53935","700":"#d32f2f","800":"#c62828","900":"#b71c1c","a100":"#ff8a80","a200":"#ff5252","a400":"#ff1744","a700":"#d50000"},"pink":{"50":"#fce4ec","100":"#f8bbd0","200":"#f48fb1","300":"#f06292","400":"#ec407a","500":"#e91e63","600":"#d81b60","700":"#c2185b","800":"#ad1457","900":"#880e4f","a100":"#ff80ab","a200":"#ff4081","a400":"#f50057","a700":"#c51162"},"purple":{"50":"#f3e5f5","100":"#e1bee7","200":"#ce93d8","300":"#ba68c8","400":"#ab47bc","500":"#9c27b0","600":"#8e24aa","700":"#7b1fa2","800":"#6a1b9a","900":"#4a148c","a100":"#ea80fc","a200":"#e040fb","a400":"#d500f9","a700":"#aa00ff"},"deepPurple":{"50":"#ede7f6","100":"#d1c4e9","200":"#b39ddb","300":"#9575cd","400":"#7e57c2","500":"#673ab7","600":"#5e35b1","700":"#512da8","800":"#4527a0","900":"#311b92","a100":"#b388ff","a200":"#7c4dff","a400":"#651fff","a700":"#6200ea"},"indigo":{"50":"#e8eaf6","100":"#c5cae9","200":"#9fa8da","300":"#7986cb","400":"#5c6bc0","500":"#3f51b5","600":"#3949ab","700":"#303f9f","800":"#283593","900":"#1a237e","a100":"#8c9eff","a200":"#536dfe","a400":"#3d5afe","a700":"#304ffe"},"blue":{"50":"#e3f2fd","100":"#bbdefb","200":"#90caf9","300":"#64b5f6","400":"#42a5f5","500":"#2196f3","600":"#1e88e5","700":"#1976d2","800":"#1565c0","900":"#0d47a1","a100":"#82b1ff","a200":"#448aff","a400":"#2979ff","a700":"#2962ff"},"lightBlue":{"50":"#e1f5fe","100":"#b3e5fc","200":"#81d4fa","300":"#4fc3f7","400":"#29b6f6","500":"#03a9f4","600":"#039be5","700":"#0288d1","800":"#0277bd","900":"#01579b","a100":"#80d8ff","a200":"#40c4ff","a400":"#00b0ff","a700":"#0091ea"},"cyan":{"50":"#e0f7fa","100":"#b2ebf2","200":"#80deea","300":"#4dd0e1","400":"#26c6da","500":"#00bcd4","600":"#00acc1","700":"#0097a7","800":"#00838f","900":"#006064","a100":"#84ffff","a200":"#18ffff","a400":"#00e5ff","a700":"#00b8d4"},"teal":{"50":"#e0f2f1","100":"#b2dfdb","200":"#80cbc4","300":"#4db6ac","400":"#26a69a","500":"#009688","600":"#00897b","700":"#00796b","800":"#00695c","900":"#004d40","a100":"#a7ffeb","a200":"#64ffda","a400":"#1de9b6","a700":"#00bfa5"},"green":{"50":"#e8f5e9","100":"#c8e6c9","200":"#a5d6a7","300":"#81c784","400":"#66bb6a","500":"#4caf50","600":"#43a047","700":"#388e3c","800":"#2e7d32","900":"#1b5e20","a100":"#b9f6ca","a200":"#69f0ae","a400":"#00e676","a700":"#00c853"},"lightGreen":{"50":"#f1f8e9","100":"#dcedc8","200":"#c5e1a5","300":"#aed581","400":"#9ccc65","500":"#8bc34a","600":"#7cb342","700":"#689f38","800":"#558b2f","900":"#33691e","a100":"#ccff90","a200":"#b2ff59","a400":"#76ff03","a700":"#64dd17"},"lime":{"50":"#f9fbe7","100":"#f0f4c3","200":"#e6ee9c","300":"#dce775","400":"#d4e157","500":"#cddc39","600":"#c0ca33","700":"#afb42b","800":"#9e9d24","900":"#827717","a100":"#f4ff81","a200":"#eeff41","a400":"#c6ff00","a700":"#aeea00"},"yellow":{"50":"#fffde7","100":"#fff9c4","200":"#fff59d","300":"#fff176","400":"#ffee58","500":"#ffeb3b","600":"#fdd835","700":"#fbc02d","800":"#f9a825","900":"#f57f17","a100":"#ffff8d","a200":"#ffff00","a400":"#ffea00","a700":"#ffd600"},"amber":{"50":"#fff8e1","100":"#ffecb3","200":"#ffe082","300":"#ffd54f","400":"#ffca28","500":"#ffc107","600":"#ffb300","700":"#ffa000","800":"#ff8f00","900":"#ff6f00","a100":"#ffe57f","a200":"#ffd740","a400":"#ffc400","a700":"#ffab00"},"orange":{"50":"#fff3e0","100":"#ffe0b2","200":"#ffcc80","300":"#ffb74d","400":"#ffa726","500":"#ff9800","600":"#fb8c00","700":"#f57c00","800":"#ef6c00","900":"#e65100","a100":"#ffd180","a200":"#ffab40","a400":"#ff9100","a700":"#ff6d00"},"deepOrange":{"50":"#fbe9e7","100":"#ffccbc","200":"#ffab91","300":"#ff8a65","400":"#ff7043","500":"#ff5722","600":"#f4511e","700":"#e64a19","800":"#d84315","900":"#bf360c","a100":"#ff9e80","a200":"#ff6e40","a400":"#ff3d00","a700":"#dd2c00"},"brown":{"50":"#efebe9","100":"#d7ccc8","200":"#bcaaa4","300":"#a1887f","400":"#8d6e63","500":"#795548","600":"#6d4c41","700":"#5d4037","800":"#4e342e","900":"#3e2723"},"grey":{"50":"#fafafa","100":"#f5f5f5","200":"#eeeeee","300":"#e0e0e0","400":"#bdbdbd","500":"#9e9e9e","600":"#757575","700":"#616161","800":"#424242","900":"#212121"},"blueGrey":{"50":"#eceff1","100":"#cfd8dc","200":"#b0bec5","300":"#90a4ae","400":"#78909c","500":"#607d8b","600":"#546e7a","700":"#455a64","800":"#37474f","900":"#263238"},"darkText":{"primary":"rgba(0, 0, 0, 0.87)","secondary":"rgba(0, 0, 0, 0.54)","disabled":"rgba(0, 0, 0, 0.38)","dividers":"rgba(0, 0, 0, 0.12)"},"lightText":{"primary":"rgba(255, 255, 255, 1)","secondary":"rgba(255, 255, 255, 0.7)","disabled":"rgba(255, 255, 255, 0.5)","dividers":"rgba(255, 255, 255, 0.12)"},"darkIcons":{"active":"rgba(0, 0, 0, 0.54)","inactive":"rgba(0, 0, 0, 0.38)"},"lightIcons":{"active":"rgba(255, 255, 255, 1)","inactive":"rgba(255, 255, 255, 0.5)"},"white":"#ffffff","black":"#000000"};
  });
  

});

;/*!node_modules/react-color/lib/components/circle/CircleSwatch.js*/
amis.define('603d6c6', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CircleSwatch = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _common = require('0eb8409');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var CircleSwatch = exports.CircleSwatch = function CircleSwatch(_ref) {
    var color = _ref.color,
        onClick = _ref.onClick,
        onSwatchHover = _ref.onSwatchHover,
        hover = _ref.hover,
        active = _ref.active,
        circleSize = _ref.circleSize,
        circleSpacing = _ref.circleSpacing;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        swatch: {
          width: circleSize,
          height: circleSize,
          marginRight: circleSpacing,
          marginBottom: circleSpacing,
          transform: 'scale(1)',
          transition: '100ms transform ease'
        },
        Swatch: {
          borderRadius: '50%',
          background: 'transparent',
          boxShadow: 'inset 0 0 0 ' + (circleSize / 2 + 1) + 'px ' + color,
          transition: '100ms box-shadow ease'
        }
      },
      'hover': {
        swatch: {
          transform: 'scale(1.2)'
        }
      },
      'active': {
        Swatch: {
          boxShadow: 'inset 0 0 0 3px ' + color
        }
      }
    }, { hover: hover, active: active });
  
    return _react2.default.createElement(
      'div',
      { style: styles.swatch },
      _react2.default.createElement(_common.Swatch, {
        style: styles.Swatch,
        color: color,
        onClick: onClick,
        onHover: onSwatchHover,
        focusStyle: { boxShadow: styles.Swatch.boxShadow + ', 0 0 5px ' + color }
      })
    );
  };
  
  CircleSwatch.defaultProps = {
    circleSize: 28,
    circleSpacing: 14
  };
  
  exports.default = (0, _reactcss.handleHover)(CircleSwatch);

});

;/*!node_modules/react-color/lib/components/circle/Circle.js*/
amis.define('9a72b29', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Circle = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _materialColors = require('4fd9d03');
  
  var material = _interopRequireWildcard(_materialColors);
  
  var _common = require('0eb8409');
  
  var _CircleSwatch = require('603d6c6');
  
  var _CircleSwatch2 = _interopRequireDefault(_CircleSwatch);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Circle = exports.Circle = function Circle(_ref) {
    var width = _ref.width,
        onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        colors = _ref.colors,
        hex = _ref.hex,
        circleSize = _ref.circleSize,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        circleSpacing = _ref.circleSpacing,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        card: {
          width: width,
          display: 'flex',
          flexWrap: 'wrap',
          marginRight: -circleSpacing,
          marginBottom: -circleSpacing
        }
      }
    }, passedStyles));
  
    var handleChange = function handleChange(hexCode, e) {
      return onChange({ hex: hexCode, source: 'hex' }, e);
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.card, className: 'circle-picker ' + className },
      (0, _map2.default)(colors, function (c) {
        return _react2.default.createElement(_CircleSwatch2.default, {
          key: c,
          color: c,
          onClick: handleChange,
          onSwatchHover: onSwatchHover,
          active: hex === c.toLowerCase(),
          circleSize: circleSize,
          circleSpacing: circleSpacing
        });
      })
    );
  };
  
  Circle.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    circleSize: _propTypes2.default.number,
    circleSpacing: _propTypes2.default.number,
    styles: _propTypes2.default.object
  };
  
  Circle.defaultProps = {
    width: 252,
    circleSize: 28,
    circleSpacing: 14,
    colors: [material.red['500'], material.pink['500'], material.purple['500'], material.deepPurple['500'], material.indigo['500'], material.blue['500'], material.lightBlue['500'], material.cyan['500'], material.teal['500'], material.green['500'], material.lightGreen['500'], material.lime['500'], material.yellow['500'], material.amber['500'], material.orange['500'], material.deepOrange['500'], material.brown['500'], material.blueGrey['500']],
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Circle);

});

;/*!node_modules/react-color/lib/components/chrome/ChromeFields.js*/
amis.define('afb892a', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ChromeFields = undefined;
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _isUndefined = require('6bd1350');
  
  var _isUndefined2 = _interopRequireDefault(_isUndefined);
  
  var _common = require('0eb8409');
  
  var _UnfoldMoreHorizontalIcon = require('ca76f78');
  
  var _UnfoldMoreHorizontalIcon2 = _interopRequireDefault(_UnfoldMoreHorizontalIcon);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; } /* eslint-disable react/no-did-mount-set-state, no-param-reassign */
  
  var ChromeFields = exports.ChromeFields = function (_React$Component) {
    _inherits(ChromeFields, _React$Component);
  
    function ChromeFields(props) {
      _classCallCheck(this, ChromeFields);
  
      var _this = _possibleConstructorReturn(this, (ChromeFields.__proto__ || Object.getPrototypeOf(ChromeFields)).call(this));
  
      _this.toggleViews = function () {
        if (_this.state.view === 'hex') {
          _this.setState({ view: 'rgb' });
        } else if (_this.state.view === 'rgb') {
          _this.setState({ view: 'hsl' });
        } else if (_this.state.view === 'hsl') {
          if (_this.props.hsl.a === 1) {
            _this.setState({ view: 'hex' });
          } else {
            _this.setState({ view: 'rgb' });
          }
        }
      };
  
      _this.handleChange = function (data, e) {
        if (data.hex) {
          color.isValidHex(data.hex) && _this.props.onChange({
            hex: data.hex,
            source: 'hex'
          }, e);
        } else if (data.r || data.g || data.b) {
          _this.props.onChange({
            r: data.r || _this.props.rgb.r,
            g: data.g || _this.props.rgb.g,
            b: data.b || _this.props.rgb.b,
            source: 'rgb'
          }, e);
        } else if (data.a) {
          if (data.a < 0) {
            data.a = 0;
          } else if (data.a > 1) {
            data.a = 1;
          }
  
          _this.props.onChange({
            h: _this.props.hsl.h,
            s: _this.props.hsl.s,
            l: _this.props.hsl.l,
            a: Math.round(data.a * 100) / 100,
            source: 'rgb'
          }, e);
        } else if (data.h || data.s || data.l) {
          // Remove any occurances of '%'.
          if (typeof data.s === 'string' && data.s.includes('%')) {
            data.s = data.s.replace('%', '');
          }
          if (typeof data.l === 'string' && data.l.includes('%')) {
            data.l = data.l.replace('%', '');
          }
  
          // We store HSL as a unit interval so we need to override the 1 input to 0.01
          if (data.s == 1) {
            data.s = 0.01;
          } else if (data.l == 1) {
            data.l = 0.01;
          }
  
          _this.props.onChange({
            h: data.h || _this.props.hsl.h,
            s: Number(!(0, _isUndefined2.default)(data.s) ? data.s : _this.props.hsl.s),
            l: Number(!(0, _isUndefined2.default)(data.l) ? data.l : _this.props.hsl.l),
            source: 'hsl'
          }, e);
        }
      };
  
      _this.showHighlight = function (e) {
        e.currentTarget.style.background = '#eee';
      };
  
      _this.hideHighlight = function (e) {
        e.currentTarget.style.background = 'transparent';
      };
  
      if (props.hsl.a !== 1 && props.view === "hex") {
        _this.state = {
          view: "rgb"
        };
      } else {
        _this.state = {
          view: props.view
        };
      }
      return _this;
    }
  
    _createClass(ChromeFields, [{
      key: 'render',
      value: function render() {
        var _this2 = this;
  
        var styles = (0, _reactcss2.default)({
          'default': {
            wrap: {
              paddingTop: '16px',
              display: 'flex'
            },
            fields: {
              flex: '1',
              display: 'flex',
              marginLeft: '-6px'
            },
            field: {
              paddingLeft: '6px',
              width: '100%'
            },
            alpha: {
              paddingLeft: '6px',
              width: '100%'
            },
            toggle: {
              width: '32px',
              textAlign: 'right',
              position: 'relative'
            },
            icon: {
              marginRight: '-4px',
              marginTop: '12px',
              cursor: 'pointer',
              position: 'relative'
            },
            iconHighlight: {
              position: 'absolute',
              width: '24px',
              height: '28px',
              background: '#eee',
              borderRadius: '4px',
              top: '10px',
              left: '12px',
              display: 'none'
            },
            input: {
              fontSize: '11px',
              color: '#333',
              width: '100%',
              borderRadius: '2px',
              border: 'none',
              boxShadow: 'inset 0 0 0 1px #dadada',
              height: '21px',
              textAlign: 'center'
            },
            label: {
              textTransform: 'uppercase',
              fontSize: '11px',
              lineHeight: '11px',
              color: '#969696',
              textAlign: 'center',
              display: 'block',
              marginTop: '12px'
            },
            svg: {
              fill: '#333',
              width: '24px',
              height: '24px',
              border: '1px transparent solid',
              borderRadius: '5px'
            }
          },
          'disableAlpha': {
            alpha: {
              display: 'none'
            }
          }
        }, this.props, this.state);
  
        var fields = void 0;
        if (this.state.view === 'hex') {
          fields = _react2.default.createElement(
            'div',
            { style: styles.fields, className: 'flexbox-fix' },
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'hex', value: this.props.hex,
                onChange: this.handleChange
              })
            )
          );
        } else if (this.state.view === 'rgb') {
          fields = _react2.default.createElement(
            'div',
            { style: styles.fields, className: 'flexbox-fix' },
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'r',
                value: this.props.rgb.r,
                onChange: this.handleChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'g',
                value: this.props.rgb.g,
                onChange: this.handleChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'b',
                value: this.props.rgb.b,
                onChange: this.handleChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.alpha },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'a',
                value: this.props.rgb.a,
                arrowOffset: 0.01,
                onChange: this.handleChange
              })
            )
          );
        } else if (this.state.view === 'hsl') {
          fields = _react2.default.createElement(
            'div',
            { style: styles.fields, className: 'flexbox-fix' },
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'h',
                value: Math.round(this.props.hsl.h),
                onChange: this.handleChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 's',
                value: Math.round(this.props.hsl.s * 100) + '%',
                onChange: this.handleChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.field },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'l',
                value: Math.round(this.props.hsl.l * 100) + '%',
                onChange: this.handleChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.alpha },
              _react2.default.createElement(_common.EditableInput, {
                style: { input: styles.input, label: styles.label },
                label: 'a',
                value: this.props.hsl.a,
                arrowOffset: 0.01,
                onChange: this.handleChange
              })
            )
          );
        }
  
        return _react2.default.createElement(
          'div',
          { style: styles.wrap, className: 'flexbox-fix' },
          fields,
          _react2.default.createElement(
            'div',
            { style: styles.toggle },
            _react2.default.createElement(
              'div',
              { style: styles.icon, onClick: this.toggleViews, ref: function ref(icon) {
                  return _this2.icon = icon;
                } },
              _react2.default.createElement(_UnfoldMoreHorizontalIcon2.default, {
                style: styles.svg,
                onMouseOver: this.showHighlight,
                onMouseEnter: this.showHighlight,
                onMouseOut: this.hideHighlight
              })
            )
          )
        );
      }
    }], [{
      key: 'getDerivedStateFromProps',
      value: function getDerivedStateFromProps(nextProps, state) {
        if (nextProps.hsl.a !== 1 && state.view === 'hex') {
          return { view: 'rgb' };
        }
        return null;
      }
    }]);
  
    return ChromeFields;
  }(_react2.default.Component);
  
  ChromeFields.defaultProps = {
    view: "hex"
  };
  
  exports.default = ChromeFields;

});

;/*!node_modules/react-color/lib/components/chrome/ChromePointer.js*/
amis.define('95ae820', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ChromePointer = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var ChromePointer = exports.ChromePointer = function ChromePointer() {
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '12px',
          height: '12px',
          borderRadius: '6px',
          transform: 'translate(-6px, -1px)',
          backgroundColor: 'rgb(248, 248, 248)',
          boxShadow: '0 1px 4px 0 rgba(0, 0, 0, 0.37)'
        }
      }
    });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  exports.default = ChromePointer;

});

;/*!node_modules/react-color/lib/components/chrome/ChromePointerCircle.js*/
amis.define('6264734', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.ChromePointerCircle = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var ChromePointerCircle = exports.ChromePointerCircle = function ChromePointerCircle() {
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '12px',
          height: '12px',
          borderRadius: '6px',
          boxShadow: 'inset 0 0 0 1px #fff',
          transform: 'translate(-6px, -6px)'
        }
      }
    });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  exports.default = ChromePointerCircle;

});

;/*!node_modules/react-color/lib/components/chrome/Chrome.js*/
amis.define('1fc76ec', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Chrome = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _ChromeFields = require('afb892a');
  
  var _ChromeFields2 = _interopRequireDefault(_ChromeFields);
  
  var _ChromePointer = require('95ae820');
  
  var _ChromePointer2 = _interopRequireDefault(_ChromePointer);
  
  var _ChromePointerCircle = require('6264734');
  
  var _ChromePointerCircle2 = _interopRequireDefault(_ChromePointerCircle);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Chrome = exports.Chrome = function Chrome(_ref) {
    var width = _ref.width,
        onChange = _ref.onChange,
        disableAlpha = _ref.disableAlpha,
        rgb = _ref.rgb,
        hsl = _ref.hsl,
        hsv = _ref.hsv,
        hex = _ref.hex,
        renderers = _ref.renderers,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className,
        defaultView = _ref.defaultView;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        picker: {
          width: width,
          background: '#fff',
          borderRadius: '2px',
          boxShadow: '0 0 2px rgba(0,0,0,.3), 0 4px 8px rgba(0,0,0,.3)',
          boxSizing: 'initial',
          fontFamily: 'Menlo'
        },
        saturation: {
          width: '100%',
          paddingBottom: '55%',
          position: 'relative',
          borderRadius: '2px 2px 0 0',
          overflow: 'hidden'
        },
        Saturation: {
          radius: '2px 2px 0 0'
        },
        body: {
          padding: '16px 16px 12px'
        },
        controls: {
          display: 'flex'
        },
        color: {
          width: '32px'
        },
        swatch: {
          marginTop: '6px',
          width: '16px',
          height: '16px',
          borderRadius: '8px',
          position: 'relative',
          overflow: 'hidden'
        },
        active: {
          absolute: '0px 0px 0px 0px',
          borderRadius: '8px',
          boxShadow: 'inset 0 0 0 1px rgba(0,0,0,.1)',
          background: 'rgba(' + rgb.r + ', ' + rgb.g + ', ' + rgb.b + ', ' + rgb.a + ')',
          zIndex: '2'
        },
        toggles: {
          flex: '1'
        },
        hue: {
          height: '10px',
          position: 'relative',
          marginBottom: '8px'
        },
        Hue: {
          radius: '2px'
        },
        alpha: {
          height: '10px',
          position: 'relative'
        },
        Alpha: {
          radius: '2px'
        }
      },
      'disableAlpha': {
        color: {
          width: '22px'
        },
        alpha: {
          display: 'none'
        },
        hue: {
          marginBottom: '0px'
        },
        swatch: {
          width: '10px',
          height: '10px',
          marginTop: '0px'
        }
      }
    }, passedStyles), { disableAlpha: disableAlpha });
  
    return _react2.default.createElement(
      'div',
      { style: styles.picker, className: 'chrome-picker ' + className },
      _react2.default.createElement(
        'div',
        { style: styles.saturation },
        _react2.default.createElement(_common.Saturation, {
          style: styles.Saturation,
          hsl: hsl,
          hsv: hsv,
          pointer: _ChromePointerCircle2.default,
          onChange: onChange
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.body },
        _react2.default.createElement(
          'div',
          { style: styles.controls, className: 'flexbox-fix' },
          _react2.default.createElement(
            'div',
            { style: styles.color },
            _react2.default.createElement(
              'div',
              { style: styles.swatch },
              _react2.default.createElement('div', { style: styles.active }),
              _react2.default.createElement(_common.Checkboard, { renderers: renderers })
            )
          ),
          _react2.default.createElement(
            'div',
            { style: styles.toggles },
            _react2.default.createElement(
              'div',
              { style: styles.hue },
              _react2.default.createElement(_common.Hue, {
                style: styles.Hue,
                hsl: hsl,
                pointer: _ChromePointer2.default,
                onChange: onChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.alpha },
              _react2.default.createElement(_common.Alpha, {
                style: styles.Alpha,
                rgb: rgb,
                hsl: hsl,
                pointer: _ChromePointer2.default,
                renderers: renderers,
                onChange: onChange
              })
            )
          )
        ),
        _react2.default.createElement(_ChromeFields2.default, {
          rgb: rgb,
          hsl: hsl,
          hex: hex,
          view: defaultView,
          onChange: onChange,
          disableAlpha: disableAlpha
        })
      )
    );
  };
  
  Chrome.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    disableAlpha: _propTypes2.default.bool,
    styles: _propTypes2.default.object,
    defaultView: _propTypes2.default.oneOf(["hex", "rgb", "hsl"])
  };
  
  Chrome.defaultProps = {
    width: 225,
    disableAlpha: false,
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Chrome);

});

;/*!node_modules/react-color/lib/components/compact/CompactColor.js*/
amis.define('cc862ad', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CompactColor = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _color = require('dade38d');
  
  var colorUtils = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var CompactColor = exports.CompactColor = function CompactColor(_ref) {
    var color = _ref.color,
        _ref$onClick = _ref.onClick,
        onClick = _ref$onClick === undefined ? function () {} : _ref$onClick,
        onSwatchHover = _ref.onSwatchHover,
        active = _ref.active;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        color: {
          background: color,
          width: '15px',
          height: '15px',
          float: 'left',
          marginRight: '5px',
          marginBottom: '5px',
          position: 'relative',
          cursor: 'pointer'
        },
        dot: {
          absolute: '5px 5px 5px 5px',
          background: colorUtils.getContrastingColor(color),
          borderRadius: '50%',
          opacity: '0'
        }
      },
      'active': {
        dot: {
          opacity: '1'
        }
      },
      'color-#FFFFFF': {
        color: {
          boxShadow: 'inset 0 0 0 1px #ddd'
        },
        dot: {
          background: '#000'
        }
      },
      'transparent': {
        dot: {
          background: '#000'
        }
      }
    }, { active: active, 'color-#FFFFFF': color === '#FFFFFF', 'transparent': color === 'transparent' });
  
    return _react2.default.createElement(
      _common.Swatch,
      {
        style: styles.color,
        color: color,
        onClick: onClick,
        onHover: onSwatchHover,
        focusStyle: { boxShadow: '0 0 4px ' + color }
      },
      _react2.default.createElement('div', { style: styles.dot })
    );
  };
  
  exports.default = CompactColor;

});

;/*!node_modules/react-color/lib/components/compact/CompactFields.js*/
amis.define('9a7f4a5', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CompactFields = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _common = require('0eb8409');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var CompactFields = exports.CompactFields = function CompactFields(_ref) {
    var hex = _ref.hex,
        rgb = _ref.rgb,
        onChange = _ref.onChange;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        fields: {
          display: 'flex',
          paddingBottom: '6px',
          paddingRight: '5px',
          position: 'relative'
        },
        active: {
          position: 'absolute',
          top: '6px',
          left: '5px',
          height: '9px',
          width: '9px',
          background: hex
        },
        HEXwrap: {
          flex: '6',
          position: 'relative'
        },
        HEXinput: {
          width: '80%',
          padding: '0px',
          paddingLeft: '20%',
          border: 'none',
          outline: 'none',
          background: 'none',
          fontSize: '12px',
          color: '#333',
          height: '16px'
        },
        HEXlabel: {
          display: 'none'
        },
        RGBwrap: {
          flex: '3',
          position: 'relative'
        },
        RGBinput: {
          width: '70%',
          padding: '0px',
          paddingLeft: '30%',
          border: 'none',
          outline: 'none',
          background: 'none',
          fontSize: '12px',
          color: '#333',
          height: '16px'
        },
        RGBlabel: {
          position: 'absolute',
          top: '3px',
          left: '0px',
          lineHeight: '16px',
          textTransform: 'uppercase',
          fontSize: '12px',
          color: '#999'
        }
      }
    });
  
    var handleChange = function handleChange(data, e) {
      if (data.r || data.g || data.b) {
        onChange({
          r: data.r || rgb.r,
          g: data.g || rgb.g,
          b: data.b || rgb.b,
          source: 'rgb'
        }, e);
      } else {
        onChange({
          hex: data.hex,
          source: 'hex'
        }, e);
      }
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.fields, className: 'flexbox-fix' },
      _react2.default.createElement('div', { style: styles.active }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.HEXwrap, input: styles.HEXinput, label: styles.HEXlabel },
        label: 'hex',
        value: hex,
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'r',
        value: rgb.r,
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'g',
        value: rgb.g,
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'b',
        value: rgb.b,
        onChange: handleChange
      })
    );
  };
  
  exports.default = CompactFields;

});

;/*!node_modules/react-color/lib/components/compact/Compact.js*/
amis.define('eeff894', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Compact = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  var _CompactColor = require('cc862ad');
  
  var _CompactColor2 = _interopRequireDefault(_CompactColor);
  
  var _CompactFields = require('9a7f4a5');
  
  var _CompactFields2 = _interopRequireDefault(_CompactFields);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Compact = exports.Compact = function Compact(_ref) {
    var onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        colors = _ref.colors,
        hex = _ref.hex,
        rgb = _ref.rgb,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        Compact: {
          background: '#f6f6f6',
          radius: '4px'
        },
        compact: {
          paddingTop: '5px',
          paddingLeft: '5px',
          boxSizing: 'initial',
          width: '240px'
        },
        clear: {
          clear: 'both'
        }
      }
    }, passedStyles));
  
    var handleChange = function handleChange(data, e) {
      if (data.hex) {
        color.isValidHex(data.hex) && onChange({
          hex: data.hex,
          source: 'hex'
        }, e);
      } else {
        onChange(data, e);
      }
    };
  
    return _react2.default.createElement(
      _common.Raised,
      { style: styles.Compact, styles: passedStyles },
      _react2.default.createElement(
        'div',
        { style: styles.compact, className: 'compact-picker ' + className },
        _react2.default.createElement(
          'div',
          null,
          (0, _map2.default)(colors, function (c) {
            return _react2.default.createElement(_CompactColor2.default, {
              key: c,
              color: c,
              active: c.toLowerCase() === hex,
              onClick: handleChange,
              onSwatchHover: onSwatchHover
            });
          }),
          _react2.default.createElement('div', { style: styles.clear })
        ),
        _react2.default.createElement(_CompactFields2.default, { hex: hex, rgb: rgb, onChange: handleChange })
      )
    );
  };
  
  Compact.propTypes = {
    colors: _propTypes2.default.arrayOf(_propTypes2.default.string),
    styles: _propTypes2.default.object
  };
  
  Compact.defaultProps = {
    colors: ['#4D4D4D', '#999999', '#FFFFFF', '#F44E3B', '#FE9200', '#FCDC00', '#DBDF00', '#A4DD00', '#68CCCA', '#73D8FF', '#AEA1FF', '#FDA1FF', '#333333', '#808080', '#cccccc', '#D33115', '#E27300', '#FCC400', '#B0BC00', '#68BC00', '#16A5A5', '#009CE0', '#7B64FF', '#FA28FF', '#000000', '#666666', '#B3B3B3', '#9F0500', '#C45100', '#FB9E00', '#808900', '#194D33', '#0C797D', '#0062B1', '#653294', '#AB149E'],
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Compact);

});

;/*!node_modules/react-color/lib/components/github/GithubSwatch.js*/
amis.define('394000e', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.GithubSwatch = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _common = require('0eb8409');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var GithubSwatch = exports.GithubSwatch = function GithubSwatch(_ref) {
    var hover = _ref.hover,
        color = _ref.color,
        onClick = _ref.onClick,
        onSwatchHover = _ref.onSwatchHover;
  
    var hoverSwatch = {
      position: 'relative',
      zIndex: '2',
      outline: '2px solid #fff',
      boxShadow: '0 0 5px 2px rgba(0,0,0,0.25)'
    };
  
    var styles = (0, _reactcss2.default)({
      'default': {
        swatch: {
          width: '25px',
          height: '25px',
          fontSize: '0'
        }
      },
      'hover': {
        swatch: hoverSwatch
      }
    }, { hover: hover });
  
    return _react2.default.createElement(
      'div',
      { style: styles.swatch },
      _react2.default.createElement(_common.Swatch, {
        color: color,
        onClick: onClick,
        onHover: onSwatchHover,
        focusStyle: hoverSwatch
      })
    );
  };
  
  exports.default = (0, _reactcss.handleHover)(GithubSwatch);

});

;/*!node_modules/react-color/lib/components/github/Github.js*/
amis.define('996d229', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Github = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _GithubSwatch = require('394000e');
  
  var _GithubSwatch2 = _interopRequireDefault(_GithubSwatch);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Github = exports.Github = function Github(_ref) {
    var width = _ref.width,
        colors = _ref.colors,
        onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        triangle = _ref.triangle,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        card: {
          width: width,
          background: '#fff',
          border: '1px solid rgba(0,0,0,0.2)',
          boxShadow: '0 3px 12px rgba(0,0,0,0.15)',
          borderRadius: '4px',
          position: 'relative',
          padding: '5px',
          display: 'flex',
          flexWrap: 'wrap'
        },
        triangle: {
          position: 'absolute',
          border: '7px solid transparent',
          borderBottomColor: '#fff'
        },
        triangleShadow: {
          position: 'absolute',
          border: '8px solid transparent',
          borderBottomColor: 'rgba(0,0,0,0.15)'
        }
      },
      'hide-triangle': {
        triangle: {
          display: 'none'
        },
        triangleShadow: {
          display: 'none'
        }
      },
      'top-left-triangle': {
        triangle: {
          top: '-14px',
          left: '10px'
        },
        triangleShadow: {
          top: '-16px',
          left: '9px'
        }
      },
      'top-right-triangle': {
        triangle: {
          top: '-14px',
          right: '10px'
        },
        triangleShadow: {
          top: '-16px',
          right: '9px'
        }
      },
      'bottom-left-triangle': {
        triangle: {
          top: '35px',
          left: '10px',
          transform: 'rotate(180deg)'
        },
        triangleShadow: {
          top: '37px',
          left: '9px',
          transform: 'rotate(180deg)'
        }
      },
      'bottom-right-triangle': {
        triangle: {
          top: '35px',
          right: '10px',
          transform: 'rotate(180deg)'
        },
        triangleShadow: {
          top: '37px',
          right: '9px',
          transform: 'rotate(180deg)'
        }
      }
    }, passedStyles), {
      'hide-triangle': triangle === 'hide',
      'top-left-triangle': triangle === 'top-left',
      'top-right-triangle': triangle === 'top-right',
      'bottom-left-triangle': triangle === 'bottom-left',
      'bottom-right-triangle': triangle === 'bottom-right'
    });
  
    var handleChange = function handleChange(hex, e) {
      return onChange({ hex: hex, source: 'hex' }, e);
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.card, className: 'github-picker ' + className },
      _react2.default.createElement('div', { style: styles.triangleShadow }),
      _react2.default.createElement('div', { style: styles.triangle }),
      (0, _map2.default)(colors, function (c) {
        return _react2.default.createElement(_GithubSwatch2.default, {
          color: c,
          key: c,
          onClick: handleChange,
          onSwatchHover: onSwatchHover
        });
      })
    );
  };
  
  Github.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    colors: _propTypes2.default.arrayOf(_propTypes2.default.string),
    triangle: _propTypes2.default.oneOf(['hide', 'top-left', 'top-right', 'bottom-left', 'bottom-right']),
    styles: _propTypes2.default.object
  };
  
  Github.defaultProps = {
    width: 200,
    colors: ['#B80000', '#DB3E00', '#FCCB00', '#008B02', '#006B76', '#1273DE', '#004DCF', '#5300EB', '#EB9694', '#FAD0C3', '#FEF3BD', '#C1E1C5', '#BEDADC', '#C4DEF6', '#BED3F3', '#D4C4FB'],
    triangle: 'top-left',
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Github);

});

;/*!node_modules/react-color/lib/components/hue/HuePointer.js*/
amis.define('a9330c9', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SliderPointer = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SliderPointer = exports.SliderPointer = function SliderPointer(_ref) {
    var direction = _ref.direction;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '18px',
          height: '18px',
          borderRadius: '50%',
          transform: 'translate(-9px, -1px)',
          backgroundColor: 'rgb(248, 248, 248)',
          boxShadow: '0 1px 4px 0 rgba(0, 0, 0, 0.37)'
        }
      },
      'vertical': {
        picker: {
          transform: 'translate(-3px, -9px)'
        }
      }
    }, { vertical: direction === 'vertical' });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  exports.default = SliderPointer;

});

;/*!node_modules/react-color/lib/components/hue/Hue.js*/
amis.define('95ec6a3', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.HuePicker = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _HuePointer = require('a9330c9');
  
  var _HuePointer2 = _interopRequireDefault(_HuePointer);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var HuePicker = exports.HuePicker = function HuePicker(_ref) {
    var width = _ref.width,
        height = _ref.height,
        onChange = _ref.onChange,
        hsl = _ref.hsl,
        direction = _ref.direction,
        pointer = _ref.pointer,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        picker: {
          position: 'relative',
          width: width,
          height: height
        },
        hue: {
          radius: '2px'
        }
      }
    }, passedStyles));
  
    // Overwrite to provide pure hue color
    var handleChange = function handleChange(data) {
      return onChange({ a: 1, h: data.h, l: 0.5, s: 1 });
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.picker, className: 'hue-picker ' + className },
      _react2.default.createElement(_common.Hue, _extends({}, styles.hue, {
        hsl: hsl,
        pointer: pointer,
        onChange: handleChange,
        direction: direction
      }))
    );
  };
  
  HuePicker.propTypes = {
    styles: _propTypes2.default.object
  };
  HuePicker.defaultProps = {
    width: '316px',
    height: '16px',
    direction: 'horizontal',
    pointer: _HuePointer2.default,
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(HuePicker);

});

;/*!node_modules/react-color/lib/components/material/Material.js*/
amis.define('cbbf7e6', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Material = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Material = exports.Material = function Material(_ref) {
    var onChange = _ref.onChange,
        hex = _ref.hex,
        rgb = _ref.rgb,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        material: {
          width: '98px',
          height: '98px',
          padding: '16px',
          fontFamily: 'Roboto'
        },
        HEXwrap: {
          position: 'relative'
        },
        HEXinput: {
          width: '100%',
          marginTop: '12px',
          fontSize: '15px',
          color: '#333',
          padding: '0px',
          border: '0px',
          borderBottom: '2px solid ' + hex,
          outline: 'none',
          height: '30px'
        },
        HEXlabel: {
          position: 'absolute',
          top: '0px',
          left: '0px',
          fontSize: '11px',
          color: '#999999',
          textTransform: 'capitalize'
        },
        Hex: {
          style: {}
        },
        RGBwrap: {
          position: 'relative'
        },
        RGBinput: {
          width: '100%',
          marginTop: '12px',
          fontSize: '15px',
          color: '#333',
          padding: '0px',
          border: '0px',
          borderBottom: '1px solid #eee',
          outline: 'none',
          height: '30px'
        },
        RGBlabel: {
          position: 'absolute',
          top: '0px',
          left: '0px',
          fontSize: '11px',
          color: '#999999',
          textTransform: 'capitalize'
        },
        split: {
          display: 'flex',
          marginRight: '-10px',
          paddingTop: '11px'
        },
        third: {
          flex: '1',
          paddingRight: '10px'
        }
      }
    }, passedStyles));
  
    var handleChange = function handleChange(data, e) {
      if (data.hex) {
        color.isValidHex(data.hex) && onChange({
          hex: data.hex,
          source: 'hex'
        }, e);
      } else if (data.r || data.g || data.b) {
        onChange({
          r: data.r || rgb.r,
          g: data.g || rgb.g,
          b: data.b || rgb.b,
          source: 'rgb'
        }, e);
      }
    };
  
    return _react2.default.createElement(
      _common.Raised,
      { styles: passedStyles },
      _react2.default.createElement(
        'div',
        { style: styles.material, className: 'material-picker ' + className },
        _react2.default.createElement(_common.EditableInput, {
          style: { wrap: styles.HEXwrap, input: styles.HEXinput, label: styles.HEXlabel },
          label: 'hex',
          value: hex,
          onChange: handleChange
        }),
        _react2.default.createElement(
          'div',
          { style: styles.split, className: 'flexbox-fix' },
          _react2.default.createElement(
            'div',
            { style: styles.third },
            _react2.default.createElement(_common.EditableInput, {
              style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
              label: 'r', value: rgb.r,
              onChange: handleChange
            })
          ),
          _react2.default.createElement(
            'div',
            { style: styles.third },
            _react2.default.createElement(_common.EditableInput, {
              style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
              label: 'g',
              value: rgb.g,
              onChange: handleChange
            })
          ),
          _react2.default.createElement(
            'div',
            { style: styles.third },
            _react2.default.createElement(_common.EditableInput, {
              style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
              label: 'b',
              value: rgb.b,
              onChange: handleChange
            })
          )
        )
      )
    );
  };
  
  exports.default = (0, _common.ColorWrap)(Material);

});

;/*!node_modules/react-color/lib/components/photoshop/PhotoshopFields.js*/
amis.define('b2dc3b0', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PhotoshopPicker = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var PhotoshopPicker = exports.PhotoshopPicker = function PhotoshopPicker(_ref) {
    var onChange = _ref.onChange,
        rgb = _ref.rgb,
        hsv = _ref.hsv,
        hex = _ref.hex;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        fields: {
          paddingTop: '5px',
          paddingBottom: '9px',
          width: '80px',
          position: 'relative'
        },
        divider: {
          height: '5px'
        },
        RGBwrap: {
          position: 'relative'
        },
        RGBinput: {
          marginLeft: '40%',
          width: '40%',
          height: '18px',
          border: '1px solid #888888',
          boxShadow: 'inset 0 1px 1px rgba(0,0,0,.1), 0 1px 0 0 #ECECEC',
          marginBottom: '5px',
          fontSize: '13px',
          paddingLeft: '3px',
          marginRight: '10px'
        },
        RGBlabel: {
          left: '0px',
          top: '0px',
          width: '34px',
          textTransform: 'uppercase',
          fontSize: '13px',
          height: '18px',
          lineHeight: '22px',
          position: 'absolute'
        },
        HEXwrap: {
          position: 'relative'
        },
        HEXinput: {
          marginLeft: '20%',
          width: '80%',
          height: '18px',
          border: '1px solid #888888',
          boxShadow: 'inset 0 1px 1px rgba(0,0,0,.1), 0 1px 0 0 #ECECEC',
          marginBottom: '6px',
          fontSize: '13px',
          paddingLeft: '3px'
        },
        HEXlabel: {
          position: 'absolute',
          top: '0px',
          left: '0px',
          width: '14px',
          textTransform: 'uppercase',
          fontSize: '13px',
          height: '18px',
          lineHeight: '22px'
        },
        fieldSymbols: {
          position: 'absolute',
          top: '5px',
          right: '-7px',
          fontSize: '13px'
        },
        symbol: {
          height: '20px',
          lineHeight: '22px',
          paddingBottom: '7px'
        }
      }
    });
  
    var handleChange = function handleChange(data, e) {
      if (data['#']) {
        color.isValidHex(data['#']) && onChange({
          hex: data['#'],
          source: 'hex'
        }, e);
      } else if (data.r || data.g || data.b) {
        onChange({
          r: data.r || rgb.r,
          g: data.g || rgb.g,
          b: data.b || rgb.b,
          source: 'rgb'
        }, e);
      } else if (data.h || data.s || data.v) {
        onChange({
          h: data.h || hsv.h,
          s: data.s || hsv.s,
          v: data.v || hsv.v,
          source: 'hsv'
        }, e);
      }
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.fields },
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'h',
        value: Math.round(hsv.h),
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 's',
        value: Math.round(hsv.s * 100),
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'v',
        value: Math.round(hsv.v * 100),
        onChange: handleChange
      }),
      _react2.default.createElement('div', { style: styles.divider }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'r',
        value: rgb.r,
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'g',
        value: rgb.g,
        onChange: handleChange
      }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.RGBwrap, input: styles.RGBinput, label: styles.RGBlabel },
        label: 'b',
        value: rgb.b,
        onChange: handleChange
      }),
      _react2.default.createElement('div', { style: styles.divider }),
      _react2.default.createElement(_common.EditableInput, {
        style: { wrap: styles.HEXwrap, input: styles.HEXinput, label: styles.HEXlabel },
        label: '#',
        value: hex.replace('#', ''),
        onChange: handleChange
      }),
      _react2.default.createElement(
        'div',
        { style: styles.fieldSymbols },
        _react2.default.createElement(
          'div',
          { style: styles.symbol },
          '\xB0'
        ),
        _react2.default.createElement(
          'div',
          { style: styles.symbol },
          '%'
        ),
        _react2.default.createElement(
          'div',
          { style: styles.symbol },
          '%'
        )
      )
    );
  };
  
  exports.default = PhotoshopPicker;

});

;/*!node_modules/react-color/lib/components/photoshop/PhotoshopPointerCircle.js*/
amis.define('be5e0d6', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PhotoshopPointerCircle = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var PhotoshopPointerCircle = exports.PhotoshopPointerCircle = function PhotoshopPointerCircle(_ref) {
    var hsl = _ref.hsl;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '12px',
          height: '12px',
          borderRadius: '6px',
          boxShadow: 'inset 0 0 0 1px #fff',
          transform: 'translate(-6px, -6px)'
        }
      },
      'black-outline': {
        picker: {
          boxShadow: 'inset 0 0 0 1px #000'
        }
      }
    }, { 'black-outline': hsl.l > 0.5 });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  exports.default = PhotoshopPointerCircle;

});

;/*!node_modules/react-color/lib/components/photoshop/PhotoshopPointer.js*/
amis.define('ddf2850', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PhotoshopPointerCircle = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var PhotoshopPointerCircle = exports.PhotoshopPointerCircle = function PhotoshopPointerCircle() {
    var styles = (0, _reactcss2.default)({
      'default': {
        triangle: {
          width: 0,
          height: 0,
          borderStyle: 'solid',
          borderWidth: '4px 0 4px 6px',
          borderColor: 'transparent transparent transparent #fff',
          position: 'absolute',
          top: '1px',
          left: '1px'
        },
        triangleBorder: {
          width: 0,
          height: 0,
          borderStyle: 'solid',
          borderWidth: '5px 0 5px 8px',
          borderColor: 'transparent transparent transparent #555'
        },
  
        left: {
          Extend: 'triangleBorder',
          transform: 'translate(-13px, -4px)'
        },
        leftInside: {
          Extend: 'triangle',
          transform: 'translate(-8px, -5px)'
        },
  
        right: {
          Extend: 'triangleBorder',
          transform: 'translate(20px, -14px) rotate(180deg)'
        },
        rightInside: {
          Extend: 'triangle',
          transform: 'translate(-8px, -5px)'
        }
      }
    });
  
    return _react2.default.createElement(
      'div',
      { style: styles.pointer },
      _react2.default.createElement(
        'div',
        { style: styles.left },
        _react2.default.createElement('div', { style: styles.leftInside })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.right },
        _react2.default.createElement('div', { style: styles.rightInside })
      )
    );
  };
  
  exports.default = PhotoshopPointerCircle;

});

;/*!node_modules/react-color/lib/components/photoshop/PhotoshopButton.js*/
amis.define('fa53314', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PhotoshopButton = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var PhotoshopButton = exports.PhotoshopButton = function PhotoshopButton(_ref) {
    var onClick = _ref.onClick,
        label = _ref.label,
        children = _ref.children,
        active = _ref.active;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        button: {
          backgroundImage: 'linear-gradient(-180deg, #FFFFFF 0%, #E6E6E6 100%)',
          border: '1px solid #878787',
          borderRadius: '2px',
          height: '20px',
          boxShadow: '0 1px 0 0 #EAEAEA',
          fontSize: '14px',
          color: '#000',
          lineHeight: '20px',
          textAlign: 'center',
          marginBottom: '10px',
          cursor: 'pointer'
        }
      },
      'active': {
        button: {
          boxShadow: '0 0 0 1px #878787'
        }
      }
    }, { active: active });
  
    return _react2.default.createElement(
      'div',
      { style: styles.button, onClick: onClick },
      label || children
    );
  };
  
  exports.default = PhotoshopButton;

});

;/*!node_modules/react-color/lib/components/photoshop/PhotoshopPreviews.js*/
amis.define('47959a2', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.PhotoshopPreviews = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var PhotoshopPreviews = exports.PhotoshopPreviews = function PhotoshopPreviews(_ref) {
    var rgb = _ref.rgb,
        currentColor = _ref.currentColor;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        swatches: {
          border: '1px solid #B3B3B3',
          borderBottom: '1px solid #F0F0F0',
          marginBottom: '2px',
          marginTop: '1px'
        },
        new: {
          height: '34px',
          background: 'rgb(' + rgb.r + ',' + rgb.g + ', ' + rgb.b + ')',
          boxShadow: 'inset 1px 0 0 #000, inset -1px 0 0 #000, inset 0 1px 0 #000'
        },
        current: {
          height: '34px',
          background: currentColor,
          boxShadow: 'inset 1px 0 0 #000, inset -1px 0 0 #000, inset 0 -1px 0 #000'
        },
        label: {
          fontSize: '14px',
          color: '#000',
          textAlign: 'center'
        }
      }
    });
  
    return _react2.default.createElement(
      'div',
      null,
      _react2.default.createElement(
        'div',
        { style: styles.label },
        'new'
      ),
      _react2.default.createElement(
        'div',
        { style: styles.swatches },
        _react2.default.createElement('div', { style: styles.new }),
        _react2.default.createElement('div', { style: styles.current })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.label },
        'current'
      )
    );
  };
  
  exports.default = PhotoshopPreviews;

});

;/*!node_modules/react-color/lib/components/photoshop/Photoshop.js*/
amis.define('919230c', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Photoshop = undefined;
  
  var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _PhotoshopFields = require('b2dc3b0');
  
  var _PhotoshopFields2 = _interopRequireDefault(_PhotoshopFields);
  
  var _PhotoshopPointerCircle = require('be5e0d6');
  
  var _PhotoshopPointerCircle2 = _interopRequireDefault(_PhotoshopPointerCircle);
  
  var _PhotoshopPointer = require('ddf2850');
  
  var _PhotoshopPointer2 = _interopRequireDefault(_PhotoshopPointer);
  
  var _PhotoshopButton = require('fa53314');
  
  var _PhotoshopButton2 = _interopRequireDefault(_PhotoshopButton);
  
  var _PhotoshopPreviews = require('47959a2');
  
  var _PhotoshopPreviews2 = _interopRequireDefault(_PhotoshopPreviews);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
  
  function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }
  
  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }
  
  var Photoshop = exports.Photoshop = function (_React$Component) {
    _inherits(Photoshop, _React$Component);
  
    function Photoshop(props) {
      _classCallCheck(this, Photoshop);
  
      var _this = _possibleConstructorReturn(this, (Photoshop.__proto__ || Object.getPrototypeOf(Photoshop)).call(this));
  
      _this.state = {
        currentColor: props.hex
      };
      return _this;
    }
  
    _createClass(Photoshop, [{
      key: 'render',
      value: function render() {
        var _props = this.props,
            _props$styles = _props.styles,
            passedStyles = _props$styles === undefined ? {} : _props$styles,
            _props$className = _props.className,
            className = _props$className === undefined ? '' : _props$className;
  
        var styles = (0, _reactcss2.default)((0, _merge2.default)({
          'default': {
            picker: {
              background: '#DCDCDC',
              borderRadius: '4px',
              boxShadow: '0 0 0 1px rgba(0,0,0,.25), 0 8px 16px rgba(0,0,0,.15)',
              boxSizing: 'initial',
              width: '513px'
            },
            head: {
              backgroundImage: 'linear-gradient(-180deg, #F0F0F0 0%, #D4D4D4 100%)',
              borderBottom: '1px solid #B1B1B1',
              boxShadow: 'inset 0 1px 0 0 rgba(255,255,255,.2), inset 0 -1px 0 0 rgba(0,0,0,.02)',
              height: '23px',
              lineHeight: '24px',
              borderRadius: '4px 4px 0 0',
              fontSize: '13px',
              color: '#4D4D4D',
              textAlign: 'center'
            },
            body: {
              padding: '15px 15px 0',
              display: 'flex'
            },
            saturation: {
              width: '256px',
              height: '256px',
              position: 'relative',
              border: '2px solid #B3B3B3',
              borderBottom: '2px solid #F0F0F0',
              overflow: 'hidden'
            },
            hue: {
              position: 'relative',
              height: '256px',
              width: '19px',
              marginLeft: '10px',
              border: '2px solid #B3B3B3',
              borderBottom: '2px solid #F0F0F0'
            },
            controls: {
              width: '180px',
              marginLeft: '10px'
            },
            top: {
              display: 'flex'
            },
            previews: {
              width: '60px'
            },
            actions: {
              flex: '1',
              marginLeft: '20px'
            }
          }
        }, passedStyles));
  
        return _react2.default.createElement(
          'div',
          { style: styles.picker, className: 'photoshop-picker ' + className },
          _react2.default.createElement(
            'div',
            { style: styles.head },
            this.props.header
          ),
          _react2.default.createElement(
            'div',
            { style: styles.body, className: 'flexbox-fix' },
            _react2.default.createElement(
              'div',
              { style: styles.saturation },
              _react2.default.createElement(_common.Saturation, {
                hsl: this.props.hsl,
                hsv: this.props.hsv,
                pointer: _PhotoshopPointerCircle2.default,
                onChange: this.props.onChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.hue },
              _react2.default.createElement(_common.Hue, {
                direction: 'vertical',
                hsl: this.props.hsl,
                pointer: _PhotoshopPointer2.default,
                onChange: this.props.onChange
              })
            ),
            _react2.default.createElement(
              'div',
              { style: styles.controls },
              _react2.default.createElement(
                'div',
                { style: styles.top, className: 'flexbox-fix' },
                _react2.default.createElement(
                  'div',
                  { style: styles.previews },
                  _react2.default.createElement(_PhotoshopPreviews2.default, {
                    rgb: this.props.rgb,
                    currentColor: this.state.currentColor
                  })
                ),
                _react2.default.createElement(
                  'div',
                  { style: styles.actions },
                  _react2.default.createElement(_PhotoshopButton2.default, { label: 'OK', onClick: this.props.onAccept, active: true }),
                  _react2.default.createElement(_PhotoshopButton2.default, { label: 'Cancel', onClick: this.props.onCancel }),
                  _react2.default.createElement(_PhotoshopFields2.default, {
                    onChange: this.props.onChange,
                    rgb: this.props.rgb,
                    hsv: this.props.hsv,
                    hex: this.props.hex
                  })
                )
              )
            )
          )
        );
      }
    }]);
  
    return Photoshop;
  }(_react2.default.Component);
  
  Photoshop.propTypes = {
    header: _propTypes2.default.string,
    styles: _propTypes2.default.object
  };
  
  Photoshop.defaultProps = {
    header: 'Color Picker',
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Photoshop);

});

;/*!node_modules/react-color/lib/components/sketch/SketchFields.js*/
amis.define('8c38341', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SketchFields = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  /* eslint-disable no-param-reassign */
  
  var SketchFields = exports.SketchFields = function SketchFields(_ref) {
    var onChange = _ref.onChange,
        rgb = _ref.rgb,
        hsl = _ref.hsl,
        hex = _ref.hex,
        disableAlpha = _ref.disableAlpha;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        fields: {
          display: 'flex',
          paddingTop: '4px'
        },
        single: {
          flex: '1',
          paddingLeft: '6px'
        },
        alpha: {
          flex: '1',
          paddingLeft: '6px'
        },
        double: {
          flex: '2'
        },
        input: {
          width: '80%',
          padding: '4px 10% 3px',
          border: 'none',
          boxShadow: 'inset 0 0 0 1px #ccc',
          fontSize: '11px'
        },
        label: {
          display: 'block',
          textAlign: 'center',
          fontSize: '11px',
          color: '#222',
          paddingTop: '3px',
          paddingBottom: '4px',
          textTransform: 'capitalize'
        }
      },
      'disableAlpha': {
        alpha: {
          display: 'none'
        }
      }
    }, { disableAlpha: disableAlpha });
  
    var handleChange = function handleChange(data, e) {
      if (data.hex) {
        color.isValidHex(data.hex) && onChange({
          hex: data.hex,
          source: 'hex'
        }, e);
      } else if (data.r || data.g || data.b) {
        onChange({
          r: data.r || rgb.r,
          g: data.g || rgb.g,
          b: data.b || rgb.b,
          a: rgb.a,
          source: 'rgb'
        }, e);
      } else if (data.a) {
        if (data.a < 0) {
          data.a = 0;
        } else if (data.a > 100) {
          data.a = 100;
        }
  
        data.a /= 100;
        onChange({
          h: hsl.h,
          s: hsl.s,
          l: hsl.l,
          a: data.a,
          source: 'rgb'
        }, e);
      }
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.fields, className: 'flexbox-fix' },
      _react2.default.createElement(
        'div',
        { style: styles.double },
        _react2.default.createElement(_common.EditableInput, {
          style: { input: styles.input, label: styles.label },
          label: 'hex',
          value: hex.replace('#', ''),
          onChange: handleChange
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.single },
        _react2.default.createElement(_common.EditableInput, {
          style: { input: styles.input, label: styles.label },
          label: 'r',
          value: rgb.r,
          onChange: handleChange,
          dragLabel: 'true',
          dragMax: '255'
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.single },
        _react2.default.createElement(_common.EditableInput, {
          style: { input: styles.input, label: styles.label },
          label: 'g',
          value: rgb.g,
          onChange: handleChange,
          dragLabel: 'true',
          dragMax: '255'
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.single },
        _react2.default.createElement(_common.EditableInput, {
          style: { input: styles.input, label: styles.label },
          label: 'b',
          value: rgb.b,
          onChange: handleChange,
          dragLabel: 'true',
          dragMax: '255'
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.alpha },
        _react2.default.createElement(_common.EditableInput, {
          style: { input: styles.input, label: styles.label },
          label: 'a',
          value: Math.round(rgb.a * 100),
          onChange: handleChange,
          dragLabel: 'true',
          dragMax: '100'
        })
      )
    );
  };
  
  exports.default = SketchFields;

});

;/*!node_modules/react-color/lib/components/sketch/SketchPresetColors.js*/
amis.define('6526990', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SketchPresetColors = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _common = require('0eb8409');
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SketchPresetColors = exports.SketchPresetColors = function SketchPresetColors(_ref) {
    var colors = _ref.colors,
        _ref$onClick = _ref.onClick,
        onClick = _ref$onClick === undefined ? function () {} : _ref$onClick,
        onSwatchHover = _ref.onSwatchHover;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        colors: {
          margin: '0 -10px',
          padding: '10px 0 0 10px',
          borderTop: '1px solid #eee',
          display: 'flex',
          flexWrap: 'wrap',
          position: 'relative'
        },
        swatchWrap: {
          width: '16px',
          height: '16px',
          margin: '0 10px 10px 0'
        },
        swatch: {
          borderRadius: '3px',
          boxShadow: 'inset 0 0 0 1px rgba(0,0,0,.15)'
        }
      },
      'no-presets': {
        colors: {
          display: 'none'
        }
      }
    }, {
      'no-presets': !colors || !colors.length
    });
  
    var handleClick = function handleClick(hex, e) {
      onClick({
        hex: hex,
        source: 'hex'
      }, e);
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.colors, className: 'flexbox-fix' },
      colors.map(function (colorObjOrString) {
        var c = typeof colorObjOrString === 'string' ? { color: colorObjOrString } : colorObjOrString;
        var key = '' + c.color + (c.title || '');
        return _react2.default.createElement(
          'div',
          { key: key, style: styles.swatchWrap },
          _react2.default.createElement(_common.Swatch, _extends({}, c, {
            style: styles.swatch,
            onClick: handleClick,
            onHover: onSwatchHover,
            focusStyle: {
              boxShadow: 'inset 0 0 0 1px rgba(0,0,0,.15), 0 0 4px ' + c.color
            }
          }))
        );
      })
    );
  };
  
  SketchPresetColors.propTypes = {
    colors: _propTypes2.default.arrayOf(_propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.shape({
      color: _propTypes2.default.string,
      title: _propTypes2.default.string
    })])).isRequired
  };
  
  exports.default = SketchPresetColors;

});

;/*!node_modules/react-color/lib/components/sketch/Sketch.js*/
amis.define('1ff03ef', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Sketch = undefined;
  
  var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _SketchFields = require('8c38341');
  
  var _SketchFields2 = _interopRequireDefault(_SketchFields);
  
  var _SketchPresetColors = require('6526990');
  
  var _SketchPresetColors2 = _interopRequireDefault(_SketchPresetColors);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Sketch = exports.Sketch = function Sketch(_ref) {
    var width = _ref.width,
        rgb = _ref.rgb,
        hex = _ref.hex,
        hsv = _ref.hsv,
        hsl = _ref.hsl,
        onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        disableAlpha = _ref.disableAlpha,
        presetColors = _ref.presetColors,
        renderers = _ref.renderers,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': _extends({
        picker: {
          width: width,
          padding: '10px 10px 0',
          boxSizing: 'initial',
          background: '#fff',
          borderRadius: '4px',
          boxShadow: '0 0 0 1px rgba(0,0,0,.15), 0 8px 16px rgba(0,0,0,.15)'
        },
        saturation: {
          width: '100%',
          paddingBottom: '75%',
          position: 'relative',
          overflow: 'hidden'
        },
        Saturation: {
          radius: '3px',
          shadow: 'inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)'
        },
        controls: {
          display: 'flex'
        },
        sliders: {
          padding: '4px 0',
          flex: '1'
        },
        color: {
          width: '24px',
          height: '24px',
          position: 'relative',
          marginTop: '4px',
          marginLeft: '4px',
          borderRadius: '3px'
        },
        activeColor: {
          absolute: '0px 0px 0px 0px',
          borderRadius: '2px',
          background: 'rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ',' + rgb.a + ')',
          boxShadow: 'inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)'
        },
        hue: {
          position: 'relative',
          height: '10px',
          overflow: 'hidden'
        },
        Hue: {
          radius: '2px',
          shadow: 'inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)'
        },
  
        alpha: {
          position: 'relative',
          height: '10px',
          marginTop: '4px',
          overflow: 'hidden'
        },
        Alpha: {
          radius: '2px',
          shadow: 'inset 0 0 0 1px rgba(0,0,0,.15), inset 0 0 4px rgba(0,0,0,.25)'
        }
      }, passedStyles),
      'disableAlpha': {
        color: {
          height: '10px'
        },
        hue: {
          height: '10px'
        },
        alpha: {
          display: 'none'
        }
      }
    }, passedStyles), { disableAlpha: disableAlpha });
  
    return _react2.default.createElement(
      'div',
      { style: styles.picker, className: 'sketch-picker ' + className },
      _react2.default.createElement(
        'div',
        { style: styles.saturation },
        _react2.default.createElement(_common.Saturation, {
          style: styles.Saturation,
          hsl: hsl,
          hsv: hsv,
          onChange: onChange
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.controls, className: 'flexbox-fix' },
        _react2.default.createElement(
          'div',
          { style: styles.sliders },
          _react2.default.createElement(
            'div',
            { style: styles.hue },
            _react2.default.createElement(_common.Hue, {
              style: styles.Hue,
              hsl: hsl,
              onChange: onChange
            })
          ),
          _react2.default.createElement(
            'div',
            { style: styles.alpha },
            _react2.default.createElement(_common.Alpha, {
              style: styles.Alpha,
              rgb: rgb,
              hsl: hsl,
              renderers: renderers,
              onChange: onChange
            })
          )
        ),
        _react2.default.createElement(
          'div',
          { style: styles.color },
          _react2.default.createElement(_common.Checkboard, null),
          _react2.default.createElement('div', { style: styles.activeColor })
        )
      ),
      _react2.default.createElement(_SketchFields2.default, {
        rgb: rgb,
        hsl: hsl,
        hex: hex,
        onChange: onChange,
        disableAlpha: disableAlpha
      }),
      _react2.default.createElement(_SketchPresetColors2.default, {
        colors: presetColors,
        onClick: onChange,
        onSwatchHover: onSwatchHover
      })
    );
  };
  
  Sketch.propTypes = {
    disableAlpha: _propTypes2.default.bool,
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    styles: _propTypes2.default.object
  };
  
  Sketch.defaultProps = {
    disableAlpha: false,
    width: 200,
    styles: {},
    presetColors: ['#D0021B', '#F5A623', '#F8E71C', '#8B572A', '#7ED321', '#417505', '#BD10E0', '#9013FE', '#4A90E2', '#50E3C2', '#B8E986', '#000000', '#4A4A4A', '#9B9B9B', '#FFFFFF']
  };
  
  exports.default = (0, _common.ColorWrap)(Sketch);

});

;/*!node_modules/react-color/lib/components/slider/SliderSwatch.js*/
amis.define('a455d7b', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SliderSwatch = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SliderSwatch = exports.SliderSwatch = function SliderSwatch(_ref) {
    var hsl = _ref.hsl,
        offset = _ref.offset,
        _ref$onClick = _ref.onClick,
        onClick = _ref$onClick === undefined ? function () {} : _ref$onClick,
        active = _ref.active,
        first = _ref.first,
        last = _ref.last;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        swatch: {
          height: '12px',
          background: 'hsl(' + hsl.h + ', 50%, ' + offset * 100 + '%)',
          cursor: 'pointer'
        }
      },
      'first': {
        swatch: {
          borderRadius: '2px 0 0 2px'
        }
      },
      'last': {
        swatch: {
          borderRadius: '0 2px 2px 0'
        }
      },
      'active': {
        swatch: {
          transform: 'scaleY(1.8)',
          borderRadius: '3.6px/2px'
        }
      }
    }, { active: active, first: first, last: last });
  
    var handleClick = function handleClick(e) {
      return onClick({
        h: hsl.h,
        s: 0.5,
        l: offset,
        source: 'hsl'
      }, e);
    };
  
    return _react2.default.createElement('div', { style: styles.swatch, onClick: handleClick });
  };
  
  exports.default = SliderSwatch;

});

;/*!node_modules/react-color/lib/components/slider/SliderSwatches.js*/
amis.define('6d20894', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SliderSwatches = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _SliderSwatch = require('a455d7b');
  
  var _SliderSwatch2 = _interopRequireDefault(_SliderSwatch);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SliderSwatches = exports.SliderSwatches = function SliderSwatches(_ref) {
    var onClick = _ref.onClick,
        hsl = _ref.hsl;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        swatches: {
          marginTop: '20px'
        },
        swatch: {
          boxSizing: 'border-box',
          width: '20%',
          paddingRight: '1px',
          float: 'left'
        },
        clear: {
          clear: 'both'
        }
      }
    });
  
    // Acceptible difference in floating point equality
    var epsilon = 0.1;
  
    return _react2.default.createElement(
      'div',
      { style: styles.swatches },
      _react2.default.createElement(
        'div',
        { style: styles.swatch },
        _react2.default.createElement(_SliderSwatch2.default, {
          hsl: hsl,
          offset: '.80',
          active: Math.abs(hsl.l - 0.80) < epsilon && Math.abs(hsl.s - 0.50) < epsilon,
          onClick: onClick,
          first: true
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.swatch },
        _react2.default.createElement(_SliderSwatch2.default, {
          hsl: hsl,
          offset: '.65',
          active: Math.abs(hsl.l - 0.65) < epsilon && Math.abs(hsl.s - 0.50) < epsilon,
          onClick: onClick
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.swatch },
        _react2.default.createElement(_SliderSwatch2.default, {
          hsl: hsl,
          offset: '.50',
          active: Math.abs(hsl.l - 0.50) < epsilon && Math.abs(hsl.s - 0.50) < epsilon,
          onClick: onClick
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.swatch },
        _react2.default.createElement(_SliderSwatch2.default, {
          hsl: hsl,
          offset: '.35',
          active: Math.abs(hsl.l - 0.35) < epsilon && Math.abs(hsl.s - 0.50) < epsilon,
          onClick: onClick
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.swatch },
        _react2.default.createElement(_SliderSwatch2.default, {
          hsl: hsl,
          offset: '.20',
          active: Math.abs(hsl.l - 0.20) < epsilon && Math.abs(hsl.s - 0.50) < epsilon,
          onClick: onClick,
          last: true
        })
      ),
      _react2.default.createElement('div', { style: styles.clear })
    );
  };
  
  exports.default = SliderSwatches;

});

;/*!node_modules/react-color/lib/components/slider/SliderPointer.js*/
amis.define('a0ece13', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SliderPointer = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SliderPointer = exports.SliderPointer = function SliderPointer() {
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '14px',
          height: '14px',
          borderRadius: '6px',
          transform: 'translate(-7px, -1px)',
          backgroundColor: 'rgb(248, 248, 248)',
          boxShadow: '0 1px 4px 0 rgba(0, 0, 0, 0.37)'
        }
      }
    });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  exports.default = SliderPointer;

});

;/*!node_modules/react-color/lib/components/slider/Slider.js*/
amis.define('94e7338', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Slider = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _SliderSwatches = require('6d20894');
  
  var _SliderSwatches2 = _interopRequireDefault(_SliderSwatches);
  
  var _SliderPointer = require('a0ece13');
  
  var _SliderPointer2 = _interopRequireDefault(_SliderPointer);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Slider = exports.Slider = function Slider(_ref) {
    var hsl = _ref.hsl,
        onChange = _ref.onChange,
        pointer = _ref.pointer,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        hue: {
          height: '12px',
          position: 'relative'
        },
        Hue: {
          radius: '2px'
        }
      }
    }, passedStyles));
  
    return _react2.default.createElement(
      'div',
      { style: styles.wrap || {}, className: 'slider-picker ' + className },
      _react2.default.createElement(
        'div',
        { style: styles.hue },
        _react2.default.createElement(_common.Hue, {
          style: styles.Hue,
          hsl: hsl,
          pointer: pointer,
          onChange: onChange
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.swatches },
        _react2.default.createElement(_SliderSwatches2.default, { hsl: hsl, onClick: onChange })
      )
    );
  };
  
  Slider.propTypes = {
    styles: _propTypes2.default.object
  };
  Slider.defaultProps = {
    pointer: _SliderPointer2.default,
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Slider);

});

;/*!node_modules/react-color/lib/components/swatches/SwatchesColor.js*/
amis.define('c8dc961', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SwatchesColor = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _color = require('dade38d');
  
  var colorUtils = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  var _CheckIcon = require('7a9924a');
  
  var _CheckIcon2 = _interopRequireDefault(_CheckIcon);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SwatchesColor = exports.SwatchesColor = function SwatchesColor(_ref) {
    var color = _ref.color,
        _ref$onClick = _ref.onClick,
        onClick = _ref$onClick === undefined ? function () {} : _ref$onClick,
        onSwatchHover = _ref.onSwatchHover,
        first = _ref.first,
        last = _ref.last,
        active = _ref.active;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        color: {
          width: '40px',
          height: '24px',
          cursor: 'pointer',
          background: color,
          marginBottom: '1px'
        },
        check: {
          color: colorUtils.getContrastingColor(color),
          marginLeft: '8px',
          display: 'none'
        }
      },
      'first': {
        color: {
          overflow: 'hidden',
          borderRadius: '2px 2px 0 0'
        }
      },
      'last': {
        color: {
          overflow: 'hidden',
          borderRadius: '0 0 2px 2px'
        }
      },
      'active': {
        check: {
          display: 'block'
        }
      },
      'color-#FFFFFF': {
        color: {
          boxShadow: 'inset 0 0 0 1px #ddd'
        },
        check: {
          color: '#333'
        }
      },
      'transparent': {
        check: {
          color: '#333'
        }
      }
    }, {
      first: first,
      last: last,
      active: active,
      'color-#FFFFFF': color === '#FFFFFF',
      'transparent': color === 'transparent'
    });
  
    return _react2.default.createElement(
      _common.Swatch,
      {
        color: color,
        style: styles.color,
        onClick: onClick,
        onHover: onSwatchHover,
        focusStyle: { boxShadow: '0 0 4px ' + color }
      },
      _react2.default.createElement(
        'div',
        { style: styles.check },
        _react2.default.createElement(_CheckIcon2.default, null)
      )
    );
  };
  
  exports.default = SwatchesColor;

});

;/*!node_modules/react-color/lib/components/swatches/SwatchesGroup.js*/
amis.define('9501ae7', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.SwatchesGroup = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _SwatchesColor = require('c8dc961');
  
  var _SwatchesColor2 = _interopRequireDefault(_SwatchesColor);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var SwatchesGroup = exports.SwatchesGroup = function SwatchesGroup(_ref) {
    var onClick = _ref.onClick,
        onSwatchHover = _ref.onSwatchHover,
        group = _ref.group,
        active = _ref.active;
  
    var styles = (0, _reactcss2.default)({
      'default': {
        group: {
          paddingBottom: '10px',
          width: '40px',
          float: 'left',
          marginRight: '10px'
        }
      }
    });
  
    return _react2.default.createElement(
      'div',
      { style: styles.group },
      (0, _map2.default)(group, function (color, i) {
        return _react2.default.createElement(_SwatchesColor2.default, {
          key: color,
          color: color,
          active: color.toLowerCase() === active,
          first: i === 0,
          last: i === group.length - 1,
          onClick: onClick,
          onSwatchHover: onSwatchHover
        });
      })
    );
  };
  
  exports.default = SwatchesGroup;

});

;/*!node_modules/react-color/lib/components/swatches/Swatches.js*/
amis.define('8f54db2', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Swatches = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _materialColors = require('4fd9d03');
  
  var material = _interopRequireWildcard(_materialColors);
  
  var _common = require('0eb8409');
  
  var _SwatchesGroup = require('9501ae7');
  
  var _SwatchesGroup2 = _interopRequireDefault(_SwatchesGroup);
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Swatches = exports.Swatches = function Swatches(_ref) {
    var width = _ref.width,
        height = _ref.height,
        onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        colors = _ref.colors,
        hex = _ref.hex,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        picker: {
          width: width,
          height: height
        },
        overflow: {
          height: height,
          overflowY: 'scroll'
        },
        body: {
          padding: '16px 0 6px 16px'
        },
        clear: {
          clear: 'both'
        }
      }
    }, passedStyles));
  
    var handleChange = function handleChange(data, e) {
      return onChange({ hex: data, source: 'hex' }, e);
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.picker, className: 'swatches-picker ' + className },
      _react2.default.createElement(
        _common.Raised,
        null,
        _react2.default.createElement(
          'div',
          { style: styles.overflow },
          _react2.default.createElement(
            'div',
            { style: styles.body },
            (0, _map2.default)(colors, function (group) {
              return _react2.default.createElement(_SwatchesGroup2.default, {
                key: group.toString(),
                group: group,
                active: hex,
                onClick: handleChange,
                onSwatchHover: onSwatchHover
              });
            }),
            _react2.default.createElement('div', { style: styles.clear })
          )
        )
      )
    );
  };
  
  Swatches.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    height: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    colors: _propTypes2.default.arrayOf(_propTypes2.default.arrayOf(_propTypes2.default.string)),
    styles: _propTypes2.default.object
  
    /* eslint-disable max-len */
  };Swatches.defaultProps = {
    width: 320,
    height: 240,
    colors: [[material.red['900'], material.red['700'], material.red['500'], material.red['300'], material.red['100']], [material.pink['900'], material.pink['700'], material.pink['500'], material.pink['300'], material.pink['100']], [material.purple['900'], material.purple['700'], material.purple['500'], material.purple['300'], material.purple['100']], [material.deepPurple['900'], material.deepPurple['700'], material.deepPurple['500'], material.deepPurple['300'], material.deepPurple['100']], [material.indigo['900'], material.indigo['700'], material.indigo['500'], material.indigo['300'], material.indigo['100']], [material.blue['900'], material.blue['700'], material.blue['500'], material.blue['300'], material.blue['100']], [material.lightBlue['900'], material.lightBlue['700'], material.lightBlue['500'], material.lightBlue['300'], material.lightBlue['100']], [material.cyan['900'], material.cyan['700'], material.cyan['500'], material.cyan['300'], material.cyan['100']], [material.teal['900'], material.teal['700'], material.teal['500'], material.teal['300'], material.teal['100']], ['#194D33', material.green['700'], material.green['500'], material.green['300'], material.green['100']], [material.lightGreen['900'], material.lightGreen['700'], material.lightGreen['500'], material.lightGreen['300'], material.lightGreen['100']], [material.lime['900'], material.lime['700'], material.lime['500'], material.lime['300'], material.lime['100']], [material.yellow['900'], material.yellow['700'], material.yellow['500'], material.yellow['300'], material.yellow['100']], [material.amber['900'], material.amber['700'], material.amber['500'], material.amber['300'], material.amber['100']], [material.orange['900'], material.orange['700'], material.orange['500'], material.orange['300'], material.orange['100']], [material.deepOrange['900'], material.deepOrange['700'], material.deepOrange['500'], material.deepOrange['300'], material.deepOrange['100']], [material.brown['900'], material.brown['700'], material.brown['500'], material.brown['300'], material.brown['100']], [material.blueGrey['900'], material.blueGrey['700'], material.blueGrey['500'], material.blueGrey['300'], material.blueGrey['100']], ['#000000', '#525252', '#969696', '#D9D9D9', '#FFFFFF']],
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Swatches);

});

;/*!node_modules/react-color/lib/components/twitter/Twitter.js*/
amis.define('9de3a99', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Twitter = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _map = require('10ab2ce');
  
  var _map2 = _interopRequireDefault(_map);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Twitter = exports.Twitter = function Twitter(_ref) {
    var onChange = _ref.onChange,
        onSwatchHover = _ref.onSwatchHover,
        hex = _ref.hex,
        colors = _ref.colors,
        width = _ref.width,
        triangle = _ref.triangle,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        card: {
          width: width,
          background: '#fff',
          border: '0 solid rgba(0,0,0,0.25)',
          boxShadow: '0 1px 4px rgba(0,0,0,0.25)',
          borderRadius: '4px',
          position: 'relative'
        },
        body: {
          padding: '15px 9px 9px 15px'
        },
        label: {
          fontSize: '18px',
          color: '#fff'
        },
        triangle: {
          width: '0px',
          height: '0px',
          borderStyle: 'solid',
          borderWidth: '0 9px 10px 9px',
          borderColor: 'transparent transparent #fff transparent',
          position: 'absolute'
        },
        triangleShadow: {
          width: '0px',
          height: '0px',
          borderStyle: 'solid',
          borderWidth: '0 9px 10px 9px',
          borderColor: 'transparent transparent rgba(0,0,0,.1) transparent',
          position: 'absolute'
        },
        hash: {
          background: '#F0F0F0',
          height: '30px',
          width: '30px',
          borderRadius: '4px 0 0 4px',
          float: 'left',
          color: '#98A1A4',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        },
        input: {
          width: '100px',
          fontSize: '14px',
          color: '#666',
          border: '0px',
          outline: 'none',
          height: '28px',
          boxShadow: 'inset 0 0 0 1px #F0F0F0',
          boxSizing: 'content-box',
          borderRadius: '0 4px 4px 0',
          float: 'left',
          paddingLeft: '8px'
        },
        swatch: {
          width: '30px',
          height: '30px',
          float: 'left',
          borderRadius: '4px',
          margin: '0 6px 6px 0'
        },
        clear: {
          clear: 'both'
        }
      },
      'hide-triangle': {
        triangle: {
          display: 'none'
        },
        triangleShadow: {
          display: 'none'
        }
      },
      'top-left-triangle': {
        triangle: {
          top: '-10px',
          left: '12px'
        },
        triangleShadow: {
          top: '-11px',
          left: '12px'
        }
      },
      'top-right-triangle': {
        triangle: {
          top: '-10px',
          right: '12px'
        },
        triangleShadow: {
          top: '-11px',
          right: '12px'
        }
      }
    }, passedStyles), {
      'hide-triangle': triangle === 'hide',
      'top-left-triangle': triangle === 'top-left',
      'top-right-triangle': triangle === 'top-right'
    });
  
    var handleChange = function handleChange(hexcode, e) {
      color.isValidHex(hexcode) && onChange({
        hex: hexcode,
        source: 'hex'
      }, e);
    };
  
    return _react2.default.createElement(
      'div',
      { style: styles.card, className: 'twitter-picker ' + className },
      _react2.default.createElement('div', { style: styles.triangleShadow }),
      _react2.default.createElement('div', { style: styles.triangle }),
      _react2.default.createElement(
        'div',
        { style: styles.body },
        (0, _map2.default)(colors, function (c, i) {
          return _react2.default.createElement(_common.Swatch, {
            key: i,
            color: c,
            hex: c,
            style: styles.swatch,
            onClick: handleChange,
            onHover: onSwatchHover,
            focusStyle: {
              boxShadow: '0 0 4px ' + c
            }
          });
        }),
        _react2.default.createElement(
          'div',
          { style: styles.hash },
          '#'
        ),
        _react2.default.createElement(_common.EditableInput, {
          label: null,
          style: { input: styles.input },
          value: hex.replace('#', ''),
          onChange: handleChange
        }),
        _react2.default.createElement('div', { style: styles.clear })
      )
    );
  };
  
  Twitter.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    triangle: _propTypes2.default.oneOf(['hide', 'top-left', 'top-right']),
    colors: _propTypes2.default.arrayOf(_propTypes2.default.string),
    styles: _propTypes2.default.object
  };
  
  Twitter.defaultProps = {
    width: 276,
    colors: ['#FF6900', '#FCB900', '#7BDCB5', '#00D084', '#8ED1FC', '#0693E3', '#ABB8C3', '#EB144C', '#F78DA7', '#9900EF'],
    triangle: 'top-left',
    styles: {}
  };
  
  exports.default = (0, _common.ColorWrap)(Twitter);

});

;/*!node_modules/react-color/lib/components/google/GooglePointerCircle.js*/
amis.define('3e855a1', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.GooglePointerCircle = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var GooglePointerCircle = exports.GooglePointerCircle = function GooglePointerCircle(props) {
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '20px',
          height: '20px',
          borderRadius: '22px',
          border: '2px #fff solid',
          transform: 'translate(-12px, -13px)',
          background: 'hsl(' + Math.round(props.hsl.h) + ', ' + Math.round(props.hsl.s * 100) + '%, ' + Math.round(props.hsl.l * 100) + '%)'
        }
      }
    });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  GooglePointerCircle.propTypes = {
    hsl: _propTypes2.default.shape({
      h: _propTypes2.default.number,
      s: _propTypes2.default.number,
      l: _propTypes2.default.number,
      a: _propTypes2.default.number
    })
  };
  
  GooglePointerCircle.defaultProps = {
    hsl: { a: 1, h: 249.94, l: 0.2, s: 0.50 }
  };
  
  exports.default = GooglePointerCircle;

});

;/*!node_modules/react-color/lib/components/google/GooglePointer.js*/
amis.define('0455570', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.GooglePointer = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var GooglePointer = exports.GooglePointer = function GooglePointer(props) {
    var styles = (0, _reactcss2.default)({
      'default': {
        picker: {
          width: '20px',
          height: '20px',
          borderRadius: '22px',
          transform: 'translate(-10px, -7px)',
          background: 'hsl(' + Math.round(props.hsl.h) + ', 100%, 50%)',
          border: '2px white solid'
        }
      }
    });
  
    return _react2.default.createElement('div', { style: styles.picker });
  };
  
  GooglePointer.propTypes = {
    hsl: _propTypes2.default.shape({
      h: _propTypes2.default.number,
      s: _propTypes2.default.number,
      l: _propTypes2.default.number,
      a: _propTypes2.default.number
    })
  };
  
  GooglePointer.defaultProps = {
    hsl: { a: 1, h: 249.94, l: 0.2, s: 0.50 }
  };
  
  exports.default = GooglePointer;

});

;/*!node_modules/react-color/lib/components/google/GoogleFields.js*/
amis.define('6d0ce21', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.GoogleFields = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _color = require('dade38d');
  
  var color = _interopRequireWildcard(_color);
  
  var _common = require('0eb8409');
  
  function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var GoogleFields = exports.GoogleFields = function GoogleFields(_ref) {
    var onChange = _ref.onChange,
        rgb = _ref.rgb,
        hsl = _ref.hsl,
        hex = _ref.hex,
        hsv = _ref.hsv;
  
  
    var handleChange = function handleChange(data, e) {
      if (data.hex) {
        color.isValidHex(data.hex) && onChange({
          hex: data.hex,
          source: 'hex'
        }, e);
      } else if (data.rgb) {
        var values = data.rgb.split(',');
        color.isvalidColorString(data.rgb, 'rgb') && onChange({
          r: values[0],
          g: values[1],
          b: values[2],
          a: 1,
          source: 'rgb'
        }, e);
      } else if (data.hsv) {
        var _values = data.hsv.split(',');
        if (color.isvalidColorString(data.hsv, 'hsv')) {
          _values[2] = _values[2].replace('%', '');
          _values[1] = _values[1].replace('%', '');
          _values[0] = _values[0].replace('°', '');
          if (_values[1] == 1) {
            _values[1] = 0.01;
          } else if (_values[2] == 1) {
            _values[2] = 0.01;
          }
          onChange({
            h: Number(_values[0]),
            s: Number(_values[1]),
            v: Number(_values[2]),
            source: 'hsv'
          }, e);
        }
      } else if (data.hsl) {
        var _values2 = data.hsl.split(',');
        if (color.isvalidColorString(data.hsl, 'hsl')) {
          _values2[2] = _values2[2].replace('%', '');
          _values2[1] = _values2[1].replace('%', '');
          _values2[0] = _values2[0].replace('°', '');
          if (hsvValue[1] == 1) {
            hsvValue[1] = 0.01;
          } else if (hsvValue[2] == 1) {
            hsvValue[2] = 0.01;
          }
          onChange({
            h: Number(_values2[0]),
            s: Number(_values2[1]),
            v: Number(_values2[2]),
            source: 'hsl'
          }, e);
        }
      }
    };
  
    var styles = (0, _reactcss2.default)({
      'default': {
        wrap: {
          display: 'flex',
          height: '100px',
          marginTop: '4px'
        },
        fields: {
          width: '100%'
        },
        column: {
          paddingTop: '10px',
          display: 'flex',
          justifyContent: 'space-between'
        },
        double: {
          padding: '0px 4.4px',
          boxSizing: 'border-box'
        },
        input: {
          width: '100%',
          height: '38px',
          boxSizing: 'border-box',
          padding: '4px 10% 3px',
          textAlign: 'center',
          border: '1px solid #dadce0',
          fontSize: '11px',
          textTransform: 'lowercase',
          borderRadius: '5px',
          outline: 'none',
          fontFamily: 'Roboto,Arial,sans-serif'
        },
        input2: {
          height: '38px',
          width: '100%',
          border: '1px solid #dadce0',
          boxSizing: 'border-box',
          fontSize: '11px',
          textTransform: 'lowercase',
          borderRadius: '5px',
          outline: 'none',
          paddingLeft: '10px',
          fontFamily: 'Roboto,Arial,sans-serif'
        },
        label: {
          textAlign: 'center',
          fontSize: '12px',
          background: '#fff',
          position: 'absolute',
          textTransform: 'uppercase',
          color: '#3c4043',
          width: '35px',
          top: '-6px',
          left: '0',
          right: '0',
          marginLeft: 'auto',
          marginRight: 'auto',
          fontFamily: 'Roboto,Arial,sans-serif'
        },
        label2: {
          left: '10px',
          textAlign: 'center',
          fontSize: '12px',
          background: '#fff',
          position: 'absolute',
          textTransform: 'uppercase',
          color: '#3c4043',
          width: '32px',
          top: '-6px',
          fontFamily: 'Roboto,Arial,sans-serif'
        },
        single: {
          flexGrow: '1',
          margin: '0px 4.4px'
        }
      }
    });
  
    var rgbValue = rgb.r + ', ' + rgb.g + ', ' + rgb.b;
    var hslValue = Math.round(hsl.h) + '\xB0, ' + Math.round(hsl.s * 100) + '%, ' + Math.round(hsl.l * 100) + '%';
    var hsvValue = Math.round(hsv.h) + '\xB0, ' + Math.round(hsv.s * 100) + '%, ' + Math.round(hsv.v * 100) + '%';
  
    return _react2.default.createElement(
      'div',
      { style: styles.wrap, className: 'flexbox-fix' },
      _react2.default.createElement(
        'div',
        { style: styles.fields },
        _react2.default.createElement(
          'div',
          { style: styles.double },
          _react2.default.createElement(_common.EditableInput, {
            style: { input: styles.input, label: styles.label },
            label: 'hex',
            value: hex,
            onChange: handleChange
          })
        ),
        _react2.default.createElement(
          'div',
          { style: styles.column },
          _react2.default.createElement(
            'div',
            { style: styles.single },
            _react2.default.createElement(_common.EditableInput, {
              style: { input: styles.input2, label: styles.label2 },
              label: 'rgb',
              value: rgbValue,
              onChange: handleChange
            })
          ),
          _react2.default.createElement(
            'div',
            { style: styles.single },
            _react2.default.createElement(_common.EditableInput, {
              style: { input: styles.input2, label: styles.label2 },
              label: 'hsv',
              value: hsvValue,
              onChange: handleChange
            })
          ),
          _react2.default.createElement(
            'div',
            { style: styles.single },
            _react2.default.createElement(_common.EditableInput, {
              style: { input: styles.input2, label: styles.label2 },
              label: 'hsl',
              value: hslValue,
              onChange: handleChange
            })
          )
        )
      )
    );
  };
  
  exports.default = GoogleFields;

});

;/*!node_modules/react-color/lib/components/google/Google.js*/
amis.define('9a32020', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.Google = undefined;
  
  var _react = require('547621d');
  
  var _react2 = _interopRequireDefault(_react);
  
  var _propTypes = require('027ad22');
  
  var _propTypes2 = _interopRequireDefault(_propTypes);
  
  var _reactcss = require('de9fee7');
  
  var _reactcss2 = _interopRequireDefault(_reactcss);
  
  var _merge = require('b33a05d');
  
  var _merge2 = _interopRequireDefault(_merge);
  
  var _common = require('0eb8409');
  
  var _GooglePointerCircle = require('3e855a1');
  
  var _GooglePointerCircle2 = _interopRequireDefault(_GooglePointerCircle);
  
  var _GooglePointer = require('0455570');
  
  var _GooglePointer2 = _interopRequireDefault(_GooglePointer);
  
  var _GoogleFields = require('6d0ce21');
  
  var _GoogleFields2 = _interopRequireDefault(_GoogleFields);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  var Google = exports.Google = function Google(_ref) {
    var width = _ref.width,
        onChange = _ref.onChange,
        rgb = _ref.rgb,
        hsl = _ref.hsl,
        hsv = _ref.hsv,
        hex = _ref.hex,
        header = _ref.header,
        _ref$styles = _ref.styles,
        passedStyles = _ref$styles === undefined ? {} : _ref$styles,
        _ref$className = _ref.className,
        className = _ref$className === undefined ? '' : _ref$className;
  
    var styles = (0, _reactcss2.default)((0, _merge2.default)({
      'default': {
        picker: {
          width: width,
          background: '#fff',
          border: '1px solid #dfe1e5',
          boxSizing: 'initial',
          display: 'flex',
          flexWrap: 'wrap',
          borderRadius: '8px 8px 0px 0px'
        },
        head: {
          height: '57px',
          width: '100%',
          paddingTop: '16px',
          paddingBottom: '16px',
          paddingLeft: '16px',
          fontSize: '20px',
          boxSizing: 'border-box',
          fontFamily: 'Roboto-Regular,HelveticaNeue,Arial,sans-serif'
        },
        saturation: {
          width: '70%',
          padding: '0px',
          position: 'relative',
          overflow: 'hidden'
        },
        swatch: {
          width: '30%',
          height: '228px',
          padding: '0px',
          background: 'rgba(' + rgb.r + ', ' + rgb.g + ', ' + rgb.b + ', 1)',
          position: 'relative',
          overflow: 'hidden'
        },
        body: {
          margin: 'auto',
          width: '95%'
        },
        controls: {
          display: 'flex',
          boxSizing: 'border-box',
          height: '52px',
          paddingTop: '22px'
        },
        color: {
          width: '32px'
        },
        hue: {
          height: '8px',
          position: 'relative',
          margin: '0px 16px 0px 16px',
          width: '100%'
        },
        Hue: {
          radius: '2px'
        }
      }
    }, passedStyles));
    return _react2.default.createElement(
      'div',
      { style: styles.picker, className: 'google-picker ' + className },
      _react2.default.createElement(
        'div',
        { style: styles.head },
        header
      ),
      _react2.default.createElement('div', { style: styles.swatch }),
      _react2.default.createElement(
        'div',
        { style: styles.saturation },
        _react2.default.createElement(_common.Saturation, {
          hsl: hsl,
          hsv: hsv,
          pointer: _GooglePointerCircle2.default,
          onChange: onChange
        })
      ),
      _react2.default.createElement(
        'div',
        { style: styles.body },
        _react2.default.createElement(
          'div',
          { style: styles.controls, className: 'flexbox-fix' },
          _react2.default.createElement(
            'div',
            { style: styles.hue },
            _react2.default.createElement(_common.Hue, {
              style: styles.Hue,
              hsl: hsl,
              radius: '4px',
              pointer: _GooglePointer2.default,
              onChange: onChange
            })
          )
        ),
        _react2.default.createElement(_GoogleFields2.default, {
          rgb: rgb,
          hsl: hsl,
          hex: hex,
          hsv: hsv,
          onChange: onChange
        })
      )
    );
  };
  
  Google.propTypes = {
    width: _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.number]),
    styles: _propTypes2.default.object,
    header: _propTypes2.default.string
  
  };
  
  Google.defaultProps = {
    width: 652,
    styles: {},
    header: 'Color picker'
  };
  
  exports.default = (0, _common.ColorWrap)(Google);

});

;/*!node_modules/react-color/lib/index.js*/
amis.define('60f471f', function(require, exports, module, define) {

  'use strict';
  
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.CustomPicker = exports.GooglePicker = exports.TwitterPicker = exports.SwatchesPicker = exports.SliderPicker = exports.SketchPicker = exports.PhotoshopPicker = exports.MaterialPicker = exports.HuePicker = exports.GithubPicker = exports.CompactPicker = exports.ChromePicker = exports.default = exports.CirclePicker = exports.BlockPicker = exports.AlphaPicker = undefined;
  
  var _Alpha = require('fbf358d');
  
  Object.defineProperty(exports, 'AlphaPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Alpha).default;
    }
  });
  
  var _Block = require('c056046');
  
  Object.defineProperty(exports, 'BlockPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Block).default;
    }
  });
  
  var _Circle = require('9a72b29');
  
  Object.defineProperty(exports, 'CirclePicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Circle).default;
    }
  });
  
  var _Chrome = require('1fc76ec');
  
  Object.defineProperty(exports, 'ChromePicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Chrome).default;
    }
  });
  
  var _Compact = require('eeff894');
  
  Object.defineProperty(exports, 'CompactPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Compact).default;
    }
  });
  
  var _Github = require('996d229');
  
  Object.defineProperty(exports, 'GithubPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Github).default;
    }
  });
  
  var _Hue = require('95ec6a3');
  
  Object.defineProperty(exports, 'HuePicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Hue).default;
    }
  });
  
  var _Material = require('cbbf7e6');
  
  Object.defineProperty(exports, 'MaterialPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Material).default;
    }
  });
  
  var _Photoshop = require('919230c');
  
  Object.defineProperty(exports, 'PhotoshopPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Photoshop).default;
    }
  });
  
  var _Sketch = require('1ff03ef');
  
  Object.defineProperty(exports, 'SketchPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Sketch).default;
    }
  });
  
  var _Slider = require('94e7338');
  
  Object.defineProperty(exports, 'SliderPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Slider).default;
    }
  });
  
  var _Swatches = require('8f54db2');
  
  Object.defineProperty(exports, 'SwatchesPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Swatches).default;
    }
  });
  
  var _Twitter = require('9de3a99');
  
  Object.defineProperty(exports, 'TwitterPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Twitter).default;
    }
  });
  
  var _Google = require('9a32020');
  
  Object.defineProperty(exports, 'GooglePicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_Google).default;
    }
  });
  
  var _ColorWrap = require('f09be53');
  
  Object.defineProperty(exports, 'CustomPicker', {
    enumerable: true,
    get: function get() {
      return _interopRequireDefault(_ColorWrap).default;
    }
  });
  
  var _Chrome2 = _interopRequireDefault(_Chrome);
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
  
  exports.default = _Chrome2.default;

});

;/*!node_modules/amis/node_modules/amis-ui/lib/components/ColorPicker.js*/
amis.define('95d0319', function(require, exports, module, define) {

  /**
   * amis-ui v6.13.0
   * Copyright 2018-2025 fex
   */
  
  'use strict';
  
  Object.defineProperty(exports, '__esModule', { value: true });
  
  var tslib = require('a5c5bc6');
  var React = require('547621d');
  var ReactDOM = require('71e5492');
  var reactColor = require('60f471f');
  var icons = require('b684f5a');
  var amisCore = require('abff7ef');
  var PopUp = require('123d74d');
  
  function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }
  
  var React__default = /*#__PURE__*/_interopDefaultLegacy(React);
  
  var __react_jsx__ = require('547621d');
  var _J$X_ = (__react_jsx__["default"] || __react_jsx__).createElement;
  (__react_jsx__["default"] || __react_jsx__).Fragment;
  var ColorControl = /** @class */ (function (_super) {
      tslib.__extends(ColorControl, _super);
      function ColorControl(props) {
          var _this = _super.call(this, props) || this;
          _this.state = {
              isOpened: false,
              isFocused: false,
              inputValue: _this.props.value || '',
              tempValue: _this.props.value || ''
          };
          _this.open = _this.open.bind(_this);
          _this.close = _this.close.bind(_this);
          _this.focus = _this.focus.bind(_this);
          _this.blur = _this.blur.bind(_this);
          _this.handleChange = _this.handleChange.bind(_this);
          _this.handleTempChange = _this.handleTempChange.bind(_this);
          _this.handleConfirm = _this.handleConfirm.bind(_this);
          _this.handleFocus = _this.handleFocus.bind(_this);
          _this.handleBlur = _this.handleBlur.bind(_this);
          _this.clearValue = _this.clearValue.bind(_this);
          _this.handleInputChange = _this.handleInputChange.bind(_this);
          _this.handleClick = _this.handleClick.bind(_this);
          _this.preview = React__default["default"].createRef();
          _this.input = React__default["default"].createRef();
          return _this;
      }
      ColorControl.prototype.componentDidUpdate = function (prevProps) {
          var props = this.props;
          if (prevProps.value !== props.value) {
              this.setState({
                  inputValue: props.value || ''
              });
          }
      };
      ColorControl.prototype.handleFocus = function () {
          this.setState({
              isFocused: true
          });
      };
      ColorControl.prototype.handleBlur = function () {
          this.setState({
              isFocused: false,
              inputValue: this.props.value
          });
      };
      ColorControl.prototype.focus = function () {
          this.input.current && this.input.current.focus();
      };
      ColorControl.prototype.blur = function () {
          this.input.current && this.input.current.blur();
      };
      ColorControl.prototype.open = function (fn) {
          if (this.props.disabled) {
              return;
          }
          this.setState({
              isOpened: true
          }, fn);
      };
      ColorControl.prototype.close = function () {
          this.setState({
              isOpened: false
          });
      };
      ColorControl.prototype.clearValue = function () {
          var _a = this.props, onChange = _a.onChange, resetValue = _a.resetValue;
          onChange(resetValue || '');
      };
      ColorControl.prototype.handleClick = function () {
          this.state.isOpened ? this.close() : this.open(this.focus);
      };
      ColorControl.prototype.handleInputChange = function (e) {
          var _this = this;
          if (!this.props.allowCustomColor) {
              return;
          }
          var onChange = this.props.onChange;
          this.setState({
              inputValue: e.currentTarget.value
          }, function () {
              var isValidated = _this.validateColor(_this.state.inputValue);
              if (isValidated) {
                  onChange(_this.state.inputValue);
              }
          });
      };
      ColorControl.prototype.validateColor = function (value) {
          if (value === '') {
              return false;
          }
          if (value === 'inherit') {
              return false;
          }
          if (value === 'transparent') {
              return false;
          }
          var image = document.createElement('img');
          image.style.color = 'rgb(0, 0, 0)';
          image.style.color = value;
          if (image.style.color !== 'rgb(0, 0, 0)') {
              return true;
          }
          image.style.color = 'rgb(255, 255, 255)';
          image.style.color = value;
          return image.style.color !== 'rgb(255, 255, 255)';
      };
      ColorControl.prototype.handleChange = function (color) {
          var _a = this.props, onChange = _a.onChange, format = _a.format
          // closeOnSelect
          ;
          if (format === 'rgba') {
              onChange("rgba(".concat(color.rgb.r, ", ").concat(color.rgb.g, ", ").concat(color.rgb.b, ", ").concat(color.rgb.a, ")"));
          }
          else if (format === 'rgb') {
              onChange("rgb(".concat(color.rgb.r, ", ").concat(color.rgb.g, ", ").concat(color.rgb.b, ")"));
          }
          else if (format === 'hexa') {
              onChange(this.rgbaToHex(color.rgb.r, color.rgb.g, color.rgb.b, color.rgb.a));
          }
          else if (format === 'hsl') {
              onChange("hsl(".concat(Math.round(color.hsl.h), ", ").concat(Math.round(color.hsl.s * 100), "%, ").concat(Math.round(color.hsl.l * 100), "%)"));
          }
          else {
              onChange(color.hex);
          }
          // closeOnSelect && this.close();
      };
      ColorControl.prototype.handleTempChange = function (color) {
          var tempValue = this.state.tempValue;
          var format = this.props.format;
          if (format === 'rgba') {
              tempValue = "rgba(".concat(color.rgb.r, ", ").concat(color.rgb.g, ", ").concat(color.rgb.b, ", ").concat(color.rgb.a, ")");
          }
          else if (format === 'rgb') {
              tempValue = "rgb(".concat(color.rgb.r, ", ").concat(color.rgb.g, ", ").concat(color.rgb.b, ")");
          }
          else if (format === 'hexa') {
              tempValue = this.rgbaToHex(color.rgb.r, color.rgb.g, color.rgb.b, color.rgb.a);
          }
          else if (format === 'hsl') {
              tempValue = "hsl(".concat(Math.round(color.hsl.h), ", ").concat(Math.round(color.hsl.s * 100), "%, ").concat(Math.round(color.hsl.l * 100), "%)");
          }
          else {
              tempValue = color.hex;
          }
          this.setState({ tempValue: tempValue });
      };
      ColorControl.prototype.handleConfirm = function () {
          var onChange = this.props.onChange;
          var tempValue = this.state.tempValue;
          onChange(tempValue);
          this.close();
      };
      /**
       * Converts an RGBA color to an 8-digit hex color.
       *
       * @param r - Red component (0-255)
       * @param g - Green component (0-255)
       * @param b - Blue component (0-255)
       * @param a - Alpha component (1-100)
       * @returns The hex color string in the format #RRGGBBAA
       */
      ColorControl.prototype.rgbaToHex = function (r, g, b, a) {
          if (r < 0 || r > 255 || g < 0 || g > 255 || b < 0 || b > 255) {
              return "#00000000";
          }
          if (typeof a === 'undefined' || a > 1) {
              a = 1;
          }
          if (a < 0.01) {
              a = 0;
          }
          var toHex = function (n) { return n.toString(16).padStart(2, '0').toUpperCase(); };
          var alphaHex = toHex(Math.round(a * 255));
          var redHex = toHex(r);
          var greenHex = toHex(g);
          var blueHex = toHex(b);
          return "#".concat(redHex).concat(greenHex).concat(blueHex).concat(alphaHex);
      };
      ColorControl.prototype.render = function () {
          var _this = this;
          var _a = this.props, ns = _a.classPrefix, className = _a.className, popoverClassName = _a.popoverClassName, value = _a.value, placeholder = _a.placeholder, disabled = _a.disabled, popOverContainer = _a.popOverContainer, popOverContainerSelector = _a.popOverContainerSelector, format = _a.format, clearable = _a.clearable, placement = _a.placement, cx = _a.classnames, presetColors = _a.presetColors, allowCustomColor = _a.allowCustomColor, mobileUI = _a.mobileUI;
          var __ = this.props.translate;
          var isOpened = this.state.isOpened;
          var isFocused = this.state.isFocused;
          var tempValue = this.state.tempValue;
          return (_J$X_("div", { className: cx("ColorPicker", {
                  'is-disabled': disabled,
                  'is-focused': isFocused,
                  'is-opened': isOpened
              }, className) },
              _J$X_("span", { onClick: this.handleClick, className: cx('ColorPicker-preview') },
                  _J$X_("i", { ref: this.preview, className: "".concat(ns, "ColorPicker-previewIcon"), style: { background: this.state.inputValue || '#ccc' } })),
              _J$X_("input", { ref: this.input, type: "text", autoComplete: "off", size: 10, className: cx('ColorPicker-input'), value: this.state.inputValue || '', placeholder: __(placeholder), disabled: disabled, onChange: this.handleInputChange, onFocus: this.handleFocus, onBlur: this.handleBlur, onClick: this.handleClick, readOnly: mobileUI }),
              clearable && !disabled && value ? (_J$X_("a", { onClick: this.clearValue, className: cx('ColorPicker-clear') },
                  _J$X_(icons.Icon, { icon: "input-clear", className: "icon" }))) : null,
              _J$X_("span", { className: cx('ColorPicker-arrow') },
                  _J$X_(icons.Icon, { icon: "right-arrow-bold", className: "icon", onClick: this.handleClick })),
              !mobileUI && isOpened ? (_J$X_(amisCore.Overlay, { placement: placement || 'auto', target: function () { return ReactDOM.findDOMNode(_this); }, onHide: this.close, container: popOverContainer || (function () { return ReactDOM.findDOMNode(_this); }), containerSelector: popOverContainerSelector, rootClose: false, show: true },
                  _J$X_(amisCore.PopOver, { classPrefix: ns, className: cx('ColorPicker-popover', popoverClassName), onHide: this.close, overlay: true }, allowCustomColor ? (_J$X_(reactColor.SketchPicker, { styles: {}, disableAlpha: !!~['rgb', 'hex'].indexOf(format), color: value, presetColors: presetColors, onChangeComplete: this.handleChange })) : (_J$X_(reactColor.GithubPicker, { color: value, colors: Array.isArray(presetColors)
                          ? presetColors
                              .filter(function (item) { return typeof item === 'string' || amisCore.isObject(item); })
                              .map(function (item) {
                              return typeof item === 'string'
                                  ? item
                                  : amisCore.isObject(item)
                                      ? item === null || item === void 0 ? void 0 : item.color
                                      : item;
                          })
                          : undefined, onChangeComplete: this.handleChange }))))) : null,
              mobileUI && (_J$X_(PopUp["default"], { className: cx("".concat(ns, "ColorPicker-popup")), container: popOverContainer, isShow: isOpened, onHide: this.handleClick, showConfirm: true, onConfirm: this.handleConfirm }, allowCustomColor ? (_J$X_(reactColor.SketchPicker, { styles: {}, disableAlpha: !!~['rgb', 'hex'].indexOf(format), color: tempValue, presetColors: presetColors, onChangeComplete: this.handleTempChange })) : (_J$X_(reactColor.GithubPicker, { color: tempValue, colors: Array.isArray(presetColors)
                      ? presetColors
                          .filter(function (item) { return typeof item === 'string' || amisCore.isObject(item); })
                          .map(function (item) {
                          return typeof item === 'string'
                              ? item
                              : amisCore.isObject(item)
                                  ? item === null || item === void 0 ? void 0 : item.color
                                  : item;
                      })
                      : undefined, onChangeComplete: this.handleTempChange }))))));
      };
      ColorControl.defaultProps = {
          format: 'hex',
          clearable: true,
          placeholder: 'ColorPicker.placeholder',
          allowCustomColor: true
          // closeOnSelect: true
      };
      tslib.__decorate([
          amisCore.autobind,
          tslib.__metadata("design:type", Function),
          tslib.__metadata("design:paramtypes", [String]),
          tslib.__metadata("design:returntype", void 0)
      ], ColorControl.prototype, "validateColor", null);
      return ColorControl;
  }(React__default["default"].PureComponent));
  var ColorPicker = amisCore.themeable(amisCore.localeable(amisCore.uncontrollable(ColorControl, {
      value: 'onChange'
  })));
  
  exports.ColorControl = ColorControl;
  exports["default"] = ColorPicker;
  

});
