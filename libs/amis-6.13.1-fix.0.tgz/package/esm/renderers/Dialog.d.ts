import React from 'react';
import { IScopedContext, RendererEvent } from 'amis-core';
import { RendererProps } from 'amis-core';
import { ActionObject } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { IModalStore } from 'amis-core';
import { AMISDialogSchemaBase, AMISSchemaCollection, AMISButtonSchema } from 'amis-core';
/**
 * 对话框组件，用于弹窗展示内容。支持确认/取消操作、自定义内容等。
 */
export interface AMISDialogSchema extends AMISDialogSchemaBase {
    type: 'dialog';
}
export type DialogSchema = AMISDialogSchema;
export interface DialogProps extends RendererProps, Omit<AMISDialogSchema, 'className' | 'data'>, SpinnerExtraProps {
    onClose: (confirmed?: boolean) => void;
    onConfirm: (values: Array<object>, action: ActionObject, ctx: object, targets: Array<any>) => void;
    children?: React.ReactNode | ((props?: any) => React.ReactNode);
    store: IModalStore;
    show?: boolean;
    lazyRender?: boolean;
    lazySchema?: (props: DialogProps) => AMISSchemaCollection;
    wrapperComponent: React.ElementType;
}
export default class Dialog extends React.Component<DialogProps> {
    static propsList: Array<string>;
    static defaultProps: {
        title: string;
        bodyClassName: string;
        confirm: boolean;
        show: boolean;
        lazyRender: boolean;
        showCloseButton: boolean;
        wrapperComponent: {
            new (props: Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                size?: any;
                overlay?: boolean | undefined;
                draggable?: boolean | undefined;
                container?: any;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
                ref: any;
                childRef(ref: any): void;
                getWrappedInstance(): any;
                render(): React.JSX.Element;
                context: unknown;
                setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
                forceUpdate(callback?: (() => void) | undefined): void;
                readonly props: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
                state: Readonly<{}>;
                refs: {
                    [key: string]: React.ReactInstance;
                };
                componentDidMount?(): void;
                shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
                componentWillUnmount?(): void;
                componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
                componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
                componentWillMount?(): void;
                UNSAFE_componentWillMount?(): void;
                componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
            };
            displayName: string;
            contextType: React.Context<string>;
            ComposedComponent: React.ComponentType<{
                new (props: Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<typeof import("amis-ui/lib/components/Modal").Modal>;
            } & import("hoist-non-react-statics").NonReactStatics<typeof import("amis-ui/lib/components/Modal").Modal, {}> & {
                ComposedComponent: typeof import("amis-ui/lib/components/Modal").Modal;
            }>;
        } & import("hoist-non-react-statics").NonReactStatics<{
            new (props: Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                size?: any;
                overlay?: boolean | undefined;
                draggable?: boolean | undefined;
                container?: any;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }): {
                ref: any;
                childRef(ref: any): void;
                getWrappedInstance(): any;
                render(): React.JSX.Element;
                context: unknown;
                setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
                forceUpdate(callback?: (() => void) | undefined): void;
                readonly props: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>;
                state: Readonly<{}>;
                refs: {
                    [key: string]: React.ReactInstance;
                };
                componentDidMount?(): void;
                shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, nextState: Readonly<{}>, nextContext: any): boolean;
                componentWillUnmount?(): void;
                componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, prevState: Readonly<{}>): any;
                componentDidUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, prevState: Readonly<{}>, snapshot?: any): void;
                componentWillMount?(): void;
                UNSAFE_componentWillMount?(): void;
                componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, nextContext: any): void;
                UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, nextContext: any): void;
                componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, nextState: Readonly<{}>, nextContext: any): void;
                UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }>, nextState: Readonly<{}>, nextContext: any): void;
            };
            displayName: string;
            contextType: React.Context<string>;
            ComposedComponent: React.ComponentType<typeof import("amis-ui/lib/components/Modal").Modal>;
        } & import("hoist-non-react-statics").NonReactStatics<typeof import("amis-ui/lib/components/Modal").Modal, {}> & {
            ComposedComponent: typeof import("amis-ui/lib/components/Modal").Modal;
        }, {}> & {
            ComposedComponent: {
                new (props: Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                    size?: any;
                    overlay?: boolean | undefined;
                    draggable?: boolean | undefined;
                    container?: any;
                } & {} & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/Modal").ModalProps, keyof import("amis-core").LocaleProps>, "disabled" | "show" | "width" | "height" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "children" | "onHide" | "onExited" | "onEntered" | "contentClassName" | "closeOnEsc" | "closeOnOutside" | "modalClassName" | "modalMaskClassName"> & {
                        size?: any;
                        overlay?: boolean | undefined;
                        draggable?: boolean | undefined;
                        container?: any;
                    } & {} & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<typeof import("amis-ui/lib/components/Modal").Modal>;
            } & import("hoist-non-react-statics").NonReactStatics<typeof import("amis-ui/lib/components/Modal").Modal, {}> & {
                ComposedComponent: typeof import("amis-ui/lib/components/Modal").Modal;
            };
        } & {
            Header: {
                new (props: Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                    className?: string | undefined;
                    showCloseButton?: boolean | undefined;
                    onClose?: (() => void) | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<{
                    new (props: Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }): {
                        ref: any;
                        childRef(ref: any): void;
                        getWrappedInstance(): any;
                        render(): React.JSX.Element;
                        context: unknown;
                        setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
                        forceUpdate(callback?: (() => void) | undefined): void;
                        readonly props: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>;
                        state: Readonly<{}>;
                        refs: {
                            [key: string]: React.ReactInstance;
                        };
                        componentDidMount?(): void;
                        shouldComponentUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextState: Readonly<{}>, nextContext: any): boolean;
                        componentWillUnmount?(): void;
                        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, prevState: Readonly<{}>): any;
                        componentDidUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, prevState: Readonly<{}>, snapshot?: any): void;
                        componentWillMount?(): void;
                        UNSAFE_componentWillMount?(): void;
                        componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextContext: any): void;
                        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextContext: any): void;
                        componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextState: Readonly<{}>, nextContext: any): void;
                        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextState: Readonly<{}>, nextContext: any): void;
                    };
                    displayName: string;
                    contextType: React.Context<string>;
                    ComposedComponent: React.ComponentType<({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element>;
                } & import("hoist-non-react-statics").NonReactStatics<({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                    className?: string | undefined;
                    showCloseButton?: boolean | undefined;
                    onClose?: (() => void) | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element, {}> & {
                    ComposedComponent: ({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element;
                }>;
            } & import("hoist-non-react-statics").NonReactStatics<{
                new (props: Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                    className?: string | undefined;
                    showCloseButton?: boolean | undefined;
                    onClose?: (() => void) | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                    locale?: string | undefined;
                    translate?: ((str: string, ...args: any[]) => string) | undefined;
                }): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                    className?: string | undefined;
                    showCloseButton?: boolean | undefined;
                    onClose?: (() => void) | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element>;
            } & import("hoist-non-react-statics").NonReactStatics<({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                className?: string | undefined;
                showCloseButton?: boolean | undefined;
                onClose?: (() => void) | undefined;
                children?: React.ReactNode;
                forwardedRef?: any;
            } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element, {}> & {
                ComposedComponent: ({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                    className?: string | undefined;
                    showCloseButton?: boolean | undefined;
                    onClose?: (() => void) | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element;
            }, {}> & {
                ComposedComponent: {
                    new (props: Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                        locale?: string | undefined;
                        translate?: ((str: string, ...args: any[]) => string) | undefined;
                    }): {
                        ref: any;
                        childRef(ref: any): void;
                        getWrappedInstance(): any;
                        render(): React.JSX.Element;
                        context: unknown;
                        setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
                        forceUpdate(callback?: (() => void) | undefined): void;
                        readonly props: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>;
                        state: Readonly<{}>;
                        refs: {
                            [key: string]: React.ReactInstance;
                        };
                        componentDidMount?(): void;
                        shouldComponentUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextState: Readonly<{}>, nextContext: any): boolean;
                        componentWillUnmount?(): void;
                        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, prevState: Readonly<{}>): any;
                        componentDidUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, prevState: Readonly<{}>, snapshot?: any): void;
                        componentWillMount?(): void;
                        UNSAFE_componentWillMount?(): void;
                        componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextContext: any): void;
                        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextContext: any): void;
                        componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextState: Readonly<{}>, nextContext: any): void;
                        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                            className?: string | undefined;
                            showCloseButton?: boolean | undefined;
                            onClose?: (() => void) | undefined;
                            children?: React.ReactNode;
                            forwardedRef?: any;
                        } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").LocaleProps> & {
                            locale?: string | undefined;
                            translate?: ((str: string, ...args: any[]) => string) | undefined;
                        }>, nextState: Readonly<{}>, nextContext: any): void;
                    };
                    displayName: string;
                    contextType: React.Context<string>;
                    ComposedComponent: React.ComponentType<({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element>;
                } & import("hoist-non-react-statics").NonReactStatics<({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                    className?: string | undefined;
                    showCloseButton?: boolean | undefined;
                    onClose?: (() => void) | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element, {}> & {
                    ComposedComponent: ({ classnames: cx, className, showCloseButton, onClose, children, classPrefix, translate: __, forwardedRef, ...rest }: import("amis-core").ThemeProps & import("amis-core").LocaleProps & {
                        className?: string | undefined;
                        showCloseButton?: boolean | undefined;
                        onClose?: (() => void) | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element;
                };
            };
            Title: {
                new (props: Omit<import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element>;
            } & import("hoist-non-react-statics").NonReactStatics<({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                className?: string | undefined;
                children?: React.ReactNode;
                forwardedRef?: any;
            } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element, {}> & {
                ComposedComponent: ({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element;
            };
            Body: {
                new (props: Omit<import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element>;
            } & import("hoist-non-react-statics").NonReactStatics<({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                className?: string | undefined;
                children?: React.ReactNode;
                forwardedRef?: any;
            } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element, {}> & {
                ComposedComponent: ({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element;
            };
            Footer: {
                new (props: Omit<import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
                    ref: any;
                    childRef(ref: any): void;
                    getWrappedInstance(): any;
                    render(): React.JSX.Element;
                    context: unknown;
                    setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
                    forceUpdate(callback?: (() => void) | undefined): void;
                    readonly props: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
                    state: Readonly<{}>;
                    refs: {
                        [key: string]: React.ReactInstance;
                    };
                    componentDidMount?(): void;
                    shouldComponentUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
                    componentWillUnmount?(): void;
                    componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
                    getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
                    componentDidUpdate?(prevProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
                    componentWillMount?(): void;
                    UNSAFE_componentWillMount?(): void;
                    componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
                    componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                    UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<import("amis-core").ThemeProps & {
                        className?: string | undefined;
                        children?: React.ReactNode;
                        forwardedRef?: any;
                    } & React.HTMLAttributes<HTMLDivElement>, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
                };
                displayName: string;
                contextType: React.Context<string>;
                ComposedComponent: React.ComponentType<({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element>;
            } & import("hoist-non-react-statics").NonReactStatics<({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                className?: string | undefined;
                children?: React.ReactNode;
                forwardedRef?: any;
            } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element, {}> & {
                ComposedComponent: ({ classnames: cx, className, children, classPrefix, forwardedRef, ...rest }: import("amis-core").ThemeProps & {
                    className?: string | undefined;
                    children?: React.ReactNode;
                    forwardedRef?: any;
                } & React.HTMLAttributes<HTMLDivElement>) => React.JSX.Element;
            };
        };
        closeOnEsc: boolean;
        closeOnOutside: boolean;
        showErrorMsg: boolean;
    };
    reaction: any;
    isDead: boolean;
    $$id: string;
    constructor(props: DialogProps);
    componentWillUnmount(): void;
    buildActions(): Array<AMISButtonSchema>;
    handleSelfScreen(e?: any): void;
    handleSelfClose(e?: any, confirmed?: boolean): Promise<void>;
    handleActionSensor(p: Promise<any>): void;
    handleAction(e: React.UIEvent<any>, action: ActionObject, data: object): void;
    handleDialogConfirm(values: object[], action: ActionObject, ...args: Array<any>): void;
    handleDialogClose(...args: Array<any>): void;
    handleDrawerConfirm(values: object[], action: ActionObject, ...args: Array<any>): void;
    handleDrawerClose(...args: Array<any>): void;
    handleEntered(): void;
    handleExited(): void;
    handleFormInit(data: any): void;
    handleFormChange(data: any, name?: string): void;
    handleFormSaved(data: any, response: any): void;
    handleChildFinished(value: any, action: ActionObject): void;
    openFeedback(dialog: any, ctx: any): Promise<unknown>;
    getPopOverContainer(): Element | null;
    renderBody(body: AMISSchemaCollection, key?: any): React.ReactNode;
    renderFooter(): React.JSX.Element | null;
    render(): React.JSX.Element;
}
export declare class DialogRenderer extends Dialog {
    static contextType: React.Context<IScopedContext>;
    clearErrorTimer: ReturnType<typeof setTimeout>;
    constructor(props: DialogProps, context: IScopedContext);
    componentWillUnmount(): void;
    tryChildrenToHandle(action: ActionObject, ctx: object, rawAction?: ActionObject): boolean;
    doAction(action: ActionObject, data: object, throwErrors: boolean): any;
    handleAction(e: React.UIEvent<any> | void, action: ActionObject, data: object, throwErrors?: boolean, delegate?: IScopedContext, rendererEvent?: RendererEvent<any>): Promise<any>;
    handleChildFinished(value: any, action: ActionObject): void;
    handleDialogConfirm(values: object[], action: ActionObject, ...rest: Array<any>): void;
    handleDrawerConfirm(values: object[], action: ActionObject, ...rest: Array<any>): void;
    reloadTarget(target: string, data?: any): void;
    closeTarget(target: string): void;
    setData(values: object, replace?: boolean): void;
    getData(): any;
}
