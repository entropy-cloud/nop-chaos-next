import React from 'react';
import { ActionObject, IScopedContext, RendererProps, RendererEvent, AMISLegacyAjaxActionButton, AMISButton, AMISLegacyDownloadActionButton, AMISLegacySaveAsActionButton, AMISLegacyUrlActionButton, AMISLegacyDialogActionButton, AMISLegacyDrawerActionButton, AMISLegacyToastActionButton, AMISLegacyCopyActionButton, AMISLegacyLinkActionButton, AMISLegacyReloadActionButton, AMISLegacyEmailActionButton, AMISLegacyBehaviorActionButton, AMISButtonSchema } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
export type ButtonSchema = AMISButton;
export type AjaxActionSchema = AMISLegacyAjaxActionButton;
export type DownloadActionSchema = AMISLegacyDownloadActionButton;
export type SaveAsActionSchema = AMISLegacySaveAsActionButton;
export type UrlActionSchema = AMISLegacyUrlActionButton;
export type DialogActionSchema = AMISLegacyDialogActionButton;
export type DrawerActionSchema = AMISLegacyDrawerActionButton;
export type ToastActionSchema = AMISLegacyToastActionButton;
export type CopyActionSchema = AMISLegacyCopyActionButton;
export type LinkActionSchema = AMISLegacyLinkActionButton;
export type ReloadActionSchema = AMISLegacyReloadActionButton;
export type EmailActionSchema = AMISLegacyEmailActionButton;
export type OtherActionSchema = AMISLegacyBehaviorActionButton;
/**
 * 按钮动作渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/action
 */
export type ActionSchema = AMISButtonSchema;
import { ThemeProps } from 'amis-core';
import { ToastSchemaBase } from '../Schema';
export declare const createSyntheticEvent: <T extends Element, E extends Event>(event: E) => React.SyntheticEvent<T, E>;
type CommonKeys = 'type' | 'className' | 'iconClassName' | 'rightIconClassName' | 'loadingClassName' | 'target';
export interface ActionProps extends Omit<ButtonSchema, 'className' | 'iconClassName' | 'rightIconClassName' | 'loadingClassName'>, Omit<ThemeProps, 'className'>, Omit<AjaxActionSchema, CommonKeys>, Omit<UrlActionSchema, CommonKeys>, Omit<LinkActionSchema, CommonKeys>, Omit<DialogActionSchema, CommonKeys>, Omit<DrawerActionSchema, CommonKeys>, Omit<ToastSchemaBase, CommonKeys>, Omit<CopyActionSchema, CommonKeys>, Omit<ReloadActionSchema, CommonKeys>, Omit<EmailActionSchema, CommonKeys | 'body'>, Omit<OtherActionSchema, CommonKeys>, Omit<RendererProps, 'data'>, SpinnerExtraProps {
    actionType: any;
    onAction?: (e: React.MouseEvent<any> | void | null, action: ActionSchema) => void;
    onActionSensor?: (promise?: Promise<any>) => void;
    isCurrentUrl?: (link: string) => boolean;
    onClick?: ((e: React.MouseEvent<any>, props: any) => void) | string | Function | null;
    componentClass: React.ElementType;
    tooltipContainer?: any;
    isMenuItem?: boolean;
    active?: boolean;
}
interface ActionState {
    inCountDown: boolean;
    countDownEnd: number;
    timeLeft: number;
}
export declare class Action extends React.Component<ActionProps, ActionState> {
    static defaultProps: {
        type: "button";
        componentClass: React.ElementType;
        tooltipPlacement: "bottom";
        activeClassName: string;
        countDownTpl: string;
        countDown: number;
    };
    state: ActionState;
    localStorageKey: string;
    dom: any;
    constructor(props: ActionProps);
    handleAction(e: React.MouseEvent<any>): Promise<void>;
    handleCountDown(): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ActionProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof Action>;
} & import("hoist-non-react-statics").NonReactStatics<typeof Action, {}> & {
    ComposedComponent: typeof Action;
};
export default _default;
export type ActionRendererProps = RendererProps & Omit<ActionProps, 'onAction' | 'isCurrentUrl' | 'tooltipContainer'> & {
    onAction: (e: React.MouseEvent<any> | string | void | null, action: object, data: any, throwErrors?: boolean, delegate?: IScopedContext, rendererEvent?: RendererEvent<any>) => void;
    btnDisabled?: boolean;
};
export declare class ActionRenderer extends React.Component<ActionRendererProps> {
    static contextType: React.Context<IScopedContext>;
    state: {
        actionDisabled: boolean;
    };
    constructor(props: ActionRendererProps, scoped: IScopedContext);
    componentWillUnmount(): void;
    /**
     * 动作处理
     */
    doAction(action: ActionObject, args: {
        value?: string | {
            [key: string]: string;
        };
    }): void;
    handleAction(e: React.MouseEvent<any> | string | void | null, action: any): Promise<void>;
    handleMouseEnter(e: React.MouseEvent<any>): void;
    handleMouseLeave(e: React.MouseEvent<any>): void;
    isCurrentAction(link: string): boolean | {
        params?: object;
    };
    render(): React.JSX.Element;
}
