import React from 'react';
import { OptionsControlProps, SchemaNode, ActionObject, PlainObject } from 'amis-core';
import { SchemaTpl } from '../../Schema';
import type { AMISTooltipWrapperSchema } from '../TooltipWrapper';
import type { AMISFormItemWithOptions, Option } from 'amis-core';
/**
 * Picker
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/picker
 */
/**
 * Picker 选择器组件，用于表单中弹窗选择数据，可通过弹窗（Dialog/Drawer）或内嵌模式展示配置的选择内容，支持自定义标签显示与选项描述。
 */
export interface AMISPickerSchema extends AMISFormItemWithOptions {
    /**
     * 指定为 picker 组件
     */
    type: 'picker';
    /**
     * 可用来生成选中的值的描述文字
     */
    labelTpl?: SchemaTpl;
    /**
     * 选中一个字段名用来作为值的描述文字
     */
    labelField?: string;
    /**
     * 选一个可以用来作为值的字段
     */
    valueField?: string;
    /**
     * 弹窗选择框详情
     */
    pickerSchema?: any;
    /**
     * 弹窗模式
     */
    modalMode?: 'dialog' | 'drawer';
    /**
     * 弹窗的尺寸
     */
    modalSize?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
    /**
     * 弹窗的标题
     */
    modalTitle?: string;
    /**
     * 内嵌模式
     */
    embed?: boolean;
    /**
     * 开启最大标签展示数量的相关配置
     */
    overflowConfig: {
        /**
         * 标签的最大展示数量
         */
        maxTagCount?: number;
        /**
         * 收纳标签生效的位置
         */
        displayPosition?: ('select' | 'crud')[];
        /**
         * 开启最大标签展示数量后，选择器内收纳标签的Popover配置
         */
        overflowTagPopover?: AMISTooltipWrapperSchema;
        /**
         * 开启最大标签展示数量后，CRUD顶部内收纳标签的Popover配置
         */
        overflowTagPopoverInCRUD?: AMISTooltipWrapperSchema;
    };
    /**
     * 选中项可删除，默认为true
     */
    itemClearable?: boolean;
}
export interface PickerProps extends OptionsControlProps {
    modalMode: 'dialog' | 'drawer';
    modalSize?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
    pickerSchema: PlainObject;
    labelField: string;
}
export interface PickerState {
    isOpened: boolean;
    isFocused: boolean;
    schema: SchemaNode;
}
export default class PickerControl extends React.PureComponent<PickerProps, any> {
    static propsList: Array<string>;
    static defaultProps: Partial<PickerProps>;
    state: PickerState;
    input: React.RefObject<HTMLInputElement | null>;
    toDispose: Array<() => void>;
    mounted: boolean;
    constructor(props: PickerProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: PickerProps): void;
    componentWillUnmount(): void;
    fetchOptions(): any;
    buildSchema(props: PickerProps): {
        labelTpl: any;
        type: string;
        pickerMode: boolean;
        syncLocation: boolean;
        filterCanAccessSuperData: boolean;
        api: import("amis-core").BaseApi | null | undefined;
        source: import("amis-core").BaseApi | null | undefined;
        keepItemSelectionOnPageChange: boolean;
        valueField: any;
        labelField: string;
        bulkActions: any;
        checkOnItemClick: boolean;
        listItem: {
            title: string;
        };
    };
    crud: any;
    crudRef(ref: any): void;
    reload(subpath?: string, query?: any): void;
    open(): void;
    close(): void;
    handleModalConfirm(values: Array<any>, action: ActionObject, ctx: any, components: Array<any>): Promise<void>;
    handleChange(items: Array<any>): Promise<void>;
    handleItemClick(item: any): Promise<void>;
    removeItem(index: number): Promise<void>;
    handleKeyDown(e: React.KeyboardEvent): void;
    handleFocus(e: React.MouseEvent<HTMLElement>): void;
    handleBlur(): void;
    handleClick(): void;
    clearValue(e: React.MouseEvent<HTMLElement>): void;
    getOverflowConfig(): any;
    handleSelect(selectedItems: Array<any>, unSelectedItems: Array<any>): void;
    renderTag(item: Option, index: number): React.JSX.Element;
    renderValues(): React.JSX.Element;
    overrideCRUDProps(): {};
    renderBody({ popOverContainer }?: any): JSX.Element;
    render(): React.JSX.Element;
}
export declare class PickerControlRenderer extends PickerControl {
}
