import React from 'react';
import { FormControlProps, FormHorizontal } from 'amis-core';
import { ActionObject } from 'amis-core';
import { IComboStore } from 'amis-core';
import Sortable from 'sortablejs';
import { AMISClassName } from '../../Schema';
import { ListenerAction } from 'amis-core';
import type { SchemaTokenizeableString } from '../../Schema';
import type { AMISApi, AMISFormItem, AMISSchema, AMISTemplate } from 'amis-core';
export type AMISComboCondition = {
    test: string;
    items: Array<AMISComboItem>;
    label: string;
    scaffold?: any;
    mode?: string;
};
export interface AMISComboItemBase {
    /**
     * 是否唯一
     */
    unique?: boolean;
    /**
     * 列类名
     */
    columnClassName?: AMISClassName;
}
export type AMISComboItem = AMISSchema & AMISComboItemBase;
/**
 * Combo 组合输入框类型
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/combo
 */
export interface AMISComboSchemaBase extends AMISFormItem {
    /**
     * 单组表单项初始值
     * @default {}
     */
    scaffold?: any;
    /**
     * 是否含有边框
     */
    noBorder?: boolean;
    /**
     * 确认删除时的提示文本
     */
    deleteConfirmText?: string;
    /**
     * 删除时调用的 API 接口
     */
    deleteApi?: AMISApi;
    /**
     * 是否可切换条件，配合 conditions 使用
     */
    typeSwitchable?: boolean;
    /**
     * 符合某类条件后才渲染的 schema 配置
     */
    conditions?: Array<AMISComboCondition>;
    /**
     * 内部单组表单项的 CSS 类名
     */
    formClassName?: AMISClassName;
    /**
     * 新增按钮的 CSS 类名
     */
    addButtonClassName?: AMISClassName;
    /**
     * 新增按钮文字
     * @default 新增
     */
    addButtonText?: string;
    /**
     * 是否可新增
     */
    addable?: boolean;
    /**
     * 是否在顶部添加
     */
    addattop?: boolean;
    /**
     * 数组输入框的子项配置
     */
    items?: Array<AMISComboItem>;
    /**
     * 是否可拖拽排序
     */
    draggable?: boolean;
    /**
     * 可拖拽排序的提示信息
     * @default 可拖拽排序
     */
    draggableTip?: string;
    /**
     * 是否将结果扁平化（去掉 name）
     * 只有当 controls 的 length 为 1 且 multiple 为 true 的时候才有效
     */
    flat?: boolean;
    /**
     * 当扁平化开启并且 joinValues 为 true 时，用什么分隔符
     * @deprecated
     */
    delimiter?: string;
    /**
     * 当扁平化开启的时候，是否用分隔符的形式发送给后端，否则采用 array 的方式
     * @deprecated
     */
    joinValues?: boolean;
    /**
     * 限制最大个数
     */
    maxLength?: number | SchemaTokenizeableString;
    /**
     * 限制最小个数
     */
    minLength?: number | SchemaTokenizeableString;
    /**
     * 是否多行模式，默认一行展示完
     */
    multiLine?: boolean;
    /**
     * 是否可多选
     */
    multiple?: boolean;
    /**
     * 是否可删除
     */
    removable?: boolean;
    /**
     * 子表单的展示模式
     */
    subFormMode?: 'normal' | 'horizontal' | 'inline';
    /**
     * 水平排版时的左右宽度占比配置
     */
    subFormHorizontal?: FormHorizontal;
    /**
     * 没有成员时显示的占位符文本
     * @default empty
     */
    placeholder?: string;
    /**
     * 是否可访问父级数据
     * 正常 combo 已经关联到数组成员，是不能访问父级数据的
     */
    canAccessSuperData?: boolean;
    /**
     * 是否采用 Tabs 展示方式
     */
    tabsMode?: boolean;
    /**
     * Tabs 的展示模式
     */
    tabsStyle?: '' | 'line' | 'card' | 'radio';
    /**
     * 选项卡标题的生成模板。
     */
    tabsLabelTpl?: AMISTemplate;
    /**
     * 数据比较多，比较卡时，可以试试开启。
     */
    lazyLoad?: boolean;
    /**
     * 分页个数，默认不分页
     */
    perPage?: number;
    /**
     * 严格模式，为了性能默认不开的。
     */
    strictMode?: boolean;
    /**
     * 配置同步字段。只有 `strictMode` 为 `false` 时有效。
     * 如果 Combo 层级比较深，底层的获取外层的数据可能不同步。
     * 但是给 combo 配置这个属性就能同步下来。输入格式：`["os"]`
     */
    syncFields?: string[];
    /**
     * 允许为空，如果子表单项里面配置验证器，且又是单条模式。可以允许用户选择清空（不填）。
     */
    nullable?: boolean;
    /**
     * 提示信息
     */
    messages?: {
        /**
         * 验证错误提示
         */
        validateFailed?: string;
        /**
         * 最小值验证错误提示
         */
        minLengthValidateFailed?: string;
        /**
         * 最大值验证错误提示
         */
        maxLengthValidateFailed?: string;
    };
    updatePristineAfterStoreDataReInit?: boolean;
}
/**
 * Combo 组合输入控件，可动态增减、编辑子项或多组表单项，支持多行、分页、懒加载、自定义提示及字段同步。
 */
export interface AMISComboSchema extends AMISComboSchemaBase {
    /**
     * 指定为组合输入框类型
     */
    type: 'combo';
}
export type ComboRendererEvent = 'add' | 'delete' | 'tabsChange' | 'dragEnd';
export interface ComboProps extends FormControlProps, Omit<AMISComboSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
    store: IComboStore;
    changeImmediately?: boolean;
}
export default class ComboControl extends React.Component<ComboProps> {
    static defaultProps: Pick<ComboProps, 'minLength' | 'maxLength' | 'multiple' | 'multiLine' | 'addButtonClassName' | 'formClassName' | 'subFormMode' | 'draggableTip' | 'addButtonText' | 'canAccessSuperData' | 'addIcon' | 'dragIcon' | 'deleteIcon' | 'tabsMode' | 'tabsStyle' | 'placeholder' | 'itemClassName' | 'itemsWrapperClassName'>;
    static propsList: Array<string>;
    subFormDefaultValues: Array<{
        index: number;
        values: any;
        setted: boolean;
    }>;
    keys: Array<string>;
    dragTip?: HTMLElement;
    sortable?: Sortable;
    defaultValue?: any;
    toDispose: Array<Function>;
    id: string;
    constructor(props: ComboProps);
    componentDidUpdate(prevProps: ComboProps): void;
    componentWillUnmount(): void;
    /** 解析props中的变量，目前支持'minLength' | 'maxLength' */
    resolveVariableProps(props: ComboProps, key: 'minLength' | 'maxLength'): any;
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    addItemValue(itemValue: any): void;
    getValueAsArray(props?: Readonly<ComboProps>): any;
    addItemWith(condition: AMISComboCondition): void;
    addItem(): Promise<void>;
    deleteItem(key: number): Promise<void>;
    handleChange(values: any, diff: any, { index }: any): void;
    handleRadioChange(ctx: any, { index, name, trueValue, falseValue }: any): false | undefined;
    handleSingleFormChange(values: object): void;
    handleSubFormValid(valid: boolean, { index }: any): void;
    handleFormInit(values: any, { index }: any): void;
    handleSingleFormInit(values: any): void;
    handleAction(e: React.UIEvent<any> | undefined, action: ActionObject): any;
    validate(): any;
    flush(): Promise<void>;
    dragTipRef(ref: any): void;
    initDragging(): void;
    destroyDragging(): void;
    refsMap: {
        [propName: string]: any;
    };
    makeFormRef: ((index: number) => (ref: any) => void) & import("lodash").MemoizedFunction;
    get subForms(): any[];
    formRef(ref: any, index?: number): void;
    memoizedFormatValue: ((strictMode: boolean, syncFields: Array<string> | void, value: any, index: number, data: any) => object) & import("lodash").MemoizedFunction;
    formatValue(value: any, index?: number): object;
    pickCondition(value: any): AMISComboCondition | null;
    handleComboTypeChange(index: number, selection: any): void;
    handleTabSelect(key: number): Promise<void>;
    setNull(e: React.MouseEvent): void;
    renderPlaceholder(): React.JSX.Element;
    renderTabsMode(): React.JSX.Element;
    renderDelBtn(value: any, index: number): React.JSX.Element | null;
    renderAddBtn(): React.JSX.Element | null;
    renderMultipe(): React.JSX.Element;
    renderSingle(): React.JSX.Element;
    renderItems(finnalControls: AMISComboItem[], data: object, index?: number, originData?: any): React.JSX.Element;
    renderStatic(displayValue?: string): JSX.Element;
    render(): React.JSX.Element | null;
}
export declare class ComboControlRenderer extends ComboControl {
    setData(value: any, replace?: boolean, index?: number | string, condition?: any): Promise<void>;
}
export declare class KVControlRenderer extends ComboControl {
}
export declare class KVSControlRenderer extends ComboControl {
}
