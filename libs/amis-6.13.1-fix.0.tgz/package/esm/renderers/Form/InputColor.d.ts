import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import type { PresetColor } from 'amis-ui';
export declare const ColorPicker: React.LazyExoticComponent<{
    new (props: Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
        format?: string | undefined;
        placeholder?: string | undefined;
        clearable?: boolean | undefined;
        allowCustomColor?: boolean | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof import("amis-ui/lib/components/ColorPicker").ColorControl>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof import("amis-ui/lib/components/ColorPicker").ColorControl, {}> & {
        ComposedComponent: typeof import("amis-ui/lib/components/ColorPicker").ColorControl;
    }>;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
        format?: string | undefined;
        placeholder?: string | undefined;
        clearable?: boolean | undefined;
        allowCustomColor?: boolean | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof import("amis-ui/lib/components/ColorPicker").ColorControl>;
} & import("hoist-non-react-statics").NonReactStatics<typeof import("amis-ui/lib/components/ColorPicker").ColorControl, {}> & {
    ComposedComponent: typeof import("amis-ui/lib/components/ColorPicker").ColorControl;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
            format?: string | undefined;
            placeholder?: string | undefined;
            clearable?: boolean | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<import("amis-ui/lib/components/ColorPicker").ColorProps, keyof import("amis-core").LocaleProps>, "disabled" | "classnames" | "classPrefix" | "className" | "theme" | "mobileUI" | "style" | "value" | "onChange" | "popoverClassName" | "resetValue" | "popOverContainer" | "placement" | "popOverContainerSelector" | "presetColors"> & {
                format?: string | undefined;
                placeholder?: string | undefined;
                clearable?: boolean | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof import("amis-ui/lib/components/ColorPicker").ColorControl>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof import("amis-ui/lib/components/ColorPicker").ColorControl, {}> & {
        ComposedComponent: typeof import("amis-ui/lib/components/ColorPicker").ColorControl;
    };
}>;
/**
 * Color 颜色选择框
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/color
 */
/**
 * Color 颜色选择框组件，支持选择和自定义各种格式的颜色，包含预设颜色、清除按钮、以及弹出层相关配置。
 */
export interface AMISInputColorSchema extends AMISFormItem {
    /**
     * 指定为 color 组件
     */
    type: 'input-color';
    /**
     * 是否显示清除按钮
     */
    clearable?: boolean;
    /**
     * 颜色格式
     */
    format?: 'hex' | 'hexa' | 'rgb' | 'rgba' | 'hsl';
    /**
     * 选中颜色后是否关闭弹出层
     */
    closeOnSelect?: boolean;
    /**
     * 预设颜色
     */
    presetColors?: Array<PresetColor>;
    /**
     * 是否允许用户输入颜色
     */
    allowCustomColor?: boolean;
    /**
     * 弹窗容器选择器
     */
    popOverContainerSelector?: string;
}
export interface ColorProps extends FormControlProps, Omit<AMISInputColorSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export interface ColorControlState {
    open: boolean;
}
export default class ColorControl extends React.PureComponent<ColorProps, ColorControlState> {
    static defaultProps: Partial<ColorProps>;
    state: ColorControlState;
    render(): React.JSX.Element;
}
export declare class ColorControlRenderer extends ColorControl {
}
