import React from 'react';
import { FormControlProps } from 'amis-core';
import { ThemeProps } from 'amis-core';
import { ActionObject } from 'amis-core';
import { Option } from 'amis-core';
import { LocaleProps } from 'amis-core';
import type { AMISFormItem, AMISSpinnerConfig, TestIdBuilder } from 'amis-core';
/**
 * City 城市选择框。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/city
 */
/**
 * 城市选择框组件，用于省市区街道等多级城市信息的选择，支持提取编码、拼接值、自定义级别和搜索等功能。
 */
export interface AMISInputCitySchema extends AMISFormItem, AMISSpinnerConfig {
    /**
     * 指定为 city 组件
     */
    type: 'input-city';
    /**
     * 开启后只会存城市的 code 信息
     */
    extractValue?: boolean;
    /**
     * 是否将各个信息拼接成字符串
     */
    joinValues?: boolean;
    /**
     * 拼接的符号
     */
    delimiter?: string;
    /**
     * 允许选择城市
     */
    allowCity?: boolean;
    /**
     * 允许选择地区
     */
    allowDistrict?: boolean;
    /**
     * 允许选择街道
     */
    allowStreet?: boolean;
    /**
     * 是否显示搜索框
     */
    searchable?: boolean;
    /**
     * 下拉框className
     */
    itemClassName?: string;
}
export interface CityPickerProps extends Omit<AMISInputCitySchema, 'type' | 'className'>, LocaleProps, ThemeProps {
    value: any;
    onChange: (value: any) => void;
    extractValue: boolean;
    delimiter: string;
    allowCity: boolean;
    allowDistrict: boolean;
    allowStreet: boolean;
    mobileUI?: boolean;
    style?: {
        [propName: string]: any;
    };
    popOverContainer?: any;
    testIdBuilder?: TestIdBuilder;
}
export interface CityDb {
    province: Array<string>;
    city: {
        [propName: number]: Array<number>;
    };
    district: {
        [propName: number]: {
            [propName: number]: Array<number>;
        } | Array<number>;
    };
    [propName: string]: any;
}
export interface CityPickerState {
    code: number;
    province: string;
    provinceCode: number;
    city: string;
    cityCode: number;
    district: string;
    districtCode: number;
    street: string;
    db?: CityDb;
}
export declare class CityPicker extends React.Component<CityPickerProps, CityPickerState> {
    static defaultProps: {
        joinValues: boolean;
        extractValue: boolean;
        delimiter: string;
        allowCity: boolean;
        allowDistrict: boolean;
        allowStreet: boolean;
    };
    state: CityPickerState;
    componentDidMount(): void;
    componentDidUpdate(prevProps: CityPickerProps): void;
    loadDb(callback?: () => void): void;
    handleProvinceChange(option: Option): void;
    handleCityChange(option: Option): void;
    handleDistrictChange(option: Option, otherStates?: Partial<CityPickerState>): void;
    handleStreetChange(e: React.ChangeEvent<HTMLInputElement>): void;
    handleStreetEnd(): void;
    syncIn(props?: Readonly<CityPickerProps>): void;
    syncOut(): void;
    render(): React.JSX.Element;
}
declare const ThemedCity: {
    new (props: Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
        joinValues?: boolean | undefined;
        delimiter?: string | undefined;
        extractValue?: boolean | undefined;
        allowCity?: boolean | undefined;
        allowDistrict?: boolean | undefined;
        allowStreet?: boolean | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof CityPicker>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof CityPicker, {}> & {
        ComposedComponent: typeof CityPicker;
    }>;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
        joinValues?: boolean | undefined;
        delimiter?: string | undefined;
        extractValue?: boolean | undefined;
        allowCity?: boolean | undefined;
        allowDistrict?: boolean | undefined;
        allowStreet?: boolean | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof CityPicker>;
} & import("hoist-non-react-statics").NonReactStatics<typeof CityPicker, {}> & {
    ComposedComponent: typeof CityPicker;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            extractValue?: boolean | undefined;
            allowCity?: boolean | undefined;
            allowDistrict?: boolean | undefined;
            allowStreet?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<CityPickerProps, keyof LocaleProps>, "onChange" | "value" | "testIdBuilder" | "className" | "style" | "mobileUI" | "classnames" | "classPrefix" | "theme" | "searchable" | "popOverContainer" | "itemClassName"> & {
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                extractValue?: boolean | undefined;
                allowCity?: boolean | undefined;
                allowDistrict?: boolean | undefined;
                allowStreet?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof CityPicker>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof CityPicker, {}> & {
        ComposedComponent: typeof CityPicker;
    };
};
export default ThemedCity;
export interface LocationControlProps extends FormControlProps {
    allowCity?: boolean;
    allowDistrict?: boolean;
    extractValue?: boolean;
    joinValues?: boolean;
    allowStreet?: boolean;
}
export declare class LocationControl extends React.Component<LocationControlProps> {
    state: {
        db: null;
    };
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    handleChange(value: number | string): Promise<void>;
    renderStatic(displayValue?: string): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class CheckboxControlRenderer extends LocationControl {
}
