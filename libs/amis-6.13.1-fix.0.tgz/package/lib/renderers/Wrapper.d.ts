import React from 'react';
import { RendererProps, AMISSchemaCollection } from 'amis-core';
import { AMISSchemaBase } from 'amis-core';
/**
 * Wrapper 容器渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/wrapper
 */
/**
 * 包装器组件，为子组件提供统一样式与容器结构。
 */
export interface AMISWrapperSchema extends AMISSchemaBase {
    /**
     * 指定为 container 类型
     */
    type: 'wrapper';
    /**
     * 内容
     */
    body: AMISSchemaCollection;
    size?: 'xs' | 'sm' | 'md' | 'lg' | 'none';
    /**
     * 是否包裹内容 默认 true
     */
    wrap?: boolean;
}
export interface WrapperProps extends RendererProps, Omit<AMISWrapperSchema, 'className'> {
    children?: JSX.Element | ((props?: any) => JSX.Element);
}
export default class Wrapper extends React.Component<WrapperProps, object> {
    static propsList: Array<string>;
    static defaultProps: Partial<WrapperProps>;
    renderBody(): JSX.Element | null;
    render(): JSX.Element | null;
}
export declare class WrapperRenderer extends Wrapper {
}
