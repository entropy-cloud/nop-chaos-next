import React from 'react';
import { RendererProps } from 'amis-core';
import { ActionObject, PlainObject } from 'amis-core';
import { AMISSchemaCollection, AMISSchemaBase, AMISSchema } from 'amis-core';
import { SchemaQuickEdit } from './QuickEdit';
import { SchemaPopOver } from './PopOver';
import { TableCell } from './Table';
import { SchemaCopyable } from './Copyable';
import { AMISClassName, SchemaUrlPath } from '../Schema';
import type { AMISButtonSchema, AMISExpression, AMISTemplate, IItem } from 'amis-core';
export type AMISCardFieldBase = {
    /**
     * 字段标签名称
     */
    label: string;
    /**
     * 标签CSS类名
     */
    labelClassName?: AMISClassName;
    /**
     * 绑定的字段名
     */
    name?: string;
    /**
     * 查看详情配置
     */
    popOver?: SchemaPopOver;
    /**
     * 快速编辑配置
     */
    quickEdit?: SchemaQuickEdit;
    /**
     * 点击复制配置
     */
    copyable?: SchemaCopyable;
};
export type AMISCardField = AMISSchema & AMISCardFieldBase;
export interface AMISCardSchemaBase extends AMISSchemaBase {
    header?: {
        /**
         * 头部容器CSS类名
         */
        className?: AMISClassName;
        /**
         * 卡片标题
         */
        title?: AMISTemplate;
        /**
         * 标题CSS类名
         */
        titleClassName?: AMISClassName;
        /**
         * 卡片副标题
         */
        subTitle?: AMISSchemaCollection;
        /**
         * 副标题CSS类名
         */
        subTitleClassName?: AMISClassName;
        /**
         * 副标题占位符文本
         */
        subTitlePlaceholder?: string;
        /**
         * 卡片描述，支持模板语法
         */
        description?: AMISTemplate;
        /**
         * 描述占位符文本
         */
        descriptionPlaceholder?: string;
        /**
         * 描述的 CSS 类名
         */
        descriptionClassName?: AMISClassName;
        /**
         * 描述字段（已废弃）
         * @deprecated 建议使用 description
         */
        desc?: AMISTemplate;
        /**
         * 描述占位符（已废弃）
         * @deprecated 建议使用 descriptionPlaceholder
         */
        descPlaceholder?: AMISTemplate;
        /**
         * 描述类名（已废弃）
         * @deprecated 建议使用 descriptionClassName
         */
        descClassName?: AMISClassName;
        /**
         * 头像图片地址
         */
        avatar?: SchemaUrlPath;
        /**
         * 头像文字，当没有图片时显示
         */
        avatarText?: AMISTemplate;
        /**
         * 头像文字背景色数组
         */
        avatarTextBackground?: String[];
        /**
         * 头像文字的 CSS 类名
         */
        avatarTextClassName?: AMISClassName;
        /**
         * 头像容器的 CSS 类名
         */
        avatarClassName?: AMISClassName;
        /**
         * 图片的 CSS 类名
         */
        imageClassName?: AMISClassName;
        /**
         * 是否高亮显示
         */
        highlight?: AMISExpression;
        /**
         * 高亮状态的 CSS 类名
         */
        highlightClassName?: AMISClassName;
        /**
         * 链接地址，点击头部时跳转
         */
        href?: AMISTemplate;
        /**
         * 是否在新窗口打开链接
         */
        blank?: boolean;
    };
    /**
     * 内容区域
     */
    body?: Array<AMISCardField>;
    /**
     * 多媒体区域
     */
    media?: {
        className?: AMISClassName;
        /**
         * 多媒体类型
         */
        type?: 'image' | 'video';
        /**
         * 多媒体链接地址
         */
        url?: SchemaUrlPath;
        /**
         * 多媒体区域位置
         */
        position?: 'top' | 'left' | 'right' | 'bottom';
        /**
         * 类型为video时是否自动播放
         */
        autoPlay?: boolean;
        /**
         * 类型为video时是否是直播
         */
        isLive?: boolean;
        /**
         * 类型为video时视频封面
         */
        poster?: SchemaUrlPath;
    };
    /**
     * 底部按钮集合。
     */
    actions?: Array<AMISButtonSchema>;
    /**
     * 工具栏按钮
     */
    toolbar?: Array<AMISButtonSchema>;
    /**
     * 次要说明
     */
    secondary?: AMISTemplate;
    /**
     * 卡片内容区的表单项label是否使用Card内部的样式，默认为true
     */
    useCardLabel?: boolean;
}
/**
 * Card 卡片渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/card
 */
/**
 * 卡片组件，用于展示信息块。支持头部、内容区域、操作按钮等配置。
 */
export interface AMISCardSchema extends AMISCardSchemaBase {
    /**
     * 指定为 card 组件
     */
    type: 'card';
}
export interface CardProps extends RendererProps, Omit<AMISCardSchema, 'className'> {
    onCheck: (item: IItem) => void;
    actionsCount: number;
    itemIndex?: number;
    dragging?: boolean;
    selectable?: boolean;
    selected?: boolean;
    checkable?: boolean;
    multiple?: boolean;
    hideCheckToggler?: boolean;
    item: IItem;
    checkOnItemClick?: boolean;
}
export declare class CardRenderer extends React.Component<CardProps> {
    static defaultProps: {
        className: string;
        avatarClassName: string;
        headerClassName: string;
        footerClassName: string;
        secondaryClassName: string;
        avatarTextClassName: string;
        bodyClassName: string;
        actionsCount: number;
        titleClassName: string;
        highlightClassName: string;
        subTitleClassName: string;
        descClassName: string;
        descriptionClassName: string;
        imageClassName: string;
        highlight: boolean;
        blank: boolean;
        dragging: boolean;
        selectable: boolean;
        checkable: boolean;
        selected: boolean;
        hideCheckToggler: boolean;
        useCardLabel: boolean;
    };
    static propsList: Array<string>;
    constructor(props: CardProps);
    isHaveLink(): any;
    handleClick(e: React.MouseEvent<HTMLDivElement>): void;
    handleAction(e: React.UIEvent<any>, action: ActionObject, ctx: object): void;
    handleCheck(): void;
    getPopOverContainer(): any;
    handleQuickChange(values: object, saveImmediately?: boolean, savePristine?: boolean, options?: {
        resetOnFailed?: boolean;
        reload?: string;
    }): void;
    renderToolbar(): React.JSX.Element | null;
    renderActions(): React.JSX.Element[] | undefined;
    renderChild(node: AMISSchemaCollection, region?: string, key?: any): React.ReactNode;
    itemRender(field: any, index: number, len: number, props: any): React.JSX.Element | undefined;
    renderField(region: string, field: AMISSchema, key: any, props: any): React.JSX.Element | undefined;
    renderBody(): React.ReactNode;
    rederTitle(): JSX.Element | undefined;
    renderSubTitle(): JSX.Element | undefined;
    renderSubTitlePlaceholder(): JSX.Element | undefined;
    renderDesc(): JSX.Element | undefined;
    renderDescPlaceholder(): JSX.Element | undefined;
    renderAvatar(): string | undefined;
    renderAvatarText(): JSX.Element | undefined;
    renderSecondary(): JSX.Element | undefined;
    renderAvatarTextStyle(): PlainObject | undefined;
    renderMedia(): React.JSX.Element | undefined;
    render(): React.JSX.Element;
}
export declare class CardItemFieldRenderer extends TableCell {
    static defaultProps: {
        wrapperComponent: string;
    };
    static propsList: string[];
    render(): JSX.Element;
}
