import { CT_PieChart } from '../../../../openxml/ChartTypes';
import { Workbook } from '../../../Workbook';
import type { SeriesOption } from 'echarts';
export declare function fromPieChart(workbook: Workbook, pieChart: CT_PieChart): {
    categories: string[];
    series: SeriesOption[];
};
