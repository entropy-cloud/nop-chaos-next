import { CT_BarChart } from '../../../../openxml/ChartTypes';
import { Workbook } from '../../../Workbook';
import type { SeriesOption } from 'echarts';
export declare function fromBarChart(workbook: Workbook, barChart: CT_BarChart): {
    categories: string[];
    series: SeriesOption[];
};
