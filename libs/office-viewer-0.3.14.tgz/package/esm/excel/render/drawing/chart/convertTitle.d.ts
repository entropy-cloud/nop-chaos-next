import { CT_Title } from '../../../../openxml/ChartTypes';
export declare function convertTitle(chartTitle?: CT_Title): {
    top?: string | number;
    right?: string | number;
    bottom?: string | number;
    left?: string | number;
    text: string;
};
