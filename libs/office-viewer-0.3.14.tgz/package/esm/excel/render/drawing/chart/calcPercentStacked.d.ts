import type { SeriesOption } from 'echarts';
export declare function calcPercentStacked(series: SeriesOption[]): void;
