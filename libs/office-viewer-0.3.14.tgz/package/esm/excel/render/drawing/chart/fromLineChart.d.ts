import { CT_LineChart } from '../../../../openxml/ChartTypes';
import { Workbook } from '../../../Workbook';
import type { SeriesOption } from 'echarts';
export declare function fromLineChart(workbook: Workbook, lineChart: CT_LineChart): {
    categories: string[];
    series: SeriesOption[];
};
