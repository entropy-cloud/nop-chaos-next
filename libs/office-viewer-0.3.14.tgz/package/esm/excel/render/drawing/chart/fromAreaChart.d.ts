import { CT_AreaChart } from '../../../../openxml/ChartTypes';
import { Workbook } from '../../../Workbook';
import type { SeriesOption } from 'echarts';
export declare function fromAreaChart(workbook: Workbook, areaChart: CT_AreaChart): {
    categories: string[];
    series: SeriesOption[];
};
