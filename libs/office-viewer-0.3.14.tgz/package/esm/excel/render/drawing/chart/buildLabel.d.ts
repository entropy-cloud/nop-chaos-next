import { CT_DLbls } from '../../../../openxml/ChartTypes';
export declare function buildLabel(dLbls?: CT_DLbls): echarts.EChartOption.SeriesLine;
