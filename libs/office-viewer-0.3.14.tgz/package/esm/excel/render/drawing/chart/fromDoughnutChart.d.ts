import { CT_DoughnutChart } from '../../../../openxml/ChartTypes';
import { Workbook } from '../../../Workbook';
import type { SeriesOption } from 'echarts';
export declare function fromDoughnutChart(workbook: Workbook, doughnutChart: CT_DoughnutChart): {
    categories: string[];
    series: SeriesOption[];
};
