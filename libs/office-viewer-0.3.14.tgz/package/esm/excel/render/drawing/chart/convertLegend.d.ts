import { CT_Legend } from '../../../../openxml/ChartTypes';
import type { LegendComponentOption } from 'echarts';
/**
 * 将 Excel chart 的图例转换为 Echarts 的图例
 */
export declare function convertLegend(categories: string[], chartLegend?: CT_Legend): LegendComponentOption;
