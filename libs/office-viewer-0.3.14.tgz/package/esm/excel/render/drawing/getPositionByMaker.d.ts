import { CT_Marker } from '../../../openxml/ExcelTypes';
import { Sheet } from '../../sheet/Sheet';
/**
 * 基于 maker 计算位置信息
 */
export declare function getPositionByMaker(maker: CT_Marker, sheet: Sheet): {
    x: number;
    y: number;
    width: number;
    height: number;
};
