/**
 * 简单的按钮组件
 */
export declare class Button {
    button: HTMLButtonElement;
    constructor(container: HTMLElement, style: 'primary' | 'normal', text: string, onClick: () => void);
}
