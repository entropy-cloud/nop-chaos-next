/**
 * 绘制圆角矩形路径
 * @param cornerRadius 圆角半径
 */
export declare function drawRoundedRectPath(ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D, width: number, height: number, cornerRadius: number | number[]): void;
