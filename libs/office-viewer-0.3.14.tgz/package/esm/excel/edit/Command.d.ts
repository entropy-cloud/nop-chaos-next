/**
 * 所有对数据的改动都通过这里
 */
export interface ICommand {
    execute: () => void;
    undo: () => void;
}
export declare class ChangeRowHeightCommand implements ICommand {
    type: 'changeRowHeight';
    sheetIndex: string;
    row: number;
    height: number;
    oldHeight: number;
    constructor(sheetIndex: string, row: number, height: number, oldHeight: number);
    execute(): void;
    undo(): void;
}
export declare class CommandManager {
}
