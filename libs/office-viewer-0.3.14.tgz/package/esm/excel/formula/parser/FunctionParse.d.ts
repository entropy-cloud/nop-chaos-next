import { Parser } from '../Parser';
import { ASTNode } from '../ast/ASTNode';
import { Token } from '../tokenizer';
import { PrefixParse } from './PrefixParse';
export declare class FunctionParse implements PrefixParse {
    parse(parser: Parser, token: Token): ASTNode;
}
