import { Parser } from '../Parser';
import { ASTNode } from '../ast/ASTNode';
import { Token } from '../tokenizer';
import { InfixParse } from './InfixParse';
export declare class BinaryOperator implements InfixParse {
    precedence: number;
    constructor(precedence: number);
    parse(parser: Parser, left: ASTNode, token: Token): ASTNode;
    getPrecedence(): number;
}
