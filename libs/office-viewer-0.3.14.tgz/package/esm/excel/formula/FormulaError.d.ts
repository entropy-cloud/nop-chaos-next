/**
 * Formula Error.
 */
export declare class FormulaError extends Error {
    private _error;
    private details?;
    /**
     * @param {string} error - error code, i.e. #NUM!
     * @param {string} [msg] - detailed error message
     * @param {object|Error} [details]
     * @returns {FormulaError}
     */
    constructor(error: string, msg?: string, details?: object);
    /**
     * Get the error name.
     * @returns {string} formula error
     */
    get error(): string;
    get name(): string;
    /**
     * Return true if two errors are same.
     * @param {FormulaError} err
     * @returns {boolean} if two errors are same.
     */
    equals(err: FormulaError): boolean;
    /**
     * Return the formula error in string representation.
     * @returns {string} the formula error in string representation.
     */
    toString(): string;
    static errorMap: Map<any, any>;
    static DIV0: FormulaError;
    static NA: FormulaError;
    static NAME: FormulaError;
    static NULL: FormulaError;
    static NUM: FormulaError;
    static REF: FormulaError;
    static VALUE: FormulaError;
    static NOT_IMPLEMENTED: (functionName: string) => FormulaError;
    static TOO_MANY_ARGS: (functionName: string) => FormulaError;
    static ARG_MISSING: () => FormulaError;
    static ERROR: (msg: string, details?: object) => FormulaError;
}
export default FormulaError;
