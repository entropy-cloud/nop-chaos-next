import { FormulaEnv } from '../FormulaEnv';
import { EvalResult } from './EvalResult';
export declare function evalFormula(formula: string, env: FormulaEnv): EvalResult;
