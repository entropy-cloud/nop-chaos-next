import { FormulaEnv } from '../FormulaEnv';
import { ASTNode } from '../ast/ASTNode';
import { EvalResult } from './EvalResult';
import '../functions/math';
import '../functions/trigonometry';
import '../functions/text';
import '../functions/statistical';
import '../functions/distribution';
import '../functions/engineering';
import '../functions/date';
import '../functions/financial';
import '../functions/information';
import '../functions/logical';
import '../functions/reference';
import '../functions/functionAlias';
import '../functions/database';
export declare class FormulaVisitor {
    formulaEnv: FormulaEnv;
    constructor(formulaEnv: FormulaEnv);
    visit(node: ASTNode | ASTNode[]): EvalResult;
}
