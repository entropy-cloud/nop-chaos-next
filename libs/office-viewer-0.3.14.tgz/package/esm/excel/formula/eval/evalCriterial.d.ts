import { Criteria } from '../parser/parseCriteria';
export declare function evalCriterial(criteria: Criteria, value: string | number | boolean): boolean;
