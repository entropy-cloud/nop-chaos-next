export type EvalResult = undefined | number | string | boolean | Date | ErrorResult | EvalResult[] | UnionValue | HyperlinkResult;
export type ErrorResult = {
    type: 'Error';
    value: string;
};
export type UnionValue = {
    type: 'Union';
    children: EvalResult[];
};
export type HyperlinkResult = {
    type: 'Hyperlink';
    text: string;
    link: string;
};
export declare function isUnionValue(value: EvalResult): boolean;
export declare function isErrorValue(value: EvalResult): boolean;
