import { FunctionName } from '../builtinFunctions';
import { EvalResult } from '../eval/EvalResult';
type Func = (...args: EvalResult[]) => EvalResult;
export declare const functions: Map<FunctionName, Func>;
export declare function regFunc(name: FunctionName, func: Func): void;
export declare function isVolatileFunction(functionName: FunctionName): boolean;
export {};
