/**
 * 来自 fast-formula-parser
 */
import { EvalResult } from '../eval/EvalResult';
export declare function parseDateWithExtra(serialOrString: string | Date): {
    date: Date;
    isDateGiven: boolean;
};
export declare function parseDate(serialOrString: string | Date): Date;
export declare function parseDates(...dates: EvalResult[]): Date[];
export declare function DATEDIF(startDate: Date, endDate: Date, unit: string): number;
export declare function DAYS(endDate: EvalResult, startDate: EvalResult): number;
export declare function DAYS360(start_date: Date, end_date: Date, method: boolean): number;
export declare function YEARFRAC(startDate: Date, endDate: Date, basis: number): number;
