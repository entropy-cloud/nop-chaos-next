import { FormulaEnv } from '../../FormulaEnv';
import FormulaError from '../../FormulaError';
import { EvalResult } from '../../eval/EvalResult';
export type CellData = string | boolean | undefined | number | {
    date: number;
};
export type Data = CellData[][];
export type TestCase = Record<string, EvalResult | FormulaError | string | number>;
export declare function testEvalCases(testCase: TestCase, env: FormulaEnv): void;
/**
 * 构建环境的辅助工具
 * @param data
 * @param vars
 * @returns
 */
export declare function buildEnv(data: Data, vars?: Map<string, string>): FormulaEnv;
