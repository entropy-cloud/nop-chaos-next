/**
 * 财务相关的函数，主要参考 formulajs 里的实现
 */
import { EvalResult } from '../eval/EvalResult';
export declare function NPV(...arg: EvalResult[]): number;
