import { EvalResult } from '../../eval/EvalResult';
export declare function getArray(arg: EvalResult): EvalResult[];
