export declare const bessel: {
    besselj: (x: number, n: number) => number;
    bessely: (x: number, n: number) => number;
    besseli: (x: number, n: number) => number;
    besselk: (x: number, n: number) => number;
};
