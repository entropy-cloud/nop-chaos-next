import { EvalResult } from '../../eval/EvalResult';
export declare function getDateOrThrow(arg: EvalResult): Date;
