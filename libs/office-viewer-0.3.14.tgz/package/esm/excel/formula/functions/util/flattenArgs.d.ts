import { EvalResult } from '../../eval/EvalResult';
/**
 * 将结果打平成一维数组
 */
export declare function flattenArgs(args: EvalResult[]): EvalResult[];
