import { EvalResult } from '../../eval/EvalResult';
/**
 *
 * 获取参数中的数字
 * @param arg
 * @param defaultValue 默认值
 * @returns
 */
export declare function getNumber(arg: EvalResult, defaultValue?: number, booleanToNumber?: boolean): number | undefined;
export declare function getNumberOrThrow(arg: EvalResult, booleanToNumber?: boolean): number;
export declare function getNumberWithDefault(arg: EvalResult, defaultValue: number): number;
