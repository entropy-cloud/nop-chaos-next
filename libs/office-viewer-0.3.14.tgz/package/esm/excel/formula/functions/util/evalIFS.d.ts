import { EvalResult } from '../../eval/EvalResult';
export declare function evalIFS(args: EvalResult[]): EvalResult[];
