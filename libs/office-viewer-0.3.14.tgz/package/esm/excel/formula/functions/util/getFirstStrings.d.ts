import { EvalResult } from '../../eval/EvalResult';
/**
 * 获取参数中的字符串，如果是数组则取第一个
 */
export declare function getFirstStrings(args: EvalResult[]): string[];
