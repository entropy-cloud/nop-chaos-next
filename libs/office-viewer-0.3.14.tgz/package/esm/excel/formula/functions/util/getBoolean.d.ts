import { EvalResult } from '../../eval/EvalResult';
/**
 *
 * 获取参数中的布尔值
 * @param arg
 * @param defaultValue 默认值
 * @returns
 */
export declare function getBoolean(arg: EvalResult, defaultValue?: boolean): boolean | undefined;
export declare function getBooleanOrThrow(arg: EvalResult): boolean;
export declare function getBooleanWithDefault(arg: EvalResult, defaultValue: boolean): boolean;
