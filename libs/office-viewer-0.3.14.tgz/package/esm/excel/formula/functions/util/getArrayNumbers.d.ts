import { EvalResult } from '../../eval/EvalResult';
/**
 *
 * 获取参数中的数字
 * @param args
 * @param process 自定义检查函数
 * @returns
 */
export declare function getArrayNumbers(args: EvalResult): number[];
