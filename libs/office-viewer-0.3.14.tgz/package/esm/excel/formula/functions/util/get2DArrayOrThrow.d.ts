import { EvalResult } from '../../eval/EvalResult';
/**
 * 判断是否是二维数组
 * @param args
 * @returns
 */
export declare function get2DArrayOrThrow(args: EvalResult): EvalResult[][];
/**
 * 将一维数组转换为二维数组
 * @param args
 * @returns
 */
export declare function get2DArray(args: EvalResult): EvalResult[][] | undefined;
