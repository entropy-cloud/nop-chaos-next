import { EvalResult } from '../../eval/EvalResult';
/**
 * 获取参数中的数字，如果是数组则取第一个
 */
export declare function getFirstNumbers(args: EvalResult[], booleanToNumber: boolean): number[];
