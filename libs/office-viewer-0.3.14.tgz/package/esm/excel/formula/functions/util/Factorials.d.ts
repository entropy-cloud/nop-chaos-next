export declare const Factorials: number[];
export declare function factorial(n: number): number;
export declare function factorialDouble(n: number): number;
