import { EvalResult } from '../../eval/EvalResult';
/**
 *
 * 获取参数中的数字
 * @param args
 * @param process 自定义检查函数
 * @returns
 */
export declare function getNumbers(args: EvalResult[], process?: (arg: number | undefined, origin: EvalResult) => number | undefined, booleanToNumber?: boolean): number[];
