import { EvalResult } from '../../eval/EvalResult';
type NumOr = number | undefined;
/**
 *
 * 获取参数中的数字
 * @param args
 * @param process 自定义检查函数
 * @returns
 */
export declare function getNumber2DArray(args: EvalResult): NumOr[][];
export declare function getNumber2DArrayOrThrow(args: EvalResult): number[][];
export {};
