import { EvalResult } from '../../eval/EvalResult';
export declare function evalIF(args: EvalResult[]): EvalResult[];
