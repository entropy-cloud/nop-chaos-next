/**
 * from https://github.com/jojoee/bahttext/blob/master/src/index.js
 * Nathachai Thongniran
 * MIT License
 */
/**
 * Change number to Thai pronunciation string
 *
 * @public
 * @param {number} num
 * @returns {string}
 */
export declare function bahttext(num: number): string;
