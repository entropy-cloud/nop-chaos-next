/**
 * 来自以下，看起来不支持，。和片假名，后面得优化
 * Width Converter
 * Copyright 2017 Yanbin Ma under MIT
 * https://github.com/myanbin/hwfw-convert
 */
/**
 * Full width to Half width Tramsformer
 * @param {string} source Source text (full width)
 * @param {object} options Options
 */
export declare function full2half(source: string, options?: object): string;
/**
 * Half width to Full width Tramsformer
 * @param {string} source Source text (half width)
 * @param {object} options Options
 */
export declare function half2full(source: string, options?: object): string;
