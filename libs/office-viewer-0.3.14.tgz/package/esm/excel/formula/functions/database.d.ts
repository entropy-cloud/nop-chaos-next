/**
 * 数据库相关的函数
 */
import { EvalResult } from '../eval/EvalResult';
/**
 * 从数据库里获取值并过滤
 * @param db 二维数据结构
 * @param criteria
 * @param field
 */
export declare function getDatabaseResult(db: EvalResult[][], criteria: EvalResult[][], field?: number | string): EvalResult[];
