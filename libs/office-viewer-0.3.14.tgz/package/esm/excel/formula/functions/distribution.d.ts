/**
 * 统计分布相关的函数，主要参考 fast-formula-parser 里的实现
 * https://github.com/LesterLyu/fast-formula-parser
 */
import { EvalResult } from '../eval/EvalResult';
export declare const standardDeviation: (arr: number[], usePopulation?: boolean) => number;
export declare function VAR(...arg: EvalResult[]): number;
export declare function VARP(data: number[]): number;
