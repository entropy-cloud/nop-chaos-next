import { Token } from '../tokenizer';
import { Reference } from './Reference';
export type ASTNodeType = 'Array' | 'Function' | 'Percent' | 'Constant' | 'UnaryExpr' | 'BinaryExpr' | 'Union' | 'Intersection' | 'Reference';
export type ASTNode = {
    type: ASTNodeType;
    token: Token;
    children: ASTNode[] | ASTNode[][];
    ref?: Reference;
    refs?: Reference[];
};
export declare function printAST(ast: ASTNode): string;
export declare function printArray(children: ASTNode[] | ASTNode[][], result: string[]): void;
export declare function print(node: ASTNode | ASTNode[], result: string[]): void;
