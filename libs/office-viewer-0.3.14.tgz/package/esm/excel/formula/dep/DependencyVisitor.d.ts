import { GraphInstance } from '../../../util/graph';
import { FormulaEnv } from '../FormulaEnv';
import { ASTNode } from '../ast/ASTNode';
export declare class DependencyVisitor {
    formulaEnv: FormulaEnv;
    fromCell: string;
    graph: GraphInstance;
    constructor(formulaEnv: FormulaEnv, graph: GraphInstance, fromCell: string);
    visit(node: ASTNode | ASTNode[]): void;
}
