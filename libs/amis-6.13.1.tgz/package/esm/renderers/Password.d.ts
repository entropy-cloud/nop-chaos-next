/**
 * @file Password
 */
import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
/**
 * Password
 */
/**
 * 密码展示组件，用于安全显示或校验密码字段。
 */
export interface AMISPasswordSchema extends AMISSchemaBase {
    type: 'password';
    /**
     * 打码模式的文本
     */
    mosaicText?: string;
}
export interface PasswordProps extends RendererProps, Omit<AMISPasswordSchema, 'type' | 'className'> {
}
export interface PasswordState {
    visible: boolean;
}
export declare class PasswordField extends React.Component<PasswordProps, PasswordState> {
    state: {
        visible: boolean;
    };
    toggleVisible(): void;
    render(): React.JSX.Element;
}
export declare class PasswordFieldRenderer extends PasswordField {
}
