import React from 'react';
import { RendererProps } from 'amis-core';
import { IServiceStore } from 'amis-core';
import { Api, RendererData, ActionObject } from 'amis-core';
import { IScopedContext } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { TestIdBuilder } from 'amis-core';
import { BaseSchema, SchemaApi, SchemaMessage, SchemaName } from '../Schema';
import type { AMISSchemaCollection, AMISExpression, ListenerAction } from 'amis-core';
export declare const eventTypes: readonly ["inited", "onApiFetched", "onSchemaApiFetched", "onWsFetched"];
export type ProviderEventType = (typeof eventTypes)[number];
export type DataProviderCollection = Partial<Record<ProviderEventType, DataProvider>>;
export type DataProvider = string;
export type ComposedDataProvider = DataProvider | DataProviderCollection;
/**
 * 服务组件，用于数据获取和处理。支持 API 调用、数据转换、条件渲染等。
 */
export interface AMISServiceSchema extends BaseSchema, SpinnerExtraProps {
    type: 'service';
    /**
     * API 接口配置
     */
    api?: SchemaApi;
    /**
     * WebSocket 地址
     */
    ws?: string;
    /**
     * 数据提供者函数
     */
    dataProvider?: ComposedDataProvider;
    /**
     * 内容区域配置
     */
    body?: AMISSchemaCollection;
    /**
     * 数据拉取条件表达式
     * @deprecated 建议使用 api 的 sendOn 属性
     */
    fetchOn?: AMISExpression;
    /**
     * 是否在组件初始化时自动拉取数据
     */
    initFetch?: boolean;
    /**
     * 通过表达式控制是否在初始化时拉取数据
     * @deprecated 建议使用 api 的 sendOn 属性
     */
    initFetchOn?: AMISExpression;
    /**
     * 用于获取远程 Schema 的 API 配置
     */
    schemaApi?: SchemaApi;
    /**
     * 是否在组件初始化时自动加载 schemaApi
     */
    initFetchSchema?: boolean;
    /**
     * 通过表达式控制是否加载 schemaApi
     * @deprecated 建议使用 api 的 sendOn 属性
     */
    initFetchSchemaOn?: AMISExpression;
    /**
     * 轮询间隔时间（毫秒），设置为 0 时停止轮询
     */
    interval?: number;
    /**
     * 是否静默轮询，不显示加载状态
     */
    silentPolling?: boolean;
    /**
     * 停止自动刷新的条件表达式
     */
    stopAutoRefreshWhen?: AMISExpression;
    /**
     * 消息配置，用于显示成功或失败提示
     */
    messages?: SchemaMessage;
    /**
     * 组件名称，用于组件通信和数据绑定
     */
    name?: SchemaName;
    /**
     * 是否以 Alert 形式显示 API 接口响应的错误信息
     * @default true
     */
    showErrorMsg?: boolean;
}
export interface ServiceProps extends RendererProps, Omit<AMISServiceSchema, 'type' | 'className'> {
    store: IServiceStore;
    messages: SchemaMessage;
    testIdBuilder?: TestIdBuilder;
}
export default class Service extends React.Component<ServiceProps> {
    timer: ReturnType<typeof setTimeout>;
    mounted: boolean;
    socket: any;
    dataProviders: DataProviderCollection;
    dataProviderUnsubscribe?: Partial<Record<ProviderEventType, Function>>;
    static defaultProps: Partial<ServiceProps>;
    static propsList: Array<string>;
    constructor(props: ServiceProps);
    componentDidMount(): Promise<void>;
    componentDidUpdate(prevProps: ServiceProps): void;
    componentWillUnmount(): void;
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    initFetch(): void;
    /**
     * 初始化Provider函数集，将Schema配置统一转化为DataProviderCollection格式
     */
    initDataProviders(provider?: ComposedDataProvider): Partial<Record<"inited" | "onApiFetched" | "onSchemaApiFetched" | "onWsFetched", string>>;
    /**
     * 标准化处理Provider函数
     */
    normalizeProvider(provider: any, event?: ProviderEventType): DataProviderCollection | null;
    /**
     * 使用外部函数获取数据
     *
     * @param {ProviderEventType} event 触发provider函数执行的事件，默认初始时执行
     */
    runDataProvider(event: ProviderEventType): Promise<void>;
    /**
     * 运行销毁外部函数的方法
     *
     * @param {ProviderEventType} event 事件名称，不传参数即执行所有销毁函数
     */
    runDataProviderUnsubscribe(event?: ProviderEventType): void;
    dataProviderSetData(data: any): void;
    fetchWSData(ws: string | Api, data: any): void;
    afterDataFetch(result: any): void;
    afterSchemaFetch(schema: any): void;
    initInterval(value: any): any;
    reload(subpath?: string, query?: any, ctx?: RendererData, silent?: boolean, replace?: boolean): Promise<any>;
    silentReload(target?: string, query?: any): void;
    receive(values: object, subPath?: string, replace?: boolean): Promise<any>;
    handleQuery(query: any): any;
    reloadTarget(target: string, data?: any): void;
    handleDialogConfirm(values: object[], action: ActionObject, ctx: any, targets: Array<any>): void;
    handleDialogClose(confirmed?: boolean): void;
    openFeedback(dialog: any, ctx: any): Promise<unknown>;
    handleAction(e: React.UIEvent<any> | void, action: ActionObject, data: object, throwErrors?: boolean, delegate?: IScopedContext): any;
    handleChange(value: any, name: string, submit?: boolean, changePristine?: boolean): void;
    renderBody(): JSX.Element;
    render(): React.JSX.Element;
}
export declare class ServiceRenderer extends Service {
    static contextType: React.Context<IScopedContext>;
    constructor(props: ServiceProps, context: IScopedContext);
    reload(subpath?: string, query?: any, ctx?: any, silent?: boolean, replace?: boolean): Promise<any>;
    receive(values: any, subPath?: string, replace?: boolean): Promise<any>;
    componentWillUnmount(): void;
    reloadTarget(target: string, data?: any): void;
    setData(values: object, replace?: boolean): void;
    getData(): any;
}
