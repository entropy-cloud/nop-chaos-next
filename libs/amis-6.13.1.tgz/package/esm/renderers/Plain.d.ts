import React from 'react';
import { RendererProps } from 'amis-core';
import { SchemaTpl } from '../Schema';
import { AMISSchemaBase } from 'amis-core';
/**
 * Plain 纯文本渲染器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/plain
 */
/**
 * 纯文本组件，用于展示文本内容。支持模板渲染与样式控制。
 */
export interface AMISPlainSchema extends AMISSchemaBase {
    /**
     * 指定为 plain 组件
     */
    type: 'plain' | 'text';
    tpl?: SchemaTpl;
    text?: SchemaTpl;
    /**
     * 是否内联显示
     */
    inline?: boolean;
    /**
     * 占位符
     * @deprecated -
     */
    placeholder?: string;
}
export interface PlainProps extends RendererProps, Omit<AMISPlainSchema, 'type' | 'className'> {
    wrapperComponent?: any;
}
export declare class Plain extends React.Component<PlainProps, object> {
    static defaultProps: Partial<PlainProps>;
    handleClick(e: React.MouseEvent<HTMLDivElement>): void;
    handleMouseEnter(e: React.MouseEvent<any>): void;
    handleMouseLeave(e: React.MouseEvent<any>): void;
    render(): React.JSX.Element;
}
export declare class PlainRenderer extends Plain {
}
