import React from 'react';
import { AMISSchemaBase, RendererEnv, RendererProps, AMISSchemaCollection } from 'amis-core';
import { Api } from 'amis-core';
import { SchemaApi, SchemaTokenizeableString, SchemaTpl } from '../Schema';
import { Instance } from 'mobx-state-tree';
/**
 * Mapping 映射展示控件。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/mapping
 */
/**
 * 数据映射组件，用于将输入值映射成标签/文本展示。
 */
export interface AMISMappingSchema extends AMISSchemaBase {
    /**
     * 指定为 mapping 组件
     */
    type: 'map' | 'mapping';
    /**
     * 关联的字段名
     */
    name?: string;
    /**
     * 映射规则配置
     */
    map?: {
        [propName: string]: SchemaTpl;
    };
    /**
     * 当 map 或 source 为对象数组时，作为 value 值的字段名
     */
    valueField?: string;
    /**
     * 当 map 或 source 为对象数组时，作为 label 值的字段名
     */
    labelField?: string;
    /**
     * 自定义渲染映射值的 Schema 配置
     */
    itemSchema?: AMISSchemaCollection;
    /**
     * 远程数据源配置
     */
    source?: SchemaApi | SchemaTokenizeableString;
    /**
     * 占位符文本
     */
    placeholder?: string;
}
export declare const Store: import("mobx-state-tree").IModelType<{
    id: import("mobx-state-tree").ISimpleType<string>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    storeType: import("mobx-state-tree").ISimpleType<string>;
    disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
} & {
    fetching: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    errorMsg: import("mobx-state-tree").IType<string | undefined, string, string>;
    valueField: import("mobx-state-tree").IType<string | undefined, string, string>;
    map: import("mobx-state-tree").IType<{
        [propName: string]: any;
    } | null | undefined, {
        [propName: string]: any;
    }, {
        [propName: string]: any;
    }>;
}, {
    readonly parentStore: any;
    readonly __: any;
    readonly hasChildren: boolean;
    readonly children: Array<any>;
} & {
    onChildStoreDispose(child: any): void;
    syncProps(props: any, prevProps: any, list?: Array<string>): void;
    dispose: (callback?: () => void) => void;
    addChildId: (id: string) => void;
    removeChildId: (id: string) => void;
} & {
    load: (env: RendererEnv, api: Api, data: any) => Promise<any>;
    setMap(options: any): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IStore = Instance<typeof Store>;
export interface MappingProps extends Omit<RendererProps, 'store'>, Omit<AMISMappingSchema, 'type' | 'className'> {
    store: IStore;
    renderValue: (map: any, key: any) => String;
    renderViewValue: (value: any, key: any) => React.ReactNode;
}
export declare const MappingField: {
    new (props: Omit<MappingProps, "store">): {
        ref: any;
        store?: ({
            id: string;
            path: string;
            storeType: string;
            disposed: boolean;
            parentId: string;
            childrenIds: import("mobx-state-tree").IMSTArray<import("mobx-state-tree").ISimpleType<string>> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>>;
            fetching: boolean;
            errorMsg: string;
            valueField: string;
            map: {
                [propName: string]: any;
            } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IType<{
                [propName: string]: any;
            } | null | undefined, {
                [propName: string]: any;
            }, {
                [propName: string]: any;
            }>>;
        } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        } & {
            load: (env: RendererEnv, api: Api, data: any) => Promise<any>;
            setMap(options: any): void;
        } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
            id: import("mobx-state-tree").ISimpleType<string>;
            path: import("mobx-state-tree").IType<string | undefined, string, string>;
            storeType: import("mobx-state-tree").ISimpleType<string>;
            disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
            parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
            childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
        } & {
            fetching: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
            errorMsg: import("mobx-state-tree").IType<string | undefined, string, string>;
            valueField: import("mobx-state-tree").IType<string | undefined, string, string>;
            map: import("mobx-state-tree").IType<{
                [propName: string]: any;
            } | null | undefined, {
                [propName: string]: any;
            }, {
                [propName: string]: any;
            }>;
        }, {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        } & {
            load: (env: RendererEnv, api: Api, data: any) => Promise<any>;
            setMap(options: any): void;
        }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>) | undefined;
        refFn: (ref: any) => void;
        componentWillUnmount(): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<MappingProps, "store">>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<MappingProps, "store">>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<MappingProps, "store">>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<MappingProps, "store">>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<MappingProps, "store">>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<MappingProps, "store">>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<MappingProps, "store">>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<MappingProps, "store">>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<MappingProps, "store">>, nextState: Readonly<{}>, nextContext: any): void;
    };
    new (props: Omit<MappingProps, "store">, context: any): {
        ref: any;
        store?: ({
            id: string;
            path: string;
            storeType: string;
            disposed: boolean;
            parentId: string;
            childrenIds: import("mobx-state-tree").IMSTArray<import("mobx-state-tree").ISimpleType<string>> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>>;
            fetching: boolean;
            errorMsg: string;
            valueField: string;
            map: {
                [propName: string]: any;
            } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IType<{
                [propName: string]: any;
            } | null | undefined, {
                [propName: string]: any;
            }, {
                [propName: string]: any;
            }>>;
        } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        } & {
            load: (env: RendererEnv, api: Api, data: any) => Promise<any>;
            setMap(options: any): void;
        } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
            id: import("mobx-state-tree").ISimpleType<string>;
            path: import("mobx-state-tree").IType<string | undefined, string, string>;
            storeType: import("mobx-state-tree").ISimpleType<string>;
            disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
            parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
            childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
        } & {
            fetching: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
            errorMsg: import("mobx-state-tree").IType<string | undefined, string, string>;
            valueField: import("mobx-state-tree").IType<string | undefined, string, string>;
            map: import("mobx-state-tree").IType<{
                [propName: string]: any;
            } | null | undefined, {
                [propName: string]: any;
            }, {
                [propName: string]: any;
            }>;
        }, {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        } & {
            load: (env: RendererEnv, api: Api, data: any) => Promise<any>;
            setMap(options: any): void;
        }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>) | undefined;
        refFn: (ref: any) => void;
        componentWillUnmount(): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K_1 extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<MappingProps, "store">>) => {} | Pick<{}, K_1> | null) | Pick<{}, K_1> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<MappingProps, "store">>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<MappingProps, "store">>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<MappingProps, "store">>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<MappingProps, "store">>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<MappingProps, "store">>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<MappingProps, "store">>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<MappingProps, "store">>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<MappingProps, "store">>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    ComposedComponent: React.ComponentType<{
        new (props: MappingProps): {
            componentDidMount(): void;
            componentDidUpdate(prevProps: MappingProps): void;
            reload(): void;
            renderSingleValue(key: any, reactKey?: number, needStyle?: boolean): React.JSX.Element;
            renderViewValue(value: any, key: any): any;
            renderValue(map: any, key: any): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: object | ((prevState: object, props: Readonly<MappingProps>) => object | Pick<object, K> | null) | Pick<object, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<MappingProps>;
            state: object;
            shouldComponentUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<MappingProps>, prevState: object): any;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<MappingProps>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<MappingProps>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): void;
        };
        defaultProps: Partial<MappingProps>;
        contextType?: React.Context<any> | undefined;
        propTypes?: any;
    }>;
    contextType?: React.Context<any> | undefined;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: MappingProps): {
        componentDidMount(): void;
        componentDidUpdate(prevProps: MappingProps): void;
        reload(): void;
        renderSingleValue(key: any, reactKey?: number, needStyle?: boolean): React.JSX.Element;
        renderViewValue(value: any, key: any): any;
        renderValue(map: any, key: any): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: object | ((prevState: object, props: Readonly<MappingProps>) => object | Pick<object, K> | null) | Pick<object, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<MappingProps>;
        state: object;
        shouldComponentUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<MappingProps>, prevState: object): any;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<MappingProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<MappingProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): void;
    };
    defaultProps: Partial<MappingProps>;
    contextType?: React.Context<any> | undefined;
    propTypes?: any;
}, {}> & {
    ComposedComponent: {
        new (props: MappingProps): {
            componentDidMount(): void;
            componentDidUpdate(prevProps: MappingProps): void;
            reload(): void;
            renderSingleValue(key: any, reactKey?: number, needStyle?: boolean): React.JSX.Element;
            renderViewValue(value: any, key: any): any;
            renderValue(map: any, key: any): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: object | ((prevState: object, props: Readonly<MappingProps>) => object | Pick<object, K> | null) | Pick<object, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<MappingProps>;
            state: object;
            shouldComponentUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<MappingProps>, prevState: object): any;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<MappingProps>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<MappingProps>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<MappingProps>, nextState: object, nextContext: any): void;
        };
        defaultProps: Partial<MappingProps>;
        contextType?: React.Context<any> | undefined;
        propTypes?: any;
    };
};
export declare class MappingFieldRenderer extends React.Component<RendererProps> {
    render(): React.JSX.Element;
}
