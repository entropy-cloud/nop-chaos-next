import React from 'react';
import { RendererProps, AMISSchemaCollection, AMISSchemaBase } from 'amis-core';
import { SchemaObject } from '../Schema';
/**
 * CollapseGroup 折叠渲染器，格式说明。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/collapse
 */
/**
 * 折叠面板组组件，用于管理多个折叠面板。支持手风琴模式。
 */
export interface AMISCollapseGroupSchema extends AMISSchemaBase {
    /**
     * 指定为 collapse-group 组件
     */
    type: 'collapse-group';
    /**
     * 激活面板
     */
    activeKey?: Array<string | number | never> | string | number;
    /**
     * 手风琴模式
     */
    accordion?: boolean;
    /**
     * 自定义切换图标
     */
    expandIcon?: SchemaObject;
    /**
     * 设置图标位置
     */
    expandIconPosition?: 'left' | 'right';
    /**
     * 内容区域
     */
    body?: AMISSchemaCollection;
    /**
     * 当Collapse作为Form组件的子元素时，开启该属性后组件样式设置为FieldSet组件的样式
     */
    enableFieldSetStyle?: boolean;
}
export interface CollapseGroupProps extends RendererProps, Omit<AMISCollapseGroupSchema, 'type' | 'className'> {
    children?: JSX.Element | ((props?: any) => JSX.Element);
}
export type CollapseGroupRenderEvent = 'collapseChange';
export declare class CollapseGroupRender extends React.Component<CollapseGroupProps, {}> {
    static defaultProps: {
        enableFieldSetStyle: boolean;
    };
    constructor(props: CollapseGroupProps);
    handleCollapseChange(activeKeys: Array<string | number>, collapseId: string | number, collapsed: boolean): Promise<void>;
    render(): React.JSX.Element;
}
export declare class CollapseGroupRenderer extends CollapseGroupRender {
}
