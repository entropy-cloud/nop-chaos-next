/**
 * @file video
 * @author fex
 */
import React from 'react';
import { RendererProps } from 'amis-core';
import { AMISClassName, SchemaUrlPath } from '../Schema';
import { AMISSchemaBase } from 'amis-core';
/**
 * 视频播放器组件，用于播放视频内容。支持封面、自动播放、倍速、弹幕等配置。
 */
export interface AMISVideoSchema extends AMISSchemaBase {
    /**
     * 指定为 video 组件
     */
    type: 'video';
    /**
     * 是否自动播放视频
     */
    autoPlay?: boolean;
    /**
     * 切帧显示时每行显示的帧数
     */
    columnsCount?: number;
    /**
     * 切帧配置
     */
    frames?: {
        [propName: string]: string;
    };
    /**
     * 帧列表容器CSS类名
     */
    framesClassName?: AMISClassName;
    /**
     * 自定义样式
     */
    style?: {
        [propName: string]: any;
    };
    /**
     * 是否为实时视频流
     */
    isLive?: boolean;
    /**
     * 点击帧画面时是否跳转到视频对应时间点
     * @default true
     */
    jumpFrame?: boolean;
    /**
     * 是否初始静音
     */
    muted?: boolean;
    /**
     * 是否循环播放
     */
    loop?: boolean;
    /**
     * 播放器容器CSS类名
     */
    playerClassName?: AMISClassName;
    /**
     * 视频封面图片地址
     */
    poster?: SchemaUrlPath;
    /**
     * 是否将视频和封面分开显示
     */
    splitPoster?: boolean;
    /**
     * 视频播放地址
     */
    src?: SchemaUrlPath;
    /**
     * 视频类型如： video/x-flv
     */
    videoType?: string;
    /**
     * 视频比率
     */
    aspectRatio?: 'auto' | '4:3' | '16:9';
    /**
     * 视频速率
     */
    rates?: Array<number>;
    /**
     * 跳转到帧时，往前多少秒。
     */
    jumpBufferDuration?: number;
    /**
     * 默认播放的时候到了下一帧会继续播放，同时高亮下一帧。
     * 如果配置这个则会停止播放，等待用户选择新的区间再播放。
     */
    stopOnNextFrame?: boolean;
}
export interface FlvSourceProps {
    src?: string;
    type?: string;
    video?: any;
    config?: object;
    manager?: any;
    isLive?: boolean;
    autoPlay?: boolean;
    actions?: any;
    order?: number;
    setError: (error: string) => void;
}
export declare class FlvSource extends React.Component<FlvSourceProps, any> {
    mpegtsPlayer: any;
    loaded: boolean;
    timer: any;
    unsubscribe: any;
    componentDidMount(): void;
    componentDidUpdate(prevProps: FlvSourceProps): void;
    componentWillUnmount(): void;
    initFlv({ video, manager, src, isLive, config, actions, setError, autoPlay }: any): void;
    render(): React.JSX.Element;
}
export interface HlsSourceProps {
    src?: string;
    type?: string;
    video?: any;
    config?: object;
    manager?: any;
    isLive?: boolean;
    autoPlay?: boolean;
    actions?: any;
    order?: number;
}
export declare class HlsSource extends React.Component<HlsSourceProps, any> {
    hls: any;
    loaded: boolean;
    unsubscribe: any;
    componentDidMount(): void;
    componentWillUnmount(): void;
    componentDidUpdate(prevProps: HlsSourceProps): void;
    initHls({ video, manager, src, autoPlay, actions }: any): void;
    render(): React.JSX.Element;
}
export interface VideoProps extends RendererProps, Omit<AMISVideoSchema, 'className'> {
    columnsCount: number;
}
export interface VideoState {
    posterInfo?: any;
    videoState?: any;
    error?: string;
}
export default class Video extends React.Component<VideoProps, VideoState> {
    static defaultProps: {
        columnsCount: number;
        isLive: boolean;
        jumpFrame: boolean;
        aspectRatio: string;
    };
    frameDom: any;
    cursorDom: any;
    player: any;
    times: Array<number>;
    currentIndex: number;
    manualJump: boolean;
    constructor(props: VideoProps);
    handleVideoPlay(currentTime: Array<string | number>, duration: string | number, src: string): Promise<void>;
    handleVideoPause(currentTime: Array<string | number>, duration: string | number, src: string): Promise<void>;
    handleVideoEnded(duration: string | number): Promise<void>;
    onImageLoaded(e: Event): void;
    frameRef(dom: any): void;
    cursorRef(dom: any): void;
    playerRef(player: any): void;
    moveCursorToIndex(index: number): void;
    jumpToIndex(index: number): void;
    onClick(e: Event): void;
    setError(error?: string): void;
    renderFrames(): React.JSX.Element | null;
    renderPlayer(): React.JSX.Element;
    renderPosterAndPlayer(): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class VideoRenderer extends Video {
}
