import React from 'react';
import { AMISSchemaBase } from 'amis-core';
import { FormControlProps } from 'amis-core';
/**
 * 自定义组件
 */
/**
 * 自定义组件，占位用于扩展自渲染逻辑。支持传入自定义渲染器。
 */
export interface AMISCustomSchema extends AMISSchemaBase {
    /**
     * 指定为 custom 组件
     */
    type: 'custom';
    /**
     * 组件挂载时的回调函数
     */
    onMount?: Function | string;
    /**
     * 组件更新时的回调函数
     */
    onUpdate?: Function | string;
    /**
     * 组件卸载时的回调函数
     */
    onUnmount?: Function | string;
    /**
     * 是否内联渲染
     */
    inline?: boolean;
    /**
     * 组件唯一标识符
     */
    id?: string;
    /**
     * HTML 字符串
     */
    html?: string;
}
export interface CustomProps extends FormControlProps, AMISCustomSchema {
    className?: string;
    value?: any;
    wrapperComponent?: any;
    inline?: boolean;
}
export declare class Custom extends React.Component<CustomProps, object> {
    static defaultProps: Partial<CustomProps>;
    dom: any;
    onUpdate: Function;
    onMount: Function;
    onUnmount: Function;
    childElemArr: HTMLElement[];
    childElemContainerSet: Set<HTMLElement>;
    constructor(props: CustomProps);
    initOnMount(props: CustomProps): void;
    initOnUpdate(props: CustomProps): void;
    initOnUnmount(props: CustomProps): void;
    componentDidUpdate(prevProps: CustomProps): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    recordChildElem(insertElem: HTMLElement): void;
    unmountChildElem(): void;
    /**
     * 渲染子元素
     * 备注：现有custom组件通过props.render生成的子元素是react虚拟dom对象，需要使用ReactDOM.render渲染，不能直接插入到当前dom中。
     **/
    renderChild(schemaPosition: string, childSchema: any, insertElemDom: HTMLElement | string): JSX.Element | null;
    render(): React.JSX.Element;
}
export declare class CustomRenderer extends Custom {
}
