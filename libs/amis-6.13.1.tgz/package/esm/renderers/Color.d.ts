/**
 * @file 用来展示颜色块。
 */
import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
/**
 * Color 显示渲染器，格式说明。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/color
 */
/**
 * 颜色展示组件，用于显示颜色块或文本。支持取色器触发。
 */
export interface AMISColorSchema extends AMISSchemaBase {
    /**
     * 指定为 color 组件
     */
    type: 'color';
    /**
     * 默认颜色
     */
    defaultColor?: string;
    /**
     * 是否用文字显示值
     */
    showValue?: boolean;
}
export interface ColorProps extends RendererProps, Omit<AMISColorSchema, 'type' | 'className'> {
}
export declare class ColorField extends React.Component<ColorProps, object> {
    static defaultProps: {
        className: string;
        defaultColor: string;
        showValue: boolean;
    };
    render(): React.JSX.Element;
}
export declare class ColorFieldRenderer extends ColorField {
}
