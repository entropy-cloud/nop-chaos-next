/**
 * @file 用来条形码
 */
import React from 'react';
import { RendererProps } from 'amis-core';
import { AMISSchemaBase } from 'amis-core';
/**
 * BarCode 显示渲染器，格式说明。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/barcode
 */
/**
 * 条形码组件，用于生成和显示条形码。支持内容、格式与尺寸。
 */
export interface AMISBarCodeSchema extends AMISSchemaBase {
    /**
     * 指定为 barcode 组件
     */
    type: 'barcode';
    /**
     * 宽度
     */
    width?: number;
    /**
     * 高度
     */
    height?: number;
    /**
     * 显示配置
     */
    options: object;
}
export interface BarCodeProps extends RendererProps, Omit<AMISBarCodeSchema, 'type' | 'className'> {
}
export declare class BarCodeField extends React.Component<BarCodeProps, object> {
    render(): React.JSX.Element;
}
export declare class BarCodeFieldRenderer extends BarCodeField {
}
