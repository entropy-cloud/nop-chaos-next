import React from 'react';
import { AMISSchema, AMISSchemaBase, RendererProps } from 'amis-core';
import { SchemaObject } from '../Schema';
export type HboxRow = SchemaObject & {
    rowClassName?: string;
    cellClassName?: string;
};
/**
 * 垂直布局控件
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/vbox
 */
/**
 * 垂直布局组件，用于纵向排列子元素。支持区块间距与对齐配置。
 */
export interface AMISVBoxSchema extends AMISSchemaBase {
    type: 'vbox';
    /**
     * 行集合
     */
    rows?: Array<HboxRow>;
}
export interface HBoxProps extends RendererProps, Omit<AMISVBoxSchema, 'className'> {
}
export default class VBox extends React.Component<HBoxProps, object> {
    static propsList: Array<string>;
    static defaultProps: Partial<HBoxProps>;
    renderChild(region: string, node: AMISSchema): JSX.Element;
    renderCell(row: HboxRow, key: any): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class VBoxRenderer extends VBox {
}
