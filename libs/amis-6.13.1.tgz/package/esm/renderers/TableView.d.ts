/**
 * @file 用于表格类型的展现效果，界面可定制化能力更强
 */
import React from 'react';
import { RendererProps, AMISSchemaBase } from 'amis-core';
import { SchemaObject } from '../Schema';
export type TdObject = {
    /**
     * 单元格背景色
     */
    background?: string;
    /**
     * 单元格文字颜色
     */
    color?: string;
    /**
     * 单元格文字是否加粗
     */
    bold?: boolean;
    /**
     * 单元格的内边距
     */
    padding?: number;
    /**
     * 单元格宽度
     */
    width?: number;
    /**
     * 单元格内的组件配置
     */
    body?: SchemaObject;
    /**
     * 水平对齐方式
     */
    align?: 'left' | 'center' | 'right' | 'justify';
    /**
     * 垂直对齐方式
     */
    valign?: 'top' | 'middle' | 'bottom' | 'baseline';
    /**
     * 跨行数
     */
    colspan?: number;
    /**
     * 跨列数
     */
    rowspan?: number;
    /**
     * 自定义样式配置
     */
    style?: object;
    /**
     * 控制单元格是否显示的表达式
     */
    visibleOn?: string;
    /**
     * 控制单元格是否隐藏的表达式
     */
    hiddenOn?: string;
};
/**
 * 行设置
 */
export type TrObject = {
    /**
     * 行背景色
     */
    background?: string;
    /**
     * 行高度
     */
    height?: number;
    /**
     * 单元格配置
     */
    tds: TdObject[];
    style?: object;
    visibleOn?: string;
    hiddenOn?: string;
};
/**
 * 列设置
 */
export type ColObject = {
    span?: number;
    style?: Object;
};
/**
 * 表格展现渲染器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/table-view
 */
/**
 * 表格视图组件，用于简化展示表格数据的只读视图。
 */
export interface AMISTableViewSchema extends AMISSchemaBase {
    /**
     * 指定为 table-view 展示类型
     */
    type: 'table-view';
    /**
     * table 容器宽度，默认为 auto
     */
    width?: number | string;
    /**
     *  默认单元格内边距
     */
    padding?: number | string;
    /**
     * 是否显示边框
     */
    border?: boolean;
    /**
     * 边框颜色
     */
    borderColor?: string;
    /**
     * 标题设置
     */
    caption?: string;
    /**
     * 标题位置
     */
    captionSide?: 'top' | 'bottom';
    /**
     * 行设置
     */
    trs: TrObject[];
    /**
     * 列设置
     */
    cols: ColObject[];
}
export interface TableViewProps extends RendererProps, Omit<AMISTableViewSchema, 'type' | 'className'> {
}
export default class TableView extends React.Component<TableViewProps, object> {
    static defaultProps: Partial<TableViewProps>;
    constructor(props: TableViewProps);
    renderTd(td: TdObject, colIndex: number, rowIndex: number): React.JSX.Element | null;
    renderTdBody(body?: SchemaObject): JSX.Element;
    renderTds(tds: TdObject[], rowIndex: number): (React.JSX.Element | null)[];
    renderTr(tr: TrObject, rowIndex: number): React.JSX.Element | null;
    renderTrs(trs: TrObject[]): (React.JSX.Element | null)[];
    renderCols(): React.JSX.Element | null;
    renderCaption(): React.JSX.Element | null;
    render(): React.JSX.Element;
}
export declare class TableViewRenderer extends TableView {
}
