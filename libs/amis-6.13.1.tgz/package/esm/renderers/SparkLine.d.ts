import { RendererProps, AMISSchemaBase } from 'amis-core';
import React from 'react';
import { AMISClassName } from '../Schema';
import { ActionSchema } from './Action';
/**
 * 迷你图组件，用于紧凑展示趋势数据。支持折线、柱状等类型。
 */
export interface AMISSparkLineSchema extends AMISSchemaBase {
    type: 'sparkline';
    /**
     * CSS 类名
     */
    className?: AMISClassName;
    /**
     * 关联数据变量
     */
    name?: string;
    /**
     * 宽度
     */
    width?: number;
    /**
     * 高度
     */
    height?: number;
    /**
     * 点击行为
     */
    clickAction?: ActionSchema;
    /**
     * 空数据时显示的内容
     */
    placeholder?: string;
    value?: Array<number | {
        value: number;
        label?: string;
    }>;
}
interface SparkLineRendProps extends RendererProps, Omit<AMISSparkLineSchema, 'type' | 'className'> {
}
export declare class SparkLineRenderer extends React.Component<SparkLineRendProps> {
    handleClick(e: React.MouseEvent, ctx: any): void;
    render(): React.JSX.Element;
}
export {};
