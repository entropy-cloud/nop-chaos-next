import React from 'react';
import { AMISSchemaBase, RendererProps, AMISSchemaCollection, AMISButtonSchema } from 'amis-core';
import { AMISClassName, SchemaIcon } from '../Schema';
import { AMISDividerSchema } from './Divider';
import type { TooltipObject, Trigger } from 'amis-ui/lib/components/TooltipWrapper';
export type DropdownNestedButton = AMISButtonSchema & {
    children?: Array<DropdownButton>;
};
export type DropdownButton = DropdownNestedButton | AMISDividerSchema | 'divider';
/**
 * 下拉按钮渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/dropdown-button
 */
/**
 * 下拉按钮组件，结合按钮与下拉菜单。支持分组操作与权限控制。
 */
export interface AMISDropdownButtonSchema extends AMISSchemaBase {
    /**
     * 指定为 dropdown-button 组件
     */
    type: 'dropdown-button';
    /**
     * 是否独占一行
     */
    block?: boolean;
    /**
     * 给 Button 配置 className
     */
    btnClassName?: AMISClassName;
    /**
     * 按钮集合，支持分组
     */
    buttons?: Array<DropdownButton>;
    /**
     * 内容区域
     */
    body?: AMISSchemaCollection;
    /**
     * 按钮文字
     */
    label?: string;
    /**
     * 按钮级别，样式
     */
    level?: 'info' | 'success' | 'danger' | 'warning' | 'primary' | 'link';
    /**
     * 按钮提示文字，hover 时显示
     */
    /**
     * 点击外部是否关闭
     */
    closeOnOutside?: boolean;
    /**
     * 点击内容是否关闭
     */
    closeOnClick?: boolean;
    /**
     * 按钮大小
     */
    size?: 'xs' | 'sm' | 'md' | 'lg';
    /**
     * 对齐方式
     */
    align?: 'left' | 'right';
    /**
     * 是否只显示图标
     */
    iconOnly?: boolean;
    /**
     * 右侧图标
     */
    rightIcon?: SchemaIcon;
    /**
     * 触发条件，默认为 click
     */
    trigger?: 'click' | 'hover';
    /**
     * 是否显示下拉按钮
     */
    hideCaret?: boolean;
    /**
     * 弹出的下拉按钮放在哪个节点下
     */
    popOverContainerSelector?: string;
    /**
     * 菜单 CSS 样式
     */
    menuClassName?: string;
    overlayPlacement?: string;
}
export interface DropDownButtonProps extends RendererProps, Omit<AMISDropdownButtonSchema, 'type' | 'className'> {
    disabledTip?: string | TooltipObject;
    /**
     * 按钮提示文字，hover focus 时显示
     */
    tooltip?: string | TooltipObject;
    placement?: 'top' | 'right' | 'bottom' | 'left';
    tooltipContainer?: any;
    tooltipTrigger?: Trigger | Array<Trigger>;
    tooltipRootClose?: boolean;
    defaultIsOpened?: boolean;
    label?: any;
    isActived?: boolean;
    menuClassName?: string;
}
export interface DropDownButtonState {
    isOpened: boolean;
}
export default class DropDownButton extends React.Component<DropDownButtonProps, DropDownButtonState> {
    state: DropDownButtonState;
    static defaultProps: Pick<DropDownButtonProps, 'placement' | 'tooltipTrigger' | 'tooltipRootClose' | 'overlayPlacement'>;
    target: any;
    timer: ReturnType<typeof setTimeout>;
    constructor(props: DropDownButtonProps);
    componentDidMount(): void;
    domRef(ref: any): void;
    toogle(e: React.MouseEvent<any>): void;
    open(): Promise<void>;
    close(e?: React.MouseEvent<any>): void;
    keepOpen(): void;
    renderButton(button: DropdownButton, index: number | string): React.ReactNode;
    renderOuter(): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class DropDownButtonRenderer extends DropDownButton {
}
