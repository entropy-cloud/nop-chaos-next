/**
 * @file 表格的方式显示只读信息，比如产品详情
 */
import React from 'react';
import { RendererProps } from 'amis-core';
import { SchemaObject, SchemaTpl } from '../Schema';
import { AMISExpression } from 'amis-core';
import { AMISSchemaBase } from 'amis-core';
export type PropertyItemProps = {
    /**
     * 属性名称标签
     */
    label?: SchemaTpl;
    /**
     * 属性值内容
     */
    content?: SchemaTpl;
    /**
     * 控制属性项是否显示的表达式
     */
    visibleOn?: AMISExpression;
    /**
     * 控制属性项是否隐藏的表达式
     */
    hiddenOn?: AMISExpression;
    /**
     * 跨列数
     */
    span?: number;
};
export type PropertyItem = PropertyItemProps & SchemaObject;
/**
 * Property 属性列表
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/property
 */
/**
 * 属性列表组件，用于展示键值对信息。支持分组、搜索与复制。
 */
export interface AMISPropertySchema extends AMISSchemaBase {
    /**
     * 指定为 property 组件
     */
    type: 'property';
    /**
     * 属性列表标题
     */
    title?: string;
    /**
     * 每行显示的列数
     */
    column?: number;
    /**
     * 显示模式
     */
    mode?: 'table' | 'simple';
    /**
     * 属性项配置数组
     */
    items: Array<PropertyItem>;
    /**
     * 自定义容器样式
     */
    style?: {
        [propName: string]: any;
    };
    /**
     * 标题样式配置
     */
    titleStyle?: {
        [propName: string]: any;
    };
    /**
     * 属性名称标签样式配置
     */
    labelStyle?: {
        [propName: string]: any;
    };
    /**
     * 属性名称和值之间的分隔符
     */
    separator?: string;
    /**
     * 属性值内容样式配置
     */
    contentStyle?: {
        [propName: string]: any;
    };
}
export interface PropertyProps extends RendererProps, Omit<AMISPropertySchema, 'type' | 'className'> {
}
interface PropertyContent {
    label: any;
    content: any;
    span: number;
}
export default class Property extends React.Component<PropertyProps, object> {
    constructor(props: PropertyProps);
    /**
     * 算好每行的分布情况，方便后续渲染
     */
    prepareRows(): PropertyContent[][];
    renderRow(rows: PropertyContent[][]): React.JSX.Element[];
    render(): React.JSX.Element;
}
export declare class PropertyRenderer extends Property {
}
export {};
