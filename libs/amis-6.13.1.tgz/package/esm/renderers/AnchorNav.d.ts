import React from 'react';
import { RendererProps } from 'amis-core';
import { AMISSchemaCollection, AMISSchemaBase } from 'amis-core';
import { AMISClassName } from '../Schema';
/**
 * AnchorNavSection 锚点区域渲染器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/anchor-nav
 */
export interface AnchorNavSectionSchema extends AMISSchemaBase {
    /**
     * 导航文字说明
     */
    title: string;
    /**
     * 锚点链接
     */
    href?: string;
    /**
     * 内容
     */
    body?: AMISSchemaCollection;
    /**
     * 子节点
     */
    children?: Array<AnchorNavSectionSchema>;
}
/**
 * 锚点导航组件，用于页面内导航跳转。支持吸顶、自动高亮对应区域。
 */
export interface AMISAnchorNavSchema extends AMISSchemaBase {
    /**
     * 指定为 anchor-nav 组件
     */
    type: 'anchor-nav';
    /**
     * 楼层集合
     */
    links: Array<AnchorNavSectionSchema>;
    /**
     * 被激活（定位）的楼层
     */
    active?: string | number;
    /**
     * 样式名
     */
    className?: AMISClassName;
    /**
     * 导航样式名
     */
    linkClassName?: AMISClassName;
    /**
     * 楼层样式名
     */
    sectionClassName?: AMISClassName;
    direction?: 'vertical' | 'horizontal';
}
export interface AnchorNavProps extends RendererProps, Omit<AMISAnchorNavSchema, 'className' | 'linkClassName' | 'sectionClassName'> {
    active?: string | number;
    sectionRender?: (section: AnchorNavSectionSchema, props: AnchorNavProps, index: number | string) => JSX.Element;
}
export interface AnchorNavState {
    active: any;
}
export default class AnchorNav extends React.Component<AnchorNavProps, AnchorNavState> {
    static defaultProps: Partial<AnchorNavProps>;
    renderSection?: (section: AnchorNavSectionSchema, props: AnchorNavProps, index: number | string) => JSX.Element;
    constructor(props: AnchorNavProps);
    getActiveSection(links: Array<AnchorNavSectionSchema>, active: string | number | undefined, section: AnchorNavSectionSchema | null): AnchorNavSectionSchema | null;
    handleSelect(key: any): void;
    locateTo(index: number): void;
    renderSections(links: AnchorNavSectionSchema[], parentIdx?: string | number): JSX.Element[];
    render(): React.JSX.Element | null;
}
export declare class AnchorNavRenderer extends AnchorNav {
}
