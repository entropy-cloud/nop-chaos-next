import React from 'react';
import { IScopedContext, RendererEvent, AMISButtonSchema } from 'amis-core';
import { RendererProps } from 'amis-core';
import { ActionObject } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { IModalStore } from 'amis-core';
import { AMISDrawerSchemaBase, AMISSchemaCollection } from 'amis-core';
/**
 * 抽屉组件，用于侧边弹窗展示内容。支持从左右两侧滑出、自定义内容等。
 */
export interface AMISDrawerSchema extends AMISDrawerSchemaBase {
    /**
     * 指定为 drawer 组件
     */
    type: 'drawer';
}
export type DrawerSchema = AMISDrawerSchema;
export interface DrawerProps extends RendererProps, Omit<AMISDrawerSchema, 'className' | 'data'>, SpinnerExtraProps {
    onClose: () => void;
    onConfirm: (values: Array<object>, action: ActionObject, ctx: object, targets: Array<any>) => void;
    children?: React.ReactNode | ((props?: any) => React.ReactNode);
    wrapperComponent: React.ElementType;
    lazySchema?: (props: DrawerProps) => AMISSchemaCollection;
    store: IModalStore;
    show?: boolean;
    drawerContainer?: () => HTMLElement;
}
export interface DrawerState {
    entered: boolean;
    resizeCoord: number;
    [propName: string]: any;
}
export default class Drawer extends React.Component<DrawerProps> {
    static propsList: Array<string>;
    static defaultProps: Partial<DrawerProps>;
    reaction: any;
    $$id: string;
    drawer: any;
    clearErrorTimer: ReturnType<typeof setTimeout> | undefined;
    constructor(props: DrawerProps);
    componentWillUnmount(): void;
    buildActions(): Array<AMISButtonSchema>;
    handleSelfClose(): Promise<void>;
    handleActionSensor(p: Promise<any>): void;
    handleAction(e: React.UIEvent<any>, action: ActionObject, data: object): void;
    handleDrawerConfirm(values: object[], action: ActionObject, ...args: Array<any>): void;
    handleDrawerClose(...args: Array<any>): void;
    handleDialogConfirm(values: object[], action: ActionObject, ...args: Array<any>): void;
    handleDialogClose(...args: Array<any>): void;
    handleChildFinished(value: any, action: ActionObject): void;
    handleFormInit(data: any): void;
    handleFormChange(data: any, name?: string): void;
    handleFormSaved(data: any, response: any): void;
    handleEntered(): void;
    handleExited(): void;
    getPopOverContainer(): Element | null;
    renderBody(body: AMISSchemaCollection, key?: any): React.ReactNode;
    renderFooter(): React.JSX.Element | null;
    openFeedback(dialog: any, ctx: any): Promise<unknown>;
    render(): React.JSX.Element;
}
export declare class DrawerRenderer extends Drawer {
    static contextType: React.Context<IScopedContext>;
    constructor(props: DrawerProps, context: IScopedContext);
    componentWillUnmount(): void;
    tryChildrenToHandle(action: ActionObject, ctx: object, rawAction?: ActionObject): boolean;
    doAction(action: ActionObject, data: object, throwErrors: boolean): any;
    handleAction(e: React.UIEvent<any> | void, action: ActionObject, data: object, throwErrors?: boolean, delegate?: IScopedContext, rendererEvent?: RendererEvent<any>): Promise<any>;
    handleChildFinished(value: any, action: ActionObject): void;
    handleDialogConfirm(values: object[], action: ActionObject, ...rest: Array<any>): void;
    handleDrawerConfirm(values: object[], action: ActionObject, ...rest: Array<any>): void;
    reloadTarget(target: string, data?: any): void;
    closeTarget(target: string): void;
    setData(values: object, replace?: boolean): void;
    getData(): any;
}
