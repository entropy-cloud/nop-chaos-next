import React from 'react';
import { AMISSchemaBase, RendererProps, AMISSchemaCollection, AMISButtonSchema } from 'amis-core';
import { AMISClassName, SchemaTpl } from '../Schema';
import { FormHorizontal } from 'amis-core';
/**
 * Panel渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/panel
 */
/**
 * 面板组件，用于分组展示内容区域。支持头部、工具栏与脚部。
 */
export interface AMISPanelSchema extends AMISSchemaBase {
    /**
     * 指定为 panel 组件
     */
    type: 'panel';
    /**
     * 按钮集合
     */
    actions?: Array<AMISButtonSchema>;
    /**
     * 按钮集合外层类名
     */
    actionsClassName?: AMISClassName;
    /**
     * 内容区域
     */
    body?: AMISSchemaCollection;
    /**
     * 配置 Body 容器 className
     */
    bodyClassName?: AMISClassName;
    /**
     * 底部内容区域
     */
    footer?: AMISSchemaCollection;
    /**
     * 配置 footer 容器 className
     */
    footerClassName?: AMISClassName;
    /**
     * footer 和 actions 外层 div 类名
     */
    footerWrapClassName?: AMISClassName;
    /**
     * 头部内容, 和 title 二选一
     */
    header?: AMISSchemaCollection;
    /**
     * 配置 header 容器 className
     */
    headerClassName?: AMISClassName;
    /**
     * Panel 标题
     */
    title?: SchemaTpl;
    /**
     * 固定底部, 想要把按钮固定在底部的时候配置
     */
    affixFooter?: boolean | 'always';
    /**\
     * 可折叠。先简单实现一下
     */
    collapsible?: boolean;
    /**
     * 配置子表单项默认的展示方式
     */
    subFormMode?: 'normal' | 'inline' | 'horizontal';
    /**
     * 如果是水平排版，这个属性可以细化水平排版的左右宽度占比
     */
    subFormHorizontal?: FormHorizontal;
    /**
     * 外观配置的classname
     */
    headerControlClassName?: string;
    bodyControlClassName?: string;
    actionsControlClassName?: string;
}
export interface PanelProps extends RendererProps, Omit<AMISPanelSchema, 'type' | 'className' | 'panelClassName' | 'bodyClassName'> {
}
export default class Panel<T extends PanelProps = PanelProps> extends React.Component<T> {
    static propsList: Array<string>;
    static defaultProps: {};
    state: {
        collapsed: boolean;
    };
    constructor(props: T);
    renderBody(): JSX.Element | null;
    renderActions(): JSX.Element[] | null;
    render(): React.JSX.Element;
}
export declare class PanelRenderer extends Panel {
}
