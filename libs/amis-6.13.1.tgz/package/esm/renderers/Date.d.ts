import React from 'react';
import { RendererProps } from 'amis-core';
import 'moment-timezone';
import { AMISSchemaBase } from 'amis-core';
/**
 * Date 展示渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/date
 */
/**
 * 日期展示组件，用于格式化显示日期/时间。支持多格式与相对时间。
 */
export interface AMISDateSchema extends AMISSchemaBase {
    /**
     * 指定为 date 组件
     */
    type: 'date' | 'datetime' | 'time' | 'static-date' | 'static-datetime' | 'static-time';
    /**
     * 展示的时间格式
     */
    format?: string;
    /**
     * 展示的时间格式（新：同format）
     */
    displayFormat?: string;
    /**
     * 占位符
     */
    placeholder?: string;
    /**
     * 值的时间格式
     */
    valueFormat?: string;
    /**
     * 显示成相对时间
     */
    fromNow?: boolean;
    /**
     * 更新频率
     */
    updateFrequency?: number;
    /**
     * 时区
     */
    displayTimeZone?: string;
}
export interface DateProps extends RendererProps, Omit<AMISDateSchema, 'type' | 'className'> {
}
export interface DateState {
    random?: number;
}
export declare class DateField extends React.Component<DateProps, DateState> {
    refreshInterval: ReturnType<typeof setTimeout>;
    static defaultProps: Pick<DateProps, 'placeholder' | 'format' | 'valueFormat' | 'fromNow' | 'updateFrequency' | 'displayFormat'>;
    state: DateState;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): React.JSX.Element;
}
export declare class DateFieldRenderer extends DateField {
    static defaultProps: Partial<DateProps>;
}
export declare class DateTimeFieldRenderer extends DateField {
    static defaultProps: Partial<DateProps>;
}
export declare class TimeFieldRenderer extends DateField {
    static defaultProps: Partial<DateProps>;
}
export declare class MonthFieldRenderer extends DateField {
    static defaultProps: Partial<DateProps>;
}
