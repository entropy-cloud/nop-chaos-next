import React from 'react';
import { RendererProps } from 'amis-core';
import { TestIdBuilder } from 'amis-core';
import { SchemaTpl } from '../Schema';
import { BadgeObject } from 'amis-ui';
import { AMISSchemaBase } from 'amis-core';
/**
 * tpl 渲染器
 */
/**
 * 模板组件，用于渲染 HTML/文本模板。支持变量插值与表达式。
 */
export interface AMISTplSchema extends AMISSchemaBase {
    /**
     * 指定为 tpl 组件
     */
    type: 'tpl' | 'html';
    tpl?: SchemaTpl;
    html?: SchemaTpl;
    text?: SchemaTpl;
    raw?: string;
    /**
     * 是否内联显示
     */
    inline?: boolean;
    /**
     * 标签类型
     */
    wrapperComponent?: any;
    /**
     * 自定义样式
     */
    style?: {
        [propName: string]: any;
    };
    /**
     * 角标
     */
    badge?: BadgeObject;
    testidBuilder?: TestIdBuilder;
}
export interface TplProps extends RendererProps, AMISTplSchema {
    className?: string;
    value?: string;
}
interface TplState {
    content: string;
}
export declare class Tpl extends React.Component<TplProps, TplState> {
    static defaultProps: Partial<TplProps>;
    dom: any;
    mounted: boolean;
    sn: number;
    constructor(props: TplProps);
    componentDidUpdate(prevProps: Readonly<TplProps>): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    updateContent(): Promise<void>;
    getContent(): string;
    getAsyncContent(): Promise<string>;
    /**
     * 过滤掉HTML标签, 仅提取文本内容, 用于HTML标签的title属性
     */
    getTitle(content: string): string;
    handleClick(e: React.MouseEvent<HTMLDivElement>): void;
    handleMouseEnter(e: React.MouseEvent<any>): void;
    handleMouseLeave(e: React.MouseEvent<any>): void;
    render(): React.JSX.Element;
}
export declare class TplRenderer extends Tpl {
}
export {};
