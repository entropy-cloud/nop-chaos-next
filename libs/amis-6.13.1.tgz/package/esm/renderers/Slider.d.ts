import { AMISSchemaBase, RendererProps, AMISSchemaCollection } from 'amis-core';
import React from 'react';
/**
 * 滑块组件，用于选择范围或数值。支持步长、范围与提示。
 */
export interface AMISSliderSchema extends AMISSchemaBase {
    type: 'slider';
    body: AMISSchemaCollection;
    left?: AMISSchemaCollection;
    right?: AMISSchemaCollection;
    bodyWidth?: string;
}
interface SliderProps extends RendererProps, Omit<AMISSliderSchema, 'className'> {
}
export declare class SliderRenderer extends React.Component<SliderProps> {
    state: {
        leftShow: boolean;
        rightShow: boolean;
    };
    handleLeftShow(): void;
    handleRightShow(): void;
    handleLeftHide(): void;
    handleRightHide(): void;
    showLeft(): void;
    hideLeft(): void;
    showRight(): void;
    hideRight(): void;
    render(): React.JSX.Element;
}
export {};
