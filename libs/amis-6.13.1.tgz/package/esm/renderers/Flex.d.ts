/**
 * @file 简化版 Flex 布局，主要用于不熟悉 CSS 的开发者
 */
import React from 'react';
import { RendererProps, AMISSchemaBase, AMISSchemaCollection } from 'amis-core';
/**
 * Flex 弹性布局组件，简化版 Flex 布局，主要用于不熟悉 CSS 的开发者
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/flex
 */
/**
 * 弹性布局组件，基于 Flexbox 布局子元素。支持方向、换行与对齐配置。
 */
export interface AMISFlexSchema extends AMISSchemaBase {
    /**
     * 指定为 flex 组件
     */
    type: 'flex';
    /**
     * 水平分布方式
     */
    justify?: 'start' | 'flex-start' | 'center' | 'end' | 'flex-end' | 'space-around' | 'space-between' | 'space-evenly';
    /**
     * 垂直对齐方式
     */
    alignItems?: 'stretch' | 'start' | 'flex-start' | 'flex-end' | 'end' | 'center' | 'baseline';
    /**
     * 多行垂直分布方式
     */
    alignContent?: 'normal' | 'flex-start' | 'flex-end' | 'center' | 'space-between' | 'space-around' | 'space-evenly' | 'stretch';
    /**
     * 布局方向
     */
    direction?: 'row' | 'column' | 'row-reverse' | 'column-reverse';
    /**
     * Flex 子项配置
     */
    items: AMISSchemaCollection;
    /**
     * 自定义样式
     */
    style?: {
        [propName: string]: any;
    };
}
export interface FlexProps extends RendererProps, Omit<AMISFlexSchema, 'type' | 'className'> {
}
export default class Flex extends React.Component<FlexProps, object> {
    static defaultProps: Partial<FlexProps>;
    constructor(props: FlexProps);
    renderItems(): JSX.Element[];
    render(): React.JSX.Element;
}
export interface FlexItemSchema extends AMISSchemaBase {
    /**
     * 功能和 wrapper 类似，主要是给 flex 子节点用的
     */
    type: 'flex-item';
    /**
     * 内容
     */
    body: AMISSchemaCollection;
    /**
     * 自定义样式
     */
    style?: {
        [propName: string]: any;
    };
}
export interface FlexItemProps extends RendererProps, Omit<FlexItemSchema, 'className'> {
    children?: JSX.Element | ((props?: any) => JSX.Element);
}
export declare class FlexItem extends React.Component<FlexItemProps, object> {
    static propsList: Array<string>;
    renderBody(): JSX.Element | null;
    render(): React.JSX.Element;
}
export declare class FlexRenderer extends Flex {
}
export declare class FlexItemRenderer extends FlexItem {
}
