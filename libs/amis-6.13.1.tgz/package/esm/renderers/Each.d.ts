import React from 'react';
import { AMISSchemaBase, RendererProps, AMISSchemaCollection } from 'amis-core';
import { Schema } from 'amis-core';
export interface EachExtraProps extends RendererProps {
    items: any;
    item: any;
    index: number;
    itemKeyName: string;
    indexKeyName: string;
    name: string;
}
/**
 * Each 循环功能渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/each
 */
/**
 * 循环渲染组件，用于遍历数组并渲染子内容。
 */
export interface AMISEachSchema extends AMISSchemaBase {
    /**
     * 指定为 each 组件
     */
    type: 'each';
    /**
     * 关联字段名
     */
    name?: string;
    /**
     * 关联字段名 支持数据映射
     */
    source?: string;
    /**
     * 用来控制通过什么字段读取成员数据
     */
    itemKeyName?: string;
    /**
     * 用来控制通过什么字段读取序号
     */
    indexKeyName?: string;
    items?: AMISSchemaCollection;
    placeholder?: string;
}
export interface EachProps extends RendererProps {
    name: string;
    items: Schema;
}
export default class Each extends React.Component<EachProps> {
    static propsList: Array<string>;
    static defaultProps: {
        className: string;
        placeholder: string;
    };
    render(): React.JSX.Element;
}
export declare class EachRenderer extends Each {
}
