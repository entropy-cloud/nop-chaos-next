import React from 'react';
import { RendererProps } from 'amis-core';
import { StepStatus } from 'amis-ui/lib/components/Steps';
import type { AMISSchemaBase, SchemaExpression, AMISSchemaCollection } from 'amis-core';
export interface StepSchema extends AMISSchemaBase {
    /**
     * 步骤标题
     */
    title?: string | AMISSchemaCollection;
    /**
     * 步骤子标题
     */
    subTitle?: string | AMISSchemaCollection;
    /**
     * 步骤图标
     */
    icon?: string;
    /**
     * 步骤值
     */
    value?: string | number;
    /**
     * 步骤描述
     */
    description?: string | AMISSchemaCollection;
}
/**
 * 步骤条组件，用于展示流程步骤。支持垂直/水平与可点击。
 */
export interface AMISStepsSchema extends AMISSchemaBase {
    /**
     * 指定为 steps 组件
     */
    type: 'steps';
    /**
     * 步骤配置数组
     */
    steps?: Array<StepSchema>;
    /**
     * 数据源配置
     */
    source?: string;
    /**
     * 指定当前激活的步骤
     */
    value?: number | string;
    /**
     * 变量映射名称
     */
    name?: string;
    /**
     * 步骤状态配置
     */
    status?: StepStatus | {
        [propName: string]: StepStatus;
    } | SchemaExpression;
    /**
     * 展示模式
     */
    mode?: 'horizontal' | 'vertical';
    /**
     * 标签放置位置
     */
    labelPlacement?: 'horizontal' | 'vertical';
    /**
     * 点状步骤条
     */
    progressDot?: boolean;
    /**
     * 切换图标位置
     */
    iconPosition: false;
}
export interface StepsProps extends RendererProps, Omit<AMISStepsSchema, 'className'> {
}
export declare function StepsCmpt(props: StepsProps): React.JSX.Element;
export declare class StepsRenderer extends React.Component<StepsProps> {
    render(): React.JSX.Element;
}
