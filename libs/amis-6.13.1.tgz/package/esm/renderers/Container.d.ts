import React from 'react';
import { RendererProps, AMISSchemaCollection, AMISSchemaBase } from 'amis-core';
import { AMISClassName } from '../Schema';
/** 容器拖拽配置 */
export interface ContainerDraggableConfig {
    /**
     * 可拖拽的方向
     */
    axis?: 'both' | 'x' | 'y';
    /**
     * 元素的起始位置
     */
    defaultPosition?: {
        x: number;
        y: number;
    };
    /**
     * 拖拽的边界
     */
    bounds?: {
        left?: number;
        right?: number;
        top?: number;
        bottom?: number;
    } | string;
    /**
     * 以网格模式拖拽的步长
     */
    grid?: [number, number];
    /**
     * 初始化拖拽的选择器
     */
    handle?: string;
    /**
     * 禁止拖拽的选择器
     */
    cancel?: string;
    /**
     * 拖拽距离的缩放比
     */
    scale?: number;
    /**
     * 默认设置容器内部为'user-select:none', 设置true关闭
     */
    enableUserSelect?: boolean;
}
/**
 * Container 容器渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/container
 */
/**
 * 容器组件，用于包裹与布局内容区域。支持标题、工具栏与样式控制。
 */
export interface AMISContainerSchema extends AMISSchemaBase {
    /**
     * 指定为 container 组件
     */
    type: 'container';
    /**
     * 内容
     */
    body: AMISSchemaCollection;
    /**
     * body 类名
     */
    bodyClassName?: AMISClassName;
    /**
     * 自定义样式
     */
    style?: {
        [propName: string]: any;
    };
    /**
     * 使用的标签
     */
    wrapperComponent?: string;
    /**
     * 是否需要对body加一层div包裹，默认为 true
     */
    wrapperBody?: boolean;
    /**
     * 是否开启容器拖拽
     */
    draggable?: boolean | string;
    /**
     * 是否开启容器拖拽配置
     */
    draggableConfig: ContainerDraggableConfig | string;
}
export interface ContainerProps extends RendererProps, Omit<AMISContainerSchema, 'type' | 'className' | 'style'> {
    children?: (props: any) => React.ReactNode;
}
export default class Container<T> extends React.Component<ContainerProps & T, object> {
    static propsList: Array<string>;
    static defaultProps: {
        className: string;
        draggableConfig: {
            axis: ContainerDraggableConfig["axis"];
            scale: number;
            enableUserSelect: boolean;
        };
    };
    handleClick(e: React.MouseEvent<any>): void;
    handleMouseEnter(e: React.MouseEvent<any>): void;
    handleMouseLeave(e: React.MouseEvent<any>): void;
    renderBody(): JSX.Element | null;
    render(): React.JSX.Element;
}
export declare class ContainerRenderer extends Container<{}> {
}
