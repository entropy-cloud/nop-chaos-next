/**
 * @file 用来渲染 Markdown
 */
import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
/**
 * Markdown 渲染组件，用于渲染 Markdown 内容。支持代码高亮、数学公式等扩展语法。
 */
export interface AMISMarkdownSchema extends AMISSchemaBase {
    /**
     * 指定为 markdown 组件
     */
    type: 'markdown';
    /**
     * markdown 内容
     */
    value?: string;
    /**
     * 样式类
     */
    className?: string;
    /**
     * 名称映射
     */
    name?: string;
}
export interface MarkdownProps extends RendererProps, Omit<AMISMarkdownSchema, 'type' | 'className'> {
}
interface MarkdownState {
    content: string;
}
export declare class Markdown extends React.Component<MarkdownProps, MarkdownState> {
    constructor(props: MarkdownProps);
    componentDidUpdate(prevProps: MarkdownProps): void;
    updateContent(): Promise<void>;
    render(): React.JSX.Element;
}
export declare class MarkdownRenderer extends Markdown {
}
export {};
