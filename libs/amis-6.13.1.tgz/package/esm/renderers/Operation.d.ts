import React from 'react';
import { AMISButtonSchema, AMISSchemaBase, RendererProps } from 'amis-core';
/**
 * 操作栏渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/operation
 */
/**
 * 操作列组件，用于表格中的操作按钮区域。支持多按钮配置与条件显示。
 */
export interface AMISOperationSchema extends AMISSchemaBase {
    /**
     * 指定为 operation 组件
     */
    type: 'operation';
    /**
     * 占位符
     */
    placeholder?: string;
    /**
     * 按钮集合
     */
    buttons: Array<AMISButtonSchema>;
}
export interface OperationProps extends RendererProps, Omit<AMISOperationSchema, 'type' | 'className'> {
}
export declare class OperationField extends React.Component<OperationProps, object> {
    static propsList: Array<string>;
    static defaultProps: Partial<OperationProps>;
    render(): React.JSX.Element;
}
export declare class OperationFieldRenderer extends OperationField {
}
