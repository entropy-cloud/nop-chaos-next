import React from 'react';
import { AMISSchemaBase, AMISUrlPath, RendererProps } from 'amis-core';
/**
 * Audio 音频渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/audio
 */
/**
 * 音频播放器组件，用于播放音频。支持自动播放、循环与控制栏。
 */
export interface AMISAudioSchema extends AMISSchemaBase {
    /**
     * 指定为 audio 组件
     */
    type: 'audio';
    /**
     * 是否是内联模式
     */
    inline?: boolean;
    /**
     * 音频播放地址
     */
    src?: AMISUrlPath;
    /**
     * 是否循环播放
     */
    loop?: boolean;
    /**
     * 是否自动播放
     */
    autoPlay?: boolean;
    /**
     * 配置可选播放倍速
     */
    rates?: Array<number>;
    /**
     * 配置控制器
     */
    controls?: Array<'rates' | 'play' | 'time' | 'process' | 'volume'>;
}
export interface AudioProps extends RendererProps, Omit<AMISAudioSchema, 'className'> {
}
export interface AudioState {
    src?: string;
    isReady?: boolean;
    muted?: boolean;
    playing?: boolean;
    played: number;
    seeking?: boolean;
    volume: number;
    prevVolume: number;
    loaded?: number;
    playbackRate: number;
    showHandlePlaybackRate: boolean;
    showHandleVolume: boolean;
}
export declare class Audio extends React.Component<AudioProps, AudioState> {
    audio: HTMLMediaElement;
    progressTimeout: ReturnType<typeof setTimeout>;
    durationTimeout: ReturnType<typeof setTimeout>;
    static defaultProps: Pick<AudioProps, 'inline' | 'autoPlay' | 'playbackRate' | 'loop' | 'rates' | 'progressInterval' | 'controls'>;
    state: AudioState;
    componentWillUnmount(): void;
    componentDidMount(): void;
    componentDidUpdate(prevProps: AudioProps): void;
    progress(): void;
    audioRef(audio: HTMLMediaElement): void;
    load(): void;
    handlePlaybackRate(rate: number): void;
    handleMute(): void;
    handlePlaying(): void;
    getCurrentTime(): string;
    getDuration(): string | number;
    onDurationCheck(): void;
    onSeekChange(e: any): void;
    onSeekMouseDown(): void;
    onSeekMouseUp(e: any): void;
    setVolume(e: any): void;
    formatTime(seconds: number): string;
    pad(string: number): string;
    toggleHandlePlaybackRate(): void;
    toggleHandleVolume(type: boolean): void;
    renderRates(): React.JSX.Element | null;
    renderPlay(): React.JSX.Element;
    renderTime(): React.JSX.Element;
    renderProcess(): React.JSX.Element;
    renderVolume(): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class AudioRenderer extends Audio {
}
