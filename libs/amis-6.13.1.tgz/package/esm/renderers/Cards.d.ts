import React from 'react';
import { RendererProps, ScopedContext } from 'amis-core';
import { SchemaNode, ActionObject } from 'amis-core';
import { IListStore } from 'amis-core';
import Sortable from 'sortablejs';
import { AMISClassName, SchemaTpl } from '../Schema';
import { AMISCardSchemaBase } from './Card';
import { AMISCard2Schema } from './Card2';
import type { IItem, IScopedContext, AMISSchemaBase, AMISSpinnerConfig, AMISSchemaCollection, AMISLocalSource, AMISExpression } from 'amis-core';
/**
 * Cards 卡片集合渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/cards
 */
export interface AMISCardsBase extends AMISSchemaBase, AMISSpinnerConfig {
    card?: AMISCardSchemaBase | AMISCard2Schema;
    /**
     * 头部 CSS 类名
     */
    headerClassName?: AMISClassName;
    /**
     * 底部 CSS 类名
     */
    footerClassName?: AMISClassName;
    /**
     * 卡片 CSS 类名
     */
    itemClassName?: AMISClassName;
    /**
     * 无数据提示
     */
    placeholder?: SchemaTpl;
    /**
     * 是否显示底部
     */
    showFooter?: boolean;
    /**
     * 是否显示头部
     */
    showHeader?: boolean;
    /**
     * 数据源
     */
    source?: AMISLocalSource;
    /**
     * 标题
     */
    title?: SchemaTpl;
    /**
     * 是否隐藏勾选框
     */
    hideCheckToggler?: boolean;
    /**
     * 是否固顶
     */
    affixHeader?: boolean;
    /**
     * 是否固底
     */
    affixFooter?: boolean;
    /**
     * 顶部区域
     */
    header?: AMISSchemaCollection;
    /**
     * 底部区域
     */
    footer?: AMISSchemaCollection;
    /**
     * 配置某项是否可点选
     */
    itemCheckableOn?: AMISExpression;
    /**
     * 配置某项是否可拖拽排序，前提是要开启拖拽功能
     */
    itemDraggableOn?: AMISExpression;
    /**
     * 点击卡片的时候是否勾选卡片。
     */
    checkOnItemClick?: boolean;
    /**
     * 是否为瀑布流布局？
     */
    masonryLayout?: boolean;
    /**
     * 可以用来作为值的字段
     */
    valueField?: string;
}
export type BaseCardsSchema = AMISCardsBase;
/**
 * 卡片集合组件，以卡片形式展示列表数据。
 */
export interface AMISCardsSchema extends AMISCardsBase {
    /**
     * 指定为 cards 类型
     */
    type: 'cards';
}
export type CardsSchema = AMISCardsSchema;
export interface Column {
    type: string;
    [propName: string]: any;
}
export type CardsRendererEvent = 'selected';
export type CardsRendererAction = 'toggleSelectAll' | 'selectAll' | 'clearAll';
export interface GridProps extends RendererProps, Omit<CardsSchema, 'className' | 'itemClassName'> {
    store: IListStore;
    selectable?: boolean;
    selected?: Array<any>;
    checkAll?: boolean;
    multiple?: boolean;
    valueField?: string;
    draggable?: boolean;
    dragIcon?: SVGAElement;
    items?: Array<object>;
    fullItems?: Array<object>;
    onSelect: (selectedItems: Array<object>, unSelectedItems: Array<object>) => void;
    onItemChange?: (item: object, diff: object, rowIndex: string | number) => void;
    onSave?: (items: Array<object> | object, diff: Array<object> | object, rowIndexes: Array<number> | number, unModifiedItems?: Array<object>, rowOrigins?: Array<object> | object, options?: {
        resetOnFailed?: boolean;
        reload?: string;
    }) => void;
    onSaveOrder?: (moved: Array<object>, items: Array<object>) => void;
    onQuery: (values: object) => any;
}
export default class Cards extends React.Component<GridProps, object> {
    static propsList: Array<string>;
    static defaultProps: Partial<GridProps>;
    dragTip?: HTMLElement;
    sortable?: Sortable;
    body?: any;
    unSensor: Function;
    renderedToolbars: Array<string>;
    constructor(props: GridProps);
    static syncItems(store: IListStore, props: GridProps, prevProps?: GridProps): boolean;
    componentDidUpdate(prevProps: GridProps): void;
    bodyRef(ref: HTMLDivElement): void;
    handleAction(e: React.UIEvent<any> | undefined, action: ActionObject, ctx: object): any;
    handleCheck(item: IItem): void;
    handleClick(item: IItem): Promise<import("amis-core").RendererEvent<any>>;
    handleCheckAll(): void;
    handleSelectAll(): void;
    handleClearAll(): void;
    syncSelected(): void;
    handleQuickChange(item: IItem, values: object, saveImmediately?: boolean | any, savePristine?: boolean, options?: {
        resetOnFailed?: boolean;
        reload?: string;
    }): void;
    handleSave(): void;
    handleSaveOrder(): Promise<void>;
    reset(): void;
    bulkUpdate(value: any, items: Array<object>): void;
    getSelected(): any[];
    dragTipRef(ref: any): void;
    initDragging(): void;
    destroyDragging(): void;
    renderActions(region: string): React.JSX.Element | null;
    renderHeading(): React.JSX.Element | null;
    renderHeader(): React.JSX.Element | React.JSX.Element[] | null;
    renderFooter(): React.JSX.Element | React.JSX.Element[] | null;
    renderCheckAll(): React.JSX.Element | null;
    renderDragToggler(): React.JSX.Element | null;
    renderToolbar(toolbar: SchemaNode, index: number): React.JSX.Element | null | undefined;
    renderCard(index: number, card: any, item: IItem, itemClassName: string, style: any): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class CardsRenderer extends Cards {
    dragging: boolean;
    selectable: boolean;
    selected: boolean;
    onSelect: boolean;
    title?: string;
    subTitle?: string;
    desc?: string;
    avatar?: string;
    avatarClassName?: string;
    body?: SchemaNode;
    actions?: Array<ActionObject>;
    static contextType: React.Context<IScopedContext>;
    context: React.ContextType<typeof ScopedContext>;
    constructor(props: GridProps, scoped: IScopedContext);
    componentWillUnmount(): void;
    receive(values: any, subPath?: string): any;
    reload(subPath?: string, query?: any, ctx?: any, silent?: boolean, replace?: boolean, args?: any): Promise<any>;
    setData(values: any, replace?: boolean, index?: number | string, condition?: any): Promise<any>;
    getData(): any;
    hasModifiedItems(): number;
    doAction(action: ActionObject, ctx: any, throwErrors: boolean, args: any): Promise<any>;
}
