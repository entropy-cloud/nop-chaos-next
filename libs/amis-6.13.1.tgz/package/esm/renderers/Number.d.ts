import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
import { Option, PlainObject } from 'amis-core';
/**
 * Number 展示渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/number
 */
/**
 * 数字显示组件，用于格式化显示数值。支持千分位、小数位与单位。
 */
export interface AMISNumberSchema extends AMISSchemaBase {
    /**
     * 指定为 number 组件
     */
    type: 'number';
    /**
     * 精度，用来控制小数点位数
     */
    precision?: number;
    /**
     * 前缀
     */
    prefix?: string;
    /**
     * 后缀
     */
    suffix?: string;
    /**
     * 是否千分分隔
     */
    kilobitSeparator?: boolean;
    /**
     * 百分比显示
     */
    percent?: boolean | number;
    /**
     * 占位符
     */
    placeholder?: string;
    /**
     * 单位列表
     */
    unitOptions?: string | Array<Option> | string[] | PlainObject;
}
export interface NumberProps extends RendererProps, Omit<AMISNumberSchema, 'type' | 'className'> {
}
export declare class NumberField extends React.Component<NumberProps> {
    static defaultProps: Pick<NumberProps, 'placeholder' | 'kilobitSeparator'>;
    render(): React.JSX.Element;
}
export declare class NumberFieldRenderer extends NumberField {
}
