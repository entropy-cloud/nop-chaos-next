import React from 'react';
import { AMISExpression, AMISSchemaBase, RendererProps, AMISSchemaCollection, AMISSchema } from 'amis-core';
import { FormHorizontal } from 'amis-core';
export type AMISHBoxColumn = {
    /**
     * 列上 CSS 类名
     */
    columnClassName?: string;
    /**
     * 垂直对齐方式
     */
    valign?: 'top' | 'middle' | 'bottom' | 'between';
    /**
     * 宽度
     */
    width?: number | string;
    /**
     * 高度
     */
    height?: number | string;
    /**
     * 其他样式
     */
    style?: {
        [propName: string]: any;
    };
    /**
     * 配置子表单项默认的展示方式
     */
    mode?: 'normal' | 'inline' | 'horizontal';
    /**
     * 如果是水平排版，这个属性可以细化水平排版的左右宽度占比
     */
    horizontal?: FormHorizontal;
    /**
     * 内容区
     */
    body?: AMISSchemaCollection;
    /**
     * 是否显示
     */
    visible?: boolean;
    /**
     * 是否显示表达式
     */
    visibleOn?: AMISExpression;
};
export type HBoxColumn = AMISHBoxColumn;
/**
 * Hbox 水平布局渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/hbox
 */
/**
 * 水平布局组件，用于横向排列子元素。支持列比例与间距设置。
 */
export interface AMISHBoxSchema extends AMISSchemaBase {
    /**
     * 指定为 hbox 组件
     */
    type: 'hbox';
    columns: Array<HBoxColumn>;
    /**
     * 配置子表单项默认的展示方式
     */
    subFormMode?: 'normal' | 'inline' | 'horizontal';
    /**
     * 如果是水平排版，这个属性可以细化水平排版的左右宽度占比
     */
    subFormHorizontal?: FormHorizontal;
    /**
     * 水平间距
     */
    gap?: 'xs' | 'sm' | 'base' | 'none' | 'md' | 'lg';
    /**
     * 垂直对齐方式
     */
    valign?: 'top' | 'middle' | 'bottom' | 'between';
    /**
     * 水平对齐方式
     */
    align?: 'left' | 'right' | 'between' | 'center';
}
export interface HBoxProps extends RendererProps, AMISHBoxSchema {
    className: string;
    itemRender?: (item: any, key: number, length: number, props: any) => JSX.Element;
}
export default class HBox extends React.Component<HBoxProps, object> {
    static propsList: Array<string>;
    static defaultProps: Partial<HBoxProps>;
    renderChild(region: string, node: AMISSchema, props?: any): JSX.Element;
    renderColumn(column: HBoxColumn, key: number, length: number): React.JSX.Element | null;
    renderColumns(): (React.JSX.Element | null)[];
    render(): React.JSX.Element;
}
export declare class HBoxRenderer extends HBox {
}
