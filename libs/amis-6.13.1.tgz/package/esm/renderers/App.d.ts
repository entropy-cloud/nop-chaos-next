import React from 'react';
import { SpinnerExtraProps } from 'amis-ui';
import { RendererProps, AMISSchemaBase } from 'amis-core';
import { AMISClassName } from '../Schema';
import { IScopedContext } from 'amis-core';
import { IAppStore } from 'amis-core';
import type { AMISApi, AMISSchemaCollection } from 'amis-core';
import { AMISDefinitions } from 'amis-core';
export interface AMISAppPage extends SpinnerExtraProps {
    /**
     * 菜单文字
     */
    label?: string;
    /**
     * 菜单图标
     */
    icon?: string;
    /**
     * 路由规则
     */
    url?: string;
    /**
     * 当match url 时跳转到目标地址
     */
    redirect?: string;
    /**
     * 当match url 转成渲染目标地址的页面
     */
    rewrite?: string;
    /**
     * 不要出现多个，如果出现多个只有第一个有用。在路由找不到的时候作为默认页面
     */
    isDefaultPage?: boolean;
    /**
     * 二选一，如果配置了 url 一定要配置。否则不知道如何渲染
     */
    schema?: any;
    schemaApi?: any;
    /**
     * 单纯的地址。设置外部链接
     */
    link?: string;
    /**
     * 支持多层级
     */
    children?: Array<AMISAppPage>;
    /**
     * 菜单上的类名
     */
    className?: AMISClassName;
    /**
     * 是否在导航中可见
     */
    visible?: boolean;
}
/**
 * App 渲染器，适合 JSSDK 用来做多页渲染。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/app
 */
/**
 * 应用容器组件，提供全局配置与布局。用于承载多页面/路由场景。
 */
export interface AMISAppSchema extends AMISSchemaBase, SpinnerExtraProps {
    /**
     * 指定为 app 组件
     */
    type: 'app';
    api?: AMISApi;
    /**
     * 系统名称
     */
    brandName?: string;
    /**
     * logo 图片地址，可以是 svg。
     */
    logo?: string;
    /**
     * 顶部区域
     */
    header?: AMISSchemaCollection;
    /**
     * 边栏菜单前面的区域
     */
    asideBefore?: AMISSchemaCollection;
    /**
     * 边栏菜单后面的区域
     */
    asideAfter?: AMISSchemaCollection;
    /**
     * 页面集合。
     */
    pages?: Array<AMISAppPage> | AMISAppPage;
    /**
     * 底部区域。
     */
    footer?: AMISSchemaCollection;
    /**
     * CSS 类名。
     */
    className?: AMISClassName;
    /**
     * 显示面包屑路径。
     */
    showBreadcrumb?: boolean;
    /**
     * 显示面包屑完整路径。
     */
    showFullBreadcrumbPath?: boolean;
    /**
     * 显示面包屑首页路径。
     */
    showBreadcrumbHomePath?: boolean;
    /**
     * 类似 json-schema 的定义，可以被其他组件引用
     * 目前只有顶级组件可以定义，其他组件不能定义。
     */
    definitions?: AMISDefinitions;
}
export interface AppProps extends RendererProps, Omit<AMISAppSchema, 'type' | 'className'> {
    children?: JSX.Element | ((props?: any) => JSX.Element);
    store: IAppStore;
}
export declare class App extends React.Component<AppProps, object> {
    static propsList: Array<string>;
    static defaultProps: {};
    unWatchRouteChange?: () => void;
    constructor(props: AppProps);
    componentDidMount(): Promise<void>;
    componentDidUpdate(prevProps: AppProps): Promise<void>;
    componentWillUnmount(): void;
    reload(subpath?: any, query?: any, ctx?: any, silent?: boolean, replace?: boolean): Promise<any>;
    receive(values: object, subPath?: string, replace?: boolean): Promise<any>;
    /**
     * 支持页面层定义 definitions，并且优先取页面层的 definitions
     * @param name
     * @returns
     */
    resolveDefinitions(name: string): any;
    handleNavClick(e: React.MouseEvent): void;
    renderHeader(): React.JSX.Element | null;
    renderAside(): React.JSX.Element;
    renderFooter(): JSX.Element | null;
    render(): React.JSX.Element;
}
export default class AppRenderer extends App {
    static contextType: React.Context<IScopedContext>;
    constructor(props: AppProps, context: IScopedContext);
    componentWillUnmount(): void;
    setData(values: object, replace?: boolean): void;
    getData(): any;
}
