import React from 'react';
import { OptionsControlProps, Option, AMISFormItemWithOptions, AMISSchemaCollection } from 'amis-core';
import { ActionObject } from 'amis-core';
import { AMISClassName } from '../../Schema';
/**
 * List 复选框
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/list-select
 */
/**
 * ListSelect 组件用于多选列表展示和选择，支持图片、模板自定义和双击提交等功能。
 */
export interface AMISListSelectSchema extends AMISFormItemWithOptions {
    /**
     * 指定为 list-select 组件
     */
    type: 'list-select';
    /**
     * 开启双击点选并提交
     */
    submitOnDBClick?: boolean;
    /**
     * 图片div类名
     */
    imageClassName?: string;
    /**
     * 可以自定义展示模板
     */
    itemSchema?: AMISSchemaCollection;
    /**
     * 激活态自定义展示模板
     */
    activeItemSchema?: AMISSchemaCollection;
    /**
     * 支持配置 list div 的 CSS 类名
     */
    listClassName?: AMISClassName;
}
export interface ListProps extends OptionsControlProps, Omit<AMISListSelectSchema, 'type' | 'options' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export default class ListControl extends React.Component<ListProps, any> {
    static propsList: string[];
    static defaultProps: {
        clearable: boolean;
        imageClassName: string;
        submitOnDBClick: boolean;
    };
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    handleDBClick(option: Option, e: React.MouseEvent<HTMLElement>): void;
    handleClick(option: Option, e: React.MouseEvent<HTMLElement>): void;
    reload(subpath?: string, query?: any): void;
    renderStatic(displayValue?: string): string | React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class ListControlRenderer extends ListControl {
}
