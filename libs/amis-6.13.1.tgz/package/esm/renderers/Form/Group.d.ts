import React from 'react';
import { AMISFormItem, RendererProps } from 'amis-core';
import { AMISClassName, SchemaObject } from '../../Schema';
import { FormHorizontal } from 'amis-core';
export type AMISGroupSubItem = SchemaObject & {
    /**
     * 列类名
     */
    columnClassName?: AMISClassName;
    /**
     * 宽度占用比率
     */
    columnRatio?: number | 'auto';
    /**
     * 列名称
     */
    name?: string;
};
/**
 * Group 表单集合渲染器，能让多个表单在一行显示
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/group
 */
/**
 * Group 表单集合渲染器，支持多个表单项横向或纵向布局，子项可配置名称、宽度比例及样式，用于在一行或一列展示多个表单控件。
 */
export interface AMISGroupSchema extends AMISFormItem {
    type: 'group';
    /**
     * FormItem 集合
     */
    body: Array<AMISGroupSubItem> | AMISGroupSubItem;
    /**
     * 间隔
     */
    gap?: 'xs' | 'sm' | 'normal';
    /**
     * 配置时垂直摆放还是左右摆放
     */
    direction?: 'horizontal' | 'vertical';
    /**
     * 子表单项展示方式
     */
    subFormMode?: 'normal' | 'inline' | 'horizontal';
    /**
     * 水平排版宽度占比
     */
    subFormHorizontal?: FormHorizontal;
}
export interface InputGroupProps extends RendererProps, Omit<AMISGroupSchema, 'type' | 'className'> {
}
export declare class ControlGroupRenderer extends React.Component<InputGroupProps> {
    reaction: any;
    constructor(props: InputGroupProps);
    componentWillUnmount(): void;
    renderControl(control: any, index: any, otherProps?: any): JSX.Element | null;
    renderVertical(props?: Readonly<InputGroupProps>): React.JSX.Element | null;
    renderHorizontal(props?: Readonly<InputGroupProps>): React.JSX.Element | null;
    renderInput(props?: Readonly<InputGroupProps>): React.JSX.Element | null;
    render(): React.JSX.Element | null;
}
