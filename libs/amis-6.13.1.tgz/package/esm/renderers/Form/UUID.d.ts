import React from 'react';
import { AMISFormItem } from 'amis-core';
import { FormControlProps } from 'amis-core';
/**
 * UUID 功能性组件
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/uuid
 */
export interface AMISUuidSchema extends AMISFormItem {
    type: 'uuid';
    /**
     * 长度
     */
    length?: number;
}
export default class UUIDControl extends React.Component<FormControlProps, any> {
    constructor(props: FormControlProps);
    componentDidUpdate(props: FormControlProps): void;
    setValue(): void;
    render(): null;
}
export declare class UUIDControlRenderer extends UUIDControl {
}
