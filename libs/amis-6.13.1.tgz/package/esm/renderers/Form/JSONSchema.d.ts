import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import { AMISInputFormulaSchema } from './InputFormula';
/**
 * JSON Schema
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/json-schema
 */
export interface AMISJsonSchemaSchema extends AMISFormItem {
    /**
     * 指定为 json-schema 组件
     */
    type: 'json-schema';
    /**
     * json-schema 详情
     */
    schema?: any;
    /**
     * 将字段输入控件变成公式编辑器
     */
    formula?: Omit<AMISInputFormulaSchema, 'type'>;
}
export interface JSONSchemaProps extends FormControlProps, Omit<AMISJsonSchemaSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export default class JSONSchemaControl extends React.PureComponent<JSONSchemaProps> {
    control: any;
    controlRef(ref: any): void;
    validate(): any;
    render(): React.JSX.Element;
}
export declare class JSONSchemaRenderer extends JSONSchemaControl {
}
