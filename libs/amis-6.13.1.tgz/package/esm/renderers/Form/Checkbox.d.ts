import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import { BadgeObject } from 'amis-ui';
import { ActionObject } from 'amis-core';
import type { TestIdBuilder } from 'amis-core';
export interface SchemaMap {
    checkbox: AMISCheckboxSchema;
}
/**
 * 复选框组件，用于多选场景。支持单个或多个选项的勾选状态。
 */
export interface AMISCheckboxSchema extends AMISFormItem {
    /**
     * 指定为 checkbox 组件
     */
    type: 'checkbox';
    /**
     * 勾选时的值
     */
    trueValue?: boolean | string | number;
    /**
     * 未勾选时的值
     */
    falseValue?: boolean | string | number;
    /**
     * 选项说明
     */
    option?: string;
    /**
     * 角标配置
     */
    badge?: BadgeObject;
    /**
     * 是否支持部分选中
     */
    partial?: boolean;
    /**
     * 选项类型
     */
    optionType?: 'default' | 'button';
    /**
     * 是否默认选中
     */
    checked?: boolean;
    /**
     * 测试 ID 构建器
     */
    testIdBuilder?: TestIdBuilder;
}
export interface CheckboxProps extends FormControlProps, Omit<AMISCheckboxSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export default class CheckboxControl extends React.Component<CheckboxProps, any> {
    static defaultProps: Partial<CheckboxProps>;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    dispatchChangeEvent(eventData?: any): Promise<void>;
    renderStatic(): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class CheckboxControlRenderer extends CheckboxControl {
}
