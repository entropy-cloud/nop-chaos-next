import React from 'react';
import { FormControlProps } from 'amis-core';
import type { AMISFormItem, ListenerAction } from 'amis-core';
/**
 * TextArea 多行文本输入框。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/textarea
 */
/**
 * TextArea 多行文本输入框组件，支持最大/最小行数、只读、边框模式、最大长度、字符统计和清除等功能。
 */
export interface AMISTextareaSchema extends AMISFormItem {
    /**
     * 指定为 textarea 组件
     */
    type: 'textarea';
    /**
     * 最大行数
     */
    maxRows?: number;
    /**
     * 最小行数
     */
    minRows?: number;
    /**
     * 是否只读
     */
    readOnly?: boolean;
    /**
     * 边框模式
     */
    borderMode?: 'full' | 'half' | 'none';
    /**
     * 最大长度
     */
    maxLength?: number;
    /**
     * 是否显示字符计数
     */
    showCounter?: boolean;
    /**
     * 是否显示清除按钮
     */
    clearable?: boolean;
    /**
     * 重置时的默认值
     */
    resetValue?: string;
}
export type TextAreaRendererEvent = 'blur' | 'focus' | 'change';
export interface TextAreaProps extends FormControlProps {
    placeholder?: string;
    minRows?: number;
    maxRows?: number;
    clearable?: boolean;
    resetValue?: string;
}
export interface TextAreaState {
    focused: boolean;
}
export default class TextAreaControl extends React.Component<TextAreaProps, TextAreaState> {
    static defaultProps: Partial<TextAreaProps>;
    inputRef: React.RefObject<any>;
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    focus(): void;
    handleChange(e: React.ChangeEvent<HTMLTextAreaElement>): void;
    handleFocus(e: React.FocusEvent<HTMLTextAreaElement>): void;
    handleBlur(e: React.FocusEvent<HTMLTextAreaElement>): void;
    renderStatic(displayValue?: string): JSX.Element;
    render(): React.JSX.Element;
}
export declare class TextAreaControlRenderer extends TextAreaControl {
}
