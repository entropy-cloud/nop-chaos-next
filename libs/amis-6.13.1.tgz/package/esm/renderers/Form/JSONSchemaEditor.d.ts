import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import type { SchemaEditorItemPlaceholder } from 'amis-ui';
/**
 * JSON Schema Editor
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/json-schema-editor
 */
export interface AMISJsonSchemaEditorSchema extends AMISFormItem {
    /**
     * 指定为 JSON Schema 编辑器组件，用于编辑 JSON Schema
     */
    type: 'json-schema-editor';
    /**
     * 类型定义模板，方便快速定义复杂类型
     * 可以理解为类型模板，用于复用常见的类型定义
     */
    definitions?: {
        [propName: string]: {
            title: string;
            type: 'string' | 'number' | 'integer' | 'object' | 'array' | 'boolean' | 'null';
            [propName: string]: any;
        };
    };
    /**
     * 顶层是否允许修改类型
     */
    rootTypeMutable?: boolean;
    /**
     * 顶层类型信息是否隐藏
     */
    showRootInfo?: boolean;
    /**
     * 禁用的类型列表，默认禁用了 null 类型
     */
    disabledTypes?: Array<string>;
    /**
     * 是否开启高级设置面板
     */
    enableAdvancedSetting?: boolean;
    /**
     * 自定义高级设置面板配置
     * 例如：{ boolean: [{type: "input-text", name: "aa", label: "AA"}] }
     * 当配置布尔字段详情时，就会出现以上配置
     */
    advancedSettings?: {
        [propName: string]: any;
    };
    /**
     * 各属性输入控件的占位提示文本配置
     * 例如：{ key: "key placeholder", title: "title placeholder" }
     */
    placeholder?: SchemaEditorItemPlaceholder;
    /**
     * 是否为迷你模式，会隐藏一些不必要的元素
     */
    mini?: boolean;
}
export interface JSONSchemaEditorProps extends FormControlProps, Omit<AMISJsonSchemaEditorSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export default class JSONSchemaEditorControl extends React.PureComponent<JSONSchemaEditorProps> {
    static defaultProps: {
        enableAdvancedSetting: boolean;
        placeholder: {
            key: string;
            title: string;
            description: string;
            default: string;
            empty: string;
        };
    };
    normalizePlaceholder(): SchemaEditorItemPlaceholder;
    renderModalProps(value: any, onChange: (value: any) => void): JSX.Element;
    render(): React.JSX.Element;
}
export declare class JSONSchemaEditorRenderer extends JSONSchemaEditorControl {
}
