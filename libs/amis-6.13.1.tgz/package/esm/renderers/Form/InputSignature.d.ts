/**
 * @file Signature.tsx 签名组件
 *
 * @created: 2024/03/04
 */
import React from 'react';
import { IScopedContext, FormControlProps, Payload } from 'amis-core';
import { SchemaApi } from '../../Schema';
import { AMISFormItem } from 'amis-core';
/**
 * InputSignature 签名输入组件，支持手写签名、撤销、清空及确认操作，可自定义宽高、线条颜色和背景色，适用于表单签名需求。
 */
export interface AMISInputSignatureSchema extends AMISFormItem {
    type: 'input-signature';
    /**
     * 组件宽度
     */
    width?: number;
    /**
     * 组件高度
     */
    height?: number;
    /**
     * 组件字段颜色
     * @default #000
     */
    color?: string;
    /**
     * 组件背景颜色
     * @default #efefef
     */
    bgColor?: string;
    /**
     * 清空按钮名称
     * @default 清空
     */
    clearBtnLabel?: string;
    /**
     * 清空按钮图标
     * @default 清空
     */
    clearBtnIcon?: string;
    /**
     * 撤销按钮名称
     * @default 撤销
     */
    undoBtnLabel?: string;
    /**
     * 撤销按钮图标
     * @default 撤销
     */
    undoBtnIcon?: string;
    /**
     * 确认按钮名称
     * @default 确认
     */
    confirmBtnLabel?: string;
    /**
     * 确认按钮图标
     * @default 确认
     */
    confirmBtnIcon?: string;
    /**
     * 是否内嵌
     */
    embed?: boolean;
    /**
     * 弹窗确认按钮名称
     */
    embedConfirmLabel?: string;
    /**
     * 弹窗确认按钮图标
     */
    embedConfirmIcon?: string;
    /**
     * 弹窗取消按钮名称
     */
    ebmedCancelLabel?: string;
    /**
     * 弹窗取消按钮图标
     */
    ebmedCancelIcon?: string;
    /**
     * 弹窗按钮图标
     */
    embedBtnIcon?: string;
    /**
     * 弹窗按钮文案
     */
    embedBtnLabel?: string;
    /**
     *  上传签名图片api, 仅在内嵌模式下生效
     */
    uploadApi?: SchemaApi;
}
export interface IInputSignatureProps extends FormControlProps {
}
interface IInputSignatureState {
    loading: boolean;
}
export default class InputSignatureComp extends React.Component<IInputSignatureProps, IInputSignatureState> {
    uploadFile(file: string, uploadApi: string): Promise<Payload>;
    handleChange(val: any): Promise<void>;
    render(): React.JSX.Element;
}
export declare class InputSignatureRenderer extends InputSignatureComp {
    static contextType: React.Context<IScopedContext>;
    constructor(props: IInputSignatureProps, context: IScopedContext);
    componentWillUnmount(): void;
}
export {};
