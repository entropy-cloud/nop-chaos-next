import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import type { SchemaApi } from '../../Schema';
/**
 * RichText
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/input-rich-text
 */
/**
 * 富文本输入框，支持 Froala 和 TinyMCE 编辑器，配置灵活，支持图片、视频、文件上传及多种边框模式。
 */
export interface AMISInputRichTextSchema extends AMISFormItem {
    /**
     * 指定为 rich-text 组件
     */
    type: 'input-rich-text';
    /**
     * 编辑器类型
     */
    vendor?: 'froala' | 'tinymce';
    /**
     * 图片保存 API 接口
     * @default /api/upload/image
     */
    receiver?: SchemaApi;
    /**
     * 视频保存 API 接口
     */
    videoReceiver?: SchemaApi;
    /**
     * 文件保存 API 接口
     */
    fileReceiver?: SchemaApi;
    /**
     * 接收器字段名
     */
    fileField?: string;
    /**
     * 边框模式
     */
    borderMode?: 'full' | 'half' | 'none';
    /**
     * 编辑器配置选项
     */
    options?: any;
}
export interface RichTextProps extends FormControlProps {
    options?: any;
    vendor?: 'froala' | 'tinymce';
}
export default class RichTextControl extends React.Component<RichTextProps, any> {
    static defaultProps: Partial<RichTextProps>;
    state: {
        config: null;
        focused: boolean;
    };
    constructor(props: RichTextProps);
    componentDidUpdate(prevProps: Readonly<RichTextProps>): void;
    uploadFile(blob: Blob, filename: string, mediaType: 'file' | 'image' | 'media'): Promise<{
        link: string;
        meta: any;
    }>;
    getConfig(props: RichTextProps): any;
    handleFocus(): void;
    handleBlur(): void;
    handleChange(value: any, submitOnChange?: boolean, changeImmediately?: boolean): Promise<void>;
    handleTinyMceLoaded(tinymce: any): void | Promise<void> | undefined;
    render(): React.JSX.Element;
}
export declare class RichTextControlRenderer extends RichTextControl {
}
