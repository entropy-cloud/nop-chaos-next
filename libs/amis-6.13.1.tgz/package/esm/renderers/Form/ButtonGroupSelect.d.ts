import React from 'react';
import { OptionsControlProps, AMISFormItemWithOptions } from 'amis-core';
import { Option, TestIdBuilder } from 'amis-core';
import { ActionObject } from 'amis-core';
import type { BadgeObject } from 'amis-ui';
import { AMISButtonGroupSchemaBase } from '../ButtonGroup';
/**
 * 按钮组控件。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/button-group
 */
/**
 * 按钮组选择器表单项，用于在表单中通过按钮组样式选择单个或多个选项。
 */
export interface AMISButtonGroupSelectSchema extends AMISFormItemWithOptions, AMISButtonGroupSchemaBase {
    type: 'button-group-select';
}
export interface ButtonGroupProps extends OptionsControlProps, Omit<AMISButtonGroupSelectSchema, 'size' | 'source' | 'type' | 'className' | 'descriptionClassName' | 'inputClassName' | 'btnClassName'> {
    options: Array<Option>;
    testIdBuilder?: TestIdBuilder;
}
export default class ButtonGroupControl extends React.Component<ButtonGroupProps, any> {
    static defaultProps: Partial<ButtonGroupProps>;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    handleToggle(option: Option): void;
    reload(subpath?: string, query?: any): void;
    getBadgeConfig(config: BadgeObject, item: Option): any;
    render(props?: Readonly<ButtonGroupProps>): React.JSX.Element;
}
export declare class ButtonGroupControlRenderer extends ButtonGroupControl {
}
