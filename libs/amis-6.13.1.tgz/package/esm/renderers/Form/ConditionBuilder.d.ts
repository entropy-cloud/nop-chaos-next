import React from 'react';
import { FormControlProps, Schema } from 'amis-core';
import { SchemaApi, SchemaTokenizeableString } from '../../Schema';
import { ConditionBuilderFields, ConditionBuilderFuncs, ConditionBuilderConfig } from 'amis-ui';
import { AMISIconSchema } from '../Icon';
import type { AMISInputFormulaSchemaBase } from './InputFormula';
import { AMISFormItem } from 'amis-core';
/**
 * 条件组合控件
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/condition-builder
 */
export interface AMISConditionBuilderSchema extends AMISFormItem {
    /**
     * 指定为 condition-builder 组件
     */
    type: 'condition-builder';
    /**
     * 内嵌模式
     */
    embed?: boolean;
    /**
     * 非内嵌模式时弹窗触发icon
     */
    pickerIcon?: AMISIconSchema;
    /**
     * 函数集合
     */
    funcs?: ConditionBuilderFuncs;
    /**
     * 字段集合
     */
    fields: ConditionBuilderFields;
    /**
     * 是否限制字段唯一
     */
    uniqueFields?: boolean;
    /**
     * 其他配置
     */
    config?: ConditionBuilderConfig;
    /**
     * 通过远程拉取配置项
     */
    source?: SchemaApi | SchemaTokenizeableString;
    /**
     * 展现模式
     */
    builderMode?: 'simple' | 'full';
    /**
     * 是否显示并或切换键按钮
     */
    showANDOR?: boolean;
    /**
     * 是否可拖拽
     */
    draggable?: boolean;
    addBtnVisibleOn?: string;
    /**
     * 表达式：控制按钮"添加条件组"的显示
     */
    addGroupBtnVisibleOn?: string;
    /**
     * 将字段输入控件变成公式编辑器。
     */
    formula?: AMISInputFormulaSchemaBase;
    /**
     * if 里面公式编辑器配置
     */
    formulaForIf?: any;
}
export interface ConditionBuilderProps extends FormControlProps, Omit<AMISConditionBuilderSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export default class ConditionBuilderControl extends React.PureComponent<ConditionBuilderProps> {
    renderEtrValue(schema: Schema, props: any): JSX.Element;
    renderPickerIcon(): JSX.Element | undefined;
    getAddBtnVisible(param: {
        depth: number;
        breadth: number;
    }): boolean | undefined;
    getAddGroupBtnVisible(param: {
        depth: number;
        breadth: number;
    }): boolean | undefined;
    validate(): any;
    render(): React.JSX.Element;
}
export declare class ConditionBuilderRenderer extends ConditionBuilderControl {
}
