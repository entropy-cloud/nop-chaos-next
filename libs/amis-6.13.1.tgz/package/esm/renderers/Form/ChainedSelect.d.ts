import React from 'react';
import { OptionsControlProps, Option, AMISFormItemWithOptions } from 'amis-core';
import { ActionObject } from 'amis-core';
/**
 * 链式下拉框
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/chain-select
 */
/**
 * 链式下拉框组件，用于根据前一次选择动态加载和展示下一级选项，支持多级联动选择，常用于省市区等多层级数据选择场景。
 */
export interface AMISChainedSelectSchema extends AMISFormItemWithOptions {
    /**
     * 指定为 chained-select 组件
     */
    type: 'chained-select';
}
export interface ChainedSelectProps extends OptionsControlProps, Omit<AMISChainedSelectSchema, 'options' | 'type' | 'source' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export interface StackItem {
    options: Array<Option>;
    parentId: any;
    loading: boolean;
    visible?: boolean;
}
export interface SelectState {
    stack: Array<StackItem>;
}
export default class ChainedSelectControl extends React.Component<ChainedSelectProps, SelectState> {
    static defaultProps: Partial<ChainedSelectProps>;
    state: SelectState;
    constructor(props: ChainedSelectProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: ChainedSelectProps): void;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    array2value(arr: Array<any>, isExtracted?: boolean): string | any[];
    loadMore(): void;
    handleChange(index: number, currentValue: any): Promise<void>;
    reload(subpath?: string, query?: any): void;
    renderStatic(displayValue?: string): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class ChainedSelectControlRenderer extends ChainedSelectControl {
}
