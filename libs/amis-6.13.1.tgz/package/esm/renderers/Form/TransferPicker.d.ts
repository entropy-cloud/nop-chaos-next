import { OptionsControlProps } from 'amis-core';
import React from 'react';
import { SpinnerExtraProps } from 'amis-ui';
import { BaseTransferRenderer, AMISTransferSchemaBase } from './Transfer';
import { ActionObject } from 'amis-core';
/**
 * TransferPicker 穿梭器的弹框形态
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/transfer-picker
 */
export interface AMISTransferPickerSchema extends AMISTransferSchemaBase, SpinnerExtraProps {
    type: 'transfer-picker';
    /**
     * 边框模式
     */
    borderMode?: 'full' | 'half' | 'none';
    /**
     * 弹窗大小
     */
    pickerSize?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
    onlyChildren?: boolean;
}
export interface TabsTransferProps extends OptionsControlProps, Omit<AMISTransferPickerSchema, 'type' | 'options' | 'inputClassName' | 'className' | 'descriptionClassName'> {
}
export declare class TransferPickerRenderer extends BaseTransferRenderer<TabsTransferProps> {
    dispatchEvent(name: string): void;
    onItemClick(item: Object): Promise<void>;
    doAction(action: ActionObject): void;
    render(): React.JSX.Element;
}
