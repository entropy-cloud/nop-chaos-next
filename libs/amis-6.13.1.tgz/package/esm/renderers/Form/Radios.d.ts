import React from 'react';
import { OptionsControlProps, Option, TestIdBuilder, AMISFormItemWithOptions } from 'amis-core';
import { ActionObject } from 'amis-core';
/**
 * Radio 单选框。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/radios
 */
/**
 * Radios 单选框组件，用于在多个选项中选择一个，支持自定义列数与选项样式。
 */
export interface AMISRadiosSchema extends AMISFormItemWithOptions {
    /**
     * 指定为 radios 组件
     */
    type: 'radios';
    /**
     * 每行显示多少个
     */
    columnsCount?: number;
}
export interface RadiosProps extends OptionsControlProps {
    placeholder?: any;
    columnsCount?: number;
    labelField?: string;
    /**
     * @deprecated 和checkbox的labelClassName有冲突，请用optionClassName代替
     */
    labelClassName?: string;
    /** 选项CSS类名 */
    optionClassName?: string;
    testIdBuilder?: TestIdBuilder;
}
export default class RadiosControl extends React.Component<RadiosProps, any> {
    static defaultProps: Partial<RadiosProps>;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    handleChange(option: Option): Promise<void>;
    reload(subpath?: string, query?: any): void;
    renderLabel(option: Option, { labelField }: any): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class RadiosControlRenderer extends RadiosControl {
    static defaultProps: {
        multiple: boolean;
        inline: boolean;
    };
}
