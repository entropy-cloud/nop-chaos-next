import React from 'react';
import { FormControlProps, ListenerAction, AMISFormItem, AMISSchemaCollection } from 'amis-core';
import { AMISIconSchema } from '../Icon';
import type { SpinnerExtraProps } from 'amis-ui';
/**
 * 开关组件，用于布尔值切换。支持开启/关闭状态的切换操作。
 */
export interface AMISSwitchSchema extends AMISFormItem {
    /**
     * 指定为 switch 组件
     */
    type: 'switch';
    /**
     * 开启时的值
     */
    trueValue?: boolean | string | number;
    /**
     * 关闭时的值
     */
    falseValue?: boolean | string | number;
    /**
     * 选项说明
     */
    option?: string;
    /**
     * 开启时显示内容
     */
    onText?: string | AMISIconSchema | AMISSchemaCollection;
    /**
     * 关闭时显示内容
     */
    offText?: string | AMISIconSchema | AMISSchemaCollection;
    /**
     * 开关尺寸
     */
    size?: 'sm' | 'md';
    /**
     * 是否加载中
     */
    loading?: boolean;
}
export interface SwitchProps extends FormControlProps, SpinnerExtraProps {
    option?: string;
    trueValue?: any;
    falseValue?: any;
    size?: 'sm';
    loading?: boolean;
}
export type SwitchRendererEvent = 'change';
export default class SwitchControl extends React.Component<SwitchProps, any> {
    static defaultProps: {
        trueValue: boolean;
        falseValue: boolean;
        optionAtLeft: boolean;
    };
    handleChange(checked: string | number | boolean): Promise<void>;
    getResult(): {
        on: any;
        off: any;
    };
    renderBody(children: any): React.JSX.Element;
    renderStatic(): React.JSX.Element;
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    render(): React.JSX.Element;
}
export declare class SwitchControlRenderer extends SwitchControl {
}
