import React from 'react';
import { FormControlProps } from 'amis-core';
import { AMISFormItem } from 'amis-core';
/**
 * 公式功能控件。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/formula
 */
/**
 * 用于根据公式自动计算并赋值给指定字段的表单控件。
 */
export interface AMISFormulaSchema extends AMISFormItem {
    /**
     * 指定为 formula 组件
     */
    type: 'formula';
    /**
     * 当某个按钮的目标指定为此值后，会触发一次公式应用
     */
    id?: string;
    /**
     * 触发公式的作用条件
     */
    condition?: string;
    /**
     * 是否自动应用
     */
    autoSet?: boolean;
    /**
     * 公式
     */
    formula?: string;
    /**
     * 是否初始应用
     */
    initSet?: boolean;
    /**
     * 字段名，公式结果将作用到此处指定的变量中去
     */
    name?: string;
}
export interface FormulaProps extends FormControlProps, Omit<AMISFormulaSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export default class FormulaControl extends React.Component<FormControlProps, any> {
    inited: boolean;
    unHook?: () => void;
    componentDidMount(): void;
    componentDidUpdate(prevProps: FormControlProps): void;
    componentWillUnmount(): void;
    handleFormInit(data: any): void;
    initSet(): any;
    autoSet(prevProps: FormControlProps): void;
    doAction(): void;
    render(): null;
}
export declare class FormulaControlRenderer extends FormulaControl {
}
