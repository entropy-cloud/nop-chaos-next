import React from 'react';
import { StateChangeOptions } from 'downshift';
import { OptionsControlProps, ActionObject } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { ActionSchema } from '../Action';
import { SchemaApi } from '../../Schema';
import type { AMISFormItemWithOptions, Option } from 'amis-core';
import type { ListenerAction } from 'amis-core';
export type InputTextAddOnObject = {
    /**
     * 按钮位置
     */
    position?: 'left' | 'right';
    [propName: string]: any;
};
export type InputTextAddOn = ActionSchema & InputTextAddOnObject;
/**
 * 文本输入框，支持建议、校验与多种展示模式。支持异步联想、前后缀、密码显隐、计数、大小写转换。
 */
export interface AMISInputTextSchema extends AMISFormItemWithOptions {
    /**
     * 指定为 text 组件
     */
    type: 'input-text' | 'input-email' | 'input-url' | 'input-password' | 'native-date' | 'native-time' | 'native-number';
    /**
     * 附加按钮
     */
    addOn?: InputTextAddOn;
    /**
     * 是否去除首尾空格
     */
    trimContents?: boolean;
    /**
     * 自动完成 API
     */
    autoComplete?: SchemaApi;
    /**
     * 原生自动完成
     * @default off
     */
    nativeAutoComplete?: string;
    /**
     * 边框模式
     */
    borderMode?: 'full' | 'half' | 'none';
    /**
     * 最小长度
     */
    minLength?: number;
    /**
     * 最大长度
     */
    maxLength?: number;
    /**
     * 是否显示字符计数
     */
    showCounter?: boolean;
    /**
     * 前缀文本
     */
    prefix?: string;
    /**
     * 后缀文本
     */
    suffix?: string;
    /**
     * 自动转换值
     */
    transform?: {
        /** 转小写 */
        lowerCase?: boolean;
        /** 转大写 */
        upperCase?: boolean;
    };
    /** control节点的CSS类名 */
    inputControlClassName?: string;
    /** 原生input标签的CSS类名 */
    nativeInputClassName?: string;
    /** 内容为空时清除值 */
    clearValueOnEmpty?: boolean;
}
export type InputTextRendererEvent = 'blur' | 'focus' | 'click' | 'change' | 'review' | 'encrypt' | 'enter';
export interface TextProps extends OptionsControlProps, SpinnerExtraProps {
    placeholder?: string | {
        [propName: string]: string;
    };
    addOn?: ActionObject & {
        position?: 'left' | 'right';
        label?: string;
        icon?: string;
        className?: string;
    };
    creatable?: boolean;
    clearable?: boolean;
    resetValue?: any;
    autoComplete?: any;
    allowInputText?: boolean;
    spinnerClassName?: string;
    revealPassword?: boolean;
    transform?: {
        lowerCase?: boolean;
        upperCase?: boolean;
    };
    /** control节点的CSS类名 */
    inputControlClassName?: string;
    /** 原生input标签的CSS类名 */
    nativeInputClassName?: string;
    popOverContainer?: any;
}
export interface TextState {
    isOpen?: boolean;
    inputValue?: string;
    isFocused?: boolean;
    revealPassword?: boolean;
}
export default class TextControl extends React.PureComponent<TextProps, TextState> {
    input?: HTMLInputElement;
    highlightedIndex?: any;
    unHook: Function;
    constructor(props: TextProps);
    static defaultProps: Partial<TextProps>;
    componentDidMount(): void;
    componentDidUpdate(prevProps: TextProps): void;
    componentWillUnmount(): void;
    inputRef(ref: any): void;
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    focus(): void;
    resetValue(): Promise<void>;
    clearValue(): Promise<void>;
    removeItem(index: number): void;
    handleClick(event: React.MouseEvent): Promise<void>;
    handleFocus(e: any): Promise<void>;
    handleBlur(e: any): Promise<void>;
    close(): void;
    handleInputChange(evt: React.ChangeEvent<HTMLInputElement>): Promise<void>;
    handleKeyDown(evt: React.KeyboardEvent<HTMLInputElement>): Promise<void>;
    handleChange(value: any): void;
    handleStateChange(changes: StateChangeOptions<any>): void;
    handleNormalInputChange(e: React.ChangeEvent<HTMLInputElement>): Promise<void>;
    normalizeValue(value: Option[] | Option | undefined | null): any;
    transformValue(value: string): string;
    loadAutoComplete(): void;
    reload(subpath?: string, query?: any): void;
    valueToString(value: any): string;
    renderOptionContent(value: any): string | number | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | null;
    getTarget(): HTMLElement | null | undefined;
    renderSugestMode(): React.JSX.Element;
    toggleRevealPassword(): Promise<void>;
    renderNormal(): JSX.Element;
    renderBody(body: JSX.Element): React.JSX.Element;
    /**
     * 处理input的自定义样式
     */
    render(): JSX.Element;
}
export declare function mapItemIndex(items: Array<any>, values: Array<any>, valueField?: string): any;
export declare class TextControlRenderer extends TextControl {
}
export declare class EmailControlRenderer extends TextControl {
}
export declare class UrlControlRenderer extends TextControl {
}
