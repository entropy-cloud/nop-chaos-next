import React from 'react';
import { FormControlProps, BaseSchemaWithoutType, FormBaseControlWithoutSize } from 'amis-core';
import type { ListenerAction } from 'amis-core';
/**
 * Editor 代码编辑器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/editor
 */
/**
 * Editor 代码编辑器表单组件，支持多种编程语言和高亮显示，用于输入和编辑代码内容，常用作表单中的代码输入项
 */
export interface AMISCodeEditorSchema extends BaseSchemaWithoutType, FormBaseControlWithoutSize {
    /**
     * 指定为 editor 组件
     */
    type: 'editor' | 'bat-editor' | 'c-editor' | 'coffeescript-editor' | 'cpp-editor' | 'csharp-editor' | 'css-editor' | 'dockerfile-editor' | 'fsharp-editor' | 'go-editor' | 'handlebars-editor' | 'html-editor' | 'ini-editor' | 'java-editor' | 'javascript-editor' | 'json-editor' | 'less-editor' | 'lua-editor' | 'markdown-editor' | 'msdax-editor' | 'objective-c-editor' | 'php-editor' | 'plaintext-editor' | 'postiats-editor' | 'powershell-editor' | 'pug-editor' | 'python-editor' | 'r-editor' | 'razor-editor' | 'ruby-editor' | 'sb-editor' | 'scss-editor' | 'sol-editor' | 'sql-editor' | 'swift-editor' | 'typescript-editor' | 'vb-editor' | 'xml-editor' | 'yaml-editor';
    /**
     * 语言类型
     */
    language?: 'bat' | 'c' | 'coffeescript' | 'cpp' | 'csharp' | 'css' | 'dockerfile' | 'fsharp' | 'go' | 'handlebars' | 'html' | 'ini' | 'java' | 'javascript' | 'json' | 'less' | 'lua' | 'markdown' | 'msdax' | 'objective-c' | 'php' | 'plaintext' | 'postiats' | 'powershell' | 'pug' | 'python' | 'r' | 'razor' | 'ruby' | 'sb' | 'scss' | 'shell' | 'sol' | 'sql' | 'swift' | 'typescript' | 'vb' | 'xml' | 'yaml';
    /**
     * 编辑器大小
     */
    size?: 'sm' | 'md' | 'lg' | 'xl' | 'xxl';
    /**
     * 是否显示全屏按钮
     */
    allowFullscreen?: boolean;
    /**
     * 编辑器实例回调
     */
    editorDidMount?: string;
}
export type EditorRendererEvent = 'blur' | 'focus';
export interface EditorProps extends FormControlProps {
    options?: object;
}
export default class EditorControl extends React.Component<EditorProps, any> {
    static defaultProps: Partial<EditorProps>;
    state: {
        focused: boolean;
    };
    editor: any;
    toDispose: Array<Function>;
    divRef: React.RefObject<HTMLDivElement | null>;
    constructor(props: EditorProps);
    componentWillUnmount(): void;
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    focus(): void;
    handleFocus(e: any): Promise<void>;
    handleBlur(e: any): Promise<void>;
    handleChange(e: any): Promise<void>;
    handleEditorMounted(editor: any, monaco: any): void;
    prevHeight: number;
    updateContainerSize(editor: any, monaco: any): void;
    render(): React.JSX.Element;
}
export declare const availableLanguages: string[];
export declare const EditorControls: Array<typeof EditorControl>;
export declare class EditorControlRenderer extends EditorControl {
    static defaultProps: {
        language: string;
        options?: object | undefined;
        render?: ((region: string, node: import("amis-core").SchemaNode, props?: import("amis-core").PlainObject) => JSX.Element) | undefined;
        env?: import("amis-core").RendererEnv | undefined;
        $path?: string | undefined;
        $schema?: any;
        testIdBuilder?: import("amis-core").TestIdBuilder | undefined;
        store?: import("amis-core").IIRendererStore | undefined;
        syncSuperStore?: boolean | undefined;
        data?: {
            [propName: string]: any;
        } | undefined;
        defaultData?: object | undefined;
        className?: any;
        style?: {
            [propName: string]: any;
        } | undefined;
        onBroadcast?: ((type: string, rawEvent: import("amis-core").RendererEvent<any>, ctx: any) => any) | undefined;
        dispatchEvent?: ((e: string | React.MouseEvent<any>, data: any, renderer?: React.Component<import("amis-core").RendererProps>, scoped?: import("amis-core").IScopedContext) => Promise<import("amis-core").RendererEvent<any>>) | undefined;
        mobileUI?: boolean | undefined;
        classnames?: import("amis-core").ClassNamesFn | undefined;
        classPrefix?: string | undefined;
        theme?: string | undefined;
        locale?: string | undefined;
        translate?: import("amis-core").TranslateFn<any> | undefined;
        onEvent?: {
            [propName: string]: {
                weight?: number;
                actions: import("amis-core").AMISAction[];
                debounce?: import("amis-core").debounceConfig;
                track?: import("amis-core").trackConfig;
            };
        } | undefined;
        statusStore?: ({
            visibleState: any;
            disableState: any;
            staticState: any;
        } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
            setVisible(key: string, value?: boolean): void;
            setDisable(key: string, value?: boolean): void;
            setStatic(key: string, value?: boolean): void;
            resetAll(): void;
        } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
            visibleState: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
            disableState: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
            staticState: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        }, {
            setVisible(key: string, value?: boolean): void;
            setDisable(key: string, value?: boolean): void;
            setStatic(key: string, value?: boolean): void;
            resetAll(): void;
        }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>) | undefined;
        onOpenDialog?: ((schema: import("amis-core").Schema, data: any) => Promise<any>) | undefined;
        name?: string | undefined;
        formStore?: import("amis-core").IFormStore | undefined;
        formItem?: import("amis-core").IFormItemStore | undefined;
        formInited?: boolean | undefined;
        formMode?: "default" | "normal" | "inline" | "horizontal" | "row" | undefined;
        formHorizontal?: import("amis-core").FormHorizontal | undefined;
        formLabelAlign?: import("packages/amis-core/lib/renderers/Item").LabelAlign | undefined;
        formLabelWidth?: number | string | undefined;
        defaultSize?: "xs" | "sm" | "md" | "lg" | "full" | undefined;
        size?: "xs" | "sm" | "md" | "lg" | "full" | undefined;
        labelAlign?: import("packages/amis-core/lib/renderers/Item").LabelAlign | undefined;
        labelWidth?: number | string | undefined;
        formLabelOverflow?: string | undefined;
        labelOverflow?: "default" | "ellipsis" | undefined;
        disabled?: boolean | undefined;
        btnDisabled?: boolean | undefined;
        defaultValue?: any;
        value?: any;
        prinstine?: any;
        setPrinstineValue?: ((value: any) => void) | undefined;
        onChange?: ((value: any, submitOnChange?: boolean, changeImmediately?: boolean) => void) | undefined;
        onBulkChange?: ((values: {
            [propName: string]: any;
        }, submitOnChange?: boolean, changeReason?: import("amis-core").DataChangeReason) => void) | undefined;
        addHook?: ((fn: Function, mode?: "validate" | "init" | "flush", enforce?: "prev" | "post") => () => void) | undefined;
        removeHook?: ((fn: Function, mode?: "validate" | "init" | "flush") => void) | undefined;
        renderFormItems?: ((schema: Partial<import("amis-core").FormSchemaBase>, region: string, props: any) => JSX.Element) | undefined;
        onFocus?: ((e: any) => void) | undefined;
        onBlur?: ((e: any) => void) | undefined;
        formItemValue?: any;
        getValue?: (() => any) | undefined;
        setValue?: ((value: any, key: string) => void) | undefined;
        inputClassName?: string | undefined;
        renderControl?: ((props: FormControlProps) => JSX.Element) | undefined;
        inputOnly?: boolean | undefined;
        renderLabel?: boolean | undefined;
        renderDescription?: boolean | undefined;
        sizeMutable?: boolean | undefined;
        wrap?: boolean | undefined;
        hint?: string | undefined;
        description?: string | undefined;
        descriptionClassName?: string | undefined;
        errors?: {
            [propName: string]: string;
        } | undefined;
        error?: string | undefined;
        showErrorMsg?: boolean | undefined;
    };
}
