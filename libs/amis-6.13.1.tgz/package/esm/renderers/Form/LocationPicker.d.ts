import React from 'react';
import { ThemeProps, AMISFormItem } from 'amis-core';
import { FormControlProps } from 'amis-core';
import { ActionObject } from 'amis-core';
/**
 * Location 选点组件
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/location
 */
export interface AMISLocationPickerSchema extends AMISFormItem {
    type: 'location-picker';
    /**
     * 选择地图类型
     */
    vendor?: 'baidu' | 'gaode' | 'tenxun';
    /**
     * 有的地图需要设置 ak 信息
     */
    ak?: string;
    /**
     * 是否自动选中当前地理位置
     */
    autoSelectCurrentLoc?: boolean;
    /**
     * 是否限制只能选中当前地理位置
     */
    onlySelectCurrentLoc?: boolean;
    /**
     * 开启只读模式后的占位提示
     */
    getLocationPlaceholder?: string;
    /**
     * 是否隐藏地图控制组件
     */
    hideViewControl?: boolean;
}
export interface LocationControlProps extends FormControlProps, Omit<ThemeProps, 'className'>, Omit<AMISLocationPickerSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
    value: any;
    onChange: (value: any) => void;
    vendor: 'baidu' | 'gaode' | 'tenxun';
    ak: string;
    coordinatesType: 'bd09' | 'gcj02';
}
export declare class LocationControl extends React.Component<LocationControlProps> {
    static defaultProps: {
        vendor: string;
        coordinatesType: string;
    };
    domRef: React.RefObject<HTMLDivElement | null>;
    state: {
        isOpened: boolean;
    };
    close(): void;
    open(): void;
    handleClick(): void;
    handleChange(value: any): Promise<void>;
    getParent(): HTMLElement | null | undefined;
    getTarget(): HTMLDivElement | null;
    doAction(action: ActionObject, data: object, throwErrors: boolean): any;
    renderStatic(displayValue?: string): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class LocationRenderer extends LocationControl {
}
