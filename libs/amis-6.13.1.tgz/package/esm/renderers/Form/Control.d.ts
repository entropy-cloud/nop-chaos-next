import React from 'react';
import { RendererProps, AMISFormItem, AMISSchemaCollection } from 'amis-core';
/**
 * Control 表单项包裹
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/control
 */
export interface AMISFormControlSchema extends AMISFormItem {
    /**
     * 指定为 control 组件
     */
    type: 'control';
    /**
     * FormItem 内容
     */
    body: AMISSchemaCollection;
}
export declare class ControlRenderer extends React.Component<RendererProps> {
    renderInput(): JSX.Element;
    render(): React.JSX.Element;
}
