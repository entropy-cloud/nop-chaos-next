import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import { BadgeObject } from 'amis-ui';
import { ActionObject } from 'amis-core';
/**
 * 单选框组件，用于单选场景。支持多个选项中的唯一选择。
 */
export interface AMISRadioSchema extends AMISFormItem {
    /**
     * 指定为 radio 组件
     */
    type: 'radio';
    /**
     * 选中时的值
     */
    trueValue?: boolean | string | number;
    /**
     * 未选中时的值
     */
    falseValue?: boolean | string | number;
    /**
     * 选项说明
     */
    option?: string;
    /**
     * 角标配置
     */
    badge?: BadgeObject;
    /**
     * 是否支持部分选中
     */
    partial?: boolean;
    /**
     * 选项类型
     */
    optionType?: 'default' | 'button';
}
export interface RadioProps extends FormControlProps, Omit<AMISRadioSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
    checked?: boolean;
    onRadioChange?: (value: any, ctx: any) => any;
}
export default class RadioControl extends React.Component<RadioProps, any> {
    static defaultProps: Partial<RadioProps>;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    dispatchChangeEvent(eventData?: any): Promise<void>;
    renderStatic(): React.JSX.Element;
    render(): React.JSX.Element;
}
export declare class RadioControlRenderer extends RadioControl {
}
