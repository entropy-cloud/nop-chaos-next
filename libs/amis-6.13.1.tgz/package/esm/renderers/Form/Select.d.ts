import React from 'react';
import { OptionsControlProps, Option, Api, ActionObject, TestIdBuilder, AMISFormItemWithOptions, AMISSpinnerConfig } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { SchemaApi } from '../../Schema';
import { AMISTransferSchema } from './Transfer';
import type { AMISClassName } from '../../Schema';
import type { TooltipObject } from 'amis-ui/lib/components/TooltipWrapper';
/**
 * 下拉选择框，支持单选/多选、异步加载选项、搜索过滤等功能。
 */
export interface AMISSelectSchema extends AMISFormItemWithOptions, AMISSpinnerConfig {
    /**
     * 指定为 select 组件
     */
    type: 'select' | 'multi-select';
    /**
     * 自动完成 API
     */
    autoComplete?: SchemaApi;
    /**
     * 菜单模板
     */
    menuTpl?: string;
    /**
     * 是否高亮无效值
     */
    showInvalidMatch?: boolean;
    /**
     * 边框模式
     */
    borderMode?: 'full' | 'half' | 'none';
    /**
     * 选择模式
     */
    selectMode?: 'table' | 'group' | 'tree' | 'chained' | 'associated';
    /**
     * 左侧选项
     */
    leftOptions?: Array<Option>;
    /**
     * 左侧模式
     */
    leftMode?: 'tree' | 'list';
    /**
     * 右侧模式
     */
    rightMode?: 'table' | 'list' | 'tree' | 'chained';
    /**
     * 搜索结果模式
     */
    searchResultMode?: 'table' | 'list' | 'tree' | 'chained';
    /**
     * 列配置
     */
    columns?: Array<any>;
    /**
     * 搜索结果列配置
     */
    searchResultColumns?: Array<any>;
    /**
     * 是否支持搜索
     */
    searchable?: boolean;
    /**
     * 搜索 API
     */
    searchApi?: SchemaApi;
    /**
     * 选项高度
     */
    itemHeight?: number;
    /**
     * 虚拟渲染阈值
     */
    virtualThreshold?: number;
    /**
     * 是否可全选
     */
    checkAll?: boolean;
    /**
     * 是否默认全选
     */
    defaultCheckAll?: boolean;
    /**
     * 全选文案
     */
    checkAllLabel?: string;
    /**
     * 最大标签数量
     */
    maxTagCount?: number;
    /**
     * 收纳标签配置
     */
    overflowTagPopover?: object;
    /**
     * 选项CSS类名
     */
    optionClassName?: AMISClassName;
    /**
     * 下拉框 Popover 设置
     */
    overlay?: {
        /**
         * 下拉框 Popover 的宽度设置，支持单位 '%'、'px'、'rem'、'em'、'vw', 支持相对写法如 '+20px'
         */
        width?: number | string;
        /**
         * 下拉框 Popover 的对齐方式
         */
        align?: 'left' | 'center' | 'right';
        /**
         * 检索函数
         */
        filterOption?: 'string';
    };
    testIdBuilder?: TestIdBuilder;
}
export interface SelectProps extends OptionsControlProps, SpinnerExtraProps {
    autoComplete?: Api;
    searchable?: boolean;
    showInvalidMatch?: boolean;
    defaultOpen?: boolean;
    mobileUI?: boolean;
    maxTagCount?: number;
    overflowTagPopover?: TooltipObject;
}
export type SelectRendererEvent = 'change' | 'blur' | 'focus' | 'add' | 'edit' | 'delete';
export default class SelectControl extends React.Component<SelectProps, any> {
    static defaultProps: Partial<SelectProps>;
    input: any;
    unHook: Function;
    lazyloadRemote: Function;
    lastTerm: string;
    constructor(props: SelectProps);
    componentDidUpdate(prevProps: SelectProps): void;
    componentWillUnmount(): void;
    inputRef(ref: any): void;
    focus(): void;
    getValue(value: Option | Array<Option> | string | void, additonalOptions?: Array<any>): string | void | Option | Option[];
    dispatchEvent(eventName: SelectRendererEvent, eventData?: any): Promise<void>;
    changeValue(value: Option | Array<Option> | string | void): Promise<void>;
    fetchCancel: Function | null;
    loadRemote(input: string, force?: boolean): Promise<(() => void) | {
        options: Option[];
    }>;
    mergeOptions(options: Array<object>): Option[];
    renderMenu(option: Option, state: any): JSX.Element;
    reload(subpath?: string, query?: any): void;
    option2value(): void;
    renderOtherMode(): React.JSX.Element;
    doAction(action: ActionObject, data: object, throwErrors: boolean): any;
    handleOptionAdd(idx?: number | Array<number>, value?: any, skipForm?: boolean, callback?: (value: any) => any): void;
    handleOptionEdit(value: Option, origin?: Option, skipForm?: boolean, callback?: (value: any) => any): void;
    handleOptionDelete(value: any, callback?: (value: any) => any): void;
    render(): React.JSX.Element;
}
export interface TransferDropDownProps extends OptionsControlProps, Omit<AMISTransferSchema, 'type' | 'options' | 'inputClassName' | 'className' | 'descriptionClassName'>, SpinnerExtraProps {
    borderMode?: 'full' | 'half' | 'none';
    mobileUI?: boolean;
}
export declare class SelectControlRenderer extends SelectControl {
}
export declare class MultiSelectControlRenderer extends SelectControl {
    static defaultProps: {
        multiple: boolean;
    };
}
