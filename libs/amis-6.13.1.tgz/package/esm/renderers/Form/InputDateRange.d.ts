import React from 'react';
import { FormControlProps } from 'amis-core';
import { ActionObject } from 'amis-core';
import type { ShortCuts } from 'amis-ui/lib/components/DatePicker';
import type { AMISFormItem, TestIdBuilder } from 'amis-core';
export interface AMISDateRangeSchemaBase extends AMISFormItem {
    /**
     * 分隔符
     */
    delimiter?: string;
    /**
     * 存储格式
     * @default X
     */
    format?: string;
    /**
     * 存储格式（新版）
     */
    valueFormat?: string;
    /**
     * 显示格式
     * @default YYYY-MM-DD
     */
    inputFormat?: string;
    /**
     * 显示格式（新版）
     */
    displayFormat?: string;
    /**
     * 是否拼接值
     */
    joinValues?: boolean;
    /**
     * 最大日期
     */
    maxDate?: string;
    /**
     * 最小日期
     */
    minDate?: string;
    /**
     * 最大跨度
     */
    maxDuration?: string;
    /**
     * 最小跨度
     */
    minDuration?: string;
    /**
     * 默认值
     */
    value?: any;
    /**
     * 边框模式
     */
    borderMode?: 'full' | 'half' | 'none';
    /**
     * 是否为内联模式
     */
    embed?: boolean;
    /**
     * 日期范围快捷键
     * @deprecated 3.1.0及以后版本废弃，建议用 shortcuts 属性。
     */
    ranges?: string | Array<ShortCuts>;
    /**
     * 日期范围快捷键
     */
    shortcuts?: string | Array<ShortCuts>;
    /**
     * 开始时间占位符
     */
    startPlaceholder?: string;
    /**
     * 日期范围结束时间-占位符
     */
    endPlaceholder?: string;
    /**
     * 是否启用游标动画，默认开启
     */
    animation?: boolean;
    /**
     * 日期数据处理函数，用来处理选择日期之后的值
     *
     * (value: moment.Moment, config: {type: 'start' | 'end'; originValue: moment.Moment, timeFormat: string}, props: any, data: any, moment: moment) => moment.Moment;
     */
    transform?: string;
    /**
     * 弹窗容器选择器
     */
    popOverContainerSelector?: string;
}
/**
 * DateRange 日期范围控件
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/date-range
 */
/**
 * 日期范围控件，支持选择开始和结束日期，可配置快捷键、占位符、时间格式等，适用于表单中的时间段选择
 */
export interface AMISInputDateRangeSchema extends AMISDateRangeSchemaBase {
    /**
     * 指定为日期范围控件
     */
    type: 'input-date-range' | 'input-datetime-range' | 'input-time-range';
}
export interface DateRangeProps extends FormControlProps, Omit<AMISInputDateRangeSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
    delimiter: string;
    format: string;
    valueFormat: string;
    joinValues: boolean;
    testIdBuilder?: TestIdBuilder;
}
export default class DateRangeControl extends React.Component<DateRangeProps> {
    static defaultProps: {
        format: string;
        joinValues: boolean;
        delimiter: string;
        animation: boolean;
    };
    dateRef?: any;
    constructor(props: DateRangeProps);
    componentDidUpdate(prevProps: DateRangeProps): void;
    getRef(ref: any): void;
    dispatchEvent(eventName: string): void;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    setData(value: any): void;
    handleChange(nextValue: any): Promise<void>;
    render(): React.JSX.Element;
}
export declare class DateRangeControlRenderer extends DateRangeControl {
    static defaultProps: {
        format: string;
        joinValues: boolean;
        delimiter: string;
        animation: boolean;
    };
}
export declare class DateTimeRangeControlRenderer extends DateRangeControl {
    static defaultProps: {
        inputFormat: string;
        format: string;
        joinValues: boolean;
        delimiter: string;
        animation: boolean;
    };
}
export declare class TimeRangeControlRenderer extends DateRangeControl {
    static defaultProps: {
        format: string;
        inputFormat: string;
        viewMode: string;
        /** shortcuts的兼容配置 */
        ranges: string;
        shortcuts: string;
        joinValues: boolean;
        delimiter: string;
        animation: boolean;
    };
}
