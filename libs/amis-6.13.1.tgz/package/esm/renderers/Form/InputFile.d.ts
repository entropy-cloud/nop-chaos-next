import React from 'react';
import { FormControlProps, AMISFormItem } from 'amis-core';
import { Payload, ApiObject, ApiString, ActionObject } from 'amis-core';
import { FileRejection } from 'react-dropzone';
import { SchemaApi, AMISClassName, SchemaTokenizeableString } from '../../Schema';
/**
 * File 文件上传控件
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/file
 */
/**
 * 文件上传控件，支持选择文件、上传文件、下载文件等操作，适用于需要文件上传的场景。
 */
export interface AMISInputFileSchema extends AMISFormItem {
    /**
     * 指定为 file 组件
     */
    type: 'input-file';
    /**
     * 按钮文案
     * @default 请选择文件
     */
    btnLabel?: string;
    /**
     * 接受的文件类型
     * @default text/plain
     */
    accept?: string;
    /**
     * 移动端拍照录像
     */
    capture?: string;
    /**
     * 是否转为 base64
     */
    asBase64?: boolean;
    /**
     * 是否转为 blob
     */
    asBlob?: boolean;
    /**
     * 是否自动上传
     */
    autoUpload?: boolean;
    /**
     * 并发数
     */
    concurrency?: number;
    /**
     * 分隔符
     */
    delimiter?: string;
    /**
     * 下载地址
     */
    downloadUrl?: SchemaApi;
    /**
     * 模板下载地址
     */
    templateUrl?: SchemaApi;
    /**
     * 文件字段名
     * @default file
     */
    fileField?: string;
    /**
     * 是否隐藏上传按钮
     */
    hideUploadButton?: boolean;
    /**
     * 最大文件数
     */
    maxLength?: number;
    /**
     * 最大文件大小
     */
    maxSize?: number;
    /**
     * 上传接口
     * @default /api/upload/file
     */
    receiver?: SchemaApi;
    /**
     * 是否分块上传
     */
    useChunk?: 'auto' | boolean;
    /**
     * 分块大小
     * @default 5242880
     */
    chunkSize?: number;
    /**
     * 分块开始接口
     * @default /api/upload/startChunk
     */
    startChunkApi?: string;
    /**
     * 默认 `/api/upload/chunk` 想自己存储时才需要关注。
     */
    chunkApi?: SchemaApi;
    /**
     * 默认 `/api/upload/finishChunkApi` 想自己存储时才需要关注。
     *
     * @default /api/upload/finishChunkApi
     */
    finishChunkApi?: SchemaApi;
    /**
     * 按钮 CSS 类名
     */
    btnClassName?: AMISClassName;
    /**
     * 上传按钮 CSS 类名
     */
    btnUploadClassName?: AMISClassName;
    /**
     * 是否为多选
     */
    multiple?: boolean;
    /**
     * 1. 单选模式：当用户选中某个选项时，选项中的 value 将被作为该表单项的值提交
     * 否则，整个选项对象都会作为该表单项的值提交。
     * 2. 多选模式：选中的多个选项的 `value` 会通过 `delimiter` 连接起来
     * 否则直接将以数组的形式提交值。
     */
    joinValues?: boolean;
    /**
     * 开启后将选中的选项 value 的值封装为数组，作为当前表单项的值。
     */
    extractValue?: boolean;
    /**
     * 清除时设置的值
     */
    resetValue?: any;
    /**
     * 上传后把其他字段同步到表单内部。
     */
    autoFill?: {
        [propName: string]: SchemaTokenizeableString;
    };
    /**
     * 初始化时是否把其他字段同步到表单内部。
     */
    initAutoFill?: boolean;
    /**
     * 接口返回的数据中，哪个用来当做值
     */
    valueField?: string;
    /**
     * 接口返回的数据中，哪个用来展示文件名
     */
    nameField?: string;
    /**
     * 接口返回的数据中哪个用来作为下载地址。
     */
    urlField?: string;
    /**
     * 按钮状态文案配置。
     */
    stateTextMap?: {
        init: string;
        pending: string;
        uploading: string;
        error: string;
        uploaded: string;
        ready: string;
    };
    /**
     * 说明文档内容配置
     */
    documentation?: string;
    /**
     * 说明文档链接配置
     */
    documentLink?: string;
    /**
     * 是否为拖拽上传
     */
    drag?: boolean;
    /**
     * 校验格式失败时显示的文字信息
     */
    invalidTypeMessage?: string;
    /**
     * 校验文件大小失败时显示的文字信息
     */
    invalidSizeMessage?: string;
}
export interface FileProps extends FormControlProps, Omit<AMISInputFileSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
    stateTextMap: {
        init: string;
        pending: string;
        uploading: string;
        error: string;
        uploaded: string;
        ready: string;
    };
}
export interface FileX extends File {
    state?: 'init' | 'error' | 'pending' | 'uploading' | 'uploaded' | 'invalid' | 'ready';
    progress?: number;
    id?: any;
}
export interface FileValue {
    filename?: string;
    value?: any;
    name?: string;
    url?: string;
    state: 'init' | 'error' | 'pending' | 'uploading' | 'uploaded' | 'invalid' | 'ready';
    id?: any;
    [propName: string]: any;
}
export interface FileState {
    uploading: boolean;
    files: Array<FileX | FileValue>;
    error?: string | null;
}
export declare function getNameFromUrl(url: string): string;
export type InputFileRendererEvent = 'change' | 'success' | 'fail' | 'remove';
export type InputFileRendererAction = 'clear';
export default class FileControl extends React.Component<FileProps, FileState> {
    static defaultProps: Partial<FileProps>;
    state: FileState;
    current: FileValue | FileX | null;
    resolve?: (value?: any) => void;
    emitValue: any;
    fileUploadCancelExecutors: Array<{
        file: any;
        executor: () => void;
    }>;
    initedFilled: boolean;
    toDispose: Array<() => void>;
    static valueToFile(value: string | FileValue, props: FileProps, files?: Array<FileX | FileValue>): FileValue | undefined;
    dropzone: React.RefObject<any>;
    constructor(props: FileProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: FileProps): void;
    componentWillUnmount(): void;
    handleDrop(files: Array<FileX>): void;
    handleDropRejected(rejectedFiles: FileRejection[], evt: React.DragEvent<any>): void;
    handleClickFile(file: FileX | FileValue, e: React.MouseEvent): void;
    downloadTpl(e: React.MouseEvent): void;
    handleApi(api: SchemaApi, payload?: object): void;
    handleSelect(): void;
    startUpload(retry?: boolean): void;
    toggleUpload(e: React.MouseEvent<HTMLButtonElement>): void;
    stopUpload(): void;
    retry(): void;
    tick(): void;
    sendFile(file: FileX, cb: (error: null | string, file?: FileX, obj?: FileValue) => void, onProgress: (progress: number) => void): void;
    removeFile(file: FileX | FileValue, index: number): Promise<void>;
    clearError(): void;
    onChange(changeImmediately?: boolean): Promise<void>;
    syncAutoFill(): void;
    uploadFile(file: FileX, receiver: string, params: object, config: Partial<FileProps> | undefined, onProgress: (progress: number) => void): Promise<Payload>;
    uploadBigFile(file: FileX, receiver: string, params: object, config: Partial<FileProps> | undefined, onProgress: (progress: number) => void): Promise<Payload>;
    _send(file: FileX, api: ApiObject | ApiString, options?: object, onProgress?: (progress: number) => void, maxRetryLimit?: number): Promise<Payload>;
    removeFileCanelExecutor(file: any, execute?: boolean): void;
    validate(): any;
    dispatchEvent(e: string, data?: Record<string, any>): Promise<import("amis-core").RendererEvent<any>>;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    sizeLimitTip(maxSize: number, file?: FileValue | FileX): any;
    render(): React.JSX.Element;
}
export declare class FileControlRenderer extends FileControl {
}
