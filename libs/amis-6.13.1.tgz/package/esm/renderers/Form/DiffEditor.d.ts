import React from 'react';
import { FormControlProps } from 'amis-core';
import { SchemaTokenizeableString } from '../../Schema';
import type { AMISFormItem, ListenerAction } from 'amis-core';
/**
 * Diff 编辑器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/diff
 */
export interface AMISDiffEditorSchema extends AMISFormItem {
    /**
     * 指定为 diff-editor 组件
     */
    type: 'diff-editor';
    /**
     * 左侧面板的值
     */
    diffValue?: SchemaTokenizeableString;
    /**
     * 语言
     */
    language?: string;
    /**
     * 编辑器配置
     */
    options?: any;
}
export type DiffEditorRendererEvent = 'blur' | 'focus';
export interface DiffEditorProps extends FormControlProps, Omit<AMISDiffEditorSchema, 'type' | 'className' | 'descriptionClassName' | 'inputClassName'> {
}
export interface DiffEditorState {
    focused: boolean;
}
export declare class DiffEditorRenderer extends React.Component<DiffEditorProps, DiffEditorState> {
    static defaultProps: Partial<DiffEditorProps>;
    state: {
        focused: boolean;
    };
    editor: any;
    constructor(props: DiffEditorProps);
    doAction(action: ListenerAction, data: any, throwErrors?: boolean, args?: any): void;
    focus(): void;
    handleFocus(e: any): Promise<void>;
    handleBlur(e: any): Promise<void>;
    handleChange(value: any): Promise<void>;
    handleEditorMounted(editor: any): void;
    render(): React.JSX.Element;
}
export declare class DiffEditorControlRenderer extends DiffEditorRenderer {
    static defaultProps: {
        [x: string]: any;
        render?: ((region: string, node: import("amis-core").SchemaNode, props?: import("amis-core").PlainObject) => JSX.Element) | undefined;
        env?: import("amis-core").RendererEnv | undefined;
        $path?: string | undefined;
        $schema?: any;
        testIdBuilder?: import("amis-core").TestIdBuilder | undefined;
        store?: import("amis-core").IIRendererStore | undefined;
        syncSuperStore?: boolean | undefined;
        data?: {
            [propName: string]: any;
        } | undefined;
        defaultData?: object | undefined;
        className?: any;
        style?: {
            [propName: string]: any;
        } | undefined;
        onBroadcast?: ((type: string, rawEvent: import("amis-core").RendererEvent<any>, ctx: any) => any) | undefined;
        dispatchEvent?: ((e: string | React.MouseEvent<any>, data: any, renderer?: React.Component<import("amis-core").RendererProps>, scoped?: import("amis-core").IScopedContext) => Promise<import("amis-core").RendererEvent<any>>) | undefined;
        mobileUI?: boolean | undefined;
        classnames?: import("amis-core").ClassNamesFn | undefined;
        classPrefix?: string | undefined;
        theme?: string | undefined;
        locale?: string | undefined;
        translate?: import("amis-core").TranslateFn<any> | undefined;
        onEvent?: {
            [propName: string]: {
                weight?: number;
                actions: import("amis-core").AMISAction[];
                debounce?: import("amis-core").debounceConfig;
                track?: import("amis-core").trackConfig;
            };
        } | undefined;
        statusStore?: ({
            visibleState: any;
            disableState: any;
            staticState: any;
        } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
            setVisible(key: string, value?: boolean): void;
            setDisable(key: string, value?: boolean): void;
            setStatic(key: string, value?: boolean): void;
            resetAll(): void;
        } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
            visibleState: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
            disableState: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
            staticState: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        }, {
            setVisible(key: string, value?: boolean): void;
            setDisable(key: string, value?: boolean): void;
            setStatic(key: string, value?: boolean): void;
            resetAll(): void;
        }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>) | undefined;
        onOpenDialog?: ((schema: import("amis-core").Schema, data: any) => Promise<any>) | undefined;
        name?: string | undefined;
        formStore?: import("amis-core").IFormStore | undefined;
        formItem?: import("amis-core").IFormItemStore | undefined;
        formInited?: boolean | undefined;
        formMode?: "default" | "normal" | "inline" | "horizontal" | "row" | undefined;
        formHorizontal?: import("amis-core").FormHorizontal | undefined;
        formLabelAlign?: import("packages/amis-core/lib/renderers/Item").LabelAlign | undefined;
        formLabelWidth?: number | string | undefined;
        defaultSize?: "xs" | "sm" | "md" | "lg" | "full" | undefined;
        size?: "xs" | "sm" | "md" | "lg" | "full" | undefined;
        labelAlign?: import("packages/amis-core/lib/renderers/Item").LabelAlign | undefined;
        labelWidth?: number | string | undefined;
        formLabelOverflow?: string | undefined;
        labelOverflow?: "default" | "ellipsis" | undefined;
        disabled?: boolean | undefined;
        btnDisabled?: boolean | undefined;
        defaultValue?: any;
        value?: any;
        prinstine?: any;
        setPrinstineValue?: ((value: any) => void) | undefined;
        onChange?: ((value: any, submitOnChange?: boolean, changeImmediately?: boolean) => void) | undefined;
        onBulkChange?: ((values: {
            [propName: string]: any;
        }, submitOnChange?: boolean, changeReason?: import("amis-core").DataChangeReason) => void) | undefined;
        addHook?: ((fn: Function, mode?: "validate" | "init" | "flush", enforce?: "prev" | "post") => () => void) | undefined;
        removeHook?: ((fn: Function, mode?: "validate" | "init" | "flush") => void) | undefined;
        renderFormItems?: ((schema: Partial<import("amis-core").FormSchemaBase>, region: string, props: any) => JSX.Element) | undefined;
        onFocus?: ((e: any) => void) | undefined;
        onBlur?: ((e: any) => void) | undefined;
        formItemValue?: any;
        getValue?: (() => any) | undefined;
        setValue?: ((value: any, key: string) => void) | undefined;
        inputClassName?: string | undefined;
        renderControl?: ((props: FormControlProps) => JSX.Element) | undefined;
        inputOnly?: boolean | undefined;
        renderLabel?: boolean | undefined;
        renderDescription?: boolean | undefined;
        sizeMutable?: boolean | undefined;
        wrap?: boolean | undefined;
        hint?: string | undefined;
        description?: string | undefined;
        descriptionClassName?: string | undefined;
        errors?: {
            [propName: string]: string;
        } | undefined;
        error?: string | undefined;
        showErrorMsg?: boolean | undefined;
        remark?: import("amis-core").AMISRemarkBase | undefined;
        label?: string | false | undefined;
        $$id?: string | undefined | undefined;
        id?: string | undefined | undefined;
        $ref?: string | undefined;
        disabledOn?: import("amis-core").AMISExpression | undefined;
        hidden?: boolean | undefined;
        hiddenOn?: import("amis-core").AMISExpression | undefined;
        visible?: boolean | undefined;
        visibleOn?: import("amis-core").AMISExpression | undefined;
        static?: boolean | undefined;
        staticOn?: import("amis-core").AMISExpression | undefined;
        staticPlaceholder?: import("amis-core").AMISTemplate | undefined;
        staticClassName?: import("amis-core").AMISClassName | undefined;
        staticLabelClassName?: import("amis-core").AMISClassName | undefined;
        staticInputClassName?: import("amis-core").AMISClassName | undefined;
        staticSchema?: any;
        editorSetting?: {
            behavior?: string;
            displayName?: string;
            mock?: any;
            [propName: string]: any;
        } | undefined;
        useMobileUI?: boolean | undefined;
        animations?: import("amis-core").AMISAnimations | undefined;
        testid?: string | undefined;
        desc?: import("amis-core").AMISTemplate | undefined;
        inline?: boolean | undefined;
        horizontal?: import("amis-core").FormHorizontal | undefined;
        placeholder?: string | {
            [propName: string]: string;
        } | undefined;
        row?: number | undefined;
        mode?: "normal" | "inline" | "horizontal" | undefined;
        options?: any;
        labelClassName?: import("amis-core").AMISClassName | undefined;
        extraName?: import("amis-core").AMISVariableName | undefined;
        labelRemark?: import("amis-core").AMISRemarkBase | undefined;
        submitOnChange?: boolean | undefined;
        readOnly?: boolean | undefined;
        readOnlyOn?: string | undefined;
        validateOnChange?: boolean | undefined;
        required?: boolean | undefined;
        validationErrors?: {
            isAlpha?: string;
            isAlphanumeric?: string;
            isEmail?: string;
            isFloat?: string;
            isInt?: string;
            isJson?: string;
            isLength?: string;
            isNumeric?: string;
            isRequired?: string;
            isUrl?: string;
            matchRegexp?: string;
            matchRegexp2?: string;
            matchRegexp3?: string;
            matchRegexp4?: string;
            matchRegexp5?: string;
            maxLength?: string;
            maximum?: string;
            minLength?: string;
            minimum?: string;
            isDateTimeSame?: string;
            isDateTimeBefore?: string;
            isDateTimeAfter?: string;
            isDateTimeSameOrBefore?: string;
            isDateTimeSameOrAfter?: string;
            isDateTimeBetween?: string;
            isTimeSame?: string;
            isTimeBefore?: string;
            isTimeAfter?: string;
            isTimeSameOrBefore?: string;
            isTimeSameOrAfter?: string;
            isTimeBetween?: string;
            [propName: string]: any;
        } | undefined;
        validations?: string | {
            isAlpha?: boolean;
            isAlphanumeric?: boolean;
            isEmail?: boolean;
            isFloat?: boolean;
            isInt?: boolean;
            isJson?: boolean;
            isLength?: number;
            isNumeric?: boolean;
            isRequired?: boolean;
            isUrl?: boolean;
            matchRegexp?: string;
            matchRegexp1?: string;
            matchRegexp2?: string;
            matchRegexp3?: string;
            matchRegexp4?: string;
            matchRegexp5?: string;
            maxLength?: number;
            maximum?: number;
            minLength?: number;
            minimum?: number;
            isDateTimeSame?: string | string[];
            isDateTimeBefore?: string | string[];
            isDateTimeAfter?: string | string[];
            isDateTimeSameOrBefore?: string | string[];
            isDateTimeSameOrAfter?: string | string[];
            isDateTimeBetween?: string | string[];
            isTimeSame?: string | string[];
            isTimeBefore?: string | string[];
            isTimeAfter?: string | string[];
            isTimeSameOrBefore?: string | string[];
            isTimeSameOrAfter?: string | string[];
            isTimeBetween?: string | string[];
            [propName: string]: any;
        } | undefined;
        clearValueOnHidden?: boolean | undefined;
        validateApi?: import("amis-core").AMISApi | undefined;
        autoFill?: {
            [propName: string]: string;
        } | {
            showSuggestion?: boolean;
            defaultSelection?: any;
            api?: import("amis-core").AMISApi;
            silent?: boolean;
            fillMapping?: {
                [propName: string]: any;
            };
            trigger?: "change" | "focus" | "blur";
            multiple?: boolean;
            mode?: "popOver" | "dialog" | "drawer";
            position?: string;
            size?: string;
            columns?: Array<any>;
            filter?: import("amis-core").AMISFormBase;
            labelField?: string;
            nameField?: string;
        } | undefined;
        initAutoFill?: boolean | "fillIfNotSet" | undefined;
        language?: string | undefined;
        diffValue?: SchemaTokenizeableString | undefined;
    };
}
