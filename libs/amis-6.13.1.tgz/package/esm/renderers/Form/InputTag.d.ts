import React from 'react';
import { OptionsControlProps, Option } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { ActionObject } from 'amis-core';
import { AMISTooltipWrapperSchema } from '../TooltipWrapper';
import { AMISFormItemWithOptions } from 'amis-core';
/**
 * Tag 输入框
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/form/tag
 */
/**
 * Tag输入组件，支持自定义标签、下拉选择、最大标签数、标签文本长度限制及批量添加。
 */
export interface AMISInputTagSchema extends AMISFormItemWithOptions {
    /**
     * 指定为 tag 组件
     */
    type: 'input-tag';
    /**
     * 选项提示信息
     */
    optionsTip?: string;
    /**
     * 是否为下拉模式
     */
    dropdown?: boolean;
    /**
     * 允许添加的标签最大数量
     */
    max?: number;
    /**
     * 单个标签最大文本长度
     */
    maxTagLength?: number;
    /**
     * 标签最大展示数量
     */
    maxTagCount?: number;
    /**
     * 收纳标签配置
     */
    overflowTagPopover?: AMISTooltipWrapperSchema;
    /** 是否开启批量添加模式 */
    enableBatchAdd?: boolean;
    /**
     * 批量添加分隔符
     * @default "-"
     */
    separator?: string;
}
export type InputTagValidationType = 'max' | 'maxLength';
export interface TagProps extends OptionsControlProps, SpinnerExtraProps {
    placeholder?: string;
    clearable: boolean;
    resetValue?: any;
    optionsTip: string;
    dropdown?: boolean;
    /** 是否支持批量输入 */
    enableBatchAdd: boolean;
    /** 开启批量添加后，输入多个标签的分隔符，支持传入多个符号，默认为英文逗号 */
    separator?: string;
    /** 允许添加的tag的最大数量 */
    max?: number;
    /** 单个标签的最大文本长度 */
    maxTagLength?: number;
    /** 文本输入后校验失败的callback */
    onInputValidateFailed?(value: string | string[], validationType: InputTagValidationType): void;
}
export interface TagState {
    inputValue: string;
    isFocused?: boolean;
    isOpened?: boolean;
    selectedOptions: Option[];
    cacheOptions: Option[];
}
export default class TagControl extends React.PureComponent<TagProps, TagState> {
    input: React.RefObject<any>;
    static defaultProps: {
        resetValue: string;
        labelField: string;
        valueField: string;
        multiple: boolean;
        placeholder: string;
        optionsTip: string;
        separator: string;
    };
    constructor(props: TagProps);
    componentDidUpdate(prevProps: TagProps): void;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    dispatchEvent(eventName: string, eventData?: any): Promise<boolean>;
    /** 处理输入的内容 */
    normalizeInputValue(inputValue: string): Option[];
    normalizeOptions(options: Option[]): string | any[];
    /** 输入的内容和存量的内容合并，过滤掉value值相同的 */
    normalizeMergedValue(inputValue: string, normalized?: boolean): string | any[];
    validateInputValue(inputValue: string): boolean;
    getValue(type?: 'push' | 'pop' | 'normal', option?: any, selectedOptions?: Option[]): string | any[];
    addItem(option: Option): Promise<void>;
    addItem2(option: Option): void;
    isExist(inputValue: string): boolean;
    addSelection(): void;
    onConfirm(): Promise<void>;
    handleFocus(e: any): Promise<void>;
    handleBlur(e: any): Promise<void>;
    close(): void;
    handleInputChange(text: string): void;
    handleChange(value: Array<Option>): Promise<void>;
    renderItem(item: Option): any;
    handleKeyDown(evt: React.KeyboardEvent<HTMLInputElement>): Promise<void>;
    handleOptionChange(option: Option): void;
    getTarget(): any;
    getParent(): any;
    reload(subpath?: string, query?: any): void;
    isReachMax(): boolean;
    isReachMaxFromState(): boolean;
    render(): React.JSX.Element;
}
export declare class TagControlRenderer extends TagControl {
}
