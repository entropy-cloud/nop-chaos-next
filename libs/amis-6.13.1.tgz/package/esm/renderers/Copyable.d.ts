/**
 * @file scoped.jsx.
 * @author fex
 */
import React from 'react';
import { RendererProps } from 'amis-core';
import { SchemaIcon, SchemaTpl } from '../Schema';
export interface AMISCopyableObject {
    /**
     * 配置图标
     */
    icon?: SchemaIcon;
    /**
     * 配置复制时的内容模板
     */
    content?: SchemaTpl;
    /**
     * 提示文字内容
     */
    tooltip?: string;
}
export type AMISCopyable = boolean | AMISCopyableObject;
export type SchemaCopyableObject = AMISCopyableObject;
export type SchemaCopyable = AMISCopyable;
export interface CopyableProps extends RendererProps {
    name?: string;
    label?: string;
    copyable: SchemaCopyable;
    tooltipContainer?: any;
}
export declare const HocCopyable: () => (Component: React.ComponentType<any>) => any;
export default HocCopyable;
