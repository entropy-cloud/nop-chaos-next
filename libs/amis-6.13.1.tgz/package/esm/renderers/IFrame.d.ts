import React from 'react';
import { RendererProps, AMISSchemaBase } from 'amis-core';
import { IScopedContext } from 'amis-core';
import { SchemaUrlPath } from '../Schema';
/**
 * IFrame 渲染器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/iframe
 */
/**
 * IFrame 组件，用于嵌入外部页面。支持高度/边框/沙箱设置。
 */
export interface AMISIFrameSchema extends AMISSchemaBase {
    type: 'iframe';
    /**
     * 页面地址
     */
    src: SchemaUrlPath;
    width?: number | string;
    height?: number | string;
    allow?: string;
    name?: string;
    referrerpolicy?: 'no-referrer' | 'no-referrer-when-downgrade' | 'origin' | 'origin-when-cross-origin' | 'same-origin' | 'strict-origin' | 'strict-origin-when-cross-origin' | 'unsafe-url';
    sandbox?: string;
}
export interface IFrameProps extends RendererProps, Omit<AMISIFrameSchema, 'type' | 'className'> {
    inDragging?: boolean;
}
export default class IFrame extends React.Component<IFrameProps, object> {
    IFrameRef: React.RefObject<HTMLIFrameElement | null>;
    static propsList: Array<string>;
    static defaultProps: Partial<IFrameProps>;
    state: {
        width: string | number;
        height: string | number;
    };
    componentDidMount(): void;
    componentDidUpdate(prevProps: IFrameProps): void;
    componentWillUnmount(): void;
    /** 校验URL是否合法 */
    validateURL(url: any): boolean;
    onMessage(e: MessageEvent): Promise<void>;
    onLoad(): void;
    reload(subpath?: any, query?: any): void;
    receive(values: object): void;
    postMessage(type: string, data: any): void;
    render(): React.JSX.Element;
}
export declare class IFrameRenderer extends IFrame {
    static contextType: React.Context<IScopedContext>;
    constructor(props: IFrameProps, context: IScopedContext);
    componentWillUnmount(): void;
}
