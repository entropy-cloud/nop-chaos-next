/**
 * @file scoped.jsx.
 * @author fex
 */
import React from 'react';
import { RendererProps } from 'amis-core';
import { AMISPopOverBase } from 'amis-core';
export interface AMISPopOver extends AMISPopOverBase {
    type: 'popOver';
}
export type SchemaPopOverObject = AMISPopOver;
export type SchemaPopOver = boolean | AMISPopOver;
export interface PopOverProps extends RendererProps {
    name?: string;
    label?: string;
    popOver: boolean | SchemaPopOverObject;
    onPopOverOpened: (popover: any) => void;
    onPopOverClosed: (popover: any) => void;
    textOverflow?: 'noWrap' | 'ellipsis' | 'default';
}
export interface PopOverState {
    isOpened: boolean;
}
export declare const HocPopOver: (config?: {
    targetOutter?: boolean;
    position?: string;
}) => (Component: React.ComponentType<any>) => any;
export default HocPopOver;
