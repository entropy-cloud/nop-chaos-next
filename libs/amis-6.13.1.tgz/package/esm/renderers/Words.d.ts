/**
 * @file Words
 */
import React from 'react';
import { RendererProps, AMISSchemaBase } from 'amis-core';
import { SchemaObject } from '../Schema';
import { AMISTagSchema } from './Tag';
type Words = string | string[];
/**
 * Words
 */
/**
 * Tags 用来展示一组标签文字，可以配置展开和收起。
 */
export interface AMISWordsSchema extends AMISSchemaBase {
    type: 'words' | 'tags';
    /**
     * 展示限制, 为0时也无限制
     */
    limit?: number;
    /**
     * 展示文字
     */
    expendButtonText?: string;
    /**
     * 展示文字
     */
    expendButton?: SchemaObject;
    /**
     * 收起文字
     */
    collapseButtonText?: string;
    /**
     * 展示文字
     */
    collapseButton?: SchemaObject;
    /**
     * tags数据
     */
    words: Words;
    /**
     * useTag 当数据是数组时，是否使用tag的方式展示
     */
    inTag?: boolean | AMISTagSchema;
    /**
     * 分割符
     */
    delimiter?: string;
    /**
     * 标签模板
     */
    labelTpl?: string;
}
export interface WordsProps extends RendererProps, Omit<AMISWordsSchema, 'type' | 'className'> {
}
export declare class WordsField extends React.Component<WordsProps, object> {
    static defaultProps: Partial<WordsProps>;
    state: {
        isExpend: boolean;
    };
    toggleExpend(): void;
    getLimit(words: Words): number;
    handleItemClick(e: React.MouseEvent<HTMLSpanElement>): void;
    renderContent(words: Words): string | React.JSX.Element[];
    renderAll(words: Words, hasBtn?: boolean): React.JSX.Element;
    renderPart(words: Words): React.JSX.Element;
    getWords(): any;
    render(): React.JSX.Element | null;
}
export declare class WordsRenderer extends WordsField {
}
export declare class TagsRenderer extends WordsField {
    static defaultProps: {
        inTag: boolean;
    };
}
export {};
