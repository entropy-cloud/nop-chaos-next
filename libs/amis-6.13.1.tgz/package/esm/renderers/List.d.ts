import React from 'react';
import Sortable from 'sortablejs';
import { ScopedContext } from 'amis-core';
import { SpinnerExtraProps } from 'amis-ui';
import { IListStore, RendererProps, SchemaNode, ActionObject, AMISRemarkBase } from 'amis-core';
import { TableCell } from './Table';
import { AMISCopyable } from './Copyable';
import { ActionSchema } from './Action';
import type { AMISButtonSchema, AMISClassName, AMISExpression, AMISLegacyActionSchema, AMISLocalSource, AMISSchemaBase, AMISSchemaCollection, AMISTemplate, AMISUrlPath, IItem, IScopedContext } from 'amis-core';
import type { OnEventProps, AMISSchema, AMISPopOverBase } from 'amis-core';
import { AMISQuickEdit } from './QuickEdit';
/**
 * 列表字段配置，不指定类型默认就是文本
 */
export type AMISListFieldBase = {
    /**
     * 字段标签名称
     */
    label?: string;
    /**
     * 标签CSS类名
     */
    labelClassName?: AMISClassName;
    /**
     * 内层组件CSS类名
     */
    innerClassName?: AMISClassName;
    /**
     * 绑定字段名
     */
    name?: string;
    /**
     * 查看详情配置
     */
    popOver?: AMISPopOverBase;
    /**
     * 快速编辑配置
     */
    quickEdit?: AMISQuickEdit;
    /**
     * 配置点击复制功能
     */
    copyable?: AMISCopyable;
};
export type ListBodyFieldObject = AMISListFieldBase;
export type AMISListField = AMISSchema & AMISListFieldBase;
export type ListBodyField = AMISListField;
export interface AMISListItemBase extends AMISSchemaBase {
    actions?: Array<AMISButtonSchema>;
    /**
     * 操作位置，默认在右侧，设置成左侧。
     */
    actionsPosition?: 'left' | 'right';
    /**
     * 图片地址
     */
    avatar?: AMISUrlPath;
    /**
     * 内容区域
     */
    body?: Array<AMISListField>;
    /**
     * 描述
     */
    desc?: AMISTemplate;
    /**
     * tooltip 说明
     */
    remark?: AMISRemarkBase;
    /**
     * 标题
     */
    title?: AMISTemplate;
    /**
     * 副标题
     */
    subTitle?: AMISTemplate;
}
export interface AMISListBase extends AMISSchemaBase {
    /**
     * 标题
     */
    title?: AMISTemplate;
    /**
     * 底部区域
     */
    footer?: AMISSchemaCollection;
    /**
     * 底部区域类名
     */
    footerClassName?: AMISClassName;
    /**
     * 顶部区域
     */
    header?: AMISSchemaCollection;
    /**
     * 顶部区域类名
     */
    headerClassName?: AMISClassName;
    /**
     * 单条数据展示内容配置
     */
    listItem?: AMISListItemBase;
    /**
     * 数据源: 绑定当前环境变量
     *
     * @default ${items}
     */
    source?: AMISLocalSource;
    /**
     * 是否显示底部
     */
    showFooter?: boolean;
    /**
     * 是否显示头部
     */
    showHeader?: boolean;
    /**
     * 无数据提示
     *
     * @default 暂无数据
     */
    placeholder?: AMISTemplate;
    /**
     * 是否隐藏勾选框
     */
    hideCheckToggler?: boolean;
    /**
     * 是否固顶
     */
    affixHeader?: boolean;
    /**
     * 是否固底
     */
    affixFooter?: boolean;
    /**
     * 配置某项是否可点选
     */
    itemCheckableOn?: AMISExpression;
    /**
     * 配置某项是否可拖拽排序，前提是要开启拖拽功能
     */
    itemDraggableOn?: AMISExpression;
    /**
     * 点击列表单行时，是否选择
     */
    checkOnItemClick?: boolean;
    /**
     * 可以用来作为值的字段
     */
    valueField?: string;
    /**
     * 大小
     */
    size?: 'sm' | 'base';
    /**
     * 点击列表项的行为
     */
    itemAction?: AMISLegacyActionSchema;
    /**
     * 是否显示右侧字母索引条
     */
    showIndexBar?: boolean;
    /**
     * 索引依据字段
     */
    indexField?: string;
    /**
     * 索引条偏移量
     */
    indexBarOffset?: number;
}
/**
 * 列表展示组件，用于展示数据列表。支持拖拽排序、选择、操作按钮等功能。
 */
export interface AMISListSchema extends AMISListBase {
    /**
     * 指定为 List 列表展示控件。
     */
    type: 'list' | 'static-list';
}
export interface Column {
    type: string;
    [propName: string]: any;
}
export interface ListProps extends RendererProps, Omit<AMISListSchema, 'type' | 'className'>, SpinnerExtraProps {
    store: IListStore;
    selectable?: boolean;
    selected?: Array<any>;
    draggable?: boolean;
    items?: Array<object>;
    fullItems?: Array<object>;
    onSelect: (selectedItems: Array<object>, unSelectedItems: Array<object>) => void;
    onItemChange?: (item: object, diff: object, rowIndex: string) => void;
    onSave?: (items: Array<object> | object, diff: Array<object> | object, rowIndexes: Array<number> | number, unModifiedItems?: Array<object>, rowOrigins?: Array<object> | object, options?: {
        resetOnFailed?: boolean;
        reload?: string;
    }) => void;
    onSaveOrder?: (moved: Array<object>, items: Array<object>) => void;
    onQuery: (values: object) => any;
}
export interface ListState {
    currentLetter?: string;
}
export default class List extends React.Component<ListProps, ListState> {
    static propsList: Array<keyof ListProps>;
    static defaultProps: Partial<ListProps>;
    dragTip?: HTMLElement;
    sortable?: Sortable;
    parentNode?: any;
    body?: any;
    renderedToolbars: Array<string>;
    private observer;
    itemRefs: Array<{
        element: HTMLElement;
        letter: string;
        isIntersecting?: boolean;
    }>;
    userClick: boolean;
    userClickTimer: any;
    constructor(props: ListProps);
    static syncItems(store: IListStore, props: ListProps, prevProps?: ListProps): boolean;
    componentDidMount(): void;
    componentDidUpdate(prevProps: ListProps): void;
    componentWillUnmount(): void;
    private getIndexDataField;
    bodyRef(ref: HTMLDivElement): void;
    getPopOverContainer(): HTMLElement | null;
    handleAction(e: React.UIEvent<any> | undefined, action: ActionObject, ctx: object): any;
    handleCheck(item: IItem): void;
    handleCheckAll(): void;
    syncSelected(): void;
    handleQuickChange(item: IItem, values: object, saveImmediately?: boolean | any, savePristine?: boolean, options?: {
        resetOnFailed?: boolean;
        reload?: string;
    }): void;
    handleSave(): void;
    handleSaveOrder(): void;
    reset(): void;
    bulkUpdate(value: any, items: Array<object>): void;
    getSelected(): any[];
    dragTipRef(ref: any): void;
    initDragging(): void;
    destroyDragging(): void;
    renderActions(region: string): React.JSX.Element | null;
    renderHeading(): React.JSX.Element | null;
    renderHeader(): React.JSX.Element | React.JSX.Element[] | null;
    renderFooter(): React.JSX.Element | React.JSX.Element[] | null;
    renderCheckAll(): React.JSX.Element | null;
    renderDragToggler(): React.JSX.Element | null;
    renderToolbar(toolbar: SchemaNode, index: number): React.JSX.Element | null | undefined;
    renderListItem(index: number, template: AMISListItemBase | undefined, item: IItem, itemClassName: string): React.ReactNode;
    handleLetterClick(letter: string): void;
    render(): React.JSX.Element;
    private observeItems;
    scrollObserver(entries: IntersectionObserverEntry[]): void;
    setItemRef(index: number, item: IItem, ref: HTMLElement | null): void;
}
export declare class ListRenderer extends List {
    dragging: boolean;
    selectable: boolean;
    selected: boolean;
    title?: string;
    subTitle?: string;
    desc?: string;
    avatar?: string;
    avatarClassName?: string;
    body?: SchemaNode;
    actions?: Array<ActionObject>;
    onCheck: (item: IItem) => void;
    static contextType: React.Context<IScopedContext>;
    context: React.ContextType<typeof ScopedContext>;
    constructor(props: ListProps, scoped: IScopedContext);
    componentWillUnmount(): void;
    receive(values: any, subPath?: string): any;
    reload(subPath?: string, query?: any, ctx?: any, silent?: boolean, replace?: boolean, args?: any): Promise<any>;
    setData(values: any, replace?: boolean, index?: number | string, condition?: any): Promise<any>;
    getData(): any;
    hasModifiedItems(): number;
    doAction(action: ActionObject, ctx: any, throwErrors: boolean, args: any): Promise<any>;
}
export interface ListItemProps extends RendererProps, Omit<AMISListItemBase, 'type' | 'className'> {
    hideCheckToggler?: boolean;
    item: IItem;
    itemIndex?: number;
    checkable?: boolean;
    checkOnItemClick?: boolean;
    itemAction?: ActionSchema;
    onEvent?: OnEventProps['onEvent'];
    hasClickActions?: boolean;
    itemRef?: (index: number, item: IItem, ref: HTMLElement | null) => void;
}
export declare class ListItem extends React.Component<ListItemProps> {
    static defaultProps: Partial<ListItemProps>;
    static propsList: Array<string>;
    constructor(props: ListItemProps);
    handleClick(e: React.MouseEvent<HTMLDivElement>): void;
    handleCheck(): void;
    handleAction(e: React.UIEvent<any>, action: ActionObject, ctx: object): void;
    handleQuickChange(values: object, saveImmediately?: boolean, savePristine?: boolean, options?: {
        resetOnFailed?: boolean;
        reload?: string;
    }): void;
    renderLeft(): React.JSX.Element | null;
    renderRight(): React.JSX.Element | null;
    renderChild(node: AMISSchema, region?: string, key?: any): React.ReactNode;
    itemRender(field: any, index: number, len: number, props: any): React.JSX.Element | null;
    renderField(region: string, field: any, key: any, props: any): React.JSX.Element | null;
    renderBody(): React.ReactNode;
    render(): React.JSX.Element;
}
export declare class ListItemRenderer extends ListItem {
    static propsList: string[];
}
export declare class ListItemFieldRenderer extends TableCell {
    static defaultProps: {
        wrapperComponent: string;
    };
    static propsList: string[];
    render(): React.JSX.Element;
}
