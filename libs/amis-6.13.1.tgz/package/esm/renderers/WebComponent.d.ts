import React from 'react';
import { AMISSchemaBase, RendererProps, AMISSchemaCollection } from 'amis-core';
/**
 * WebComponent 容器渲染器。
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/web-component
 */
/**
 * Web 组件，用于集成自定义 WebComponent。支持属性与事件绑定。
 */
export interface AMISWebComponentSchema extends AMISSchemaBase {
    /**
     * 指定为 web-component 组件
     */
    type: 'web-component';
    /**
     * HTML 标签名
     */
    tag: string;
    /**
     * 子内容配置
     */
    body: AMISSchemaCollection;
    /**
     * 传递给 Web 组件的属性
     */
    props?: {
        [propName: string]: any;
    };
}
export default class WebComponent extends React.Component<RendererProps> {
    renderBody(): JSX.Element | null;
    render(): React.JSX.Element;
}
export declare class WebComponentRenderer extends WebComponent {
}
