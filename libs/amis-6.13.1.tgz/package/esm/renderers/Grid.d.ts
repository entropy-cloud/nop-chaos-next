import React from 'react';
import { FormHorizontal, RendererProps, AMISSchemaCollection } from 'amis-core';
import { AMISClassName } from '../Schema';
import { SpinnerExtraProps } from 'amis-ui';
import { AMISSchemaBase } from 'amis-core';
export declare const ColProps: string[];
export type AMISGridColumn = {
    id?: string;
    /**
     * 极小屏幕宽度占比
     */
    xs?: number | 'auto';
    /**
     * 小屏幕宽度占比
     */
    sm?: number | 'auto';
    /**
     * 中等屏幕宽度占比
     */
    md?: number | 'auto';
    /**
     * 大屏幕宽度占比
     */
    lg?: number | 'auto';
    /**
     * 垂直对齐方式
     */
    valign?: 'top' | 'middle' | 'bottom' | 'between';
    /**
     * 子表单项展示方式
     */
    mode?: 'normal' | 'inline' | 'horizontal';
    /**
     * 水平排版宽度占比配置
     */
    horizontal?: FormHorizontal;
    /**
     * 列内容配置
     */
    body?: AMISSchemaCollection;
    /**
     * 列CSS类名
     */
    columnClassName?: AMISClassName;
    /**
     * 自定义样式
     */
    style?: any;
    /**
     * 包装器自定义样式
     */
    wrapperCustomStyle?: any;
    /**
     * 主题样式配置
     */
    themeCss?: any;
};
export type ColumnNode = AMISGridColumn;
export interface ColumnArray extends Array<ColumnNode> {
}
/**
 * Grid 网格布局组件，用于创建响应式网格系统
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/grid
 */
/**
 * 栅格布局组件，用于按列布局子元素。支持响应式断点与列间距配置。
 */
export interface AMISGridSchema extends AMISSchemaBase {
    /**
     * 指定为 grid 组件
     */
    type: 'grid';
    /**
     * 列配置数组，定义每列的布局和内容
     */
    columns: Array<AMISGridColumn>;
    /**
     * 列之间的水平间距
     */
    gap?: 'xs' | 'sm' | 'base' | 'none' | 'md' | 'lg';
    /**
     * 垂直对齐方式
     */
    valign?: 'top' | 'middle' | 'bottom' | 'between';
    /**
     * 水平对齐方式
     */
    align?: 'left' | 'right' | 'between' | 'center';
}
export interface GridProps extends RendererProps, Omit<AMISGridSchema, 'type' | 'className' | 'columnClassName'>, SpinnerExtraProps {
    itemRender?: (item: any, index: number, length: number, props: any) => JSX.Element;
}
export default class Grid<T> extends React.Component<GridProps & T, object> {
    static propsList: Array<string>;
    static defaultProps: {};
    renderChild(region: string, key: number, column: AMISGridColumn, length: number, props?: any): JSX.Element;
    renderColumn(column: ColumnNode, key: number, length: number): React.JSX.Element;
    renderColumns(columns: ColumnArray): React.JSX.Element[] | null;
    render(): React.JSX.Element;
}
export declare class GridRenderer extends Grid<{}> {
}
