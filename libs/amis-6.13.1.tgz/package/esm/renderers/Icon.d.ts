import React from 'react';
import { RendererProps } from 'amis-core';
import { SchemaTpl } from '../Schema';
import { BadgeObject, IconCheckedSchema } from 'amis-ui';
import { AMISSchemaBase } from 'amis-core';
/**
 * Icon 图标渲染器
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/icon
 */
/**
 * 图标组件，用于展示图标或符号。支持字体图标、SVG 与样式控制。
 */
export interface AMISIconSchema extends AMISSchemaBase {
    type: 'icon';
    /**
     * 图标类型
     */
    icon: SchemaTpl | IconCheckedSchema;
    vendor?: 'iconfont' | 'fa' | '';
    /**
     * 角标
     */
    badge?: BadgeObject;
}
export interface IconProps extends RendererProps, Omit<AMISIconSchema, 'type' | 'className'> {
}
export declare class Icon extends React.Component<IconProps, object> {
    static defaultProps: Partial<IconProps>;
    handleClick(e: React.MouseEvent<any>): void;
    handleMouseEnter(e: React.MouseEvent<any>): void;
    handleMouseLeave(e: React.MouseEvent<any>): void;
    render(): React.JSX.Element;
}
export declare class IconRenderer extends Icon {
}
