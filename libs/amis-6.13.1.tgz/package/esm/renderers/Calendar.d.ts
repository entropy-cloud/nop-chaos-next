import { SchemaObject } from '../Schema';
import { DateControlRenderer } from './Form/InputDate';
import type { AMISClassName, AMISSchemaBase } from 'amis-core';
interface AMISScheduleItem {
    startTime: string;
    endTime: string;
    content: any;
    className?: AMISClassName;
}
/**
 * 日历组件，用于日期选择与事件展示。支持自定义渲染与多视图。
 */
export interface AMISCalendarSchema extends AMISSchemaBase {
    /**
     * 指定为 calendar 组件
     */
    type: 'calendar';
    /**
     * 日程
     */
    schedules?: Array<AMISScheduleItem> | string;
    /**
     * 日程显示颜色自定义
     */
    scheduleClassNames?: Array<AMISClassName>;
    /**
     * 日程点击展示
     */
    scheduleAction?: SchemaObject;
    /**
     * 是否开启放大模式
     */
    largeMode?: boolean;
    /**
     * 今日激活时的自定义样式
     */
    todayActiveStyle?: {
        [propName: string]: any;
    };
}
export declare class CalendarRenderer extends DateControlRenderer {
    static defaultProps: {
        embed: boolean;
        strictMode: boolean;
        format: string;
        viewMode: string;
        inputFormat: string;
        timeConstraints: {
            minutes: {
                step: number;
            };
        };
        clearable: boolean;
    };
}
export {};
