import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
export interface StatusSource {
    /**
     * 状态映射配置
     */
    [propName: string]: {
        /**
         * 状态图标
         */
        icon?: string;
        /**
         * 状态标签文本
         */
        label?: string;
        /**
         * 状态颜色
         */
        color?: string;
        /**
         * 状态样式类名
         */
        className?: string;
    };
}
/**
 * 状态展示组件，用于显示各种状态信息
 * 文档：https://aisuda.bce.baidu.com/amis/zh-CN/components/status
 */
/**
 * 状态组件，用于显示状态点/标签等。支持多状态映射与颜色标识。
 */
export interface AMISStatusSchema extends AMISSchemaBase {
    /**
     * 指定为 status 组件
     */
    type: 'status';
    /**
     * 占位符文本
     * @default -
     */
    placeholder?: string;
    /**
     * 状态图标映射关系
     * @deprecated 已废弃，2.8.0 废弃，建议使用 source 配置
     */
    map?: {
        [propName: string]: string;
    };
    /**
     * 文字映射关系
     * @deprecated 已废弃，2.8.0 废弃，建议使用 source 配置
     */
    labelMap?: {
        [propName: string]: string;
    };
    /**
     * 新版状态映射源配置
     */
    source?: StatusSource;
}
export interface StatusProps extends RendererProps, Omit<AMISStatusSchema, 'className'> {
}
export declare class StatusField extends React.Component<StatusProps, object> {
    static defaultProps: Partial<StatusProps>;
    render(): React.JSX.Element;
}
export declare class StatusFieldRenderer extends StatusField {
}
