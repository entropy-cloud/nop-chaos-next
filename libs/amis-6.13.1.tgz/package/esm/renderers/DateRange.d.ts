import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
/**
 * DateRange 展示渲染器。
 */
/**
 * 日期范围展示组件，用于显示开始-结束时间段。
 */
export interface AMISDateRangeSchema extends AMISSchemaBase {
    /**
     * 指定为 date-range 组件
     */
    type: 'date-range';
    /**
     * 值的时间格式
     */
    valueFormat?: string;
    /**
     * 展示的时间格式
     */
    format?: string;
    /**
     * 展示的时间格式（新：同format）
     */
    displayFormat?: string;
    /**
     * 分割符
     */
    delimiter?: string;
    /**
     * 连接符
     */
    connector?: string;
}
export interface DateRangeProps extends RendererProps, Omit<AMISDateRangeSchema, 'type' | 'className'> {
}
export declare class DateRangeField extends React.Component<DateRangeProps, Object> {
    refreshInterval: ReturnType<typeof setTimeout>;
    static defaultProps: Pick<DateRangeProps, 'valueFormat' | 'format' | 'connector' | 'displayFormat'>;
    render(): React.JSX.Element | null;
}
export declare class DateRangeFieldRenderer extends DateRangeField {
}
