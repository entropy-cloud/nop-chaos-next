import React from 'react';
import { AMISSchemaBase, RendererProps } from 'amis-core';
import type { MODE_TYPE } from 'amis-ui/lib/components/Pagination';
/**
 * 分页组件，用于数据分页跳转。支持页码、页大小与快速跳转。
 */
export interface AMISPaginationSchema extends AMISSchemaBase {
    type: 'pagination';
    /**
     * 通过控制layout属性的顺序，调整分页结构
     */
    layout?: string | Array<string>;
    /**
     * 最多显示多少个分页按钮
     */
    maxButtons?: number;
    /**
     * 模式，默认normal，如果只想简单显示配置成 simple
     */
    mode?: MODE_TYPE;
    /**
     * 当前页数
     */
    activePage: number;
    /**
     * 总条数
     */
    total?: number;
    /**
     * 最后一页，总页数（如果传入了total，会重新计算lastPage）
     */
    /**
     * 每页显示条数
     */
    perPage?: number;
    /**
     * 是否展示分页切换，也同时受layout控制
     */
    showPerPage?: boolean;
    /**
     * 指定每页可以显示多少条
     */
    perPageAvailable?: Array<number>;
    /**
     * 是否显示快速跳转输入框
     */
    showPageInput?: boolean;
    /**
     * 是否禁用
     */
    disabled?: boolean;
    hasNext?: boolean;
    /**
     * 弹层挂载节点
     */
    popOverContainerSelector?: string;
}
export interface PaginationProps extends RendererProps, Omit<AMISPaginationSchema, 'type' | 'className'> {
}
export default class Pagination extends React.Component<PaginationProps> {
    formatNumber(num: number | string | undefined, defaultValue?: number): number | undefined;
    onPageChange(page: number, perPage?: number, dir?: string): Promise<void>;
    render(): React.JSX.Element;
}
export declare class PaginationRenderer extends Pagination {
}
