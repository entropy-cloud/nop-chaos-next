import { AMISPageSchema } from './renderers/Page';
import { AMISButtonSchema, AMISFormSchema } from 'amis-core';
import { AMISAlertSchema } from './renderers/Alert';
import { AMISFlexSchema } from './renderers/Flex';
import { AMISTplSchema } from './renderers/Tpl';
import { AMISRemarkSchema } from './renderers/Remark';
import { AMISAudioSchema } from './renderers/Audio';
import { AMISButtonGroupSchema } from './renderers/ButtonGroup';
import { AMISButtonToolbarSchema } from './renderers/Form/ButtonToolbar';
import { AMISCardSchema } from './renderers/Card';
import { AMISCardsSchema } from './renderers/Cards';
import { AMISCarouselSchema } from './renderers/Carousel';
import { AMISChartSchema } from './renderers/Chart';
import { AMISCollapseSchema } from './renderers/Collapse';
import { AMISCollapseGroupSchema } from './renderers/CollapseGroup';
import { AMISColorSchema } from './renderers/Color';
import { AMISContainerSchema } from './renderers/Container';
import { AMISSwitchContainerSchema } from './renderers/SwitchContainer';
import { AMISCRUDSchema } from './renderers/CRUD';
import { AMISDateSchema } from './renderers/Date';
import { AMISDividerSchema } from './renderers/Divider';
import { AMISDropdownButtonSchema } from './renderers/DropDownButton';
import { AMISGridSchema } from './renderers/Grid';
import { AMISHBoxSchema } from './renderers/HBox';
import { AMISIconSchema } from './renderers/Icon';
import { AMISIFrameSchema } from './renderers/IFrame';
import { AMISImageSchema } from './renderers/Image';
import { AMISImagesSchema } from './renderers/Images';
import { AMISJsonSchema } from './renderers/Json';
import { AMISLinkSchema } from './renderers/Link';
import { AMISListSchema } from './renderers/List';
import { AMISMappingSchema } from './renderers/Mapping';
import { AMISNavSchema } from './renderers/Nav';
import { AMISOperationSchema } from './renderers/Operation';
import { AMISPanelSchema } from './renderers/Panel';
import { AMISPlainSchema } from './renderers/Plain';
import { AMISProgressSchema } from './renderers/Progress';
import { AMISQRCodeSchema } from './renderers/QRCode';
import { AMISServiceSchema } from './renderers/Service';
import { AMISStatusSchema } from './renderers/Status';
import { AMISTabsSchema } from './renderers/Tabs';
import { AMISVBoxSchema } from './renderers/VBox';
import { AMISVideoSchema } from './renderers/Video';
import { AMISWizardSchema } from './renderers/Wizard';
import { AMISWrapperSchema } from './renderers/Wrapper';
import { AMISTableSchema } from './renderers/Table';
import { AMISSearchBoxSchema } from './renderers/SearchBox';
import { AMISAnchorNavSchema } from './renderers/AnchorNav';
import { AMISAvatarSchema } from './renderers/Avatar';
import { AMISTimelineSchema } from './renderers/Timeline';
import { AMISButtonGroupSelectSchema } from './renderers/Form/ButtonGroupSelect';
import { AMISChainedSelectSchema } from './renderers/Form/ChainedSelect';
import { AMISCheckboxSchema } from './renderers/Form/Checkbox';
import { AMISCheckboxesSchema } from './renderers/Form/Checkboxes';
import { AMISComboSchema } from './renderers/Form/Combo';
import { AMISCodeEditorSchema } from './renderers/Form/Editor';
import { AMISFieldSetSchema } from './renderers/Form/FieldSet';
import { AMISFormulaSchema } from './renderers/Form/Formula';
import { AMISGroupSchema } from './renderers/Form/Group';
import { AMISHiddenSchema } from './renderers/Form/Hidden';
import { AMISInputCitySchema } from './renderers/Form/InputCity';
import { AMISInputColorSchema } from './renderers/Form/InputColor';
import { AMISInputDateSchema, AMISInputDateTimeSchema, AMISInputTimeSchema, AMISInputMonthSchema, AMISInputQuarterSchema, AMISInputYearSchema } from './renderers/Form/InputDate';
import { AMISInputDateRangeSchema } from './renderers/Form/InputDateRange';
import { AMISInputFileSchema } from './renderers/Form/InputFile';
import { AMISInputGroupSchema } from './renderers/Form/InputGroup';
import { AMISInputImageSchema } from './renderers/Form/InputImage';
import { AMISInputMonthRangeSchema } from './renderers/Form/InputMonthRange';
import { AMISInputQuarterRangeSchema } from './renderers/Form/InputQuarterRange';
import { AMISInputNumberSchema } from './renderers/Form/InputNumber';
import { AMISInputRangeSchema } from './renderers/Form/InputRange';
import { AMISInputRatingSchema } from './renderers/Form/InputRating';
import { AMISInputRichTextSchema } from './renderers/Form/InputRichText';
import { AMISInputTableSchema } from './renderers/Form/InputTable';
import { AMISInputTagSchema } from './renderers/Form/InputTag';
import { AMISInputTextSchema } from './renderers/Form/InputText';
import { AMISInputTreeSchema } from './renderers/Form/InputTree';
import { AMISListSelectSchema } from './renderers/Form/ListSelect';
import { AMISNestedSelectSchema } from './renderers/Form/NestedSelect';
import { AMISPickerSchema } from './renderers/Form/Picker';
import { AMISRadiosSchema } from './renderers/Form/Radios';
import { AMISSelectSchema } from './renderers/Form/Select';
import { AMISStaticSchema } from './renderers/Form/Static';
import { AMISSwitchSchema } from './renderers/Form/Switch';
import { AMISTextareaSchema } from './renderers/Form/Textarea';
import { AMISTreeSelectSchema } from './renderers/Form/TreeSelect';
import { AMISInputSignatureSchema } from './renderers/Form/InputSignature';
import { AMISIShapeSchema } from './renderers/Shape';
import { AMISMarkdownSchema } from './renderers/Markdown';
import { AMISNumberSchema } from './renderers/Number';
import { AMISPropertySchema } from './renderers/Property';
import { AMISTagSchema } from './renderers/Tag';
import { AMISTableViewSchema } from './renderers/TableView';
import { AMISDateRangeSchema } from './renderers/DateRange';
import { AMISPasswordSchema } from './renderers/Password';
import { AMISWordsSchema } from './renderers/Words';
import { AMISRadioSchema } from './renderers/Form/Radio';
import { AMISDialogSchema } from './renderers/Dialog';
import { AMISDrawerSchema } from './renderers/Drawer';
export type RootSchema = AMISPageSchema;
declare module 'amis-core' {
    interface AMISSchemaRegistry {
        /** 表单容器组件，用于收集和提交用户输入数据 */
        'form': AMISFormSchema;
        /** 警告提示组件，用于显示重要信息或警告 */
        'alert': AMISAlertSchema;
        /** 应用容器组件，提供全局配置和布局 */
        /** 音频播放器组件，支持多种音频格式 */
        'audio': AMISAudioSchema;
        /** 头像组件，用于显示用户头像或图标 */
        'avatar': AMISAvatarSchema;
        /** 按钮组组件，将多个按钮组合在一起 */
        'button-group': AMISButtonGroupSchema;
        /** 面包屑导航组件，显示当前页面在网站中的位置 */
        /** 卡片组件，用于展示信息块 */
        'card': AMISCardSchema;
        /** 卡片组件（别名），用于展示信息块 */
        /** 卡片列表组件，以卡片形式展示数据列表 */
        'cards': AMISCardsSchema;
        /** 轮播图组件，支持图片或内容的轮播展示 */
        'carousel': AMISCarouselSchema;
        /** 图表组件，支持多种图表类型 */
        'chart': AMISChartSchema;
        /** 日历组件，用于日期选择和事件展示 */
        /** 折叠面板组件，可展开/收起内容区域 */
        'collapse': AMISCollapseSchema;
        /** 折叠面板组组件，管理多个折叠面板 */
        'collapse-group': AMISCollapseGroupSchema;
        /** 颜色选择器组件，用于颜色选择 */
        'color': AMISColorSchema;
        /** CRUD 增删改查组件，提供完整的数据操作界面 */
        'crud': AMISCRUDSchema;
        /** CRUD2 增删改查组件（新版），提供完整的数据操作界面 */
        /** 自定义组件，允许开发者自定义渲染逻辑 */
        /** 日期显示组件，用于格式化显示日期 */
        'date': AMISDateSchema;
        /** 静态日期显示组件，用于格式化显示日期 */
        /** 日期时间输入组件，支持日期和时间选择 */
        'datetime': AMISInputDateTimeSchema;
        /** 静态日期时间显示组件，用于格式化显示日期时间 */
        /** 时间输入组件，用于时间选择 */
        'time': AMISInputTimeSchema;
        /** 静态时间显示组件，用于格式化显示时间 */
        /** 月份输入组件，用于月份选择 */
        'month': AMISInputMonthSchema;
        /** 静态月份显示组件，用于格式化显示月份 */
        /** 日期范围组件，用于选择日期范围 */
        'date-range': AMISDateRangeSchema;
        /** 对话框组件，用于弹窗展示内容 */
        'dialog': AMISDialogSchema;
        /** 加载动画组件，用于显示加载状态 */
        /** 分割线组件，用于分隔内容区域 */
        'divider': AMISDividerSchema;
        /** 下拉按钮组件，将按钮和下拉菜单结合 */
        'dropdown-button': AMISDropdownButtonSchema;
        'drawer': AMISDrawerSchema;
        /** 循环渲染组件，用于遍历数据并渲染 */
        /** 弹性布局组件，支持 flex 布局 */
        'flex': AMISFlexSchema;
        /** 弹性布局子项组件，flex 布局的子元素 */
        /** 二维网格组件，支持二维网格布局 */
        /** 图标组件，用于显示各种图标 */
        'icon': AMISIconSchema;
        /** 内嵌框架组件，用于嵌入其他页面 */
        'iframe': AMISIFrameSchema;
        /** 图片组件，用于显示图片 */
        'image': AMISImageSchema;
        /** 静态图片组件，用于显示图片 */
        /** 图片列表组件，以列表形式展示多张图片 */
        'images': AMISImagesSchema;
        /** 静态图片列表组件，以列表形式展示多张图片 */
        /** JSON Schema 编辑器组件，用于编辑 JSON Schema */
        /** JSON Schema 编辑器组件（别名），用于编辑 JSON Schema */
        /** JSON 数据展示组件，用于格式化显示 JSON 数据 */
        'json': AMISJsonSchema;
        /** 静态 JSON 数据展示组件，用于格式化显示 JSON 数据 */
        /** 链接组件，用于创建可点击的链接 */
        'link': AMISLinkSchema;
        /** 列表组件，用于展示数据列表 */
        'list': AMISListSchema;
        /** 日志组件，用于显示日志信息 */
        /** 静态列表组件，用于展示数据列表 */
        /** 地图组件，用于显示地图和位置信息 */
        /** 数据映射组件，用于数据转换和映射 */
        'mapping': AMISMappingSchema;
        /** Markdown 渲染组件，用于渲染 Markdown 内容 */
        'markdown': AMISMarkdownSchema;
        /** 导航组件，用于页面导航 */
        'nav': AMISNavSchema;
        /** 数字显示组件，用于格式化显示数字 */
        'number': AMISNumberSchema;
        /** 页面组件，作为页面的根容器 */
        'page': AMISPageSchema;
        /** 分页组件，用于数据分页 */
        /** 分页包装器组件，为其他组件提供分页功能 */
        /** 属性列表组件，用于展示键值对数据 */
        'property': AMISPropertySchema;
        /** 操作列组件，用于表格中的操作按钮 */
        'operation': AMISOperationSchema;
        /** 纯文本组件，用于显示纯文本内容 */
        'plain': AMISPlainSchema;
        /** 文本输入组件，用于文本输入 */
        /** 进度条组件，用于显示进度 */
        'progress': AMISProgressSchema;
        /** 二维码组件，用于生成和显示二维码 */
        'qrcode': AMISQRCodeSchema;
        /** 二维码组件（别名），用于生成和显示二维码 */
        /** 条形码组件，用于生成和显示条形码 */
        /** 备注组件，用于显示提示信息 */
        'remark': AMISRemarkSchema;
        /** 搜索框组件，用于搜索功能 */
        'search-box': AMISSearchBoxSchema;
        /** 迷你图表组件，用于显示小型图表 */
        /** 状态组件，用于显示状态信息 */
        'status': AMISStatusSchema;
        /** 表格组件，用于展示表格数据 */
        'table': AMISTableSchema;
        /** 静态表格组件，用于展示表格数据 */
        /** 表格组件（新版），用于展示表格数据 */
        /** HTML 模板组件，用于渲染 HTML 内容 */
        /** 模板组件，用于渲染模板内容 */
        'tpl': AMISTplSchema;
        /** 任务组件，用于展示任务列表 */
        /** 垂直布局组件，用于垂直排列子元素 */
        'vbox': AMISVBoxSchema;
        /** 视频播放器组件，支持多种视频格式 */
        'video': AMISVideoSchema;
        /** 向导组件，用于多步骤流程 */
        'wizard': AMISWizardSchema;
        /** 包装器组件，用于包装其他组件 */
        'wrapper': AMISWrapperSchema;
        /** Web 组件，用于集成自定义 Web 组件 */
        /** 锚点导航组件，用于页面内导航 */
        'anchor-nav': AMISAnchorNavSchema;
        /** 步骤条组件，用于显示步骤进度 */
        /** 时间轴组件，用于展示时间线 */
        'timeline': AMISTimelineSchema;
        /** 表单控件组件，通用表单控件基类 */
        /** 数组输入组件，用于输入数组数据 */
        /** 动作按钮组件，用于执行各种动作 */
        /** 按钮组件，用于触发动作 */
        'button': AMISButtonSchema;
        /** 提交按钮组件，用于提交表单 */
        'submit': AMISButtonSchema;
        /** 重置按钮组件，用于重置表单 */
        'reset': AMISButtonSchema;
        /** 按钮组选择组件，将按钮组作为选择器使用 */
        'button-group-select': AMISButtonGroupSelectSchema;
        /** 按钮工具栏组件，用于工具栏中的按钮组 */
        'button-toolbar': AMISButtonToolbarSchema;
        /** 级联选择组件，支持级联选择 */
        'chained-select': AMISChainedSelectSchema;
        /** 图表单选组件，以图表形式展示单选选项 */
        /** 复选框组件，用于多选 */
        'checkbox': AMISCheckboxSchema;
        /** 复选框组组件，用于多选 */
        'checkboxes': AMISCheckboxesSchema;
        /** 城市选择组件，用于选择城市 */
        'input-city': AMISInputCitySchema;
        /** 颜色输入组件，用于颜色选择 */
        'input-color': AMISInputColorSchema;
        /** 组合输入组件，用于复杂输入场景 */
        'combo': AMISComboSchema;
        /** 条件构建器组件，用于构建复杂条件 */
        /** 容器组件，用于布局和包装 */
        'container': AMISContainerSchema;
        /** 开关容器组件，根据条件显示不同内容 */
        'switch-container': AMISSwitchContainerSchema;
        /** 日期输入组件，用于日期选择 */
        'input-date': AMISInputDateSchema;
        /** 日期时间输入组件，用于日期时间选择 */
        'input-datetime': AMISInputDateTimeSchema;
        /** 时间输入组件，用于时间选择 */
        'input-time': AMISInputTimeSchema;
        /** 季度输入组件，用于季度选择 */
        'input-quarter': AMISInputQuarterSchema;
        /** 年份输入组件，用于年份选择 */
        'input-year': AMISInputYearSchema;
        /** 年份范围输入组件，用于年份范围选择 */
        'input-year-range': AMISInputDateRangeSchema;
        /** 月份输入组件，用于月份选择 */
        'input-month': AMISInputMonthSchema;
        /** 日期范围输入组件，用于日期范围选择 */
        'input-date-range': AMISInputDateRangeSchema;
        /** 时间范围输入组件，用于时间范围选择 */
        'input-time-range': AMISInputDateRangeSchema;
        /** 日期时间范围输入组件，用于日期时间范围选择 */
        'input-datetime-range': AMISInputDateRangeSchema;
        /** Excel 文件输入组件，用于上传 Excel 文件 */
        'input-excel': AMISInputFileSchema;
        /** 公式输入组件，用于输入和计算公式 */
        /** 差异编辑器组件，用于比较和编辑差异 */
        /** Office 文档查看器组件，用于查看 Office 文档 */
        /** PDF 查看器组件，用于查看 PDF 文档 */
        /** 签名输入组件，用于电子签名 */
        'input-signature': AMISInputSignatureSchema;
        /** 验证码输入组件，用于输入验证码 */
        'input-verification-code': AMISInputTextSchema;
        /** 形状组件，用于绘制各种形状 */
        'shape': AMISIShapeSchema;
        /** 代码编辑器 */
        'editor': AMISCodeEditorSchema;
        /** Batch 脚本编辑器 */
        /** C 语言编辑器 */
        /** CoffeeScript 编辑器 */
        /** C++ 编辑器 */
        /** C# 编辑器 */
        /** CSS 编辑器 */
        /** Dockerfile 编辑器 */
        /** F# 编辑器 */
        /** Go 语言编辑器 */
        /** Handlebars 模板编辑器 */
        /** HTML 编辑器 */
        /** INI 配置文件编辑器 */
        /** Java 编辑器 */
        /** JavaScript 编辑器 */
        /** JSON 编辑器 */
        /** Less 样式编辑器 */
        /** Lua 编辑器 */
        /** Markdown 编辑器 */
        /** MSDAX 编辑器 */
        /** Objective-C 编辑器 */
        /** PHP 编辑器 */
        /** 纯文本编辑器 */
        /** Postiats 编辑器 */
        /** PowerShell 编辑器 */
        /** Pug 模板编辑器 */
        /** Python 编辑器 */
        /** R 语言编辑器 */
        /** Razor 模板编辑器 */
        /** Ruby 编辑器 */
        /** Small Basic 编辑器 */
        /** SCSS 样式编辑器 */
        /** Solidity 编辑器 */
        /** SQL 编辑器 */
        /** Swift 编辑器 */
        /** TypeScript 编辑器 */
        /** VB.NET 编辑器 */
        /** XML 编辑器 */
        /** YAML 编辑器 */
        /** 字段集 */
        'fieldset': AMISFieldSetSchema;
        /** 字段集（别名） */
        /** 文件上传 */
        'input-file': AMISInputFileSchema;
        /** 公式 */
        'formula': AMISFormulaSchema;
        /** 网格布局 */
        'grid': AMISGridSchema;
        /** 分组 */
        'group': AMISGroupSchema;
        /** 水平布局 */
        'hbox': AMISHBoxSchema;
        /** 隐藏字段 */
        'hidden': AMISHiddenSchema;
        /** 图标选择器 */
        /** 图标选择器（别名） */
        /** 图片上传 */
        'input-image': AMISInputImageSchema;
        /** 输入组合 */
        'input-group': AMISInputGroupSchema;
        /** 列表选择 */
        'list-select': AMISListSelectSchema;
        /** 位置选择器 */
        /** 矩阵复选框 */
        /** 月份范围输入 */
        'input-month-range': AMISInputMonthRangeSchema;
        /** 季度范围输入 */
        'input-quarter-range': AMISInputQuarterRangeSchema;
        /** 嵌套选择 */
        'nested-select': AMISNestedSelectSchema;
        /** 数字输入 */
        'input-number': AMISInputNumberSchema;
        /** 面板 */
        'panel': AMISPanelSchema;
        /** 选择器 */
        'picker': AMISPickerSchema;
        /** 单选按钮 */
        'radio': AMISRadioSchema;
        /** 单选按钮组 */
        'radios': AMISRadiosSchema;
        /** 范围输入 */
        'input-range': AMISInputRangeSchema;
        /** 评分输入 */
        'input-rating': AMISInputRatingSchema;
        /** 重复输入 */
        /** 富文本输入 */
        'input-rich-text': AMISInputRichTextSchema;
        /** 下拉选择 */
        'select': AMISSelectSchema;
        /** 服务 */
        'service': AMISServiceSchema;
        /** 静态展示 */
        'static': AMISStaticSchema;
        /** 子表单输入 */
        /** 开关 */
        'switch': AMISSwitchSchema;
        /** 表格输入 */
        'input-table': AMISInputTableSchema;
        /** 标签页 */
        'tabs': AMISTabsSchema;
        /** 标签页穿梭框 */
        /** 标签输入 */
        'input-tag': AMISInputTagSchema;
        /** 文本输入 */
        'input-text': AMISInputTextSchema;
        /** 密码输入 */
        'input-password': AMISPasswordSchema;
        /** 邮箱输入 */
        'input-email': AMISInputTextSchema;
        /** URL 输入 */
        'input-url': AMISInputTextSchema;
        /** UUID 生成 */
        /** 多选 */
        /** 多行文本输入 */
        'textarea': AMISTextareaSchema;
        /** 穿梭框 */
        /** 穿梭框选择器 */
        /** 标签页穿梭框选择器 */
        /** 树形输入 */
        'input-tree': AMISInputTreeSchema;
        /** 树形选择 */
        'tree-select': AMISTreeSelectSchema;
        /** 表格视图 */
        'table-view': AMISTableViewSchema;
        /** 门户 */
        /** 网格导航 */
        'grid-nav': AMISGridSchema;
        /** 用户选择 */
        /** 标签 */
        /** 标签（别名） */
        'tag': AMISTagSchema;
        'tags': AMISWordsSchema;
        /** 密码（别名） */
        'password': AMISPasswordSchema;
        /** 多行文本 */
        /** AMIS 组件 */
        /** 原生日期输入 */
        'native-date': AMISInputDateSchema;
        /** 原生时间输入 */
        'native-time': AMISInputTimeSchema;
        /** 原生数字输入 */
        'native-number': AMISInputNumberSchema;
    }
}
export type RootRenderer = AMISPageSchema;
export { AMISSchemaType } from 'amis-core';
