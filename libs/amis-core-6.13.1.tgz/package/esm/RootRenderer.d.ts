import React from 'react';
import type { RootProps } from './Root';
import { IScopedContext } from './Scoped';
import { IRootStore } from './store/root';
import { ActionObject } from './types';
import { GlobalVariableItem } from './globalVar';
export interface RootRendererProps extends RootProps {
    /**
     * 当前页面的路径信息，用于路由识别
     */
    location?: any;
    /**
     * 当前页面的参数信息，用于路由识别
     */
    params?: Record<string, any>;
    /**
     * 数据对象，推荐用 context 代替，context 数据在弹窗中也会被继承
     */
    data?: Record<string, any>;
    /**
     * 全局变量清单，只有这里面定义的变量才会被作为全局变量注入到各个组件中
     */
    globalVars?: Array<GlobalVariableItem>;
    /**
     * 上下文环境变量，所有组件都能获取得到
     */
    context?: Record<string, any>;
    render: (region: string, schema: any, props: any) => React.ReactNode;
}
export declare class RootRenderer extends React.Component<RootRendererProps> {
    store: IRootStore;
    static contextType: React.Context<IScopedContext>;
    constructor(props: RootRendererProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: RootRendererProps): void;
    componentDidCatch(error: any, errorInfo: any): void;
    componentWillUnmount(): void;
    handlePageVisibilityChange(): void;
    handleAction(e: React.UIEvent<any> | void, action: ActionObject, ctx: object, throwErrors?: boolean, delegate?: IScopedContext): any;
    dispatchEvent(e: string | React.MouseEvent<any>, data: any, renderer?: React.Component<any>, scoped?: IScopedContext): Promise<void | import("./utils/renderer-event").RendererEvent<any, any>>;
    handleDialogConfirm(values: object[], action: ActionObject, ...args: Array<any>): void;
    handleDialogClose(confirmed?: boolean): void;
    handleDrawerConfirm(values: object[], action: ActionObject, ...args: Array<any>): void;
    handleDrawerClose(): void;
    openFeedback(dialog: any, ctx: any): Promise<unknown>;
    reloadTarget(scoped: IScopedContext, target: string, data?: any): void;
    renderRuntimeError(): React.ReactNode;
    renderSpinner(): React.ReactNode;
    renderError(): React.ReactNode;
    renderDialog(): React.ReactNode;
    renderDrawer(): React.ReactNode;
    render(): string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | import("react/jsx-runtime").JSX.Element | null | undefined;
}
