/**
 * @file 所有列表选择类控件的父级，比如 Select、Radios、Checkboxes、
 * List、ButtonGroup 等等
 */
import { Api, PlainObject, ActionObject, OptionProps } from '../types';
import { FormControlProps, FormItemBasicConfig, AMISFormItem } from './Item';
export type OptionsControlComponent = React.ComponentType<FormControlProps>;
import React from 'react';
import type { Option } from '../types';
import { AMISOptions, AMISApi, AMISExpression, AMISDialogSchemaBase, AMISTemplate, AMISSchema } from '../schema';
export { Option };
export interface AMISFormItemWithOptions extends AMISFormItem {
    /**
     * 选项集合
     */
    options?: AMISOptions | string[] | PlainObject;
    /**
     * 可用来通过 API 拉取 options。
     */
    source?: AMISApi;
    /**
     * 默认选择选项第一个值。
     */
    selectFirst?: boolean;
    /**
     * 用表达式来配置 source 接口初始要不要拉取
     *
     * @deprecated 建议用 source 接口的 sendOn
     */
    initFetchOn?: AMISExpression;
    /**
     * 配置 source 接口初始拉不拉取。
     *
     * @deprecated 建议用 source 接口的 sendOn
     */
    initFetch?: boolean;
    /**
     * 是否为多选模式
     */
    multiple?: boolean;
    /**
     * 是否默认全选
     */
    checkAll?: boolean;
    /**
     * 单选模式：当用户选中某个选项时，选项中的 value 将被作为该表单项的值提交，否则，整个选项对象都会作为该表单项的值提交。
     * 多选模式：选中的多个选项的 `value` 会通过 `delimiter` 连接起来，否则直接将以数组的形式提交值。
     */
    joinValues?: boolean;
    /**
     * 分割符
     */
    delimiter?: string;
    /**
     * 多选模式，值太多时是否避免折行
     */
    valuesNoWrap?: boolean;
    /**
     * 开启后将选中的选项 value 的值封装为数组，作为当前表单项的值。
     */
    extractValue?: boolean;
    /**
     * 是否可清除。
     */
    clearable?: boolean;
    /**
     * 点清除按钮时，将表单项设置成当前配置的值。
     *
     * @default ''
     */
    resetValue?: string;
    /**
     * 懒加载字段
     */
    deferField?: string;
    /**
     * 延时加载的 API，当选项中有 defer: true 的选项时，点开会通过此接口扩展。
     */
    deferApi?: AMISApi;
    /**
     * 添加时调用的接口
     */
    addApi?: AMISApi;
    /**
     * 新增时的表单项。
     */
    addControls?: Array<AMISSchema>;
    /**
     * 控制新增弹框设置项
     */
    addDialog?: AMISDialogSchemaBase;
    /**
     * 是否可以新增
     */
    creatable?: boolean;
    /**
     * 新增文字
     */
    createBtnLabel?: string;
    /**
     * 是否可以编辑
     */
    editable?: boolean;
    /**
     * 编辑时调用的 API
     */
    editApi?: AMISApi;
    /**
     * 选项修改的表单项
     */
    editControls?: Array<AMISSchema>;
    /**
     * 控制编辑弹框设置项
     */
    editDialog?: AMISDialogSchemaBase;
    /**
     * 是否可删除
     */
    removable?: boolean;
    /**
     * 选项删除 API
     */
    deleteApi?: AMISApi;
    /**
     * 选项删除提示文字。
     */
    deleteConfirmText?: AMISTemplate;
    /**
     * source从数据域取值时，数据域值变化后是否自动清空
     */
    clearValueOnSourceChange?: boolean;
}
export interface FormOptionsControl extends AMISFormItemWithOptions {
}
export interface OptionsBasicConfig extends FormItemBasicConfig {
    autoLoadOptionsFromSource?: boolean;
}
export interface OptionsConfig extends OptionsBasicConfig {
    component: React.ComponentType<OptionsControlProps>;
}
export interface OptionsControlProps extends FormControlProps, Omit<FormOptionsControl, 'type' | 'className' | 'descriptionClassName' | 'inputClassName' | 'remark' | 'labelRemark'> {
    options: Array<Option>;
    onToggle: (option: Option, submitOnChange?: boolean, changeImmediately?: boolean) => void;
    onToggleAll: () => void;
    selectedOptions: Array<Option>;
    setOptions: (value: Array<any>, skipNormalize?: boolean) => void;
    setLoading: (value: boolean) => void;
    reloadOptions: (subpath?: string, query?: any) => void;
    deferLoad: (option: Option) => void;
    leftDeferLoad: (option: Option, leftOptions: Option) => void;
    expandTreeOptions: (nodePathArr: any[]) => void;
    onAdd?: (idx?: number | Array<number>, value?: any, skipForm?: boolean, callback?: (value: any) => any) => void;
    onEdit?: (value: Option, origin?: Option, skipForm?: boolean, callback?: (value: any) => any) => void;
    onDelete?: (value: Option, callback?: (value: any) => any) => void;
}
export interface OptionsProps extends FormControlProps, Omit<OptionProps, 'className'> {
    source?: Api;
    deferApi?: Api;
    creatable?: boolean;
    addApi?: Api;
    addControls?: Array<any>;
    editInitApi?: Api;
    editApi?: Api;
    editControls?: Array<any>;
    deleteApi?: Api;
    deleteConfirmText?: string;
    optionLabel?: string;
}
export declare const detectProps: string[];
export declare class OptionsControlBase<T extends OptionsProps = OptionsProps, S = any> extends React.Component<T, S> {
    readonly config: OptionsConfig;
    toDispose: Array<() => void>;
    input: any;
    mounted: boolean;
    constructor(props: T, config: OptionsConfig);
    componentDidMount(): void;
    shouldComponentUpdate(nextProps: OptionsProps): boolean;
    onLoadOptionsFinished(): Promise<void>;
    componentDidUpdate(prevProps: OptionsProps): void;
    componentWillUnmount(): void;
    oldDispatchOptionEvent(eventName: string, eventData?: any): Promise<boolean>;
    dispatchOptionEvent(eventName: string, eventData?: any): Promise<boolean>;
    doAction(action: ActionObject, data: object, throwErrors: boolean): void;
    normalizeValue(): void;
    getWrappedInstance(): any;
    inputRef(ref: any): void;
    handleToggle(option: Option, submitOnChange?: boolean, changeImmediately?: boolean): Promise<void>;
    /**
     * 初始化时处理默认全选逻辑
     */
    defaultCheckAll(): void;
    /**
     * 选中的值经过joinValues和delimiter等规则处理输出规定格式的值
     * @param valueArray 选中值的数组
     * @returns 通过joinValues和delimiter等规则输出规定格式的值
     */
    formatValueArray(valueArray: Array<Option>): string | Option | Option[];
    handleToggleAll(): Promise<void>;
    toggleValue(option: Option, originValue?: any): string | Option | Option[];
    reload(subpath?: string, query?: any): Promise<void> | undefined;
    reloadOptions(setError?: boolean, isInit?: boolean, data?: T["data"]): Promise<void> | undefined;
    deferLoad(option: Option): Promise<void>;
    leftDeferLoad(option: Option, leftOptions: Option): void;
    expandTreeOptions(nodePathArr: any[]): void;
    initOptions(data: any): Promise<void>;
    focus(): void;
    changeOptionValue(value: any): void;
    setOptions(options: Array<any>, skipNormalize?: boolean): void;
    syncOptions(): void;
    setLoading(value: boolean): void;
    handleOptionAdd(idx?: number | Array<number>, value?: any, skipForm?: boolean, callback?: (value: any) => any): Promise<void>;
    handleOptionEdit(value: any, origin?: any, skipForm?: boolean, callback?: (value: any) => any): Promise<void>;
    handleOptionDelete(value: any, callback?: (value: any) => any): Promise<void>;
    render(): React.ReactNode;
}
export declare function registerOptionsControl(config: OptionsConfig): import("..").RendererConfig;
export declare function OptionsControl(config: OptionsBasicConfig): <T extends React.ComponentType<OptionsControlProps>>(component: T) => T;
