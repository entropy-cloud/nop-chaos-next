import React from 'react';
import hoistNonReactStatic from 'hoist-non-react-statics';
import { IFormItemStore, IFormStore } from '../store/form';
import { RendererProps, TestFunc, RendererConfig } from '../factory';
import { AMISFormBase, FormHorizontal, FormSchemaBase } from './Form';
import { ActionObject, ClassName, DataChangeReason, Schema } from '../types';
import { IScopedContext } from '../Scoped';
import { AMISApi, AMISClassName, AMISRemarkBase, AMISSchemaBase, AMISTemplate, AMISVariableName } from '../schema';
export type LabelAlign = 'right' | 'left' | 'top' | 'inherit';
export interface AMISFormItemBase extends AMISSchemaBase {
    /**
     * 描述标题, 当值为 false 时不展示
     */
    label?: string | false;
    /**
     * 描述标题
     */
    labelAlign?: LabelAlign;
    /**
     * label自定义宽度，默认单位为px
     */
    labelWidth?: number | string;
    /**
     * label展示形式
     */
    labelOverflow?: 'default' | 'ellipsis';
    /**
     * 配置 label className
     */
    labelClassName?: AMISClassName;
    /**
     * 字段名，表单提交时的 key，支持多层级，用.连接，如： a.b.c
     */
    name?: AMISVariableName;
    /**
     * 额外的字段名，当为范围组件时可以用来将另外一个值打平出来
     */
    extraName?: AMISVariableName;
    /**
     * 显示一个小图标, 鼠标放上去的时候显示提示内容
     */
    remark?: AMISRemarkBase;
    /**
     * 显示一个小图标, 鼠标放上去的时候显示提示内容, 这个小图标跟 label 在一起
     */
    labelRemark?: AMISRemarkBase;
    /**
     * 输入提示，聚焦的时候显示
     */
    hint?: AMISTemplate;
    /**
     * 当修改完的时候是否提交表单。
     */
    submitOnChange?: boolean;
    /**
     * 是否只读
     */
    readOnly?: boolean;
    /**
     * 只读条件
     */
    readOnlyOn?: string;
    /**
     * 不设置时，当表单提交过后表单项每次修改都会触发重新验证，
     * 如果设置了，则由此配置项来决定要不要每次修改都触发验证。
     */
    validateOnChange?: boolean;
    /**
     * 描述内容，支持 Html 片段。
     */
    description?: AMISTemplate;
    /**
     * @deprecated 用 description 代替
     */
    desc?: AMISTemplate;
    /**
     * 配置描述上的 className
     */
    descriptionClassName?: AMISClassName;
    /**
     * 配置当前表单项展示模式
     */
    mode?: 'normal' | 'inline' | 'horizontal';
    /**
     * 当配置为水平布局的时候，用来配置具体的左右分配。
     */
    horizontal?: FormHorizontal;
    /**
     * 表单 control 是否为 inline 模式。
     */
    inline?: boolean;
    /**
     * 配置 input className
     */
    inputClassName?: ClassName;
    /**
     * 占位符
     */
    placeholder?: string | {
        [propName: string]: string;
    };
    /**
     * 是否为必填
     */
    required?: boolean;
    /**
     * 验证失败的提示信息
     */
    validationErrors?: {
        isAlpha?: string;
        isAlphanumeric?: string;
        isEmail?: string;
        isFloat?: string;
        isInt?: string;
        isJson?: string;
        isLength?: string;
        isNumeric?: string;
        isRequired?: string;
        isUrl?: string;
        matchRegexp?: string;
        matchRegexp2?: string;
        matchRegexp3?: string;
        matchRegexp4?: string;
        matchRegexp5?: string;
        maxLength?: string;
        maximum?: string;
        minLength?: string;
        minimum?: string;
        isDateTimeSame?: string;
        isDateTimeBefore?: string;
        isDateTimeAfter?: string;
        isDateTimeSameOrBefore?: string;
        isDateTimeSameOrAfter?: string;
        isDateTimeBetween?: string;
        isTimeSame?: string;
        isTimeBefore?: string;
        isTimeAfter?: string;
        isTimeSameOrBefore?: string;
        isTimeSameOrAfter?: string;
        isTimeBetween?: string;
        [propName: string]: any;
    };
    validations?: string | {
        /**
         * 是否是字母
         */
        isAlpha?: boolean;
        /**
         * 是否为字母数字
         */
        isAlphanumeric?: boolean;
        /**
         * 是否为邮箱地址
         */
        isEmail?: boolean;
        /**
         * 是否为浮点型
         */
        isFloat?: boolean;
        /**
         * 是否为整型
         */
        isInt?: boolean;
        /**
         * 是否为 json
         */
        isJson?: boolean;
        /**
         * 长度等于指定值
         */
        isLength?: number;
        /**
         * 是否为数字
         */
        isNumeric?: boolean;
        /**
         * 是否为必填
         */
        isRequired?: boolean;
        /**
         * 是否为 URL 地址
         */
        isUrl?: boolean;
        /**
         * 内容命中指定正则
         */
        matchRegexp?: string;
        /**
         * 内容命中指定正则
         */
        matchRegexp1?: string;
        /**
         * 内容命中指定正则
         */
        matchRegexp2?: string;
        /**
         * 内容命中指定正则
         */
        matchRegexp3?: string;
        /**
         * 内容命中指定正则
         */
        matchRegexp4?: string;
        /**
         * 内容命中指定正则
         */
        matchRegexp5?: string;
        /**
         * 最大长度为指定值
         */
        maxLength?: number;
        /**
         * 最大值为指定值
         */
        maximum?: number;
        /**
         * 最小长度为指定值
         */
        minLength?: number;
        /**
         * 最小值为指定值
         */
        minimum?: number;
        /**
         * 和目标日期相同，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isDateTimeSame?: string | string[];
        /**
         * 早于目标日期，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isDateTimeBefore?: string | string[];
        /**
         * 晚于目标日期，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isDateTimeAfter?: string | string[];
        /**
         * 早于目标日期或和目标日期相同，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isDateTimeSameOrBefore?: string | string[];
        /**
         * 晚于目标日期或和目标日期相同，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isDateTimeSameOrAfter?: string | string[];
        /**
         * 日期处于目标日期范围，支持指定粒度和区间的开闭形式，默认到毫秒, 左右开区间
         * @version 2.2.0
         */
        isDateTimeBetween?: string | string[];
        /**
         * 和目标时间相同，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isTimeSame?: string | string[];
        /**
         * 早于目标时间，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isTimeBefore?: string | string[];
        /**
         * 晚于目标时间，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isTimeAfter?: string | string[];
        /**
         * 早于目标时间或和目标时间相同，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isTimeSameOrBefore?: string | string[];
        /**
         * 晚于目标时间或和目标时间相同，支持指定粒度，默认到毫秒
         * @version 2.2.0
         */
        isTimeSameOrAfter?: string | string[];
        /**
         * 时间处于目标时间范围，支持指定粒度和区间的开闭形式，默认到毫秒, 左右开区间
         * @version 2.2.0
         */
        isTimeBetween?: string | string[];
        [propName: string]: any;
    };
    /**
     * 默认值，切记只能是静态值，不支持取变量，跟数据关联是通过设置 name 属性来实现的。
     */
    value?: any;
    /**
     * 表单项隐藏时，是否在当前 Form 中删除掉该表单项值。注意同名的未隐藏的表单项值也会删掉
     */
    clearValueOnHidden?: boolean;
    /**
     * 远端校验表单项接口
     */
    validateApi?: AMISApi;
    /**
     * 自动填充，当选项被选择的时候，将选项中的其他值同步设置到表单内。
     *
     * 支持配置 api，配置 api 后将额外请求外部接口完成填充，同时支持自动填充与用户选择填充两种模式。
     */
    autoFill?: {
        [propName: string]: string;
    } | {
        /**
         * 是否为参照录入模式，参照录入会展示候选值供用户选择，而不是直接填充。
         */
        showSuggestion?: boolean;
        /**
         * 参照录入时，默认选中的值
         */
        defaultSelection?: any;
        /**
         * 自动填充 api
         */
        api?: AMISApi;
        /**
         * 是否展示数据格式错误提示，默认为不展示
         * @default true
         */
        silent?: boolean;
        /**
         * 填充时的数据映射
         */
        fillMapping?: {
            [propName: string]: any;
        };
        /**
         * 触发条件，默认为 change
         */
        trigger?: 'change' | 'focus' | 'blur';
        /**
         * 是否支持多选
         */
        multiple?: boolean;
        /**
         * 弹窗方式，当为参照录入时用可以配置
         */
        mode?: 'popOver' | 'dialog' | 'drawer';
        /**
         * 当参照录入为抽屉时可以配置弹出位置
         */
        position?: string;
        /**
         * 当为参照录入时可以配置弹出容器的大小
         */
        size?: string;
        /**
         * 参照录入展示的项
         */
        columns?: Array<any>;
        /**
         * 参照录入时的过滤条件
         */
        filter?: AMISFormBase;
        labelField?: string;
        nameField?: string;
    };
    /**
     * @default fillIfNotSet
     * 初始化时是否把其他字段同步到表单内部。
     */
    initAutoFill?: boolean | 'fillIfNotSet';
    row?: number;
}
export interface AMISFormItem extends AMISFormItemBase {
    /**
     * 表单项大小
     */
    size?: 'xs' | 'sm' | 'md' | 'lg' | 'full';
}
export type FormBaseControl = AMISFormItem;
export interface FormItemBasicConfig extends Partial<RendererConfig> {
    type?: string;
    wrap?: boolean;
    renderLabel?: boolean;
    renderDescription?: boolean;
    test?: RegExp | TestFunc;
    storeType?: string;
    formItemStoreType?: string;
    validations?: string;
    strictMode?: boolean;
    /**
     * 是否是瘦子
     */
    thin?: boolean;
    /**
     * schema变化使视图更新的属性白名单
     */
    detectProps?: Array<string>;
    shouldComponentUpdate?: (props: any, prevProps: any) => boolean;
    descriptionClassName?: string;
    storeExtendsData?: boolean;
    sizeMutable?: boolean;
    weight?: number;
    extendsData?: boolean;
    showErrorMsg?: boolean;
    validate?: (values: any, value: any) => string | boolean;
}
export interface FormItemProps extends RendererProps {
    name?: string;
    formStore?: IFormStore;
    formItem?: IFormItemStore;
    formInited: boolean;
    formMode: 'normal' | 'horizontal' | 'inline' | 'row' | 'default';
    formHorizontal: FormHorizontal;
    formLabelAlign: LabelAlign;
    formLabelWidth?: number | string;
    defaultSize?: 'xs' | 'sm' | 'md' | 'lg' | 'full';
    size?: 'xs' | 'sm' | 'md' | 'lg' | 'full';
    labelAlign?: LabelAlign;
    labelWidth?: number | string;
    formLabelOverflow?: string;
    labelOverflow?: 'default' | 'ellipsis';
    disabled?: boolean;
    btnDisabled: boolean;
    defaultValue: any;
    value?: any;
    prinstine: any;
    setPrinstineValue: (value: any) => void;
    onChange: (value: any, submitOnChange?: boolean, changeImmediately?: boolean) => void;
    onBulkChange?: (values: {
        [propName: string]: any;
    }, submitOnChange?: boolean, changeReason?: DataChangeReason) => void;
    addHook: (fn: Function, mode?: 'validate' | 'init' | 'flush', enforce?: 'prev' | 'post') => () => void;
    removeHook: (fn: Function, mode?: 'validate' | 'init' | 'flush') => void;
    renderFormItems: (schema: Partial<FormSchemaBase>, region: string, props: any) => JSX.Element;
    onFocus: (e: any) => void;
    onBlur: (e: any) => void;
    formItemValue: any;
    getValue: () => any;
    setValue: (value: any, key: string) => void;
    inputClassName?: string;
    renderControl?: (props: FormControlProps) => JSX.Element;
    inputOnly?: boolean;
    renderLabel?: boolean;
    renderDescription?: boolean;
    sizeMutable?: boolean;
    wrap?: boolean;
    hint?: string;
    description?: string;
    descriptionClassName?: string;
    errors?: {
        [propName: string]: string;
    };
    error?: string;
    showErrorMsg?: boolean;
}
export type FormControlProps = RendererProps & {
    onOpenDialog: (schema: Schema, data: any) => Promise<any>;
} & Exclude<FormItemProps, 'inputClassName' | 'renderControl' | 'defaultSize' | 'size' | 'error' | 'errors' | 'hint' | 'descriptionClassName' | 'inputOnly' | 'renderLabel' | 'renderDescription' | 'sizeMutable' | 'wrap'>;
export type FormItemComponent = React.ComponentType<FormItemProps>;
export type FormControlComponent = React.ComponentType<FormControlProps>;
export interface FormItemConfig extends FormItemBasicConfig {
    component: FormControlComponent;
}
export declare class FormItemWrap extends React.Component<FormItemProps> {
    lastSearchTerm: any;
    target: HTMLElement;
    mounted: boolean;
    initedOptionFilled: boolean;
    initedApiFilled: boolean;
    toDispose: Array<() => void>;
    constructor(props: FormItemProps);
    componentDidMount(): void;
    componentDidUpdate(prevProps: FormItemProps): void;
    componentWillUnmount(): void;
    handleFocus(e: any): void;
    handleBlur(e: any): void;
    handleAutoFill(type: string): void;
    updateAutoFillData(context: any): void;
    syncApiAutoFill: import("lodash").DebouncedFunc<(term: any, forceLoad?: boolean, skipIfExits?: any) => Promise<void>>;
    syncOptionAutoFill(selectedOptions: Array<any>, skipIfExits?: boolean): void;
    /**
     * 应用映射函数，根据给定的映射关系，更新数据对象
     *
     * @param mapping 映射关系，类型为任意类型
     * @param ctx 上下文对象，类型为任意类型
     * @param skipIfExits 是否跳过已存在的属性，默认为 false
     */
    applyMapping(mapping: any, ctx: any, skipIfExits?: boolean): void;
    buildAutoFillSchema(): {
        popOverContainer: any;
        popOverClassName: any;
        placement: any;
        offset: any;
        body: {
            type: string;
            title: string;
            className: string;
            body: {
                type: string;
                embed: boolean;
                joinValues: boolean;
                strictMode: boolean;
                label: boolean;
                labelField: any;
                valueField: any;
                multiple: any;
                name: string;
                value: any;
                options: never[];
                required: boolean;
                source: any;
                pickerSchema: {
                    type: string;
                    bodyClassName: string;
                    affixHeader: boolean;
                    alwaysShowPagination: boolean;
                    keepItemSelectionOnPageChange: boolean;
                    headerToolbar: never[];
                    footerToolbar: ({
                        type: string;
                        align: string;
                        className?: undefined;
                    } | {
                        type: string;
                        align: string;
                        className: string;
                    })[];
                    multiple: any;
                    filter: any;
                    columns: any;
                };
            }[];
            actions: ({
                type: string;
                actionType: string;
                label: any;
                level?: undefined;
            } | {
                type: string;
                actionType: string;
                level: string;
                label: any;
            })[];
        };
        type?: undefined;
        className?: undefined;
        title?: undefined;
        size?: undefined;
        actions?: undefined;
    } | {
        type: any;
        className: string;
        title: any;
        size: any;
        body: {
            wrapWithPanel: boolean;
            type: string;
            title: string;
            className: string;
            body: {
                type: string;
                embed: boolean;
                joinValues: boolean;
                strictMode: boolean;
                label: boolean;
                labelField: any;
                valueField: any;
                multiple: any;
                name: string;
                value: any;
                options: never[];
                required: boolean;
                source: any;
                pickerSchema: {
                    type: string;
                    bodyClassName: string;
                    affixHeader: boolean;
                    alwaysShowPagination: boolean;
                    keepItemSelectionOnPageChange: boolean;
                    headerToolbar: never[];
                    footerToolbar: ({
                        type: string;
                        align: string;
                        className?: undefined;
                    } | {
                        type: string;
                        align: string;
                        className: string;
                    })[];
                    multiple: any;
                    filter: any;
                    columns: any;
                };
            }[];
            actions: ({
                type: string;
                actionType: string;
                label: any;
                level?: undefined;
            } | {
                type: string;
                actionType: string;
                level: string;
                label: any;
            })[];
        };
        actions: ({
            type: string;
            actionType: string;
            label: any;
            level?: undefined;
        } | {
            type: string;
            actionType: string;
            level: string;
            label: any;
        })[];
        popOverContainer?: undefined;
        popOverClassName?: undefined;
        placement?: undefined;
        offset?: undefined;
    } | undefined;
    handlePopOverConfirm(values: any): void;
    handlePopOverAction(e: React.UIEvent<any>, action: ActionObject, data: object, throwErrors?: boolean, delegate?: IScopedContext): any;
    closePopOver(): void;
    handleOpenDialog(schema: Schema, data: any): Promise<unknown>;
    handleDialogConfirm([values]: Array<any>): void;
    handleDialogClose(confirmed?: boolean): void;
    renderControl(): JSX.Element | null;
    /**
     * 布局扩充点，可以自己扩充表单项的布局方式
     */
    static layoutRenderers: {
        [propsName: string]: (props: FormItemProps, renderControl: () => JSX.Element | null) => JSX.Element;
    };
    render(): import("react/jsx-runtime").JSX.Element | null;
}
export declare const detectProps: string[];
export declare function asFormItem(config: Omit<FormItemConfig, 'component'>): (Control: FormControlComponent) => {
    new (props: Omit<any, "rootStore">): {
        ref: any;
        getWrappedInstance(): any;
        refFn(ref: any): void;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<any, "rootStore">>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<any, "rootStore">>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<any, "rootStore">>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<any, "rootStore">>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<any, "rootStore">>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<any, "rootStore">>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<any, "rootStore">>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<any, "rootStore">>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<any, "rootStore">>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<{
        storeType: string;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly fetcher: any;
        readonly notify: any;
        readonly isCancel: (value: any) => boolean;
        readonly __: import("..").TranslateFn;
        getStoreById(id: string): {
            id: string;
            path: string;
            storeType: string;
            disposed: boolean;
            parentId: string;
            childrenIds: import("mobx-state-tree").IMSTArray<import("mobx-state-tree").ISimpleType<string>> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>>;
        } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
            id: import("mobx-state-tree").ISimpleType<string>;
            path: import("mobx-state-tree").IType<string | undefined, string, string>;
            storeType: import("mobx-state-tree").ISimpleType<string>;
            disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
            parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
            childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
        }, {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
        readonly stores: {
            [propName: string]: {
                id: string;
                path: string;
                storeType: string;
                disposed: boolean;
                parentId: string;
                childrenIds: import("mobx-state-tree").IMSTArray<import("mobx-state-tree").ISimpleType<string>> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>>;
            } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
                readonly parentStore: any;
                readonly __: any;
                readonly hasChildren: boolean;
                readonly children: Array<any>;
            } & {
                onChildStoreDispose(child: any): void;
                syncProps(props: any, prevProps: any, list?: Array<string>): void;
                dispose: (callback?: () => void) => void;
                addChildId: (id: string) => void;
                removeChildId: (id: string) => void;
            } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
                id: import("mobx-state-tree").ISimpleType<string>;
                path: import("mobx-state-tree").IType<string | undefined, string, string>;
                storeType: import("mobx-state-tree").ISimpleType<string>;
                disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
                parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
                childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
            }, {
                readonly parentStore: any;
                readonly __: any;
                readonly hasChildren: boolean;
                readonly children: Array<any>;
            } & {
                onChildStoreDispose(child: any): void;
                syncProps(props: any, prevProps: any, list?: Array<string>): void;
                dispose: (callback?: () => void) => void;
                addChildId: (id: string) => void;
                removeChildId: (id: string) => void;
            }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
        };
    } & {
        addStore(store: {
            storeType: string;
            id: string;
            path: string;
            parentId?: string;
            [propName: string]: any;
        }): import("..").IStoreNode;
        removeStore(store: import("..").IStoreNode): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
    }, {
        readonly fetcher: any;
        readonly notify: any;
        readonly isCancel: (value: any) => boolean;
        readonly __: import("..").TranslateFn;
        getStoreById(id: string): {
            id: string;
            path: string;
            storeType: string;
            disposed: boolean;
            parentId: string;
            childrenIds: import("mobx-state-tree").IMSTArray<import("mobx-state-tree").ISimpleType<string>> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>>;
        } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
            id: import("mobx-state-tree").ISimpleType<string>;
            path: import("mobx-state-tree").IType<string | undefined, string, string>;
            storeType: import("mobx-state-tree").ISimpleType<string>;
            disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
            parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
            childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
        }, {
            readonly parentStore: any;
            readonly __: any;
            readonly hasChildren: boolean;
            readonly children: Array<any>;
        } & {
            onChildStoreDispose(child: any): void;
            syncProps(props: any, prevProps: any, list?: Array<string>): void;
            dispose: (callback?: () => void) => void;
            addChildId: (id: string) => void;
            removeChildId: (id: string) => void;
        }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
        readonly stores: {
            [propName: string]: {
                id: string;
                path: string;
                storeType: string;
                disposed: boolean;
                parentId: string;
                childrenIds: import("mobx-state-tree").IMSTArray<import("mobx-state-tree").ISimpleType<string>> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>>;
            } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
                readonly parentStore: any;
                readonly __: any;
                readonly hasChildren: boolean;
                readonly children: Array<any>;
            } & {
                onChildStoreDispose(child: any): void;
                syncProps(props: any, prevProps: any, list?: Array<string>): void;
                dispose: (callback?: () => void) => void;
                addChildId: (id: string) => void;
                removeChildId: (id: string) => void;
            } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
                id: import("mobx-state-tree").ISimpleType<string>;
                path: import("mobx-state-tree").IType<string | undefined, string, string>;
                storeType: import("mobx-state-tree").ISimpleType<string>;
                disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
                parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
                childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
            }, {
                readonly parentStore: any;
                readonly __: any;
                readonly hasChildren: boolean;
                readonly children: Array<any>;
            } & {
                onChildStoreDispose(child: any): void;
                syncProps(props: any, prevProps: any, list?: Array<string>): void;
                dispose: (callback?: () => void) => void;
                addChildId: (id: string) => void;
                removeChildId: (id: string) => void;
            }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
        };
    } & {
        addStore(store: {
            storeType: string;
            id: string;
            path: string;
            parentId?: string;
            [propName: string]: any;
        }): import("..").IStoreNode;
        removeStore(store: import("..").IStoreNode): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>>;
    ComposedComponent: React.ComponentType<any>;
    propTypes?: any;
} & hoistNonReactStatic.NonReactStatics<any, {}> & {
    ComposedComponent: any;
} & {
    ComposedComponent: any;
};
export declare function registerFormItem(config: FormItemConfig): RendererConfig;
export declare function FormItem(config: FormItemBasicConfig): (component: FormControlComponent) => any;
export declare function getFormItemByName(name: string): boolean;
export default FormItem;
