import { RendererProps } from '../factory';
import { RendererEvent } from '../utils/renderer-event';
import { IBreakAction } from './BreakAction';
import { IContinueAction } from './ContinueAction';
import { ILoopAction } from './LoopAction';
import { IParallelAction } from './ParallelAction';
import { ISwitchAction } from './SwitchAction';
import { AMISAction, AMISActionBase } from '../schema';
export declare enum LoopStatus {
    NORMAL = 0,
    BREAK = 1,
    CONTINUE = 2
}
export interface ListenerAction extends AMISActionBase {
    [propName: string]: any;
}
export interface ILogicAction extends ListenerAction {
    children?: AMISAction[];
}
export type LogicAction = IParallelAction | ISwitchAction | ILoopAction | IContinueAction | IBreakAction;
export interface ListenerContext extends React.Component<RendererProps> {
    [propName: string]: any;
}
interface MappingIgnoreMap {
    [propName: string]: string[];
}
export interface RendererAction {
    run: (action: ListenerAction, renderer: ListenerContext, event: RendererEvent<any>, mergeData?: any) => Promise<RendererEvent<any> | void>;
}
export declare const registerAction: (type: string, action: RendererAction) => void;
export declare const getActionByType: (type: string) => RendererAction;
export declare const getTargetComponent: (action: ListenerAction, renderer: ListenerContext, event: RendererEvent<any>, key?: string) => ListenerContext;
export declare const runActions: (actions: ListenerAction | ListenerAction[], renderer: ListenerContext, event: any) => Promise<void>;
export declare const runAction: (actionInstrance: RendererAction, actionConfig: ListenerAction, renderer: ListenerContext, event: any) => Promise<void>;
export declare const registerActionMappingIgnoreKey: (actionType: string, ignoreKey: string[], replace?: boolean) => void;
export declare const registerActionMappingIgnoreMap: (maps: MappingIgnoreMap, replace?: boolean) => void;
export declare const registerComponentActionMappingIgnoreKey: (cmptType: string, ignoreKey: string[], replace?: boolean) => void;
export declare const registerComponentActionMappingIgnoreMap: (maps: MappingIgnoreMap, replace?: boolean) => void;
export {};
