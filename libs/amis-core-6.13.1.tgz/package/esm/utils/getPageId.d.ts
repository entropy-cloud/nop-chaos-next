export declare function getPageId(): string;
