import React from 'react';
type ReactInstance = React.Component | HTMLElement | Text;
type Fiber = any;
/**
 * 从 React 组件实例获取关联的 DOM 节点
 * 基于 React 内部 Fiber 结构实现
 *
 * 原理：
 * - React 组件实例上存储了一个隐藏的 Fiber 引用
 * - Fiber 树包含了组件与 DOM 的映射关系
 * - 通过遍历 Fiber 树可以找到关联的 DOM 节点
 */
declare function getDOMNode(instance: ReactInstance | null | undefined): HTMLElement | null;
export declare const findDomCompat: typeof getDOMNode;
export declare function findCurrentHostFiber(parent: Fiber): Fiber | null;
export {};
