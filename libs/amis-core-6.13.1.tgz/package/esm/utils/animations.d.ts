import { AMISAnimations } from '../schema';
export interface AnimationsProps extends AMISAnimations {
}
export declare function createAnimationStyle(id: string, animationsConfig: AnimationsProps): void;
