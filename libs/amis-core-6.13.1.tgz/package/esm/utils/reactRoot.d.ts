import type { ReactNode } from 'react';
import { Root } from 'react-dom/client';
export declare function renderWithRoot(container: Element, node: ReactNode): Root;
export declare function unmountRoot(container: Element): void;
