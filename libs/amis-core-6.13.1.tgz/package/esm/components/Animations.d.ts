import React from 'react';
import { AMISSchemaBase } from '../schema';
declare function Animations({ schema, component, show }: {
    schema: AMISSchemaBase;
    component: any;
    show: boolean;
}): React.JSX.Element;
export default Animations;
