import { AMISSchemaBase } from '../schema';
declare function Animations({ schema, component, show }: {
    schema: AMISSchemaBase;
    component: any;
    show: boolean;
}): import("react/jsx-runtime").JSX.Element;
export default Animations;
