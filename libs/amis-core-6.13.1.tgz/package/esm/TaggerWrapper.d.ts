import React from 'react';
interface TaggerWrapperProps {
    children: React.ReactElement;
    tagger: {
        [propName: string]: string | number;
    };
}
/**
 * 自动给组件对应 dom 打标记，开发态时才会进来
 * @param param0
 * @returns
 */
export declare const TaggerWrapper: React.FC<TaggerWrapperProps>;
export default TaggerWrapper;
