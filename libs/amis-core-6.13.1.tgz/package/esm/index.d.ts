/** @license amis v@version
 *
 * Copyright Baidu
 *
 * This source code is licensed under the Apache license found in the
 * LICENSE file in the root directory of this source tree.
 */
import { Renderer, getRendererByName, getRenderers, loadAllAsyncRenderers, loadAsyncRenderersByType, loadAsyncRenderer, registerRenderer, unRegisterRenderer, resolveRenderer, filterSchema, clearStoresCache, updateEnv, addSchemaFilter, extendDefaultEnv, getGlobalOptions, setGlobalOptions } from './factory';
import type { RenderOptions, RendererConfig, RendererProps, hasAsyncRenderers } from './factory';
import './polyfills';
import './renderers/builtin';
import './renderers/register';
export * from './utils/index';
export * from './utils/animations';
export * from './schema';
export * from './types';
export * from './store';
export * from './globalVar';
import * as utils from './utils/helper';
import './globalVarClientHandler';
import './globalVarDefaultValueHandler';
import { RegisterStore, registerStore } from './store';
import type { IColumn, IColumn2, IRow, IRow2 } from './store';
import { setDefaultLocale, getDefaultLocale, makeTranslator, register as registerLocale, extendLocale, removeLocaleData, localeable, format as localeFormatter } from './locale';
import type { LocaleProps, TranslateFn } from './locale';
import Scoped, { ScopedContext, filterTarget, splitTarget } from './Scoped';
import type { ScopedComponentType, IScopedContext } from './Scoped';
import { classnames, getClassPrefix, setDefaultTheme, theme, getTheme, themeable, makeClassnames } from './theme';
import type { ClassNamesFn, ThemeProps } from './theme';
declare const classPrefix: string | undefined;
export * from './actions';
import FormItem, { FormItemWrap, registerFormItem, getFormItemByName } from './renderers/Item';
import type { AMISFormItem, AMISFormItemBase, FormControlProps, FormItemProps } from './renderers/Item';
import { OptionsControl, registerOptionsControl, OptionsControlBase } from './renderers/Options';
import type { OptionsControlProps } from './renderers/Options';
import type { FormOptionsControl, AMISFormItemWithOptions } from './renderers/Options';
import { Schema } from './types';
import { addRootWrapper, RootRenderProps, AMISPartialPropsContext } from './Root';
import { envOverwrite } from './envOverwrite';
import { EnvContext } from './env';
import type { RendererEnv } from './env';
import { evaluate, evaluateForAsync, Evaluator, AsyncEvaluator, extendsFilters, filters, getFilters, lexer, parse, registerFilter, registerFunction } from 'amis-formula';
import type { FilterContext } from 'amis-formula';
import LazyComponent from './components/LazyComponent';
import Overlay from './components/Overlay';
import PopOver from './components/PopOver';
import ErrorBoundary from './components/ErrorBoundary';
import { FormRenderer } from './renderers/Form';
import type { FormHorizontal, FormSchemaBase, AMISFormSchema, AMISFormBase } from './renderers/Form';
import { enableDebug, disableDebug, wrapFetcher, resolveVariableAndFilter, resolveVariableAndFilterForAsync } from './utils/index';
import type { OnEventProps } from './utils/index';
import { valueMap as styleMap } from './utils/style-helper';
import { RENDERER_TRANSMISSION_OMIT_PROPS, SchemaRenderer } from './SchemaRenderer';
import type { IItem } from './store/list';
import CustomStyle from './components/CustomStyle';
import { StatusScoped } from './StatusScoped';
import styleManager from './StyleManager';
import { bindGlobalEvent, dispatchGlobalEvent } from './utils/renderer-event';
import { getCustomVendor, registerCustomVendor } from './utils/icon';
import useEnvContext, { EnvContextProvider } from './hooks/useEnvContext';
import useRenderOptionsContext, { RenderOptionsContextProvider } from './hooks/useRenderOptionsContext';
export declare const version = "__buildVersion";
export { styleManager, clearStoresCache, updateEnv, Renderer, RendererProps, RenderOptions, RendererEnv, EnvContext, EnvContextProvider, useEnvContext, RenderOptionsContextProvider, AMISPartialPropsContext, useRenderOptionsContext, RegisterStore, registerStore, FormItem, FormItemWrap, FormItemProps, OptionsControl, FormRenderer, FormHorizontal, utils, getRendererByName, registerRenderer, unRegisterRenderer, getRenderers, loadAllAsyncRenderers, loadAsyncRenderersByType, loadAsyncRenderer, hasAsyncRenderers, registerFormItem, getFormItemByName, registerOptionsControl, resolveRenderer, filterSchema, Scoped, ScopedContext, IScopedContext, StatusScoped, setDefaultTheme, theme, themeable, ThemeProps, getTheme, classPrefix, getClassPrefix, classnames, makeClassnames, bindGlobalEvent, dispatchGlobalEvent, getDefaultLocale, setDefaultLocale, registerLocale, makeTranslator, extendLocale, removeLocaleData, localeable, localeFormatter, LocaleProps, TranslateFn, ClassNamesFn, parse, lexer, Evaluator, AsyncEvaluator, FilterContext, filters, getFilters, registerFilter, extendsFilters, registerFunction, evaluate, evaluateForAsync, LazyComponent, Overlay, PopOver, ErrorBoundary, addSchemaFilter, OptionsControlProps, OptionsControlBase, FormOptionsControl, AMISFormItemWithOptions as FormOptionsControlSelf, AMISFormItemWithOptions, FormControlProps, AMISFormItem, AMISFormItemBase, AMISFormItem as FormBaseControl, AMISFormItemBase as FormBaseControlWithoutSize, AMISFormSchema, AMISFormBase, extendDefaultEnv, addRootWrapper, RendererConfig, styleMap, RENDERER_TRANSMISSION_OMIT_PROPS, ScopedComponentType, IItem, IColumn, IRow, IColumn2, IRow2, OnEventProps, FormSchemaBase, filterTarget, splitTarget, CustomStyle, enableDebug, disableDebug, envOverwrite, getGlobalOptions, setGlobalOptions, wrapFetcher, SchemaRenderer, getCustomVendor, registerCustomVendor, resolveVariableAndFilter, resolveVariableAndFilterForAsync };
export declare function render(schema: Schema, { key, ...props }?: RootRenderProps, options?: RenderOptions, pathPrefix?: string): JSX.Element;
