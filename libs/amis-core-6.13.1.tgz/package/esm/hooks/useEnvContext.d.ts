import React from 'react';
import { EnvContext } from '../env';
export declare const EnvContextProvider: React.Provider<void | import("../env").RendererEnv>;
/**
 * Hook to access the AMIS environment context
 * @returns The environment context object
 */
export declare function useEnvContext(): React.ContextType<typeof EnvContext>;
export default useEnvContext;
