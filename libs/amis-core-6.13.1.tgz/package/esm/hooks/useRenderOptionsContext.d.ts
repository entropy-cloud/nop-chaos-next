import React from 'react';
import { RenderOptionsContext } from '../factory';
export declare const RenderOptionsContextProvider: React.Provider<import("../factory").RenderOptions>;
/**
 * Hook to access the AMIS render options context
 * @returns The render options context object
 */
export declare function useRenderOptionsContext(): React.ContextType<typeof RenderOptionsContext>;
export default useRenderOptionsContext;
