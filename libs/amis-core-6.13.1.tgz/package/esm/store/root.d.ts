import { Instance } from 'mobx-state-tree';
import { GlobalVariableItem, GlobalVariableState, GlobalVariableItemFull } from '../globalVar';
export declare const RootStore: import("mobx-state-tree").IModelType<{
    id: import("mobx-state-tree").ISimpleType<string>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    storeType: import("mobx-state-tree").ISimpleType<string>;
    disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
} & {
    hasRemoteData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    data: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    initedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    updatedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    pristineRaw: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    upStreamData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    action: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    dialogSchema: import("mobx-state-tree").IType<any, any, any>;
    dialogOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dialogData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    drawerSchema: import("mobx-state-tree").IType<any, any, any>;
    drawerOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    drawerData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
} & {
    msg: import("mobx-state-tree").IType<string | undefined, string, string>;
    error: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    fetching: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    saving: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    busying: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    checking: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    initializing: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    schema: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    schemaKey: import("mobx-state-tree").IType<string | undefined, string, string>;
} & {
    runtimeError: import("mobx-state-tree").IType<any, any, any>;
    runtimeErrorStack: import("mobx-state-tree").IType<any, any, any>;
    query: import("mobx-state-tree").IType<any, any, any>;
    params: import("mobx-state-tree").IType<any, any, any>;
    ready: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    globalVarTempStates: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IMapType<import("mobx-state-tree").IType<GlobalVariableState, GlobalVariableState, GlobalVariableState>>, [undefined]>;
    globalVarStates: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IMapType<import("mobx-state-tree").IType<GlobalVariableState, GlobalVariableState, GlobalVariableState>>, [undefined]>;
}, {
    readonly parentStore: any;
    readonly __: any;
    readonly hasChildren: boolean;
    readonly children: Array<any>;
} & {
    onChildStoreDispose(child: any): void;
    syncProps(props: any, prevProps: any, list?: Array<string>): void;
    dispose: (callback?: () => void) => void;
    addChildId: (id: string) => void;
    removeChildId: (id: string) => void;
} & {
    getValueByName(name: string, canAccessSuper?: boolean): any;
    getPristineValueByName(name: string): any;
    readonly pristineDiff: any;
} & {
    setTopStore(value: any): void;
    initData(data?: object, skipSetPristine?: boolean, changeReason?: import("..").DataChangeReason): void;
    temporaryUpdateGlobalVars(globalVar: any): void;
    unDoTemporaryUpdateGlobalVars(): void;
    reset(): void;
    updateData(data?: object, tag?: object, replace?: boolean, concatFields?: string | string[], changeReason?: import("..").DataChangeReason): void;
    changeValue(name: string, value: any, changePristine?: boolean, force?: boolean, otherModifier?: (data: Object) => void, changeReason?: import("..").DataChangeReason): void;
    setCurrentAction(action: any, resolveDefinitions?: (schema: any) => any): void;
    openDialog(ctx: any, additonal?: object, callback?: (confirmed: boolean, values: any) => void, scoped?: import("..").IScopedContext): void;
    closeDialog(confirmed?: any, data?: any): void;
    openDrawer(ctx: any, additonal?: object, callback?: (confirmed: boolean, ret: any) => void, scoped?: import("..").IScopedContext): void;
    closeDrawer(confirmed?: any, data?: any): void;
    getDialogScoped(): import("..").IScopedContext | null;
    getDrawerScoped(): import("..").IScopedContext | null;
} & {
    readonly loading: boolean;
} & {
    markFetching: (fetching?: boolean) => void;
    markSaving: (saving?: boolean) => void;
    markBusying: (busying?: boolean) => void;
    fetchInitData: (api: import("..").Api, data?: object, options?: import("..").fetchOptions) => Promise<any>;
    fetchData: (api: import("..").Api, data?: object, options?: import("..").fetchOptions) => Promise<any>;
    reInitData: (data: object | undefined, replace?: boolean, concatFields?: string | string[]) => void;
    updateMessage: (msg?: string, error?: boolean) => void;
    clearMessage: () => void;
    setHasRemoteData: () => void;
    saveRemote: (api: import("..").Api, data?: object, options?: import("..").fetchOptions) => Promise<any>;
    fetchSchema: (api: import("..").Api, data?: object, options?: import("..").fetchOptions) => Promise<any>;
    checkRemote: (api: import("..").Api, data?: object, options?: import("..").fetchOptions) => Promise<any>;
} & {
    context: any;
    legacyGlobalTempContext: any;
    globalVars: Array<GlobalVariableItemFull>;
    globalData: any;
} & {
    readonly nextGlobalData: any;
    readonly downStream: object;
} & {
    updateContextBySetter(context: any): void;
    updateContext(context: any, isInit?: boolean): void;
    updateGlobalVarState(key: string, state: Partial<GlobalVariableState>): void;
    setGlobalVars: (vars?: Array<GlobalVariableItem>) => Promise<any>;
    updateGlobalVarValue: (key: string, value: any) => void;
    modifyGlobalVarValue: (key: string, options: {
        op: "set" | "merge" | "push" | "unshift" | "remove" | "toggle" | "empty" | "sort" | "reverse" | "refresh";
        value: any;
    }) => void;
    saveGlobalVarValues: import("lodash").DebouncedFunc<(key?: string) => Promise<void>>;
    setRuntimeError(error: any, errorStack: any): void;
    updateLocation(location?: any, parseFn?: Function): void;
    updateParams(params?: any): void;
    init: (schema: any) => Promise<any>;
    syncGlobalVarStates: () => void;
    syncLegacyGlobalVarStates: () => void;
    addSyncGlobalVarStatePendingTask: (fn: (callback: () => void) => void, callback?: () => void) => void;
    afterCreate(): void;
    afterDestroy(): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IRootStore = Instance<typeof RootStore>;
