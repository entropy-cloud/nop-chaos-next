import { SnapshotIn, Instance } from 'mobx-state-tree';
export declare const Item: import("mobx-state-tree").IModelType<{
    storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
    id: import("mobx-state-tree").ISimpleType<string>;
    pristine: import("mobx-state-tree").IType<any, any, any>;
    data: import("mobx-state-tree").IType<any, any, any>;
    index: import("mobx-state-tree").ISimpleType<number>;
    newIndex: import("mobx-state-tree").ISimpleType<number>;
}, {
    readonly checked: boolean;
    readonly modified: boolean;
    readonly moved: boolean;
    readonly locals: any;
    readonly checkable: boolean;
    readonly draggable: boolean;
} & {
    toggle(): void;
    change(values: object, savePristine?: boolean): void;
    reset(): void;
    updateData({ children, ...rest }: any): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IItem = Instance<typeof Item>;
export type SItem = SnapshotIn<typeof Item>;
export declare const ListStore: import("mobx-state-tree").IModelType<{
    id: import("mobx-state-tree").ISimpleType<string>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    storeType: import("mobx-state-tree").ISimpleType<string>;
    disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
} & {
    hasRemoteData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    data: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    initedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    updatedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    pristineRaw: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    upStreamData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    action: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    dialogSchema: import("mobx-state-tree").IType<any, any, any>;
    dialogOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dialogData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    drawerSchema: import("mobx-state-tree").IType<any, any, any>;
    drawerOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    drawerData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
} & {
    items: import("mobx-state-tree").IArrayType<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
    fullItems: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    fullSelectedItems: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    selectedItems: import("mobx-state-tree").IArrayType<import("mobx-state-tree").IReferenceType<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>>;
    primaryField: import("mobx-state-tree").IType<string | undefined, string, string>;
    orderBy: import("mobx-state-tree").IType<string | undefined, string, string>;
    orderDir: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ITypeUnion<"desc" | "asc", "desc" | "asc", "desc" | "asc">, [undefined]>;
    draggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dragging: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    multiple: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    strictMode: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    selectable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    itemCheckableOn: import("mobx-state-tree").IType<string | undefined, string, string>;
    itemDraggableOn: import("mobx-state-tree").IType<string | undefined, string, string>;
    hideCheckToggler: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
}, {
    readonly parentStore: any;
    readonly __: any;
    readonly hasChildren: boolean;
    readonly children: Array<any>;
} & {
    onChildStoreDispose(child: any): void;
    syncProps(props: any, prevProps: any, list?: Array<string>): void;
    dispose: (callback?: () => void) => void;
    addChildId: (id: string) => void;
    removeChildId: (id: string) => void;
} & {
    getValueByName(name: string, canAccessSuper?: boolean): any;
    getPristineValueByName(name: string): any;
    readonly pristineDiff: any;
} & {
    setTopStore(value: any): void;
    initData(data?: object, skipSetPristine?: boolean, changeReason?: import("..").DataChangeReason): void;
    temporaryUpdateGlobalVars(globalVar: any): void;
    unDoTemporaryUpdateGlobalVars(): void;
    reset(): void;
    updateData(data?: object, tag?: object, replace?: boolean, concatFields?: string | string[], changeReason?: import("..").DataChangeReason): void;
    changeValue(name: string, value: any, changePristine?: boolean, force?: boolean, otherModifier?: (data: Object) => void, changeReason?: import("..").DataChangeReason): void;
    setCurrentAction(action: any, resolveDefinitions?: (schema: any) => any): void;
    openDialog(ctx: any, additonal?: object, callback?: (confirmed: boolean, values: any) => void, scoped?: import("..").IScopedContext): void;
    closeDialog(confirmed?: any, data?: any): void;
    openDrawer(ctx: any, additonal?: object, callback?: (confirmed: boolean, ret: any) => void, scoped?: import("..").IScopedContext): void;
    closeDrawer(confirmed?: any, data?: any): void;
    getDialogScoped(): import("..").IScopedContext | null;
    getDrawerScoped(): import("..").IScopedContext | null;
} & {
    readonly allChecked: boolean;
    readonly checkableItems: ({
        storeType: string;
        id: string;
        pristine: any;
        data: any;
        index: number;
        newIndex: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly unSelectedItems: ({
        storeType: string;
        id: string;
        pristine: any;
        data: any;
        index: number;
        newIndex: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    isSelected: (item: IItem) => boolean;
    readonly modified: number;
    readonly modifiedItems: ({
        storeType: string;
        id: string;
        pristine: any;
        data: any;
        index: number;
        newIndex: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly moved: number;
    readonly movedItems: ({
        storeType: string;
        id: string;
        pristine: any;
        data: any;
        index: number;
        newIndex: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly checked: boolean;
        readonly modified: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
    } & {
        toggle(): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    /**
     * 构建事件的上下文数据
     * @param buildChain
     * @returns
     */
    readonly eventContext: {
        selectedItems: any[];
        selectedIndexes: number[];
        items: any[];
        unSelectedItems: any[];
    };
} & {
    getData: (superData: any) => any;
    update: (config: Partial<SListStore>) => void;
    initItems: (items: Array<object>, fullItems?: Array<any>, fullSelectedItems?: Array<any>) => void;
    updateSelected: (selected: Array<any>, valueField?: string) => void;
    toggleAll: () => void;
    clearAll: () => void;
    selectAll: () => void;
    toggle: (item: IItem) => void;
    clear: () => void;
    setOrderByInfo: (key: string, direction: "asc" | "desc") => void;
    reset: () => void;
    toggleDragging: () => void;
    startDragging: () => void;
    stopDragging: () => void;
    exchange: (fromIndex: number, toIndex: number) => void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IListStore = Instance<typeof ListStore>;
export type SListStore = SnapshotIn<typeof ListStore>;
