import { Instance } from 'mobx-state-tree';
import { Api, fetchOptions, ActionObject } from '../types';
import type { MatchSorterOptions } from 'match-sorter';
interface MatchFunc {
    (items: any, itemsRaw: any, 
    /** 相关配置 */
    options?: {
        query: Record<string, any>;
        columns: any;
        /**
         * match-sorter 匹配函数
         * @doc https://github.com/kentcdodds/match-sorter
         */
        matchSorter: (items: any[], value: string, options?: MatchSorterOptions<any>) => any[];
    }): any;
}
export declare const CRUDStore: import("mobx-state-tree").IModelType<{
    id: import("mobx-state-tree").ISimpleType<string>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    storeType: import("mobx-state-tree").ISimpleType<string>;
    disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
} & {
    hasRemoteData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    data: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    initedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    updatedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    pristineRaw: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    upStreamData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    action: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    dialogSchema: import("mobx-state-tree").IType<any, any, any>;
    dialogOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dialogData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    drawerSchema: import("mobx-state-tree").IType<any, any, any>;
    drawerOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    drawerData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
} & {
    msg: import("mobx-state-tree").IType<string | undefined, string, string>;
    error: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    fetching: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    saving: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    busying: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    checking: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    initializing: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    schema: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    schemaKey: import("mobx-state-tree").IType<string | undefined, string, string>;
} & {
    pristineQuery: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    query: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    prevPage: import("mobx-state-tree").IType<number | undefined, number, number>;
    page: import("mobx-state-tree").IType<number | undefined, number, number>;
    perPage: import("mobx-state-tree").IType<number | undefined, number, number>;
    total: import("mobx-state-tree").IType<number | undefined, number, number>;
    mode: import("mobx-state-tree").IType<string | undefined, string, string>;
    hasNext: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    selectedAction: import("mobx-state-tree").IType<any, any, any>;
    columns: import("mobx-state-tree").IType<any, any, any>;
    items: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    selectedItems: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    unSelectedItems: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    filterTogglable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    filterVisible: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    hasInnerModalOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
}, {
    readonly parentStore: any;
    readonly __: any;
    readonly hasChildren: boolean;
    readonly children: Array<any>;
} & {
    onChildStoreDispose(child: any): void;
    syncProps(props: any, prevProps: any, list?: Array<string>): void;
    dispose: (callback?: () => void) => void;
    addChildId: (id: string) => void;
    removeChildId: (id: string) => void;
} & {
    getValueByName(name: string, canAccessSuper?: boolean): any;
    getPristineValueByName(name: string): any;
    readonly pristineDiff: any;
} & {
    setTopStore(value: any): void;
    initData(data?: object, skipSetPristine?: boolean, changeReason?: import("../types").DataChangeReason): void;
    temporaryUpdateGlobalVars(globalVar: any): void;
    unDoTemporaryUpdateGlobalVars(): void;
    reset(): void;
    updateData(data?: object, tag?: object, replace?: boolean, concatFields?: string | string[], changeReason?: import("../types").DataChangeReason): void;
    changeValue(name: string, value: any, changePristine?: boolean, force?: boolean, otherModifier?: (data: Object) => void, changeReason?: import("../types").DataChangeReason): void;
    setCurrentAction(action: any, resolveDefinitions?: (schema: any) => any): void;
    openDialog(ctx: any, additonal?: object, callback?: (confirmed: boolean, values: any) => void, scoped?: import("..").IScopedContext): void;
    closeDialog(confirmed?: any, data?: any): void;
    openDrawer(ctx: any, additonal?: object, callback?: (confirmed: boolean, ret: any) => void, scoped?: import("..").IScopedContext): void;
    closeDrawer(confirmed?: any, data?: any): void;
    getDialogScoped(): import("..").IScopedContext | null;
    getDrawerScoped(): import("..").IScopedContext | null;
} & {
    readonly loading: boolean;
} & {
    markFetching: (fetching?: boolean) => void;
    markSaving: (saving?: boolean) => void;
    markBusying: (busying?: boolean) => void;
    fetchInitData: (api: Api, data?: object, options?: fetchOptions) => Promise<any>;
    fetchData: (api: Api, data?: object, options?: fetchOptions) => Promise<any>;
    reInitData: (data: object | undefined, replace?: boolean, concatFields?: string | string[]) => void;
    updateMessage: (msg?: string, error?: boolean) => void;
    clearMessage: () => void;
    setHasRemoteData: () => void;
    saveRemote: (api: Api, data?: object, options?: fetchOptions) => Promise<any>;
    fetchSchema: (api: Api, data?: object, options?: fetchOptions) => Promise<any>;
    checkRemote: (api: Api, data?: object, options?: fetchOptions) => Promise<any>;
} & {
    readonly lastPage: number;
    readonly filterData: object;
    readonly toolbarData: object;
    readonly mergedData: any;
    readonly hasModalOpened: boolean;
    readonly selectedItemsAsArray: any[];
    readonly itemsAsArray: any[];
    fetchCtxOf(data: any, options: {
        pageField?: string;
        perPageField?: string;
    }): object;
    readonly eventContext: {
        items: any[];
        selectedItems: any[];
        unSelectedItems: any[];
        selectedIndexes: string[];
    };
    readonly offset: number;
} & {
    getData: (superData: any) => any;
    updateSelectData: (selected: Array<any>, unSelected: Array<any>) => void;
    setPristineQuery: () => void;
    updateQuery: (values: object, updater?: Function, pageField?: string, perPageField?: string, replace?: boolean) => void;
    fetchInitData: (api: Api, data?: object, options?: fetchOptions & {
        forceReload?: boolean;
        loadDataOnce?: boolean;
        source?: string;
        loadDataMode?: boolean;
        syncResponse2Query?: boolean;
        columns?: Array<any>;
        matchFunc?: MatchFunc;
        filterOnAllColumns?: boolean;
        isTable2?: Boolean;
        minLoadingTime?: number;
        dataAppendTo?: "top" | "bottom";
        totalField?: string;
    }) => Promise<any>;
    changePage: (page: number | string, perPage?: number | string) => void;
    changePerPage: (perPage: number | string) => void;
    selectAction: (action: ActionObject) => void;
    saveRemote: (api: Api, data?: object, options?: fetchOptions) => Promise<any>;
    setFilterTogglable: (togglable: boolean, filterVisible?: boolean) => void;
    setFilterVisible: (visible: boolean) => void;
    setSelectedItems: (items: Array<any>) => void;
    setUnSelectedItems: (items: Array<any>) => void;
    setInnerModalOpened: (value: boolean) => void;
    initFromScope: (scope: any, source: string, options: {
        columns?: Array<any>;
        matchFunc?: MatchFunc | null;
        totalField?: string;
    }) => void;
    exportAsCSV: (options?: {
        loadDataOnce?: boolean;
        api?: Api;
        data?: any;
        filename?: string;
        pageField?: string;
        perPageField?: string;
    }) => Promise<void>;
    updateColumns: (columns: Array<any>) => void;
    updateTotal: (total: number) => void;
    resetSelection: () => void;
    replaceItems(items: Array<any>): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type ICRUDStore = Instance<typeof CRUDStore>;
export {};
