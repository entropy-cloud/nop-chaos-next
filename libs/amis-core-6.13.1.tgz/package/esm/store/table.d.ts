import { SnapshotIn, IAnyModelType, Instance } from 'mobx-state-tree';
import { IFormStore } from './form';
export declare enum SELECTED_STATUS {
    ALL = 0,
    PARTIAL = 1,
    NONE = 2
}
export declare const Column: import("mobx-state-tree").IModelType<{
    label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
    name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
    value: import("mobx-state-tree").IType<any, any, any>;
    id: import("mobx-state-tree").IType<string | undefined, string, string>;
    groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
    toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
    enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
    index: import("mobx-state-tree").IType<number | undefined, number, number>;
    rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
    width: import("mobx-state-tree").IType<number | undefined, number, number>;
    minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
    realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
    breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    className: import("mobx-state-tree").ITypeUnion<any, any, any>;
    appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
}, {
    readonly isPrimary: boolean;
    readonly columnKey: any;
} & {
    toggleToggle(min?: number): void;
    setToggled(value: boolean): void;
    setEnableSearch(value: boolean, skipSave?: boolean): void;
    setMinWidth(value: number): void;
    setWidth(value: number): void;
    setRealWidth(value: number): void;
    markAppeared(value: boolean): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IColumn = Instance<typeof Column>;
export type SColumn = SnapshotIn<typeof Column>;
export declare const Row: import("mobx-state-tree").IModelType<{
    storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
    id: import("mobx-state-tree").ISimpleType<string>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    key: import("mobx-state-tree").ISimpleType<string>;
    pristine: import("mobx-state-tree").IType<any, any, any>;
    data: import("mobx-state-tree").IType<any, any, any>;
    rowSpans: import("mobx-state-tree").IType<any, any, any>;
    index: import("mobx-state-tree").ISimpleType<number>;
    newIndex: import("mobx-state-tree").ISimpleType<number>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
    height: import("mobx-state-tree").IType<number | undefined, number, number>;
    defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    error: import("mobx-state-tree").IType<string | undefined, string, string>;
    depth: import("mobx-state-tree").ISimpleType<number>;
}, {
    readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
    readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
    readonly expandable: boolean;
    childrenSelected(): SELECTED_STATUS;
    readonly partial: boolean;
    readonly checked: boolean;
    readonly modified: boolean;
    getDataWithModifiedChilden(): any;
    readonly collapsed: boolean;
    readonly expanded: boolean;
    readonly moved: boolean;
    readonly locals: any;
    readonly checkable: boolean;
    readonly draggable: boolean;
    /**
     * 判断当前行点击后是否应该继续触发check
     * 用于限制checkOnItemClick触发的check事件
     */
    readonly isCheckAvaiableOnClick: boolean;
    readonly indentStyle: {
        paddingLeft: string;
    };
} & {
    toggle(checked: boolean): void;
    toggleExpanded(): void;
    setExpanded(expanded: boolean): void;
    change(values: object, savePristine?: boolean): void;
    reset(): void;
    setCheckdisable(bool: boolean): void;
    setIsHover(value: boolean): void;
    setHeight(value: number): void;
    replaceWith(data: any): void;
    replaceChildren(children: Array<any>): void;
    markLoading(value: any): void;
    markLoaded(value: any): void;
    setError(value: any): void;
    resetDefered(): void;
    updateData({ children, ...rest }: any): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IRow = Instance<typeof Row>;
export type SRow = SnapshotIn<typeof Row>;
export declare const TableStore: import("mobx-state-tree").IModelType<{
    id: import("mobx-state-tree").ISimpleType<string>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    storeType: import("mobx-state-tree").ISimpleType<string>;
    disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
} & {
    hasRemoteData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    data: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    initedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    updatedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    pristineRaw: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    upStreamData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    action: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    dialogSchema: import("mobx-state-tree").IType<any, any, any>;
    dialogOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dialogData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    drawerSchema: import("mobx-state-tree").IType<any, any, any>;
    drawerOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    drawerData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
} & {
    columns: import("mobx-state-tree").IArrayType<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
    rows: import("mobx-state-tree").IArrayType<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>;
    fullItems: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    fullSelectedItems: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    selectedRows: import("mobx-state-tree").IArrayType<import("mobx-state-tree").IReferenceType<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>>;
    expandedRows: import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>;
    primaryField: import("mobx-state-tree").IType<string | undefined, string, string>;
    orderBy: import("mobx-state-tree").IType<string | undefined, string, string>;
    orderDir: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ITypeUnion<"" | "desc" | "asc", "" | "desc" | "asc", "" | "desc" | "asc">, [undefined]>;
    loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    canAccessSuperData: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    draggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dragging: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    selectable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    showIndex: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    multiple: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    footable: import("mobx-state-tree").IType<any, any, any>;
    expandConfig: import("mobx-state-tree").IType<any, any, any>;
    isNested: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    columnsTogglable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ITypeUnion<boolean | "auto", boolean | "auto", boolean | "auto">, [undefined]>;
    itemCheckableOn: import("mobx-state-tree").IType<string | undefined, string, string>;
    itemDraggableOn: import("mobx-state-tree").IType<string | undefined, string, string>;
    hideCheckToggler: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    combineNum: import("mobx-state-tree").IType<number | undefined, number, number>;
    combineFromIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
    formsRef: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").IType<any, any, any>>, [undefined]>;
    maxKeepItemSelectionLength: import("mobx-state-tree").IType<number | undefined, number, number>;
    keepItemSelectionOnPageChange: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    maxItemSelectionLength: import("mobx-state-tree").IType<number | undefined, number, number>;
    exportExcelLoading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    searchFormExpanded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    lazyRenderAfter: import("mobx-state-tree").IType<number | undefined, number, number>;
    tableLayout: import("mobx-state-tree").IType<string | undefined, string, string>;
    theadHeight: import("mobx-state-tree").IType<number | undefined, number, number>;
    persistKey: import("mobx-state-tree").IType<string | undefined, string, string>;
}, {
    readonly parentStore: any;
    readonly __: any;
    readonly hasChildren: boolean;
    readonly children: Array<any>;
} & {
    onChildStoreDispose(child: any): void;
    syncProps(props: any, prevProps: any, list?: Array<string>): void;
    dispose: (callback?: () => void) => void;
    addChildId: (id: string) => void;
    removeChildId: (id: string) => void;
} & {
    getValueByName(name: string, canAccessSuper?: boolean): any;
    getPristineValueByName(name: string): any;
    readonly pristineDiff: any;
} & {
    setTopStore(value: any): void;
    initData(data?: object, skipSetPristine?: boolean, changeReason?: import("..").DataChangeReason): void;
    temporaryUpdateGlobalVars(globalVar: any): void;
    unDoTemporaryUpdateGlobalVars(): void;
    reset(): void;
    updateData(data?: object, tag?: object, replace?: boolean, concatFields?: string | string[], changeReason?: import("..").DataChangeReason): void;
    changeValue(name: string, value: any, changePristine?: boolean, force?: boolean, otherModifier?: (data: Object) => void, changeReason?: import("..").DataChangeReason): void;
    setCurrentAction(action: any, resolveDefinitions?: (schema: any) => any): void;
    openDialog(ctx: any, additonal?: object, callback?: (confirmed: boolean, values: any) => void, scoped?: import("..").IScopedContext): void;
    closeDialog(confirmed?: any, data?: any): void;
    openDrawer(ctx: any, additonal?: object, callback?: (confirmed: boolean, ret: any) => void, scoped?: import("..").IScopedContext): void;
    closeDrawer(confirmed?: any, data?: any): void;
    getDialogScoped(): import("..").IScopedContext | null;
    getDrawerScoped(): import("..").IScopedContext | null;
} & {
    readonly __: any;
    getSelectionUpperLimit: () => number;
    readonly columnsKey: string;
    readonly columnsData: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly forms: {
        store: IFormStore;
        rowIndex: any;
    }[];
    readonly searchableColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly activedSearchableColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    /** 导出excel列（包含breakpoint列） */
    readonly exportColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly filteredColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly footableColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly toggableColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly activeToggaleColumns: ({
        label: any;
        type: string;
        name: string | undefined;
        value: any;
        id: string;
        groupName: string;
        toggled: boolean;
        toggable: boolean;
        expandable: boolean;
        checkdisable: boolean;
        searchable: any;
        enableSearch: boolean;
        sortable: boolean;
        filterable: any;
        fixed: string;
        index: number;
        rawIndex: number;
        width: number;
        minWidth: number;
        realWidth: number;
        breakpoint: any;
        pristine: any;
        remark: any;
        className: any;
        appeared: boolean;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        label: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        type: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<string>, [undefined]>;
        name: import("mobx-state-tree").IMaybe<import("mobx-state-tree").ISimpleType<string>>;
        value: import("mobx-state-tree").IType<any, any, any>;
        id: import("mobx-state-tree").IType<string | undefined, string, string>;
        groupName: import("mobx-state-tree").IType<string | undefined, string, string>;
        toggled: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        toggable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        expandable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        searchable: import("mobx-state-tree").IMaybe<import("mobx-state-tree").IType<any, any, any>>;
        enableSearch: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        sortable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        filterable: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        fixed: import("mobx-state-tree").IType<string | undefined, string, string>;
        index: import("mobx-state-tree").IType<number | undefined, number, number>;
        rawIndex: import("mobx-state-tree").IType<number | undefined, number, number>;
        width: import("mobx-state-tree").IType<number | undefined, number, number>;
        minWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        realWidth: import("mobx-state-tree").IType<number | undefined, number, number>;
        breakpoint: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        remark: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
        className: import("mobx-state-tree").ITypeUnion<any, any, any>;
        appeared: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    }, {
        readonly isPrimary: boolean;
        readonly columnKey: any;
    } & {
        toggleToggle(min?: number): void;
        setToggled(value: boolean): void;
        setEnableSearch(value: boolean, skipSave?: boolean): void;
        setMinWidth(value: number): void;
        setWidth(value: number): void;
        setRealWidth(value: number): void;
        markAppeared(value: boolean): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly someChecked: boolean;
    readonly allChecked: boolean;
    isSelected: (row: IRow) => boolean;
    readonly allExpanded: boolean;
    isExpanded: (row: IRow) => boolean;
    readonly toggable: boolean;
    readonly modified: number;
    readonly modifiedRows: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly unSelectedRows: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly falttenedRows: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly checkableRows: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly expandableRows: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly moved: number;
    readonly movedRows: import("../utils/helper").TreeItem[];
    readonly hoverRow: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>) | undefined;
    /** 已选择item是否达到数量上限 */
    readonly isSelectionThresholdReached: boolean;
    readonly firstToggledColumnIndex: number | null;
    getData(superData: any): any;
    readonly columnGroup: {
        rowSpan: number;
        label: any;
        fixed: any;
        width: any;
        /** Group单元格包含的首列的索引值，范围[1, columns.length] */
        index: number;
        /** Group单元格包含列数 */
        colSpan: number;
        /** Group单元格包含列信息 */
        has: Array<any>;
    }[];
    getRowById(id: string): import("../utils/helper").TreeItem | null;
    getItemsByName(name: string): any;
    hasColumnHidden(): boolean;
    getExpandedRows(): ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    readonly columnWidthReady: boolean;
    getStickyStyles(column: IColumn, columns: Array<IColumn>, colSpan?: number): any[];
    readonly items: ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    buildStyles(style: any): any;
    /**
     * 构建事件的上下文数据
     * @param buildChain
     * @returns
     */
    readonly eventContext: {
        selectedItems: any[];
        selectedIndexes: string[];
        items: any[];
        unSelectedItems: any[];
    };
    getItemById(id: string): IRow;
} & {
    setTable: (ref: HTMLElement | null) => void;
    getTable: () => HTMLElement | null;
    update: (config: Partial<STableStore>, options?: {
        resolveDefinitions?: (ref: string) => any;
    }) => void;
    updateColumns: (columns: Array<SColumn>) => void;
    initTableWidth: () => void;
    syncTableWidth: (setWidth?: boolean) => void;
    initRows: (rows: Array<any>, getEntryId?: (entry: any, index: number) => string, reUseRow?: boolean | "match", fullItems?: Array<any>, fullSelectedItems?: Array<any>) => void;
    updateSelected: (selected: Array<any>, valueField?: string) => void;
    toggleAll: () => void;
    getSelectedRows: () => ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    toggle: (row: IRow, checked: boolean) => void;
    toggleAncestors: (row: IRow) => void;
    toggleDescendants: (row: IRow, checked: boolean) => void;
    toggleShift: (row: IRow, checked: boolean) => void;
    getToggleShiftRows: (row: IRow) => ({
        storeType: string;
        id: string;
        parentId: string;
        key: string;
        pristine: any;
        data: any;
        rowSpans: any;
        index: number;
        newIndex: number;
        path: string;
        checkdisable: boolean;
        isHover: boolean;
        children: import("mobx-state-tree").IMSTArray<IAnyModelType> & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>>;
        height: number;
        defer: boolean;
        loaded: boolean;
        loading: boolean;
        error: string;
        depth: number;
    } & import("mobx-state-tree/dist/internal").NonEmptyObject & {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    } & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IModelType<{
        storeType: import("mobx-state-tree").IType<string | undefined, string, string>;
        id: import("mobx-state-tree").ISimpleType<string>;
        parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
        key: import("mobx-state-tree").ISimpleType<string>;
        pristine: import("mobx-state-tree").IType<any, any, any>;
        data: import("mobx-state-tree").IType<any, any, any>;
        rowSpans: import("mobx-state-tree").IType<any, any, any>;
        index: import("mobx-state-tree").ISimpleType<number>;
        newIndex: import("mobx-state-tree").ISimpleType<number>;
        path: import("mobx-state-tree").IType<string | undefined, string, string>;
        checkdisable: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        isHover: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        children: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<IAnyModelType>, [undefined]>;
        height: import("mobx-state-tree").IType<number | undefined, number, number>;
        defer: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loaded: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        loading: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
        error: import("mobx-state-tree").IType<string | undefined, string, string>;
        depth: import("mobx-state-tree").ISimpleType<number>;
    }, {
        readonly parent: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly table: import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyStateTreeNode> | (object & import("mobx-state-tree").IStateTreeNode<import("mobx-state-tree").IAnyComplexType>);
        readonly expandable: boolean;
        childrenSelected(): SELECTED_STATUS;
        readonly partial: boolean;
        readonly checked: boolean;
        readonly modified: boolean;
        getDataWithModifiedChilden(): any;
        readonly collapsed: boolean;
        readonly expanded: boolean;
        readonly moved: boolean;
        readonly locals: any;
        readonly checkable: boolean;
        readonly draggable: boolean;
        /**
         * 判断当前行点击后是否应该继续触发check
         * 用于限制checkOnItemClick触发的check事件
         */
        readonly isCheckAvaiableOnClick: boolean;
        readonly indentStyle: {
            paddingLeft: string;
        };
    } & {
        toggle(checked: boolean): void;
        toggleExpanded(): void;
        setExpanded(expanded: boolean): void;
        change(values: object, savePristine?: boolean): void;
        reset(): void;
        setCheckdisable(bool: boolean): void;
        setIsHover(value: boolean): void;
        setHeight(value: number): void;
        replaceWith(data: any): void;
        replaceChildren(children: Array<any>): void;
        markLoading(value: any): void;
        markLoaded(value: any): void;
        setError(value: any): void;
        resetDefered(): void;
        updateData({ children, ...rest }: any): void;
    }, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>>)[];
    toggleExpandAll: () => void;
    toggleExpanded: (row: IRow) => void;
    setExpanded: (row: IRow | string, expanded: boolean) => void;
    collapseAllAtDepth: (depth: number) => void;
    clear: () => void;
    setOrderByInfo: (key: string, direction: "asc" | "desc" | "") => void;
    changeOrder: (key: string, direction: "asc" | "desc" | "") => void;
    reset: () => void;
    toggleDragging: () => void;
    startDragging: () => void;
    stopDragging: () => void;
    exchange: (fromIndex: number, toIndex: number, item?: IRow) => void;
    addForm: (form: IFormStore, rowIndex: number) => void;
    toggleAllColumns: (min?: number) => void;
    toggleColumnsAtLeast: (min?: number) => void;
    persistSaveToggledColumns: () => void;
    setSearchFormExpanded: (value: any) => void;
    toggleSearchFormExpanded: () => void;
    switchToFixedLayout(): void;
    afterCreate(): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type ITableStore = Instance<typeof TableStore>;
export type STableStore = SnapshotIn<typeof TableStore>;
