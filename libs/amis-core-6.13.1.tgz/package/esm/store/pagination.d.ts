import { Instance, SnapshotIn } from 'mobx-state-tree';
export declare const PaginationStore: import("mobx-state-tree").IModelType<{
    id: import("mobx-state-tree").ISimpleType<string>;
    path: import("mobx-state-tree").IType<string | undefined, string, string>;
    storeType: import("mobx-state-tree").ISimpleType<string>;
    disposed: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    parentId: import("mobx-state-tree").IType<string | undefined, string, string>;
    childrenIds: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IArrayType<import("mobx-state-tree").ISimpleType<string>>, [undefined]>;
} & {
    hasRemoteData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").ISimpleType<boolean>, [undefined]>;
    data: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    initedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    updatedAt: import("mobx-state-tree").IType<number | undefined, number, number>;
    pristine: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    pristineRaw: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    upStreamData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    action: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    dialogSchema: import("mobx-state-tree").IType<any, any, any>;
    dialogOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    dialogData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
    drawerSchema: import("mobx-state-tree").IType<any, any, any>;
    drawerOpen: import("mobx-state-tree").IType<boolean | undefined, boolean, boolean>;
    drawerData: import("mobx-state-tree").IOptionalIType<import("mobx-state-tree").IType<any, any, any>, [undefined]>;
} & {
    page: import("mobx-state-tree").IType<number | undefined, number, number>;
    perPage: import("mobx-state-tree").IType<number | undefined, number, number>;
    inputName: import("mobx-state-tree").IType<string | undefined, string, string>;
    outputName: import("mobx-state-tree").IType<string | undefined, string, string>;
    mode: import("mobx-state-tree").IType<string | undefined, string, string>;
    ellipsisPageGap: import("mobx-state-tree").IType<number | undefined, number, number>;
}, {
    readonly parentStore: any;
    readonly __: any;
    readonly hasChildren: boolean;
    readonly children: Array<any>;
} & {
    onChildStoreDispose(child: any): void;
    syncProps(props: any, prevProps: any, list?: Array<string>): void;
    dispose: (callback?: () => void) => void;
    addChildId: (id: string) => void;
    removeChildId: (id: string) => void;
} & {
    getValueByName(name: string, canAccessSuper?: boolean): any;
    getPristineValueByName(name: string): any;
    readonly pristineDiff: any;
} & {
    setTopStore(value: any): void;
    initData(data?: object, skipSetPristine?: boolean, changeReason?: import("..").DataChangeReason): void;
    temporaryUpdateGlobalVars(globalVar: any): void;
    unDoTemporaryUpdateGlobalVars(): void;
    reset(): void;
    updateData(data?: object, tag?: object, replace?: boolean, concatFields?: string | string[], changeReason?: import("..").DataChangeReason): void;
    changeValue(name: string, value: any, changePristine?: boolean, force?: boolean, otherModifier?: (data: Object) => void, changeReason?: import("..").DataChangeReason): void;
    setCurrentAction(action: any, resolveDefinitions?: (schema: any) => any): void;
    openDialog(ctx: any, additonal?: object, callback?: (confirmed: boolean, values: any) => void, scoped?: import("..").IScopedContext): void;
    closeDialog(confirmed?: any, data?: any): void;
    openDrawer(ctx: any, additonal?: object, callback?: (confirmed: boolean, ret: any) => void, scoped?: import("..").IScopedContext): void;
    closeDrawer(confirmed?: any, data?: any): void;
    getDialogScoped(): import("..").IScopedContext | null;
    getDrawerScoped(): import("..").IScopedContext | null;
} & {
    readonly inputItems: any[];
    readonly locals: object;
    readonly lastPage: number;
} & {
    switchTo(page: number, perPage?: number): void;
}, import("mobx-state-tree")._NotCustomized, import("mobx-state-tree")._NotCustomized>;
export type IPaginationStore = Instance<typeof PaginationStore>;
export type SPaginationStore = SnapshotIn<typeof PaginationStore>;
