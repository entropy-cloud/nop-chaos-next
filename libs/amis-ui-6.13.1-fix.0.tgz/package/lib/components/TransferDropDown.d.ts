import { Transfer, TransferProps } from './Transfer';
import React from 'react';
import { OverlayAlignType, PopOverOverlay } from './PopOverContainer';
import type { TooltipObject } from './TooltipWrapper';
export interface TransferDropDownProps extends TransferProps {
    multiple?: boolean;
    borderMode?: 'full' | 'half' | 'none';
    popOverContainer?: any;
    itemRender: (value: any) => JSX.Element | string;
    maxTagCount?: number;
    overflowTagPopover?: TooltipObject;
    overlayAlign?: OverlayAlignType;
    overlayWidth?: string;
    overlay?: PopOverOverlay;
}
export declare class TransferDropDown extends Transfer<TransferDropDownProps> {
    constructor(props: TransferDropDownProps);
    componentDidUpdate(prevProps: TransferDropDownProps): void;
    handleAfterPopoverHide(): void;
    handleChange(value: any, onClose: () => void): void;
    onConfirm(): void;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
        multiple?: boolean | undefined;
        valueField?: string | undefined;
        itemHeight?: number | undefined;
        checkAllLabel?: string | undefined;
        virtualThreshold?: number | undefined;
        statistics?: boolean | undefined;
        selectMode?: import("./Transfer").SelectMode | undefined;
        resultListModeFollowSelect?: boolean | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof import("amis-core").ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof TransferDropDown>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof TransferDropDown, {}> & {
        ComposedComponent: typeof TransferDropDown;
    }>;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
        multiple?: boolean | undefined;
        valueField?: string | undefined;
        itemHeight?: number | undefined;
        checkAllLabel?: string | undefined;
        virtualThreshold?: number | undefined;
        statistics?: boolean | undefined;
        selectMode?: import("./Transfer").SelectMode | undefined;
        resultListModeFollowSelect?: boolean | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof TransferDropDown>;
} & import("hoist-non-react-statics").NonReactStatics<typeof TransferDropDown, {}> & {
    ComposedComponent: typeof TransferDropDown;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
            multiple?: boolean | undefined;
            valueField?: string | undefined;
            itemHeight?: number | undefined;
            checkAllLabel?: string | undefined;
            virtualThreshold?: number | undefined;
            statistics?: boolean | undefined;
            selectMode?: import("./Transfer").SelectMode | undefined;
            resultListModeFollowSelect?: boolean | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<TransferDropDownProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "overlay" | "inline" | "showArrow" | "placeholder" | "loadingConfig" | "itemClassName" | "labelClassName" | "labelField" | "popOverContainer" | "clearable" | "borderMode" | "onRef" | "overlayWidth" | "showInvalidMatch" | "noResultsText" | "checkAll" | "maxTagCount" | "overflowTagPopover" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "itemRender" | "placeholderRender" | "initiallyOpen" | "onlyChildren" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "searchResultMode" | "searchResultColumns" | "selectRender" | "resultTitle" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "overlayAlign"> & {
                multiple?: boolean | undefined;
                valueField?: string | undefined;
                itemHeight?: number | undefined;
                checkAllLabel?: string | undefined;
                virtualThreshold?: number | undefined;
                statistics?: boolean | undefined;
                selectMode?: import("./Transfer").SelectMode | undefined;
                resultListModeFollowSelect?: boolean | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof TransferDropDown>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof TransferDropDown, {}> & {
        ComposedComponent: typeof TransferDropDown;
    };
};
export default _default;
