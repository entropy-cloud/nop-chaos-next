import React from 'react';
export declare const dimensions: {
    name: string;
    width: number;
    height: number;
}[];
export default function MobileDevTool(props: {
    container: HTMLElement | null;
    previewBody: HTMLElement | null;
    border?: number;
    onChangeScale?: (scale: number) => void;
}): React.JSX.Element;
