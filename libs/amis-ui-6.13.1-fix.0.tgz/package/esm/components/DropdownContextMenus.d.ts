/**
 * @file DropdownContextMenus
 * @desc 下拉菜单组件,用于展示上下文菜单
 */
import React from 'react';
import { ThemeProps } from 'amis-core';
/**
 * 菜单项配置
 */
export interface ContextMenu<T = any> {
    /** 菜单项 ID */
    id?: string;
    /** 菜单项文本 */
    label: string;
    /** 菜单项图标 */
    icon?: string;
    /** 菜单项等级 */
    level?: 'normal' | 'danger';
    className?: string;
    disabled?: boolean;
    /** 点击菜单项的回调 */
    onClick?: (item: T) => void;
}
/**
 * 组件属性定义
 */
interface DropdownContextMenusProps<T = Record<string, any>> extends ThemeProps {
    /** 是否禁用 */
    disabled?: boolean;
    /** 上下文数据 */
    context: T;
    /** 获取目标元素的方法 */
    getTargetElement?: (dom: HTMLElement) => HTMLElement;
    /** 上下文菜单配置，可以是数组或返回数组的函数 */
    contextMenus: ContextMenu<T>[] | ((item: T) => ContextMenu<T>[]);
    /** 上下文菜单点击回调 */
    onContextMenu?: (item: T, menu: ContextMenu<T>) => void;
    /** 弹出框容器 */
    popOverContainer?: React.ReactNode | (() => React.ReactNode);
    /** 自定义样式 */
    style?: React.CSSProperties;
    /** 自定义类名 */
    className?: string;
}
/**
 * 下拉菜单组件
 * 用于展示上下文菜单的弹出层组件
 */
export declare function DropdownContextMenus<T = Record<string, any>>({ context, contextMenus, classnames: cx, onContextMenu, popOverContainer, getTargetElement, style, className }: DropdownContextMenusProps<T>): React.JSX.Element;
declare const _default: {
    new (props: Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<DropdownContextMenusProps<unknown>, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof DropdownContextMenus>;
} & import("hoist-non-react-statics").NonReactStatics<typeof DropdownContextMenus, {}> & {
    ComposedComponent: typeof DropdownContextMenus;
};
export default _default;
