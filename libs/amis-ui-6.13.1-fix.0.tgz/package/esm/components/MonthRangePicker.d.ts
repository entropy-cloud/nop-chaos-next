/**
 * @file MonthRangePicker
 * @description 月份范围选择器
 * @author fex
 */
import React from 'react';
import moment from 'moment';
import { ThemeProps } from 'amis-core';
import { LocaleProps } from 'amis-core';
import { ShortCuts } from './DatePicker';
import type { PlainObject } from 'amis-core';
export interface MonthRangePickerProps extends ThemeProps, LocaleProps {
    className?: string;
    popoverClassName?: string;
    placeholder?: string;
    theme?: any;
    format: string;
    utc?: boolean;
    inputFormat?: string;
    timeFormat?: string;
    /**
     * @deprecated 3.1.0后废弃，用shortcuts替代
     */
    ranges?: string | Array<ShortCuts>;
    shortcuts?: string | Array<ShortCuts>;
    clearable?: boolean;
    minDate?: moment.Moment;
    maxDate?: moment.Moment;
    minDuration?: moment.Duration;
    maxDuration?: moment.Duration;
    joinValues: boolean;
    delimiter: string;
    value?: any;
    onChange: (value: any) => void;
    data?: any;
    disabled?: boolean;
    closeOnSelect?: boolean;
    overlayPlacement: string;
    resetValue?: any;
    popOverContainer?: any;
    embed?: boolean;
    onFocus?: Function;
    onBlur?: Function;
    label?: string | false;
}
export interface MonthRangePickerState {
    isOpened: boolean;
    isFocused: boolean;
    startDate?: moment.Moment;
    endDate?: moment.Moment;
}
export declare class MonthRangePicker extends React.Component<MonthRangePickerProps, MonthRangePickerState> {
    static defaultProps: {
        placeholder: string;
        format: string;
        inputFormat: string;
        joinValues: boolean;
        clearable: boolean;
        delimiter: string;
        resetValue: string;
        closeOnSelect: boolean;
        overlayPlacement: string;
    };
    innerDom: any;
    popover: any;
    input?: HTMLInputElement;
    dom: React.RefObject<HTMLDivElement | null>;
    nextMonth: moment.Moment;
    constructor(props: MonthRangePickerProps);
    componentDidUpdate(prevProps: MonthRangePickerProps): void;
    focus(): void;
    blur(): void;
    handleFocus(e: React.SyntheticEvent<HTMLDivElement>): void;
    handleBlur(e: React.SyntheticEvent<HTMLDivElement>): void;
    open(): void;
    close(): void;
    handleClick(): void;
    handlePopOverClick(e: React.MouseEvent<any>): void;
    handleKeyPress(e: React.KeyboardEvent): void;
    confirm(): void;
    filterDate(date: moment.Moment, originValue?: moment.Moment, timeFormat?: string, type?: 'start' | 'end'): moment.Moment;
    handleStartChange(newValue: moment.Moment): void;
    handleEndChange(newValue: moment.Moment): void;
    handleMobileChange(data: any, callback?: () => void): void;
    selectShortcut(shortcut: PlainObject): void;
    renderShortcuts(shortcuts: string | Array<ShortCuts> | undefined): React.JSX.Element | null;
    clearValue(e: React.MouseEvent<any>): void;
    checkStartIsValidDate(currentDate: moment.Moment): boolean;
    checkEndIsValidDate(currentDate: moment.Moment): boolean;
    renderMonth(props: any, month: number, year: number): React.JSX.Element;
    renderCalendar(): React.JSX.Element;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        overlayPlacement?: string | undefined;
        joinValues?: boolean | undefined;
        delimiter?: string | undefined;
        resetValue?: any;
        inputFormat?: string | undefined;
        closeOnSelect?: boolean | undefined;
        format?: string | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof MonthRangePicker>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof MonthRangePicker, {}> & {
        ComposedComponent: typeof MonthRangePicker;
    }>;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        overlayPlacement?: string | undefined;
        joinValues?: boolean | undefined;
        delimiter?: string | undefined;
        resetValue?: any;
        inputFormat?: string | undefined;
        closeOnSelect?: boolean | undefined;
        format?: string | undefined;
    } & {} & {
        locale?: string | undefined;
        translate?: ((str: string, ...args: any[]) => string) | undefined;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof MonthRangePicker>;
} & import("hoist-non-react-statics").NonReactStatics<typeof MonthRangePicker, {}> & {
    ComposedComponent: typeof MonthRangePicker;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            overlayPlacement?: string | undefined;
            joinValues?: boolean | undefined;
            delimiter?: string | undefined;
            resetValue?: any;
            inputFormat?: string | undefined;
            closeOnSelect?: boolean | undefined;
            format?: string | undefined;
        } & {} & {
            locale?: string | undefined;
            translate?: ((str: string, ...args: any[]) => string) | undefined;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>;
            state: Readonly<{}>;
            refs: {
                [key: string]: React.ReactInstance;
            };
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<MonthRangePickerProps, keyof LocaleProps>, "onChange" | "className" | "style" | "label" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "onFocus" | "onBlur" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "data" | "embed" | "minDate" | "maxDate" | "timeFormat" | "utc" | "minDuration" | "maxDuration" | "shortcuts" | "ranges"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                overlayPlacement?: string | undefined;
                joinValues?: boolean | undefined;
                delimiter?: string | undefined;
                resetValue?: any;
                inputFormat?: string | undefined;
                closeOnSelect?: boolean | undefined;
                format?: string | undefined;
            } & {} & {
                locale?: string | undefined;
                translate?: ((str: string, ...args: any[]) => string) | undefined;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof MonthRangePicker>;
    } & import("hoist-non-react-statics").NonReactStatics<typeof MonthRangePicker, {}> & {
        ComposedComponent: typeof MonthRangePicker;
    };
};
export default _default;
