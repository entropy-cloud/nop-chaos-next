/**
 * @file 角标组件
 */
import React from 'react';
import hoistNonReactStatic from 'hoist-non-react-statics';
import { ClassNamesFn, AMISBadgeBase } from 'amis-core';
export type BadgeObject = AMISBadgeBase;
export interface BadgeProps {
    badge?: BadgeObject;
    classnames: ClassNamesFn;
    data?: any;
    children?: React.ReactNode | Array<React.ReactNode>;
}
export declare class Badge extends React.Component<BadgeProps, object> {
    static propsList: Array<string>;
    constructor(props: BadgeProps);
    renderBadge(text: any, size: number, position: any, offsetStyle: any, sizeStyle: any, animationElement: any): React.JSX.Element | null;
    render(): string | number | bigint | boolean | React.JSX.Element | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | null | undefined;
}
export default Badge;
export declare function withBadge<P extends object>(Component: React.ComponentType<P>): {
    new (props: P & BadgeProps): {
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<P & BadgeProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<P & BadgeProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<P & BadgeProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<P & BadgeProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<P & BadgeProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<P & BadgeProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<P & BadgeProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<P & BadgeProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<P & BadgeProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    new (props: P & BadgeProps, context: any): {
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<P & BadgeProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<P & BadgeProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<P & BadgeProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<P & BadgeProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<P & BadgeProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<P & BadgeProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<P & BadgeProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<P & BadgeProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<P & BadgeProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType?: React.Context<any> | undefined;
    propTypes?: any;
} & hoistNonReactStatic.NonReactStatics<React.ComponentType<P>, {}>;
