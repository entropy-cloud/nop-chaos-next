/**
 * AutoFoldedList Component
 *
 * A component that automatically folds list items when there are too many to display.
 * When clicked, it expands to show all items.
 *
 * @component
 */
import React from 'react';
import { ThemeProps } from 'amis-core';
import { type TooltipObject } from './TooltipWrapper';
export interface AutoFoldedListProps extends ThemeProps {
    enabled?: boolean;
    /**
     * Maximum number of items to be visible
     */
    maxVisibleCount?: number;
    /**
     * Custom class name for the tooltip
     */
    tooltipClassName?: string;
    /**
     * Configuration options for the tooltip
     */
    tooltipOptions?: TooltipObject;
    /**
     * Array of items to be displayed in the list
     */
    items: Array<any>;
    /**
     * Function to render each list item
     * @param item - The item to render
     * @param index - The index of the item
     * @param folded - Whether the item is in folded state
     */
    renderItem: (item: any, index: number, folded: boolean) => React.ReactNode;
    /**
     * Function to render the summary text for remaining items
     * @param restItems - Array of remaining items
     */
    renderMoreSummary?: (restItems: any[]) => React.ReactNode;
    /**
     * Function to render the tooltip content
     * @param restItems - Array of remaining items
     */
    renderTooltipContent?: (restItems: any[]) => React.ReactNode;
    /**
     * Container element for the popover
     */
    popOverContainer?: any;
}
export declare const AutoFoldedList: React.FC<AutoFoldedListProps>;
declare const _default: {
    new (props: Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        refs: {
            [key: string]: React.ReactInstance;
        };
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<AutoFoldedListProps, keyof ThemeProps> & import("amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<React.FC<AutoFoldedListProps>>;
} & import("hoist-non-react-statics").NonReactStatics<React.FC<AutoFoldedListProps>, {}> & {
    ComposedComponent: React.FC<AutoFoldedListProps>;
};
export default _default;
