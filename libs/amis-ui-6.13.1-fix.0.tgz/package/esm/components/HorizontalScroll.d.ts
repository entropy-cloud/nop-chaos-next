import { TestIdBuilder, ThemeProps } from 'amis-core';
import React, { ReactNode } from 'react';
type ChildrenType = React.ReactNode | ((showSelect: () => void) => React.ReactNode);
export interface HorizontalScrollProps extends ThemeProps {
    /**
     * 左右按钮图标
     */
    icons?: ReactNode | ReactNode[];
    /**
     * 外层容器类名
     */
    className?: string;
    /**
     * 左右图标类名
     */
    iconsClassName?: string | string[];
    /**
     * 测试ID生成器
     */
    testIdBuilder?: TestIdBuilder;
    children: ChildrenType;
    /**
     * 子元素滚动容器，用于计算当前点击。默认为当前滚动容器最内层
     */
    getScrollParentElement?: () => HTMLElement;
    /**
     * 激活的子元素类名，如果设置，那么每次页面缩放的时候，都会让对应的位置滚动到可视区域。如果命中多个元素，则只会滚动第一个
     * 支持传入多个类名，按照传入数组中元素的顺序作为优先级顺序。[p0, p1, p2...]，优先级高的类名命中元素则会停止寻找
     */
    activeChildClassName?: string | string[];
}
interface HorizontalScrollState {
    isOverflow: boolean;
    arrowLeftDisabled: boolean;
    arrowRightDisabled: boolean;
    scroll: boolean;
}
export declare class HorizontalScroll extends React.Component<HorizontalScrollProps, HorizontalScrollState> {
    innerWrapper: React.RefObject<HTMLDivElement | null>;
    resizeDom: React.RefObject<HTMLDivElement | null>;
    toDispose: Array<() => void>;
    constructor(props: HorizontalScrollProps);
    /**
     * 处理箭头点击事件
     * @param type 箭头方向，'left' 表示向左，'right' 表示向右
     */
    handleArrow(type: 'left' | 'right'): void;
    /**
     * 根据滚动条位置更新左右箭头的禁用状态
     */
    checkArrowStatus: import("lodash").DebouncedFunc<() => void>;
    /**
     * 保证选中的yua始终显示在可视区域
     */
    showSelected(isOverflow?: boolean): void;
    /**
     * 处理内容与容器之间的位置关系
     */
    checkIsOverflow(): void;
    /**
     * 渲染箭头图标
     * @param type 箭头类型，'left' 表示左箭头，'right' 表示右箭头
     * @returns 返回渲染的箭头图标组件或 null
     */
    renderArrow(type: 'left' | 'right'): React.JSX.Element | null;
    /**
     * 监听导航上的滚动事件
     */
    handleWheel(e: WheelEvent): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): ReactNode;
}
export {};
