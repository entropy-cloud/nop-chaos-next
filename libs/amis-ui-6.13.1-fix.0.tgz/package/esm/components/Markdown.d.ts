import React from 'react';
/**
 * @file markdown 解析
 */
import markdownIt from 'markdown-it';
export declare function markdown(content: string, options?: markdownIt.Options): string;
interface MarkdownProps {
    content: string;
    options: object;
}
export default class Markdown extends React.Component<MarkdownProps> {
    dom: any;
    static defaultProps: {
        content: string;
        options: {
            linkify: boolean;
        };
    };
    constructor(props: MarkdownProps);
    htmlRef(dom: any): void;
    componentDidUpdate(nextProps: MarkdownProps): void;
    _render(): Promise<void>;
    render(): React.JSX.Element;
}
export {};
