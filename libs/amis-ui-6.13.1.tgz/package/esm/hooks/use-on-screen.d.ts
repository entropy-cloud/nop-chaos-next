declare const useOnScreen: (ref: any) => boolean;
export default useOnScreen;
