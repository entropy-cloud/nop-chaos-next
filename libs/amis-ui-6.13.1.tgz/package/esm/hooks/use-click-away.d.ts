import { RefObject } from 'react';
/**
 * 自定义 Hook：useClickAway
 * 当点击事件发生在指定元素外部时，触发回调函数
 *
 * @param ref - 目标元素的引用
 * @param onClickAway - 点击外部时的回调函数
 * @param doc - Document 对象，默认为当前文档
 * @param events - 监听的事件类型，默认为 ['mousedown', 'touchstart']
 */
declare const useClickAway: (ref: RefObject<HTMLElement | null>, onClickAway: (e: Event) => void, doc?: Document, events?: string[]) => void;
export default useClickAway;
