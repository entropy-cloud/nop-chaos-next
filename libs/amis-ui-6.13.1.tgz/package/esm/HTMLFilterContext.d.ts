import React from 'react';
export declare const HTMLFilterContext: React.Context<(txt: string) => string>;
export default HTMLFilterContext;
