export declare function vectorLength(v: number[]): number;
export declare function dotProduct(v1: number[], v2: number[]): number;
export declare function vectorAngle(v1: number[], v2: number[]): number;
export declare function computeSideLength(side: number, angle: number): number;
/**
 * 传入起点、终点和距离，返回直线上距离起点距离为distance
 *
 * @param {[number, number]} [startX, startY]
 * @param {[number, number]} [endX, endY]
 * @param {number} distance
 * @returns
 * @memberof SvgPathGenerator
 */
export declare function radiusPoint([startX, startY]: number[], [endX, endY]: number[], distance: number): number[];
export declare function radiusStartEndPoint(v1: number[], v2: number[], radius: number): {
    start: number[];
    end: number[];
    radius: number;
    sweepFlag: number;
};
