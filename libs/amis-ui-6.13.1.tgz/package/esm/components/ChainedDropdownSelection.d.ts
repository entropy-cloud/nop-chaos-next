import React from 'react';
import { ThemeProps, LocaleProps } from 'amis-core';
import { Options } from './Select';
import { BaseSelection, BaseSelectionProps } from './Selection';
import type { TestIdBuilder } from 'amis-core';
export interface ChainedDropDownSelectionProps extends ThemeProps, LocaleProps, BaseSelectionProps {
    options: Array<any>;
    value: any;
    onChange: (value: any) => void;
    disabled?: boolean;
    searchable?: boolean;
    popOverContainer?: any;
    testIdBuilder?: TestIdBuilder;
}
interface ChainedDropdownSelectionState {
    stacks: Array<Options>;
    values: Array<string>;
}
export declare class ChainedDropdownSelection extends BaseSelection<ChainedDropDownSelectionProps, ChainedDropdownSelectionState> {
    constructor(props: ChainedDropDownSelectionProps);
    componentDidUpdate(prevProps: ChainedDropDownSelectionProps): void;
    computed(value: string, options: Options): {
        values: string[];
        stacks: Options[];
    };
    getFlatOptions(options: Options): Pick<import("amis-core").Option, keyof import("amis-core").Option>[];
    handleSelect(index: number, value: string): void;
    computedStask(values: string[]): Options[];
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
        multiple?: boolean | undefined;
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ChainedDropdownSelection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ChainedDropdownSelection, {}> & {
        ComposedComponent: typeof ChainedDropdownSelection;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
        multiple?: boolean | undefined;
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ChainedDropdownSelection>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ChainedDropdownSelection, {}> & {
    ComposedComponent: typeof ChainedDropdownSelection;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ChainedDropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: import("amis-core").Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ChainedDropdownSelection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ChainedDropdownSelection, {}> & {
        ComposedComponent: typeof ChainedDropdownSelection;
    };
};
export default _default;
