import { SchemaEditorItemCommon } from './Common';
export declare class SchemaEditorItemArray extends SchemaEditorItemCommon {
    state: {
        collapsed: boolean;
    };
    toggleCollapsed(): void;
    handleItemsChange(items: any): void;
    renderItems(): import("react/jsx-runtime").JSX.Element;
    render(): import("react/jsx-runtime").JSX.Element;
}
