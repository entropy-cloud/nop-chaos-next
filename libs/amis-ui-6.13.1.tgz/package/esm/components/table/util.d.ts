import { ColumnProps, SummaryProps, ThProps, TdProps, SortProps } from './index';
export declare function checkChildrenRow(data: any, childrenColumnName: string): any;
export declare function getDataChildrenKeys(data: any, childrenColumnName: string, rowSelectionKeyField: string): string[];
export declare function getAllSelectableRows(dataSource: Array<any>, rowSelectionKeyField: string, childrenColumnName: string, expandable: boolean, selectedRowKeys: Array<string | number>, maxSelectedLength: number | undefined): {
    rows: any[];
    rowKeys: (string | number)[];
    restSelectedKeys: (string | number)[];
};
export declare function getRowsByKeys(dataSource: Array<any>, keys: Array<string | number>, keyField: string, childrenColumnName: string): {
    selectedRows: any[];
    unSelectedRows: any[];
};
export declare function getMaxLevelThRowSpan(columns: Array<ColumnProps>): number;
export declare function getThRowSpan(column: ColumnProps): number;
export declare function getThColSpan(column: ColumnProps): number;
export declare function buildColumns(columns: Array<ColumnProps> | undefined, thColumns: Array<Array<any>>, tdColumns: Array<ColumnProps> | undefined, maxLevel: number, depth?: number, fixed?: boolean | string): void;
export declare function getBuildColumns(columns: Array<any>): {
    thColumns: ThProps[][];
    tdColumns: TdProps[];
};
export declare function updateFixedRow(row: HTMLTableRowElement, columns: Array<ColumnProps | SummaryProps>, cx: Function): void;
export declare function updateStickyRow(thead: HTMLCollection, rowIndex: number): void;
export declare function hasFixedColumn(columns: Array<ColumnProps | SummaryProps>): number | ColumnProps | SummaryProps | ((predicate: (value: ColumnProps | SummaryProps, index: number, obj: (ColumnProps | SummaryProps)[]) => unknown, thisArg?: any) => number) | (() => ArrayIterator<ColumnProps | SummaryProps>) | {
    [x: number]: boolean | undefined;
    length?: boolean | undefined;
    toString?: boolean | undefined;
    toLocaleString?: boolean | undefined;
    pop?: boolean | undefined;
    push?: boolean | undefined;
    concat?: boolean | undefined;
    join?: boolean | undefined;
    reverse?: boolean | undefined;
    shift?: boolean | undefined;
    slice?: boolean | undefined;
    sort?: boolean | undefined;
    splice?: boolean | undefined;
    unshift?: boolean | undefined;
    indexOf?: boolean | undefined;
    lastIndexOf?: boolean | undefined;
    every?: boolean | undefined;
    some?: boolean | undefined;
    forEach?: boolean | undefined;
    map?: boolean | undefined;
    filter?: boolean | undefined;
    reduce?: boolean | undefined;
    reduceRight?: boolean | undefined;
    find?: boolean | undefined;
    findIndex?: boolean | undefined;
    fill?: boolean | undefined;
    copyWithin?: boolean | undefined;
    entries?: boolean | undefined;
    keys?: boolean | undefined;
    values?: boolean | undefined;
    includes?: boolean | undefined;
    flatMap?: boolean | undefined;
    flat?: boolean | undefined;
    [Symbol.iterator]?: boolean | undefined;
    readonly [Symbol.unscopables]?: boolean | undefined;
} | (() => string) | {
    (): string;
    (locales: string | string[], options?: Intl.NumberFormatOptions & Intl.DateTimeFormatOptions): string;
} | (() => ColumnProps | SummaryProps | undefined) | ((...items: (ColumnProps | SummaryProps)[]) => number) | {
    (...items: ConcatArray<ColumnProps | SummaryProps>[]): (ColumnProps | SummaryProps)[];
    (...items: (ColumnProps | SummaryProps | ConcatArray<ColumnProps | SummaryProps>)[]): (ColumnProps | SummaryProps)[];
} | ((separator?: string) => string) | (() => (ColumnProps | SummaryProps)[]) | (() => ColumnProps | SummaryProps | undefined) | ((start?: number, end?: number) => (ColumnProps | SummaryProps)[]) | ((compareFn?: ((a: ColumnProps | SummaryProps, b: ColumnProps | SummaryProps) => number) | undefined) => (ColumnProps | SummaryProps)[]) | {
    (start: number, deleteCount?: number): (ColumnProps | SummaryProps)[];
    (start: number, deleteCount: number, ...items: (ColumnProps | SummaryProps)[]): (ColumnProps | SummaryProps)[];
} | ((...items: (ColumnProps | SummaryProps)[]) => number) | ((searchElement: ColumnProps | SummaryProps, fromIndex?: number) => number) | ((searchElement: ColumnProps | SummaryProps, fromIndex?: number) => number) | {
    <S extends ColumnProps | SummaryProps>(predicate: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => value is S, thisArg?: any): this is S[];
    (predicate: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => unknown, thisArg?: any): boolean;
} | ((predicate: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => unknown, thisArg?: any) => boolean) | ((callbackfn: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => void, thisArg?: any) => void) | (<U>(callbackfn: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => U, thisArg?: any) => U[]) | {
    <S extends ColumnProps | SummaryProps>(predicate: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => value is S, thisArg?: any): S[];
    (predicate: (value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => unknown, thisArg?: any): (ColumnProps | SummaryProps)[];
} | {
    (callbackfn: (previousValue: ColumnProps | SummaryProps, currentValue: ColumnProps | SummaryProps, currentIndex: number, array: (ColumnProps | SummaryProps)[]) => ColumnProps | SummaryProps): ColumnProps | SummaryProps;
    (callbackfn: (previousValue: ColumnProps | SummaryProps, currentValue: ColumnProps | SummaryProps, currentIndex: number, array: (ColumnProps | SummaryProps)[]) => ColumnProps | SummaryProps, initialValue: ColumnProps | SummaryProps): ColumnProps | SummaryProps;
    <U>(callbackfn: (previousValue: U, currentValue: ColumnProps | SummaryProps, currentIndex: number, array: (ColumnProps | SummaryProps)[]) => U, initialValue: U): U;
} | {
    (callbackfn: (previousValue: ColumnProps | SummaryProps, currentValue: ColumnProps | SummaryProps, currentIndex: number, array: (ColumnProps | SummaryProps)[]) => ColumnProps | SummaryProps): ColumnProps | SummaryProps;
    (callbackfn: (previousValue: ColumnProps | SummaryProps, currentValue: ColumnProps | SummaryProps, currentIndex: number, array: (ColumnProps | SummaryProps)[]) => ColumnProps | SummaryProps, initialValue: ColumnProps | SummaryProps): ColumnProps | SummaryProps;
    <U>(callbackfn: (previousValue: U, currentValue: ColumnProps | SummaryProps, currentIndex: number, array: (ColumnProps | SummaryProps)[]) => U, initialValue: U): U;
} | {
    <S extends ColumnProps | SummaryProps>(predicate: (value: ColumnProps | SummaryProps, index: number, obj: (ColumnProps | SummaryProps)[]) => value is S, thisArg?: any): S | undefined;
    (predicate: (value: ColumnProps | SummaryProps, index: number, obj: (ColumnProps | SummaryProps)[]) => unknown, thisArg?: any): ColumnProps | SummaryProps | undefined;
} | ((value: ColumnProps | SummaryProps, start?: number, end?: number) => (ColumnProps | SummaryProps)[]) | ((target: number, start: number, end?: number) => (ColumnProps | SummaryProps)[]) | (() => ArrayIterator<[number, ColumnProps | SummaryProps]>) | (() => ArrayIterator<number>) | (() => ArrayIterator<ColumnProps | SummaryProps>) | ((searchElement: ColumnProps | SummaryProps, fromIndex?: number) => boolean) | (<U, This = undefined>(callback: (this: This, value: ColumnProps | SummaryProps, index: number, array: (ColumnProps | SummaryProps)[]) => U | readonly U[], thisArg?: This | undefined) => U[]) | (<A, D extends number = 1>(this: A, depth?: D | undefined) => FlatArray<A, D>[]) | undefined;
export declare function levelsSplit(level: string): number[];
export declare function getSortData(data: Array<any>, columns: Array<ColumnProps>, childrenColumnName: string, sort?: SortProps): Array<any>;
