/**
 * @file table/BodyCell
 * @author fex
 */
import React from 'react';
import { ThemeProps, ClassNamesFn } from 'amis-core';
import { ColumnProps } from './index';
import type { TestIdBuilder } from 'amis-core';
export interface Props extends ThemeProps {
    fixed?: string | boolean;
    selfSticky?: boolean;
    rowSpan?: number | any;
    colSpan?: number | any;
    key?: string | number;
    className?: string;
    children?: any;
    tagName?: string;
    style?: Object;
    column?: ColumnProps;
    wrapperComponent: any;
    depth?: number;
    col?: string;
    index?: number;
    classnames: ClassNamesFn;
    testIdBuilder?: TestIdBuilder;
}
export default class BodyCell extends React.PureComponent<Props> {
    static defaultProps: {
        fixed: string;
        selfSticky: boolean;
        wrapperComponent: string;
        rowSpan: null;
        colSpan: null;
    };
    render(): import("react/jsx-runtime").JSX.Element;
}
