import React from 'react';
import { BaseSelection, BaseSelectionProps } from './Selection';
import { SpinnerExtraProps } from './Spinner';
import { ThemeProps, LocaleProps } from 'amis-core';
import { Option } from './Select';
import type { TestIdBuilder } from 'amis-core';
export interface DropDownSelectionProps extends ThemeProps, LocaleProps, SpinnerExtraProps, BaseSelectionProps {
    options: Array<any>;
    value: any;
    onChange: (value: any) => void;
    disabled?: boolean;
    searchable?: boolean;
    popOverContainer?: any;
    mode?: 'list' | 'tree';
    testIdBuilder?: TestIdBuilder;
}
export interface DropDownSelectionState {
    searchText: string;
}
declare class DropDownSelection extends BaseSelection<DropDownSelectionProps, DropDownSelectionState> {
    constructor(props: DropDownSelectionProps);
    onSearch(text: string): void;
    filterOptions(options: any[]): any[];
    onPopClose(onClose: () => void): void;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
        multiple?: boolean | undefined;
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof DropDownSelection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof DropDownSelection, {}> & {
        ComposedComponent: typeof DropDownSelection;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
        multiple?: boolean | undefined;
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof DropDownSelection>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof DropDownSelection, {}> & {
    ComposedComponent: typeof DropDownSelection;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<DropDownSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "searchable" | "options" | "value" | "inline" | "disabled" | "popOverContainer" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "mode" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof DropDownSelection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof DropDownSelection, {}> & {
        ComposedComponent: typeof DropDownSelection;
    };
};
export default _default;
