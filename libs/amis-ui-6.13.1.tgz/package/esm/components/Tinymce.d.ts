import React from 'react';
import tinymce, { Editor } from 'tinymce/tinymce';
import 'tinymce/icons/default/index';
import 'tinymce/themes/silver';
import 'tinymce/models/dom/model';
import 'tinymce/plugins/advlist';
import 'tinymce/plugins/autolink';
import 'tinymce/plugins/autoresize';
import 'tinymce/plugins/lists';
import 'tinymce/plugins/link';
import 'tinymce/plugins/image';
import 'tinymce/plugins/charmap';
import 'tinymce/plugins/preview';
import 'tinymce/plugins/anchor';
import 'tinymce/plugins/searchreplace';
import 'tinymce/plugins/visualblocks';
import 'tinymce/plugins/code';
import 'tinymce/plugins/fullscreen';
import 'tinymce/plugins/insertdatetime';
import 'tinymce/plugins/media';
import 'tinymce/plugins/table';
import 'tinymce/plugins/help';
import 'tinymce/plugins/wordcount';
import 'tinymce/plugins/pagebreak';
import 'tinymce/plugins/visualchars';
import 'tinymce/plugins/template';
import 'tinymce/plugins/nonbreaking';
import 'tinymce/plugins/emoticons';
import 'tinymce/plugins/emoticons/js/emojis';
import 'tinymce/plugins/quickbars/plugin';
import 'tinymce/plugins/help/js/i18n/keynav/zh_CN';
import 'tinymce/plugins/help/js/i18n/keynav/en';
import 'tinymce/plugins/help/js/i18n/keynav/de';
import { LocaleProps } from 'amis-core';
interface TinymceEditorProps extends LocaleProps {
    model: string;
    onModelChange?: (value: string) => void;
    onFocus?: () => void;
    onBlur?: () => void;
    disabled?: boolean;
    config?: {
        onLoaded?: (tinymce: any) => void | Promise<void>;
        [propName: string]: any;
    };
    outputFormat?: 'html' | 'text';
    receiver?: string;
}
export default class TinymceEditor extends React.Component<TinymceEditorProps> {
    static defaultProps: {
        outputFormat: string;
    };
    config?: any;
    editor?: Editor;
    unmounted: boolean;
    editorInitialized?: boolean;
    currentContent?: string;
    elementRef: React.RefObject<HTMLTextAreaElement | null>;
    componentDidMount(): void;
    componentDidUpdate(prevProps: TinymceEditorProps): void;
    componentWillUnmount(): void;
    initTiny(): Promise<void>;
    handleIframeUnload(): void;
    initEditor(e: any, editor: Editor): void;
    render(): import("react/jsx-runtime").JSX.Element;
}
export { tinymce };
