import React from 'react';
import { LocaleProps, ThemeProps } from 'amis-core';
import type { TestIdBuilder } from 'amis-core';
export interface ConfirmBoxProps extends LocaleProps, ThemeProps {
    show?: boolean;
    disabled?: boolean;
    closeOnEsc?: boolean;
    beforeConfirm?: (bodyRef?: any) => any;
    onConfirm?: (data: any) => void;
    onCancel?: () => void;
    title?: string;
    showTitle?: boolean;
    showFooter?: boolean;
    children?: JSX.Element | ((methods: {
        loading?: boolean;
        bodyRef: React.MutableRefObject<{
            submit: () => Promise<Record<string, any>>;
        } | undefined>;
        popOverContainer: () => HTMLElement | null | undefined;
        onConfirm: () => void;
    }) => JSX.Element);
    popOverContainer?: any;
    size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | 'full';
    position?: 'top' | 'right' | 'bottom' | 'left';
    resizable?: boolean;
    type: 'dialog' | 'drawer';
    className?: string;
    headerClassName?: string;
    bodyClassName?: string;
    footerClassName?: string;
    testIdBuilder?: TestIdBuilder;
    onExited?: () => void;
    onEntered?: () => void;
}
export declare function ConfirmBox({ type, size, closeOnEsc, show, onCancel, title, showTitle, headerClassName, translate: __, children, showFooter, onConfirm, beforeConfirm, popOverContainer, position, resizable, classnames: cx, className, bodyClassName, footerClassName, mobileUI, disabled, testIdBuilder, onEntered, onExited }: ConfirmBoxProps): import("react/jsx-runtime").JSX.Element;
export declare namespace ConfirmBox {
    var defaultProps: {
        type: "dialog";
        position: "right";
    };
}
declare const _default: {
    new (props: Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
        type?: "dialog" | "drawer" | undefined;
        position?: "top" | "right" | "bottom" | "left" | undefined;
    } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps): {
            ref: any;
            childRef: (ref: any) => void;
            getWrappedInstance: () => any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ConfirmBox>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ConfirmBox, {}> & {
        ComposedComponent: typeof ConfirmBox;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
        type?: "dialog" | "drawer" | undefined;
        position?: "top" | "right" | "bottom" | "left" | undefined;
    } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ConfirmBox>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ConfirmBox, {}> & {
    ComposedComponent: typeof ConfirmBox;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
            type?: "dialog" | "drawer" | undefined;
            position?: "top" | "right" | "bottom" | "left" | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps): {
            ref: any;
            childRef: (ref: any) => void;
            getWrappedInstance: () => any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ConfirmBoxProps, keyof ThemeProps>, "children" | "locale" | "translate" | "disabled" | "popOverContainer" | "testIdBuilder" | "title" | "size" | "closeOnEsc" | "show" | "onExited" | "onEntered" | "onCancel" | "bodyClassName" | "onConfirm" | "resizable" | "headerClassName" | "showTitle" | "showFooter" | "beforeConfirm" | "footerClassName"> & {
                type?: "dialog" | "drawer" | undefined;
                position?: "top" | "right" | "bottom" | "left" | undefined;
            } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ConfirmBox>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ConfirmBox, {}> & {
        ComposedComponent: typeof ConfirmBox;
    };
};
export default _default;
