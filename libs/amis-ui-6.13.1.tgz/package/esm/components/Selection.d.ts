/**
 * @file Checkboxes
 * @description 多选输入框
 * @author fex
 */
import React from 'react';
import { LocaleProps, ThemeProps, ClassNamesFn } from 'amis-core';
import { Option, Options } from './Select';
import type { TestIdBuilder } from 'amis-core';
export interface BaseSelectionProps extends ThemeProps, LocaleProps {
    options: Options;
    className?: string;
    placeholder?: string;
    value?: any | Array<any>;
    multiple?: boolean;
    clearable?: boolean;
    labelField?: string;
    valueField?: string;
    deferField?: string;
    onChange?: (value: Array<any> | any) => void;
    onDeferLoad?: (option: Option) => void;
    onLeftDeferLoad?: (option: Option, leftOptions: Option) => void;
    inline?: boolean;
    labelClassName?: string;
    option2value?: (option: Option) => any;
    itemClassName?: string;
    itemHeight?: number;
    virtualThreshold?: number;
    virtualListHeight?: number;
    itemRender: (option: Option, states: ItemRenderStates) => JSX.Element;
    disabled?: boolean;
    onClick?: (e: React.MouseEvent) => void;
    placeholderRender?: (props: any) => JSX.Element | null;
    checkAll?: boolean;
    checkAllLabel?: string;
    testIdBuilder?: TestIdBuilder;
}
export interface ItemRenderStates {
    index: number;
    labelField?: string;
    multiple?: boolean;
    checked: boolean;
    onChange: () => void;
    disabled?: boolean;
    classnames: ClassNamesFn;
    testIdBuilder?: TestIdBuilder;
}
export declare class BaseSelection<T extends BaseSelectionProps = BaseSelectionProps, S = any> extends React.Component<T, S> {
    static itemRender(option: Option, states: ItemRenderStates): React.JSX.Element;
    static defaultProps: {
        placeholder: string;
        itemRender: typeof BaseSelection.itemRender;
        multiple: boolean;
        clearable: boolean;
        virtualThreshold: number;
        itemHeight: number;
    };
    static value2array(value: any, options: Options, option2value?: (option: Option) => any, valueField?: string): Options;
    static resolveSelected(value: any, options: Options, option2value?: (option: Option) => any): Option | null;
    intersectArray(arr1: undefined | Array<Option>, arr2: undefined | Array<Option>): Array<Option>;
    toggleOption(option: Option): void;
    getAvailableOptions(): Option[];
    toggleAll(): void;
    render(): React.JSX.Element;
}
export declare class Selection extends BaseSelection {
}
declare const _default: {
    new (props: Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
        multiple?: boolean | undefined;
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof Selection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof Selection, {}> & {
        ComposedComponent: typeof Selection;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
        multiple?: boolean | undefined;
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof Selection>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof Selection, {}> & {
    ComposedComponent: typeof Selection;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
            multiple?: boolean | undefined;
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<BaseSelectionProps, keyof LocaleProps>, "onChange" | "className" | "style" | "valueField" | "labelField" | "options" | "value" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "onClick" | "itemClassName" | "labelClassName" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender"> & {
                multiple?: boolean | undefined;
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof Selection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof Selection, {}> & {
        ComposedComponent: typeof Selection;
    };
};
export default _default;
