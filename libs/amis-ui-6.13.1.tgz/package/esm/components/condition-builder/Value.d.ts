import React from 'react';
import { FieldSimple } from './types';
import { ThemeProps, LocaleProps } from 'amis-core';
import { FormulaPickerProps } from '../formula/Picker';
import type { AMISOperatorType, TestIdBuilder } from 'amis-core';
export interface ValueProps extends ThemeProps, LocaleProps {
    value: any;
    data?: any;
    onChange: (value: any) => void;
    field: FieldSimple;
    op?: AMISOperatorType;
    disabled?: boolean;
    formula?: FormulaPickerProps;
    popOverContainer?: any;
    renderEtrValue?: any;
    testIdBuilder?: TestIdBuilder;
    onFocus?: (e: any) => void;
    onBlur?: (e: any) => void;
}
export declare class Value extends React.Component<ValueProps> {
    renderCustomValue(props: any): any;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Omit<Omit<ValueProps, keyof LocaleProps> & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof Value>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof Value, {}> & {
        ComposedComponent: typeof Value;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Omit<ValueProps, keyof LocaleProps> & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof Value>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof Value, {}> & {
    ComposedComponent: typeof Value;
}, {}> & {
    ComposedComponent: {
        new (props: Omit<ValueProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ValueProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof Value>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof Value, {}> & {
        ComposedComponent: typeof Value;
    };
};
export default _default;
