import React from 'react';
import { ConditionBuilderFields, ConditionBuilderFuncs } from './types';
import { ThemeProps, LocaleProps, AMISConditionGroupValue } from 'amis-core';
import { ConditionBuilderConfig } from './config';
import { FormulaPickerProps } from '../formula/Picker';
import type { TestIdBuilder } from 'amis-core';
interface ConditionGroupState {
    isCollapsed: boolean;
}
export interface ConditionGroupProps extends ThemeProps, LocaleProps {
    builderMode?: 'simple' | 'full';
    config: ConditionBuilderConfig;
    value?: AMISConditionGroupValue;
    fields: ConditionBuilderFields;
    funcs?: ConditionBuilderFuncs;
    showNot?: boolean;
    showANDOR?: boolean;
    showIf?: boolean;
    formulaForIf?: FormulaPickerProps;
    data?: any;
    disabled?: boolean;
    searchable?: boolean;
    onChange: (value: AMISConditionGroupValue) => void;
    removeable?: boolean;
    onRemove?: (e: React.MouseEvent) => void;
    draggable?: boolean;
    onDragStart?: (e: React.MouseEvent) => void;
    fieldClassName?: string;
    formula?: FormulaPickerProps;
    popOverContainer?: any;
    renderEtrValue?: any;
    selectMode?: 'list' | 'tree' | 'chained';
    isCollapsed?: boolean;
    depth: number;
    isAddBtnVisibleOn?: (param: {
        depth: number;
        breadth: number;
    }) => boolean | undefined;
    isAddGroupBtnVisibleOn?: (param: {
        depth: number;
        breadth: number;
    }) => boolean | undefined;
    testIdBuilder?: TestIdBuilder;
}
export declare class ConditionGroup extends React.Component<ConditionGroupProps, ConditionGroupState> {
    constructor(props: ConditionGroupProps);
    componentDidUpdate(prevProps: Readonly<ConditionGroupProps>): void;
    getValue(): AMISConditionGroupValue;
    handleNotClick(): void;
    handleConjunctionChange(val: {
        value: 'or' | 'and';
    }): void;
    handleAdd(): void;
    handleAddGroup(): void;
    handleItemChange(item: any, index: number): void;
    handleItemRemove(index: number): void;
    toggleCollapse(): void;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ConditionGroup>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ConditionGroup, {}> & {
        ComposedComponent: typeof ConditionGroup;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Omit<ConditionGroupProps, keyof LocaleProps> & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ConditionGroup>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ConditionGroup, {}> & {
    ComposedComponent: typeof ConditionGroup;
}, {}> & {
    ComposedComponent: {
        new (props: Omit<ConditionGroupProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ConditionGroupProps, keyof LocaleProps> & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ConditionGroup>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ConditionGroup, {}> & {
        ComposedComponent: typeof ConditionGroup;
    };
};
export default _default;
