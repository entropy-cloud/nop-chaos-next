import React from 'react';
import { EditorBaseProps } from './Editor';
export interface DiffEditorProps extends EditorBaseProps {
    originValue?: string;
}
export default class DiffEditor extends React.Component<DiffEditorProps> {
    editor: any;
    monaco: any;
    originalEditor: any;
    modifiedEditor: any;
    toDispose: Array<Function>;
    domRef: React.RefObject<any>;
    componentDidUpdate(prevProps: any): void;
    componentWillUnmount(): void;
    prevHeight: number;
    updateContainerSize(editor: any, monaco: any): void;
    editorFactory(containerElement: any, monaco: any, options: any): any;
    handleModifiedEditorChange(e: any): void;
    editorDidMount(editor: any, monaco: any): void;
    render(): import("react/jsx-runtime").JSX.Element;
}
