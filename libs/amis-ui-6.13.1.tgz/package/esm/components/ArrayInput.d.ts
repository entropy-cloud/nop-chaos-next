import React from 'react';
import { ThemeProps } from 'amis-core';
import { LocaleProps } from 'amis-core';
import Sortable from 'sortablejs';
export interface ArrayInputProps extends ThemeProps, LocaleProps {
    value?: Array<any>;
    onChange?: (value: Array<any>) => void;
    placeholder: string;
    itemRender: (props: {
        value: any;
        onChange: (value: any) => void;
        index: number;
        disabled?: boolean;
    }) => JSX.Element;
    itemInitalValue?: any;
    maxLength?: number;
    minLength?: number;
    disabled?: boolean;
    sortable?: boolean;
    removable?: boolean;
    addable?: boolean;
    editable?: boolean;
    sortTip?: string;
}
export declare class ArrayInput extends React.Component<ArrayInputProps> {
    static defaultProps: {
        placeholder: string;
        itemRender: ({ value, onChange }: {
            value: any;
            onChange: (value: any) => void;
            index: number;
            disabled?: boolean;
        }) => React.JSX.Element;
    };
    id: string;
    dragTip?: HTMLElement;
    sortable?: Sortable;
    handleItemOnChange(index: number, itemValue: any): void;
    dragTipRef(ref: any): void;
    handleAdd(): void;
    handleRemove(e: React.MouseEvent<HTMLElement>): void;
    initDragging(): void;
    destroyDragging(): void;
    renderItem(value: any, index: number, collection: Array<any>): React.JSX.Element;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
        placeholder?: string | undefined;
        itemRender?: ((props: {
            value: any;
            onChange: (value: any) => void;
            index: number;
            disabled?: boolean;
        }) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ArrayInput>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ArrayInput, {}> & {
        ComposedComponent: typeof ArrayInput;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
        placeholder?: string | undefined;
        itemRender?: ((props: {
            value: any;
            onChange: (value: any) => void;
            index: number;
            disabled?: boolean;
        }) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ArrayInput>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ArrayInput, {}> & {
    ComposedComponent: typeof ArrayInput;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
            placeholder?: string | undefined;
            itemRender?: ((props: {
                value: any;
                onChange: (value: any) => void;
                index: number;
                disabled?: boolean;
            }) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ArrayInputProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "disabled" | "editable" | "removable" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "maxLength" | "minLength" | "addable" | "sortable" | "itemInitalValue" | "sortTip"> & {
                placeholder?: string | undefined;
                itemRender?: ((props: {
                    value: any;
                    onChange: (value: any) => void;
                    index: number;
                    disabled?: boolean;
                }) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ArrayInput>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ArrayInput, {}> & {
        ComposedComponent: typeof ArrayInput;
    };
};
export default _default;
