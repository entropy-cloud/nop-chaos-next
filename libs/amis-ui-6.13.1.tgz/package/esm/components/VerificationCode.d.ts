/**
 * @file VerificationCode
 */
import React, { ComponentState, PropsWithoutRef } from 'react';
import { ThemeProps } from 'amis-core';
/**
 * VerificationCodeOptions
 *
 */
export interface VerificationCodeOptions {
    /**
     * 长度
     */
    length?: number;
    /**
     * value
     */
    value?: string;
    /**
     * onChange
     */
    onChange?: (value: string) => void;
    /**
     * onFinish
     */
    onFinish?: (value: string) => void;
    /**
     * input list
     */
    getInputRefList?: () => HTMLInputElement[];
}
/**
 *  VerificationCodeReturnType
 */
export type VerificationCodeReturnType = {
    filledValue: VerificationCodeOptions['value'][];
    value: VerificationCodeOptions['value'];
    setValue: (v: VerificationCodeOptions['value']) => void;
    getInputProps: (index: number) => {
        key: string | number;
        value: string;
        onClick: (e: React.MouseEvent<HTMLInputElement>) => void;
        onKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => void;
        onChange: (v: string | React.ChangeEvent<HTMLInputElement>) => void;
        onPaste: (e: React.ClipboardEvent<HTMLInputElement>) => void;
    };
};
export interface VerificationCodeProps extends ThemeProps {
    value?: string;
    length?: number;
    /**
     * 是否是密码模式
     */
    masked?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    /**
     * 分隔符
     */
    separator?: (data: {
        index: number;
        character: string;
    }) => React.ReactNode;
    onChange?: (value: string) => void;
    /**
     * 输入框都被填充后触发的回调
     */
    onFinish?: (value: string) => void;
}
export declare function isExist(obj: any): boolean;
export declare const Backspace: {
    key: string;
    code: number;
};
export declare function isUndefined(obj: any): obj is undefined;
export declare function usePrevious<T>(value: PropsWithoutRef<T> | ComponentState): any;
export declare function useMergeValue<T>(defaultStateValue: T, props?: {
    value?: T;
}): [T, React.Dispatch<React.SetStateAction<T>>, T];
export declare function useVerificationCode(props: VerificationCodeOptions): VerificationCodeReturnType;
export declare function VerificationCodeComponent(baseProps: VerificationCodeProps): React.JSX.Element;
declare const _default: {
    new (props: Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<VerificationCodeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof VerificationCodeComponent>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof VerificationCodeComponent, {}> & {
    ComposedComponent: typeof VerificationCodeComponent;
};
export default _default;
