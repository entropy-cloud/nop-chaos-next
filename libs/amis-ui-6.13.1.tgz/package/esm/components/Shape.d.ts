/**
 * @file Shape.tsx 图形组件
 *
 * @author allenve(yupeng12@baidu.com)
 * @created: 2024/12/12
 */
import React from 'react';
import { ThemeProps } from 'amis-core';
export type IShapeType = 'square' | 'triangle' | 'right-triangle' | 'rectangle' | 'convex-arc-rectangle' | 'concave-arc-rectangle' | 'double-convex-arc-rectangle' | 'double-concave-arc-rectangle' | 'barrel-rectangle' | 'rhombus' | 'parallelogram' | 'rectangle-1' | 'rectangle-2' | 'rectangle-3' | 'pentagon' | 'hexagon' | 'octagon' | 'hexagon-star' | 'star' | 'heart' | 'circle' | 'arrow' | 'leaf';
export type IShapeCustomType = 'custom';
export type ISHapeStrokeType = 'line' | 'dash' | 'dot';
export interface IShapeProps extends ThemeProps {
    shapeType: IShapeType | IShapeCustomType;
    radius: number;
    width?: number;
    height?: number;
    color?: string;
    stroke?: string;
    strokeWidth?: number;
    strokeType?: 'line' | 'dash' | 'dot';
    paths?: string[];
    onClick?: (event: React.MouseEvent) => void;
}
declare const _default: {
    new (props: Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<IShapeProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<React.FC<IShapeProps>>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<React.FC<IShapeProps>, {}> & {
    ComposedComponent: React.FC<IShapeProps>;
};
export default _default;
