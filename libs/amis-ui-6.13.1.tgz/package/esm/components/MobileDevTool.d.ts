export declare const dimensions: {
    name: string;
    width: number;
    height: number;
}[];
export default function MobileDevTool(props: {
    container: HTMLElement | null;
    previewBody: HTMLElement | null;
    border?: number;
    onChangeScale?: (scale: number) => void;
}): import("react/jsx-runtime").JSX.Element;
