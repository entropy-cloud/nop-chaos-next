import React from 'react';
import { ClassNamesFn } from 'amis-core';
interface AlphabetIndexerProps {
    items: Array<any>;
    getItemLetter: (item: any) => string;
    onLetterClick: (letter: string) => void;
    classnames: ClassNamesFn;
    currentLetter?: string;
}
declare const AlphabetIndexer: React.FC<AlphabetIndexerProps>;
export default AlphabetIndexer;
