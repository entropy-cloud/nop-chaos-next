import React from 'react';
import { ThemeProps } from 'amis-core';
import { Options, Option } from './Select';
import { TransferProps } from './Transfer';
import { ItemRenderStates } from './Selection';
import { SpinnerExtraProps } from './Spinner';
export interface TabsTransferProps extends Omit<TransferProps, 'selectMode' | 'columns' | 'selectRender' | 'statistics' | 'onSearch' | 'optionItemRender'>, SpinnerExtraProps, ThemeProps {
    onSearch: (term: string, option: Option, setCancel: (cancel: () => void) => void) => Promise<Options | void>;
    optionItemRender?: (option: Option, states: ItemRenderStates, tab: Option) => JSX.Element;
    cellRender?: (column: {
        name: string;
        label: string;
        [propName: string]: any;
    }, option: Option, colIndex: number, rowIndex: number) => JSX.Element;
    onTabChange: (key: number) => void;
    activeKey: number;
    onlyChildren?: boolean;
    ctx?: Record<string, any>;
    selectMode?: 'table' | 'list' | 'tree' | 'chained' | 'associated';
    searchable?: boolean;
    /**
     * 是否默认都展开
     */
    initiallyOpen?: boolean;
}
export interface TabsTransferState {
    inputValue: string;
    searchResult: Options | null;
}
export declare class TabsTransfer extends React.Component<TabsTransferProps, TabsTransferState> {
    static defaultProps: {
        multiple: boolean;
        onlyChildren: boolean;
    };
    state: {
        inputValue: string;
        searchResult: null;
    };
    unmounted: boolean;
    cancelSearch?: () => void;
    componentWillUnmount(): void;
    handleSearch(text: string, option: Option): void;
    handleSeachCancel(): void;
    lazySearch: import("lodash").DebouncedFunc<(text: string, option: Option) => void>;
    handleSearchKeyDown(e: React.KeyboardEvent<any>): void;
    handleTabChange(key: number): void;
    renderSearchResult(searchResult: Options | null): import("react/jsx-runtime").JSX.Element;
    renderSelect(): import("react/jsx-runtime").JSX.Element;
    renderOptions(option: Option): import("react/jsx-runtime").JSX.Element;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
        multiple?: boolean | undefined;
        onlyChildren?: boolean | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof TabsTransfer>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof TabsTransfer, {}> & {
        ComposedComponent: typeof TabsTransfer;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
        multiple?: boolean | undefined;
        onlyChildren?: boolean | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof TabsTransfer>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof TabsTransfer, {}> & {
    ComposedComponent: typeof TabsTransfer;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
            multiple?: boolean | undefined;
            onlyChildren?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<TabsTransferProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "showInvalidMatch" | "valueField" | "labelField" | "searchable" | "options" | "value" | "noResultsText" | "clearable" | "placeholder" | "inline" | "disabled" | "checkAll" | "checkAllLabel" | "maxTagCount" | "overflowTagPopover" | "itemHeight" | "virtualThreshold" | "testIdBuilder" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "loadingConfig" | "onClick" | "showArrow" | "itemClassName" | "labelClassName" | "onRef" | "activeKey" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "initiallyOpen" | "autoCheckChildren" | "onSearch" | "searchPlaceholder" | "sortable" | "cellRender" | "leftOptions" | "leftDefaultValue" | "leftMode" | "rightMode" | "onPageChange" | "selectTitle" | "selectMode" | "searchResultMode" | "searchResultColumns" | "resultTitle" | "resultListModeFollowSelect" | "resultSearchPlaceholder" | "optionItemRender" | "resultItemRender" | "resultSearchable" | "onResultSearch" | "onSelectAll" | "accumulatedOptions" | "pagination" | "onTabChange" | "ctx"> & {
                multiple?: boolean | undefined;
                onlyChildren?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof TabsTransfer>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof TabsTransfer, {}> & {
        ComposedComponent: typeof TabsTransfer;
    };
};
export default _default;
