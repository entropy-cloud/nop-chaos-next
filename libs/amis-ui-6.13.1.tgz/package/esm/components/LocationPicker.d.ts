import React from 'react';
import { ThemeProps } from 'amis-core';
import { LocaleProps } from 'amis-core';
export interface LocationProps extends ThemeProps, LocaleProps {
    vendor: 'baidu' | 'gaode' | 'tenxun';
    coordinatesType: 'bd09' | 'gcj02';
    placeholder: string;
    getLocationPlaceholder: string;
    clearable: boolean;
    ak: string;
    value?: {
        address: string;
        lat: number;
        lng: number;
        city?: string;
    };
    disabled?: boolean;
    className?: string;
    popoverClassName?: string;
    onChange: (value: any) => void;
    popOverContainer?: any;
    autoSelectCurrentLoc?: boolean;
    onlySelectCurrentLoc?: boolean;
    hideViewControl?: boolean;
}
export interface LocationState {
    isFocused: boolean;
    isOpened: boolean;
}
export declare class LocationPicker extends React.Component<LocationProps, LocationState> {
    static defaultProps: {
        placeholder: string;
        getLocationPlaceholder: string;
        clearable: boolean;
    };
    domRef: React.RefObject<HTMLDivElement | null>;
    tempValue: any;
    state: {
        isFocused: boolean;
        isOpened: boolean;
    };
    handleKeyPress(e: React.KeyboardEvent): void;
    handleFocus(): void;
    handleBlur(): void;
    handleClick(): void;
    getTarget(): HTMLDivElement | null;
    getParent(): HTMLElement | null | undefined;
    open(fn?: () => void): void;
    close(): void;
    clearValue(e: React.MouseEvent<any>): void;
    handlePopOverClick(e: React.MouseEvent<any>): void;
    handleChange(value: any): void;
    handleTempChange(value: any): void;
    handleConfirm(): void;
    render(): React.JSX.Element;
}
declare const ThemedCity: {
    new (props: Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        getLocationPlaceholder?: string | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof LocationPicker>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof LocationPicker, {}> & {
        ComposedComponent: typeof LocationPicker;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        getLocationPlaceholder?: string | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof LocationPicker>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof LocationPicker, {}> & {
    ComposedComponent: typeof LocationPicker;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            getLocationPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<LocationProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "vendor" | "ak" | "coordinatesType" | "autoSelectCurrentLoc" | "onlySelectCurrentLoc" | "hideViewControl"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                getLocationPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof LocationPicker>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof LocationPicker, {}> & {
        ComposedComponent: typeof LocationPicker;
    };
};
export default ThemedCity;
