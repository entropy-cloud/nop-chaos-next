import type { InputJSONSchemaItemProps } from './index';
export declare function InputJSONSchemaArray(props: InputJSONSchemaItemProps): import("react/jsx-runtime").JSX.Element;
