/**
 * @file PopUp
 * @description
 * @author fex
 */
import React from 'react';
import { ThemeProps } from 'amis-core';
import { LocaleProps } from 'amis-core';
export interface PopUpPorps extends ThemeProps, LocaleProps {
    title?: string;
    className?: string;
    style?: {
        [styleName: string]: string;
    };
    overlay?: boolean;
    onHide?: () => void;
    isShow?: boolean;
    container?: any;
    showConfirm?: boolean;
    onConfirm?: (value: any) => void;
    showClose?: boolean;
    placement?: 'left' | 'center' | 'right';
    header?: JSX.Element;
    children?: React.ReactNode | Array<React.ReactNode>;
    onExited?: () => void;
    onEntered?: () => void;
}
export declare class PopUp extends React.PureComponent<PopUpPorps> {
    scrollTop: number;
    transitionNodeRef: {
        current: HTMLDivElement | null;
    };
    static defaultProps: {
        className: string;
        overlay: boolean;
        isShow: boolean;
        container: HTMLElement;
        showClose: boolean;
        onConfirm: () => void;
    };
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    handleClick(e: React.MouseEvent): void;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
        container?: any;
        className?: string | undefined;
        overlay?: boolean | undefined;
        isShow?: boolean | undefined;
        onConfirm?: ((value: any) => void) | undefined;
        showClose?: boolean | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof PopUp>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof PopUp, {}> & {
        ComposedComponent: typeof PopUp;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
        container?: any;
        className?: string | undefined;
        overlay?: boolean | undefined;
        isShow?: boolean | undefined;
        onConfirm?: ((value: any) => void) | undefined;
        showClose?: boolean | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof PopUp>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof PopUp, {}> & {
    ComposedComponent: typeof PopUp;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
            container?: any;
            className?: string | undefined;
            overlay?: boolean | undefined;
            isShow?: boolean | undefined;
            onConfirm?: ((value: any) => void) | undefined;
            showClose?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<PopUpPorps, keyof LocaleProps>, "children" | "style" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "header" | "title" | "onHide" | "onExited" | "onEntered" | "placement" | "showConfirm"> & {
                container?: any;
                className?: string | undefined;
                overlay?: boolean | undefined;
                isShow?: boolean | undefined;
                onConfirm?: ((value: any) => void) | undefined;
                showClose?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof PopUp>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof PopUp, {}> & {
        ComposedComponent: typeof PopUp;
    };
};
export default _default;
