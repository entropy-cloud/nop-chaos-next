/**
 * @file DndContainer
 * @desc 可拖拽容器
 */
import React from 'react';
import { LocaleProps, ThemeProps } from 'amis-core';
import type { DraggableEvent, DraggableData, DraggableBounds } from 'react-draggable';
export interface DndContainerProps extends LocaleProps, ThemeProps {
    /**
     * 可拖拽的方向, 默认为所有方向, 支持设置为X或Y轴
     */
    axis?: 'both' | 'x' | 'y' | 'none';
    /** 元素的位置 */
    position?: {
        x: number;
        y: number;
    };
    /** 元素的起始位置 */
    defaultPosition?: {
        x: number;
        y: number;
    };
    /**
     * 拖拽的边界, 可以设置坐标, 也可以设置父级元素的选择器
     */
    bounds?: DraggableBounds | string;
    /** 以网格范围拖拽的步长 */
    grid?: [number, number];
    /** 初始化拖拽的选择器 */
    handle?: string;
    /** 禁止拖拽的选择器 */
    cancel?: string;
    /** 拖拽距离的缩放比, 默认为1 */
    scale?: number;
    /** 是否禁止拖拽 */
    draggable?: boolean;
    /** 默认设置容器内部为'user-select:none', 可以设置true关闭 */
    enableUserSelect?: boolean;
    nodeRef?: React.RefObject<HTMLElement>;
    children?: React.ReactElement<any>;
    onStart?: (event: DraggableEvent, data: DraggableData) => void | false;
    onDrag?: (event: DraggableEvent, data: DraggableData) => void | false;
    onStop?: (event: DraggableEvent, data: DraggableData) => void | false;
}
declare const _default: {
    new (props: Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps, keyof LocaleProps> & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
            ref: any;
            childRef: (ref: any) => void;
            getWrappedInstance: () => any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<React.FC<DndContainerProps>>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<React.FC<DndContainerProps>, {}> & {
        ComposedComponent: React.FC<DndContainerProps>;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<React.FC<DndContainerProps>>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<React.FC<DndContainerProps>, {}> & {
    ComposedComponent: React.FC<DndContainerProps>;
}, {}> & {
    ComposedComponent: {
        new (props: Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
            ref: any;
            childRef: (ref: any) => void;
            getWrappedInstance: () => any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<DndContainerProps, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<React.FC<DndContainerProps>>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<React.FC<DndContainerProps>, {}> & {
        ComposedComponent: React.FC<DndContainerProps>;
    };
};
export default _default;
