/**
 * @file ColorPicker
 * @description 颜色选择器组件
 * @author fex
 */
import React from 'react';
import { ColorResult } from 'react-color';
import { ThemeProps } from 'amis-core';
import { LocaleProps } from 'amis-core';
export type PresetColor = {
    color: string;
    title: string;
} | string;
export interface ColorProps extends LocaleProps, ThemeProps {
    placeholder?: string;
    format: string;
    clearable: boolean;
    className?: string;
    popoverClassName?: string;
    disabled?: boolean;
    popOverContainer?: any;
    popOverContainerSelector?: string;
    placement?: string;
    value?: any;
    onChange: (value: any) => void;
    presetColors?: PresetColor[];
    resetValue?: string;
    allowCustomColor?: boolean;
}
export interface ColorControlState {
    isOpened: boolean;
    isFocused: boolean;
    inputValue: string;
    tempValue: string;
}
export declare class ColorControl extends React.PureComponent<ColorProps, ColorControlState> {
    static defaultProps: {
        format: string;
        clearable: boolean;
        placeholder: string;
        allowCustomColor: boolean;
    };
    state: {
        isOpened: boolean;
        isFocused: boolean;
        inputValue: any;
        tempValue: any;
    };
    popover: any;
    closeTimer: number;
    preview: React.RefObject<HTMLElement | null>;
    input: React.RefObject<HTMLInputElement | null>;
    constructor(props: ColorProps);
    componentDidUpdate(prevProps: ColorProps): void;
    handleFocus(): void;
    handleBlur(): void;
    focus(): void;
    blur(): void;
    open(fn?: () => void): void;
    close(): void;
    clearValue(): void;
    handleClick(): void;
    handleInputChange(e: React.ChangeEvent<HTMLInputElement>): void;
    validateColor(value: string): boolean;
    handleChange(color: ColorResult): void;
    handleTempChange(color: ColorResult): void;
    handleConfirm(): void;
    /**
     * Converts an RGBA color to an 8-digit hex color.
     *
     * @param r - Red component (0-255)
     * @param g - Green component (0-255)
     * @param b - Blue component (0-255)
     * @param a - Alpha component (1-100)
     * @returns The hex color string in the format #RRGGBBAA
     */
    rgbaToHex(r: number, g: number, b: number, a: number | undefined): string;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        format?: string | undefined;
        allowCustomColor?: boolean | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ColorControl>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ColorControl, {}> & {
        ComposedComponent: typeof ColorControl;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
        clearable?: boolean | undefined;
        placeholder?: string | undefined;
        format?: string | undefined;
        allowCustomColor?: boolean | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ColorControl>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ColorControl, {}> & {
    ComposedComponent: typeof ColorControl;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
            clearable?: boolean | undefined;
            placeholder?: string | undefined;
            format?: string | undefined;
            allowCustomColor?: boolean | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ColorProps, keyof LocaleProps>, "onChange" | "className" | "style" | "popoverClassName" | "value" | "disabled" | "popOverContainer" | "popOverContainerSelector" | "resetValue" | "classnames" | "classPrefix" | "theme" | "mobileUI" | "placement" | "presetColors"> & {
                clearable?: boolean | undefined;
                placeholder?: string | undefined;
                format?: string | undefined;
                allowCustomColor?: boolean | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ColorControl>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ColorControl, {}> & {
        ComposedComponent: typeof ColorControl;
    };
};
export default _default;
