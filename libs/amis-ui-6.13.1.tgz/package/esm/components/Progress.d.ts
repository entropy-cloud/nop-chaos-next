import React from 'react';
import { ClassNamesFn, ClassName, ThemeProps } from 'amis-core';
interface ColorProps {
    value: number;
    color: string;
}
export interface ThresholdProps {
    value: string;
    color?: string;
}
export type ColorMapType = Array<string> | Array<ColorProps> | string;
interface ProgressProps extends ThemeProps {
    type: 'line' | 'circle' | 'dashboard';
    showLabel: boolean;
    value: number;
    stripe?: boolean;
    animate?: boolean;
    map?: ColorMapType;
    placeholder?: string;
    format?: (value?: number) => JSX.Element;
    gapDegree?: number;
    gapPosition?: 'top' | 'bottom' | 'left' | 'right';
    strokeWidth?: number;
    progressClassName?: ClassName;
    classnames: ClassNamesFn;
    threshold: ThresholdProps | ThresholdProps[];
    showThresholdText: boolean;
}
export declare class Progress extends React.Component<ProgressProps, Object> {
    static defaultProps: Partial<ProgressProps>;
    getCurrentColor(): string;
    getLevelColor(color: Array<string> | Array<ColorProps>): string;
    getColorArray(color: Array<string> | Array<ColorProps>): ColorProps[];
    getLabel(prefixCls: string): import("react/jsx-runtime").JSX.Element | null;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
        map?: ColorMapType | undefined;
        type?: "circle" | "line" | "dashboard" | undefined;
        value?: number | undefined;
        placeholder?: string | undefined;
        animate?: boolean | undefined;
        format?: ((value?: number) => JSX.Element) | undefined;
        threshold?: ThresholdProps | ThresholdProps[] | undefined;
        showLabel?: boolean | undefined;
        stripe?: boolean | undefined;
        gapDegree?: number | undefined;
        gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
        strokeWidth?: number | undefined;
        progressClassName?: ClassName | undefined;
        showThresholdText?: boolean | undefined;
    } & {
        className?: string | undefined;
        style?: {
            [propName: string]: any;
        } | undefined;
        classnames?: ClassNamesFn | undefined;
        classPrefix?: string | undefined;
        theme?: string | undefined;
        mobileUI?: boolean | undefined;
    } & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ProgressProps, keyof ThemeProps>, never> & {
            map?: ColorMapType | undefined;
            type?: "circle" | "line" | "dashboard" | undefined;
            value?: number | undefined;
            placeholder?: string | undefined;
            animate?: boolean | undefined;
            format?: ((value?: number) => JSX.Element) | undefined;
            threshold?: ThresholdProps | ThresholdProps[] | undefined;
            showLabel?: boolean | undefined;
            stripe?: boolean | undefined;
            gapDegree?: number | undefined;
            gapPosition?: "top" | "bottom" | "left" | "right" | undefined;
            strokeWidth?: number | undefined;
            progressClassName?: ClassName | undefined;
            showThresholdText?: boolean | undefined;
        } & {
            className?: string | undefined;
            style?: {
                [propName: string]: any;
            } | undefined;
            classnames?: ClassNamesFn | undefined;
            classPrefix?: string | undefined;
            theme?: string | undefined;
            mobileUI?: boolean | undefined;
        } & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof Progress>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof Progress, {}> & {
    ComposedComponent: typeof Progress;
};
export default _default;
