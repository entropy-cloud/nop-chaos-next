/**
 * @file AsideNav
 * @description 左侧导航。
 * @author fex
 */
import React from 'react';
import { TestIdBuilder } from 'amis-core';
import { ClassNamesFn } from 'amis-core';
export type LinkItem = LinkItemProps;
interface LinkItemProps {
    id?: number;
    label: string;
    hidden?: boolean;
    open?: boolean;
    active?: boolean;
    className?: string;
    children?: Array<LinkItem>;
    path?: string;
    icon?: string;
    component?: React.ElementType;
    testIdBuilder?: TestIdBuilder;
}
export interface Navigation {
    label: string;
    children?: Array<LinkItem>;
    prefix?: JSX.Element;
    affix?: JSX.Element;
    className?: string;
    [propName: string]: any;
}
export interface AsideNavProps {
    id?: string;
    className?: string;
    classPrefix: string;
    classnames: ClassNamesFn;
    renderLink: Function;
    isActive: Function;
    isOpen: (link: LinkItemProps) => boolean;
    navigations: Array<Navigation>;
    renderSubLinks: (link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode;
}
interface AsideNavState {
    navigations: Array<Navigation>;
}
export declare class AsideNav extends React.Component<AsideNavProps, AsideNavState> {
    static defaultProps: {
        renderLink: (item: LinkItemProps) => import("react/jsx-runtime").JSX.Element;
        renderSubLinks: (link: LinkItemProps, renderLink: Function, depth: number, { classnames: cx }: AsideNavProps) => import("react/jsx-runtime").JSX.Element | null;
        isActive: (link: LinkItem) => boolean | undefined;
        isOpen: (item: LinkItemProps) => boolean;
    };
    constructor(props: AsideNavProps);
    componentDidUpdate(prevProps: AsideNavProps): void;
    toggleExpand(link: LinkItemProps, e?: React.MouseEvent<HTMLElement>): void;
    renderLink(link: LinkItemProps, key: any, props?: Partial<AsideNavProps>, depth?: number): React.ReactNode;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
        renderLink?: Function | undefined;
        isActive?: Function | undefined;
        isOpen?: ((link: LinkItemProps) => boolean) | undefined;
        renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
    } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<AsideNavProps, keyof import("amis-core").ThemeProps>, "id" | "navigations"> & {
            renderLink?: Function | undefined;
            isActive?: Function | undefined;
            isOpen?: ((link: LinkItemProps) => boolean) | undefined;
            renderSubLinks?: ((link: LinkItemProps, renderLink: Function, depth: number, props: AsideNavProps) => React.ReactNode) | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof AsideNav>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof AsideNav, {}> & {
    ComposedComponent: typeof AsideNav;
};
export default _default;
