import { ClassNamesFn } from 'amis-core';
import React from 'react';
import type { DebouncedFunc } from 'lodash';
interface ContextMenuProps {
    className?: string;
    classPrefix: string;
    classnames: ClassNamesFn;
    container?: HTMLElement | null | (() => HTMLElement);
}
export type MenuItem = {
    id?: string;
    label: string | React.ReactNode;
    icon?: string;
    disabled?: boolean;
    children?: Array<MenuItem | MenuDivider>;
    data?: any;
    className?: string;
    selected?: boolean;
    onSelect?: (data: any) => void;
    onHighlight?: (isHiglight: boolean, data: any) => void;
};
export type MenuDivider = '|';
interface ContextMenuState {
    isOpened: boolean;
    menus: Array<MenuItem | MenuDivider> | (() => JSX.Element);
    x: number;
    y: number;
    cursorX: number;
    cursorY: number;
    align?: 'left' | 'right';
    onClose?: (ctx: ContextMenu) => void;
    contentClassName?: string;
    preventClose?: (e?: Event) => boolean;
}
export declare class ContextMenu extends React.Component<ContextMenuProps, ContextMenuState> {
    static instance: any;
    debounceCalculatePosition: DebouncedFunc<(menu: HTMLElement) => void>;
    static getInstance(): Promise<any>;
    state: ContextMenuState;
    menuRef: React.RefObject<HTMLDivElement | null>;
    contentRef: React.RefObject<HTMLDivElement | null>;
    originInstance: this | null;
    prevInfo: {
        x: number;
        y: number;
    } | null;
    unmount: boolean;
    menuEntered: boolean;
    constructor(props: ContextMenuProps);
    componentDidMount(): void;
    componentWillUnmount(): void;
    openContextMenus(info: {
        x: number;
        y: number;
    }, menus: Array<MenuItem>, onClose?: (ctx: ContextMenu) => void, options?: {
        contentClassName?: string;
        preventClose?: (e?: Event) => boolean;
    }): void;
    close(e?: Event): void;
    handleOutClick(e: Event): void;
    handleClick(item: MenuItem): void;
    handleKeyDown(e: KeyboardEvent): void;
    handleMouseEnter(item: MenuItem): void;
    handleMouseLeave(item: MenuItem): void;
    resizeObserver: null | ResizeObserver;
    handleEnter(): void;
    handleEntered(): void;
    autoCalculatePosition(menu: HTMLElement): void;
    handleSelfContextMenu(e: React.MouseEvent): void;
    renderMenus(menus: Array<MenuItem | MenuDivider>): React.JSX.Element[];
    render(): React.JSX.Element;
}
export declare const ThemedContextMenu: {
    new (props: Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<ContextMenuProps, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ContextMenu>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ContextMenu, {}> & {
    ComposedComponent: typeof ContextMenu;
};
export default ThemedContextMenu;
export declare function openContextMenus(info: Event | {
    x: number;
    y: number;
}, menus: Array<MenuItem | MenuDivider> | (() => React.ReactNode), onClose?: (ctx: ContextMenu) => void, options?: {
    contentClassName?: string;
    preventClose?: (e?: Event) => boolean;
}): Promise<any>;
export declare function closeContextMenus(): Promise<any>;
