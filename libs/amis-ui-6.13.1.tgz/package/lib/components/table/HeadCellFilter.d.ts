/**
 * @file table/HeadCellFilter
 * @author fex
 */
import React from 'react';
import { ThemeProps, ClassNamesFn, LocaleProps } from 'amis-core';
import { FilterPayload } from './HeadCellDropDown';
import type { TestIdBuilder } from 'amis-core';
export interface Props extends ThemeProps, LocaleProps {
    column: any;
    onFilter?: Function;
    filteredValue?: Array<string>;
    filterMultiple?: boolean;
    popOverContainer?: () => HTMLElement;
    classnames: ClassNamesFn;
    classPrefix: string;
    testIdBuilder?: TestIdBuilder;
}
export interface OptionProps {
    text: string;
    value: string;
    selected?: boolean;
    children?: Array<OptionProps>;
}
export interface State {
    options: Array<OptionProps>;
    filteredValue: Array<string>;
}
export declare class HeadCellFilter extends React.PureComponent<Props, State> {
    static defaultProps: {
        filteredValue: never[];
        filterMultiple: boolean;
    };
    constructor(props: Props);
    alterOptions(options: Array<any>): any[];
    componentDidMount(): void;
    componentDidUpdate(prevProps: Props, prevState: State): void;
    render(): React.JSX.Element;
    handleClick(confirm: (payload?: FilterPayload) => void, setSelectedKeys?: (keys?: string | Array<string | number>) => void, selectedKeys?: Array<string>): Promise<void>;
    handleCheck(confirm: (payload?: FilterPayload) => void, setSelectedKeys?: (keys: string | Array<string | number>) => void | undefined, selectedKeys?: Array<string>): void;
    handleConfirmClick(confirm: (payload?: FilterPayload) => void): void;
    handleCancelClick(confirm: (payload?: FilterPayload) => void, setSelectedKeys?: (keys: string | Array<string | number>) => void | undefined): void;
}
declare const _default: {
    new (props: Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
        filterMultiple?: boolean | undefined;
        filteredValue?: Array<string> | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof HeadCellFilter>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof HeadCellFilter, {}> & {
        ComposedComponent: typeof HeadCellFilter;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
        filterMultiple?: boolean | undefined;
        filteredValue?: Array<string> | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof HeadCellFilter>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof HeadCellFilter, {}> & {
    ComposedComponent: typeof HeadCellFilter;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
            filterMultiple?: boolean | undefined;
            filteredValue?: Array<string> | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<Props, keyof LocaleProps>, "className" | "style" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "testIdBuilder" | "column" | "popOverContainer" | "onFilter"> & {
                filterMultiple?: boolean | undefined;
                filteredValue?: Array<string> | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof HeadCellFilter>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof HeadCellFilter, {}> & {
        ComposedComponent: typeof HeadCellFilter;
    };
};
export default _default;
