import React from 'react';
import { LocaleProps } from 'amis-core';
import { ThemeProps } from 'amis-core';
export interface MultilineTextProps extends ThemeProps, LocaleProps {
    /**
     * 最大行数
     */
    maxRows?: number;
    /**
     * 展示文本
     */
    text: string;
    /**
     * 展开按钮文本
     */
    expendButtonText?: string;
    /**
     * 收起按钮文本
     */
    collapseButtonText?: string;
}
export interface MultilineTextState {
    isExpend: boolean;
    showBtn: boolean;
}
export declare class MultilineText extends React.Component<MultilineTextProps, MultilineTextState> {
    static defaultProps: {
        maxRows: number;
        expendButtonText: string;
        collapseButtonText: string;
    };
    state: {
        isExpend: boolean;
        showBtn: boolean;
    };
    ref?: React.RefObject<HTMLDivElement | null>;
    constructor(props: MultilineTextProps);
    componentDidMount(): void;
    shouldComponentUpdate(nextProps: Readonly<MultilineTextProps>, nextState: Readonly<MultilineTextState>, nextContext: any): boolean;
    componentDidUpdate(oldProps: any, oldState: any): void;
    toggleExpend(): void;
    render(): React.JSX.Element | null;
}
declare const _default: {
    new (props: Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
        maxRows?: number | undefined;
        expendButtonText?: string | undefined;
        collapseButtonText?: string | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof MultilineText>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof MultilineText, {}> & {
        ComposedComponent: typeof MultilineText;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
        maxRows?: number | undefined;
        expendButtonText?: string | undefined;
        collapseButtonText?: string | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof MultilineText>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof MultilineText, {}> & {
    ComposedComponent: typeof MultilineText;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
            maxRows?: number | undefined;
            expendButtonText?: string | undefined;
            collapseButtonText?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<MultilineTextProps, keyof LocaleProps>, "className" | "style" | "text" | "classPrefix" | "classnames" | "theme" | "mobileUI"> & {
                maxRows?: number | undefined;
                expendButtonText?: string | undefined;
                collapseButtonText?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof MultilineText>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof MultilineText, {}> & {
        ComposedComponent: typeof MultilineText;
    };
};
export default _default;
