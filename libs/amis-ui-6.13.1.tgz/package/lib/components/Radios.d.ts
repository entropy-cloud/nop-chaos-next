/**
 * @file Radios
 * @description
 * @author fex
 *
 * @param 参数说明：
 * options: [
 *   {
 *      label: '显示的名字',
 *      value: '值',
 *      disabled: false
 *   }
 * ]
 *
 */
import React from 'react';
import { OptionProps, Option } from './Select';
import { ClassNamesFn } from 'amis-core';
import { TestIdBuilder } from 'amis-core';
interface RadioProps extends OptionProps {
    id?: string;
    type: string;
    optionType?: 'default' | 'button';
    value?: string;
    className?: string;
    style?: React.CSSProperties;
    inline?: boolean;
    level?: string;
    btnActiveLevel?: string;
    disabled?: boolean;
    onChange?: Function;
    columnsCount: number | number[];
    itemClassName?: string;
    labelField?: string;
    labelClassName?: string;
    classPrefix: string;
    classnames: ClassNamesFn;
    renderLabel?: (item: Option, props: RadioProps) => JSX.Element;
    testIdBuilder?: TestIdBuilder;
}
export declare class Radios extends React.Component<RadioProps, any> {
    static defaultProps: {
        type: string;
        btnActiveLevel: string;
        resetValue: string;
        inline: boolean;
        joinValues: boolean;
        clearable: boolean;
        columnsCount: number;
    };
    toggleOption(option: Option): void;
    renderGroup(option: Option, index: number, valueArray: Array<Option>): import("react/jsx-runtime").JSX.Element;
    renderItem(option: Option, index: number, valueArray: Array<Option>): import("react/jsx-runtime").JSX.Element;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
        type?: string | undefined;
        inline?: boolean | undefined;
        clearable?: boolean | undefined;
        joinValues?: boolean | undefined;
        resetValue?: any;
        btnActiveLevel?: string | undefined;
        columnsCount?: number | number[] | undefined;
    } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<RadioProps, keyof import("amis-core").ThemeProps>, "onChange" | "value" | "disabled" | "options" | "testIdBuilder" | "multiple" | "id" | "block" | "placeholder" | "level" | "loading" | "itemClassName" | "labelClassName" | "optionType" | "labelField" | "valueField" | "itemHeight" | "delimiter" | "onAdd" | "editable" | "onEdit" | "multi" | "pathSeparator" | "creatable" | "simpleValue" | "extractValue" | "virtualThreshold" | "hasError" | "controlStyle" | "removable" | "onDelete" | "renderLabel"> & {
            type?: string | undefined;
            inline?: boolean | undefined;
            clearable?: boolean | undefined;
            joinValues?: boolean | undefined;
            resetValue?: any;
            btnActiveLevel?: string | undefined;
            columnsCount?: number | number[] | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof Radios>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof Radios, {}> & {
    ComposedComponent: typeof Radios;
};
export default _default;
