/**
 * 用来显示选择结果，垂直显示。支持移出、排序等操作。
 */
import React from 'react';
import Sortable from 'sortablejs';
import { Option, Options } from './Select';
import { ThemeProps } from 'amis-core';
import { LocaleProps, ClassNamesFn } from 'amis-core';
import type { TestIdBuilder } from 'amis-core';
export interface ResultListProps extends ThemeProps, LocaleProps {
    className?: string;
    value?: Array<Option>;
    onChange?: (value: Array<Option>, optionModified?: boolean) => void;
    sortable?: boolean;
    disabled?: boolean;
    title?: string;
    searchPlaceholder?: string;
    placeholder: string;
    itemRender: (option: Option, states: ItemRenderStates) => JSX.Element;
    itemClassName?: string;
    searchable?: boolean;
    onSearch?: Function;
    valueField?: string;
    labelField?: string;
    itemHeight?: number;
    virtualThreshold?: number;
    showInvalidMatch?: boolean;
    testIdBuilder?: TestIdBuilder;
}
export interface ItemRenderStates {
    index: number;
    disabled?: boolean;
    labelField?: string;
    classnames: ClassNamesFn;
    onChange: (value: any, name: string) => void;
}
interface ResultListState {
    searchResult: Options | null;
}
export declare class ResultList extends React.Component<ResultListProps, ResultListState> {
    static itemRender(option: Option, states: ItemRenderStates): import("react/jsx-runtime").JSX.Element;
    static defaultProps: Pick<ResultListProps, 'placeholder' | 'itemRender' | 'searchPlaceholder' | 'virtualThreshold' | 'itemHeight'>;
    state: ResultListState;
    cancelSearch?: () => void;
    id: string;
    sortable?: Sortable;
    unmounted: boolean;
    searchRef?: any;
    componentDidMount(): void;
    componentDidUpdate(): void;
    componentWillUnmount(): void;
    domSearchRef(ref: any): void;
    initSortable(): void;
    desposeSortable(): void;
    handleValueChange(index: number, value: any, name: string): void;
    search(inputValue: string): void;
    clearSearch(): void;
    clearInput(): void;
    handleCloseItem(e: React.MouseEvent<HTMLElement>, option: Option): void;
    renderOption(option: any, index: number, value: Options, styles?: object): import("react/jsx-runtime").JSX.Element;
    renderNormalList(value?: Options): import("react/jsx-runtime").JSX.Element;
    render(): import("react/jsx-runtime").JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        searchPlaceholder?: string | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ResultList>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ResultList, {}> & {
        ComposedComponent: typeof ResultList;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
        searchPlaceholder?: string | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): import("react/jsx-runtime").JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof ResultList>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof ResultList, {}> & {
    ComposedComponent: typeof ResultList;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
            searchPlaceholder?: string | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): import("react/jsx-runtime").JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultListProps, keyof LocaleProps>, "onChange" | "className" | "style" | "value" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "testIdBuilder" | "itemClassName" | "labelField" | "valueField" | "showInvalidMatch" | "searchable" | "onSearch" | "sortable"> & {
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: ItemRenderStates) => JSX.Element) | undefined;
                searchPlaceholder?: string | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof ResultList>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof ResultList, {}> & {
        ComposedComponent: typeof ResultList;
    };
};
export default _default;
