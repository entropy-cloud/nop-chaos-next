import React from 'react';
import { LocaleProps, ThemeProps } from 'amis-core';
import type { PlainObject } from 'amis-core';
export interface SparkLineProps extends ThemeProps, LocaleProps {
    className?: string;
    width: number;
    height: number;
    value?: Array<number | {
        value: number;
        label?: string;
    }>;
    placeholder?: string;
    onClick?: (e: React.MouseEvent, value?: PlainObject) => void;
    id?: string;
    wrapperCustomStyle?: any;
    themeCss?: any;
}
export declare class SparkLine extends React.Component<SparkLineProps> {
    static defaultProps: {
        width: number;
        height: number;
    };
    normalizeValue(item: any): number;
    renderLines(): React.JSX.Element;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
        width?: number | undefined;
        height?: number | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof SparkLine>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof SparkLine, {}> & {
        ComposedComponent: typeof SparkLine;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
        width?: number | undefined;
        height?: number | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof SparkLine>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof SparkLine, {}> & {
    ComposedComponent: typeof SparkLine;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
            width?: number | undefined;
            height?: number | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<SparkLineProps, keyof LocaleProps>, "className" | "style" | "value" | "onClick" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "id" | "placeholder" | "wrapperCustomStyle" | "themeCss"> & {
                width?: number | undefined;
                height?: number | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof SparkLine>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof SparkLine, {}> & {
        ComposedComponent: typeof SparkLine;
    };
};
export default _default;
