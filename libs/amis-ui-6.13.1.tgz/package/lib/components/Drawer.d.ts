/**
 * @file Drawer
 * @description
 * @author fex
 */
import React from 'react';
import { ClassNamesFn } from 'amis-core';
type DrawerPosition = 'top' | 'right' | 'bottom' | 'left';
export interface DrawerProps {
    className?: string;
    bodyClassName?: string;
    size: any;
    overlay: boolean;
    onHide: (e: any) => void;
    closeOnEsc?: boolean;
    container: any;
    show?: boolean;
    showCloseButton?: boolean;
    width?: number | string;
    height?: number | string;
    position: DrawerPosition;
    disabled?: boolean;
    closeOnOutside?: boolean;
    classPrefix: string;
    resizable?: boolean;
    classnames: ClassNamesFn;
    children?: React.ReactNode | Array<React.ReactNode>;
    onExited?: () => void;
    onEntered?: () => void;
    drawerClassName?: string;
    drawerMaskClassName?: string;
    mobileUI?: boolean;
    onDragging?: (value: boolean) => void;
}
export interface DrawerState {
}
export declare class Drawer extends React.Component<DrawerProps, DrawerState> {
    static defaultProps: Pick<DrawerProps, 'container' | 'position' | 'size' | 'overlay' | 'showCloseButton'>;
    modalDom: HTMLElement;
    contentDom: HTMLElement;
    isRootClosed: boolean;
    resizer: React.RefObject<HTMLDivElement | null>;
    transitionNodeRef: {
        current: HTMLDivElement | null;
    };
    resizeCoord: number;
    componentDidMount(): void;
    componentDidUpdate(prevProps: DrawerProps): void;
    componentWillUnmount(): void;
    contentRef: (ref: any) => any;
    handleEnter: () => void;
    handleEntered: () => void;
    handleExited: () => void;
    modalRef: (ref: any) => void;
    transitionRef: (ref: HTMLDivElement | null) => void;
    handleRootMouseDownCapture(e: MouseEvent): void;
    handleRootMouseUpCapture(e: MouseEvent): void;
    handleRootMouseUp(e: MouseEvent): void;
    getDrawerStyle(): {
        width?: number | string;
        height?: number | string;
    };
    resizeMouseDown(e: React.MouseEvent<any>): void;
    bindResize(e: any): void;
    removeResize(): void;
    renderResizeCtrl(): React.JSX.Element;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
        container?: any;
        showCloseButton?: boolean | undefined;
        size?: any;
        overlay?: boolean | undefined;
        position?: DrawerPosition | undefined;
    } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<DrawerProps, keyof import("amis-core").ThemeProps>, "width" | "height" | "children" | "disabled" | "onHide" | "closeOnEsc" | "show" | "closeOnOutside" | "onExited" | "onEntered" | "bodyClassName" | "resizable" | "drawerClassName" | "drawerMaskClassName" | "onDragging"> & {
            container?: any;
            showCloseButton?: boolean | undefined;
            size?: any;
            overlay?: boolean | undefined;
            position?: DrawerPosition | undefined;
        } & {} & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof Drawer>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof Drawer, {}> & {
    ComposedComponent: typeof Drawer;
};
export default _default;
