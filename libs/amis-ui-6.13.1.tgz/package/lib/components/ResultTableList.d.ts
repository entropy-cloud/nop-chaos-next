/**
 * 结果表格(暂时不支持结果排序)
 */
import React from 'react';
import { BaseSelection, BaseSelectionProps } from './Selection';
import { Option, Options } from './Select';
export interface ResultTableSelectionProps extends BaseSelectionProps {
    title?: string;
    searchPlaceholder?: string;
    placeholder?: string;
    searchable?: boolean;
    onSearch?: Function;
    columns: Array<{
        name: string;
        label: string;
        [propName: string]: any;
    }>;
    cellRender: (column: {
        name: string;
        label: string;
        [propName: string]: any;
    }, option: Option, colIndex: number, rowIndex: number) => JSX.Element;
}
export interface ResultTableSelectionState {
    tableOptions: Options;
    searching: Boolean;
    searchTableOptions: Options;
}
export declare class BaseResultTableSelection extends BaseSelection<ResultTableSelectionProps, ResultTableSelectionState> {
    static defaultProps: {
        cellRender: (column: {
            name: string;
            label: string;
            [propName: string]: any;
        }, option: Option, colIndex: number, rowIndex: number) => React.JSX.Element;
        placeholder: string;
        itemRender: typeof BaseSelection.itemRender;
        multiple: boolean;
        clearable: boolean;
        virtualThreshold: number;
        itemHeight: number;
    };
    state: ResultTableSelectionState;
    searchRef?: any;
    static getDerivedStateFromProps(props: ResultTableSelectionProps): {
        tableOptions: Options;
    };
    domSearchRef(ref: any): void;
    handleCloseItem(option: Option): void;
    search(inputValue: string): void;
    clearSearch(): void;
    clearInput(): void;
    renderTable(): React.JSX.Element;
    render(): React.JSX.Element;
}
declare const _default: {
    new (props: Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
        multiple?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        clearable?: boolean | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        cellRender?: ((column: {
            name: string;
            label: string;
            [propName: string]: any;
        }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps): {
        ref: any;
        childRef: (ref: any) => void;
        getWrappedInstance: () => any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Omit<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }, keyof import("amis-core").ThemeProps> & import("packages/amis-core/lib/theme").ThemeOuterProps>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<{
        new (props: Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof BaseResultTableSelection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof BaseResultTableSelection, {}> & {
        ComposedComponent: typeof BaseResultTableSelection;
    }>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<{
    new (props: Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
        multiple?: boolean | undefined;
        placeholder?: string | undefined;
        itemHeight?: number | undefined;
        clearable?: boolean | undefined;
        virtualThreshold?: number | undefined;
        itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
        cellRender?: ((column: {
            name: string;
            label: string;
            [propName: string]: any;
        }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
    } & {} & {
        locale?: string;
        translate?: (str: string, ...args: any[]) => string;
    }): {
        ref: any;
        childRef(ref: any): void;
        getWrappedInstance(): any;
        render(): React.JSX.Element;
        context: unknown;
        setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
        forceUpdate(callback?: (() => void) | undefined): void;
        readonly props: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>;
        state: Readonly<{}>;
        componentDidMount?(): void;
        shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): boolean;
        componentWillUnmount?(): void;
        componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
        getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>): any;
        componentDidUpdate?(prevProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, prevState: Readonly<{}>, snapshot?: any): void;
        componentWillMount?(): void;
        UNSAFE_componentWillMount?(): void;
        componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextContext: any): void;
        componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
        UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }>, nextState: Readonly<{}>, nextContext: any): void;
    };
    displayName: string;
    contextType: React.Context<string>;
    ComposedComponent: React.ComponentType<typeof BaseResultTableSelection>;
    propTypes?: any;
} & import("hoist-non-react-statics").NonReactStatics<typeof BaseResultTableSelection, {}> & {
    ComposedComponent: typeof BaseResultTableSelection;
}, {}> & {
    ComposedComponent: {
        new (props: Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
            multiple?: boolean | undefined;
            placeholder?: string | undefined;
            itemHeight?: number | undefined;
            clearable?: boolean | undefined;
            virtualThreshold?: number | undefined;
            itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
            cellRender?: ((column: {
                name: string;
                label: string;
                [propName: string]: any;
            }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
        } & {} & {
            locale?: string;
            translate?: (str: string, ...args: any[]) => string;
        }): {
            ref: any;
            childRef(ref: any): void;
            getWrappedInstance(): any;
            render(): React.JSX.Element;
            context: unknown;
            setState<K extends never>(state: {} | ((prevState: Readonly<{}>, props: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>) => {} | Pick<{}, K> | null) | Pick<{}, K> | null, callback?: (() => void) | undefined): void;
            forceUpdate(callback?: (() => void) | undefined): void;
            readonly props: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>;
            state: Readonly<{}>;
            componentDidMount?(): void;
            shouldComponentUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): boolean;
            componentWillUnmount?(): void;
            componentDidCatch?(error: Error, errorInfo: React.ErrorInfo): void;
            getSnapshotBeforeUpdate?(prevProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>): any;
            componentDidUpdate?(prevProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, prevState: Readonly<{}>, snapshot?: any): void;
            componentWillMount?(): void;
            UNSAFE_componentWillMount?(): void;
            componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            UNSAFE_componentWillReceiveProps?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextContext: any): void;
            componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
            UNSAFE_componentWillUpdate?(nextProps: Readonly<Pick<Omit<ResultTableSelectionProps, keyof import("amis-core").LocaleProps>, "onChange" | "className" | "style" | "value" | "onClick" | "title" | "classPrefix" | "classnames" | "theme" | "mobileUI" | "disabled" | "columns" | "options" | "testIdBuilder" | "inline" | "itemClassName" | "labelClassName" | "labelField" | "valueField" | "searchable" | "checkAll" | "checkAllLabel" | "deferField" | "onDeferLoad" | "onLeftDeferLoad" | "option2value" | "virtualListHeight" | "placeholderRender" | "onSearch" | "searchPlaceholder"> & {
                multiple?: boolean | undefined;
                placeholder?: string | undefined;
                itemHeight?: number | undefined;
                clearable?: boolean | undefined;
                virtualThreshold?: number | undefined;
                itemRender?: ((option: Option, states: import("./Selection").ItemRenderStates) => JSX.Element) | undefined;
                cellRender?: ((column: {
                    name: string;
                    label: string;
                    [propName: string]: any;
                }, option: Option, colIndex: number, rowIndex: number) => JSX.Element) | undefined;
            } & {} & {
                locale?: string;
                translate?: (str: string, ...args: any[]) => string;
            }>, nextState: Readonly<{}>, nextContext: any): void;
        };
        displayName: string;
        contextType: React.Context<string>;
        ComposedComponent: React.ComponentType<typeof BaseResultTableSelection>;
        propTypes?: any;
    } & import("hoist-non-react-statics").NonReactStatics<typeof BaseResultTableSelection, {}> & {
        ComposedComponent: typeof BaseResultTableSelection;
    };
};
export default _default;
